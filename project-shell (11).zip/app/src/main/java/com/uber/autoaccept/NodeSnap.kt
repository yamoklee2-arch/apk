package com.uber.autoaccept

import android.graphics.Rect

data class NodeSnap(
    val r: Rect,
    val cls: String = "",
    val txt: String = "",
    val clk: String = "",
    val act: String = ""
) {
    constructor(text: String, desc: String, cls: String, viewId: String, bounds: Rect, clickable: Boolean) :
            this(bounds, cls, text, desc, if (clickable) "CLICKABLE" else "")

    val text: String get() = txt
    val desc: String get() = clk
    val bounds: Rect get() = r
    val clickable: Boolean get() = act.contains("CLICKABLE") || clk == "true"
    val viewId: String get() = cls
}
