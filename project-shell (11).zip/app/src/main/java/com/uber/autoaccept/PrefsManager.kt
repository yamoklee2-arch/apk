package com.uber.autoaccept

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Rect
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object PrefsManager {
    private const val PREF_NAME = "uber_auto_accept"

    private const val KEY_ACCEPT_ALL = "accept_all"
    private const val KEY_ACCEPT_COUNT = "accept_count"
    private const val KEY_ACCEPT_NO_DELAY = "accept_no_delay"
    private const val KEY_ACCEPT_SCHEDULED = "accept_scheduled"
    private const val KEY_ACCEPT_SCREENSHOT = "accept_screenshot"
    private const val KEY_ACTIVE = "is_active"
    private const val KEY_AIRPORT_MODE = "airport_mode"
    private const val KEY_AUTO_DISMISS = "auto_dismiss"
    private const val KEY_BLACKLIST_MODE = "blacklist_mode"
    private const val KEY_CALL_COUNT = "call_count"
    private const val KEY_DISMISS_COOLDOWN = "dismiss_cooldown_ms"
    private const val KEY_DISMISS_COUNT = "dismiss_count"
    private const val KEY_DISMISS_DIAG = "dismiss_diag"
    private const val KEY_DISMISS_EXECUTED = "dismiss_executed"
    private const val KEY_DISMISS_SCHEDULED = "dismiss_scheduled"
    private const val KEY_EVENT_COUNT = "event_count"
    private const val KEY_FLOATING_BUBBLE = "floating_bubble"
    private const val KEY_HUMAN_MODE = "human_mode"
    private const val KEY_KEYWORDS = "keywords"
    private const val KEY_LAST_ACCEPT_RECT = "last_accept_rect"
    private const val KEY_MAX_DELAY = "max_delay_ms"
    private const val KEY_MICRO_VARIANCE = "micro_variance"
    private const val KEY_MIN_DELAY = "min_delay_ms"
    private const val KEY_OCR_POLL = "ocr_poll"
    private const val KEY_PRESETS = "keyword_presets"
    private const val KEY_SLEEP_ALARM = "sleep_alarm"
    private const val KEY_VIBRATION = "vibration"

    private val gson = Gson()

    private fun prefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    private fun getBool(context: Context, key: String, def: Boolean = false): Boolean {
        return prefs(context).getBoolean(key, def)
    }

    private fun setBool(context: Context, key: String, v: Boolean) {
        prefs(context).edit().putBoolean(key, v).apply()
    }

    private fun getInt(context: Context, key: String, def: Int = 0): Int {
        return prefs(context).getInt(key, def)
    }

    private fun setInt(context: Context, key: String, v: Int) {
        prefs(context).edit().putInt(key, v).apply()
    }

    private fun getLong(context: Context, key: String, def: Long = 0L): Long {
        return prefs(context).getLong(key, def)
    }

    private fun setLong(context: Context, key: String, v: Long) {
        prefs(context).edit().putLong(key, v).apply()
    }

    fun isActive(context: Context): Boolean = getBool(context, KEY_ACTIVE, false)
    fun setActive(context: Context, active: Boolean) = setBool(context, KEY_ACTIVE, active)
    fun saveActive(context: Context, active: Boolean) = setActive(context, active)

    fun isHumanMode(context: Context): Boolean = getBool(context, KEY_HUMAN_MODE, true)
    fun setHumanMode(context: Context, enabled: Boolean) = setBool(context, KEY_HUMAN_MODE, enabled)
    fun saveHumanMode(context: Context, enabled: Boolean) = setHumanMode(context, enabled)

    fun isMicroVariance(context: Context): Boolean = getBool(context, KEY_MICRO_VARIANCE, true)
    fun setMicroVariance(context: Context, enabled: Boolean) = setBool(context, KEY_MICRO_VARIANCE, enabled)
    fun saveMicroVariance(context: Context, enabled: Boolean) = setMicroVariance(context, enabled)

    fun isVibration(context: Context): Boolean = getBool(context, KEY_VIBRATION, true)
    fun setVibration(context: Context, enabled: Boolean) = setBool(context, KEY_VIBRATION, enabled)
    fun saveVibration(context: Context, enabled: Boolean) = setVibration(context, enabled)

    fun isAcceptAll(context: Context): Boolean = getBool(context, KEY_ACCEPT_ALL, false)
    fun setAcceptAll(context: Context, enabled: Boolean) = setBool(context, KEY_ACCEPT_ALL, enabled)
    fun saveAcceptAll(context: Context, enabled: Boolean) = setAcceptAll(context, enabled)

    fun isBlacklistMode(context: Context): Boolean = getBool(context, KEY_BLACKLIST_MODE, false)
    fun setBlacklistMode(context: Context, enabled: Boolean) = setBool(context, KEY_BLACKLIST_MODE, enabled)
    fun saveBlacklistMode(context: Context, enabled: Boolean) = setBlacklistMode(context, enabled)

    fun isAutoDismiss(context: Context): Boolean = getBool(context, KEY_AUTO_DISMISS, false)
    fun setAutoDismiss(context: Context, enabled: Boolean) = setBool(context, KEY_AUTO_DISMISS, enabled)
    fun saveAutoDismiss(context: Context, enabled: Boolean) = setAutoDismiss(context, enabled)

    fun getMinDelay(context: Context): Long = getLong(context, KEY_MIN_DELAY, 750L)
    fun setMinDelay(context: Context, delay: Long) = setLong(context, KEY_MIN_DELAY, delay)
    fun getMinDelayMs(context: Context): Long = getMinDelay(context)
    fun saveMinDelayMs(context: Context, delay: Long) = setMinDelay(context, delay)

    fun getMaxDelay(context: Context): Long = getLong(context, KEY_MAX_DELAY, 3000L)
    fun setMaxDelay(context: Context, delay: Long) = setLong(context, KEY_MAX_DELAY, delay)
    fun getMaxDelayMs(context: Context): Long = getMaxDelay(context)
    fun saveMaxDelayMs(context: Context, delay: Long) = setMaxDelay(context, delay)

    fun getDismissCooldown(context: Context): Int = (getLong(context, KEY_DISMISS_COOLDOWN, 1500L) / 1000L).toInt()
    fun setDismissCooldown(context: Context, cooldownSec: Int) = setLong(context, KEY_DISMISS_COOLDOWN, cooldownSec * 1000L)
    fun getDismissCooldownMs(context: Context): Long = getLong(context, KEY_DISMISS_COOLDOWN, 1500L)
    fun saveDismissCooldownMs(context: Context, cooldown: Long) = setLong(context, KEY_DISMISS_COOLDOWN, cooldown)

    fun isSleepAlarm(context: Context): Boolean = getBool(context, KEY_SLEEP_ALARM, false)
    fun setSleepAlarm(context: Context, enabled: Boolean) = setBool(context, KEY_SLEEP_ALARM, enabled)
    fun saveSleepAlarm(context: Context, enabled: Boolean) = setSleepAlarm(context, enabled)

    fun isAirportMode(context: Context): Boolean = getBool(context, KEY_AIRPORT_MODE, false)
    fun setAirportMode(context: Context, enabled: Boolean) = setBool(context, KEY_AIRPORT_MODE, enabled)
    fun saveAirportMode(context: Context, enabled: Boolean) = setAirportMode(context, enabled)

    fun isAcceptNoDelay(context: Context): Boolean = getBool(context, KEY_ACCEPT_NO_DELAY, false)
    fun setAcceptNoDelay(context: Context, enabled: Boolean) = setBool(context, KEY_ACCEPT_NO_DELAY, enabled)
    fun saveAcceptNoDelay(context: Context, enabled: Boolean) = setAcceptNoDelay(context, enabled)

    fun isFloatingBubble(context: Context): Boolean = getBool(context, KEY_FLOATING_BUBBLE, false)
    fun setFloatingBubble(context: Context, enabled: Boolean) = setBool(context, KEY_FLOATING_BUBBLE, enabled)
    fun saveFloatingBubble(context: Context, enabled: Boolean) = setFloatingBubble(context, enabled)

    fun isAcceptScreenshot(context: Context): Boolean = getBool(context, KEY_ACCEPT_SCREENSHOT, false)
    fun setAcceptScreenshot(context: Context, enabled: Boolean) = setBool(context, KEY_ACCEPT_SCREENSHOT, enabled)
    fun saveAcceptScreenshot(context: Context, enabled: Boolean) = setAcceptScreenshot(context, enabled)

    fun isOcrPoll(context: Context): Boolean = getBool(context, KEY_OCR_POLL, false)
    fun setOcrPoll(context: Context, enabled: Boolean) = setBool(context, KEY_OCR_POLL, enabled)
    fun saveOcrPoll(context: Context, enabled: Boolean) = setOcrPoll(context, enabled)

    fun getKeywords(context: Context): MutableList<String> {
        val json = prefs(context).getString(KEY_KEYWORDS, null) ?: return mutableListOf()
        return try {
            val type = object : TypeToken<MutableList<String>>() {}.type
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (_: Exception) {
            mutableListOf()
        }
    }

    fun saveKeywords(context: Context, keywords: List<String>) {
        prefs(context).edit().putString(KEY_KEYWORDS, gson.toJson(keywords)).apply()
    }

    fun getPresets(context: Context): MutableList<KeywordPreset> {
        val json = prefs(context).getString(KEY_PRESETS, null) ?: return mutableListOf()
        return try {
            val type = object : TypeToken<MutableList<KeywordPreset>>() {}.type
            gson.fromJson(json, type) ?: mutableListOf()
        } catch (_: Exception) {
            mutableListOf()
        }
    }

    fun savePresets(context: Context, presets: List<KeywordPreset>) {
        prefs(context).edit().putString(KEY_PRESETS, gson.toJson(presets)).apply()
    }

    fun getAcceptCount(context: Context): Int = getInt(context, KEY_ACCEPT_COUNT, 0)
    fun incrementAcceptCount(context: Context, source: String = "PrefsManager") {
        val next = getAcceptCount(context) + 1
        LogBuffer.diag(context, "ACCEPT-COUNT", "source=$source, incrementAcceptCount -> $next")
        setInt(context, KEY_ACCEPT_COUNT, next)
    }

    fun getEventCount(context: Context): Int = getInt(context, KEY_EVENT_COUNT, 0)
    fun incrementEventCount(context: Context, delta: Int = 1) = setInt(context, KEY_EVENT_COUNT, getEventCount(context) + delta)

    fun getCallCount(context: Context): Int = getInt(context, KEY_CALL_COUNT, 0)
    fun incrementCallCount(context: Context) = setInt(context, KEY_CALL_COUNT, getCallCount(context) + 1)

    fun getDismissCount(context: Context): Int = getInt(context, KEY_DISMISS_COUNT, 0)
    fun incrementDismissCount(context: Context, source: String = "PrefsManager") {
        val next = getDismissCount(context) + 1
        LogBuffer.diag(context, "DISMISS-COUNT", "source=$source, incrementDismissCount -> $next")
        setInt(context, KEY_DISMISS_COUNT, next)
    }

    fun getAcceptScheduled(context: Context): Int = getInt(context, KEY_ACCEPT_SCHEDULED, 0)
    fun incrementAcceptScheduled(context: Context, source: String = "PrefsManager") {
        val next = getAcceptScheduled(context) + 1
        LogBuffer.diag(context, "ACCEPT-COUNT", "source=$source, incrementAcceptScheduled -> $next")
        setInt(context, KEY_ACCEPT_SCHEDULED, next)
    }

    fun getDismissScheduled(context: Context): Int = getInt(context, KEY_DISMISS_SCHEDULED, 0)
    fun incrementDismissScheduled(context: Context, source: String = "PrefsManager") {
        val next = getDismissScheduled(context) + 1
        LogBuffer.diag(context, "DISMISS-COUNT", "source=$source, incrementDismissScheduled -> $next")
        setInt(context, KEY_DISMISS_SCHEDULED, next)
    }

    fun getDismissExecuted(context: Context): Int = getInt(context, KEY_DISMISS_EXECUTED, 0)
    fun incrementDismissExecuted(context: Context, source: String = "PrefsManager") {
        val next = getDismissExecuted(context) + 1
        LogBuffer.diag(context, "DISMISS-COUNT", "source=$source, incrementDismissExecuted -> $next")
        setInt(context, KEY_DISMISS_EXECUTED, next)
    }

    fun saveDismissDiag(context: Context, diag: String) {
        prefs(context).edit().putString(KEY_DISMISS_DIAG, diag).apply()
    }

    fun getDismissDiag(context: Context): String {
        return prefs(context).getString(KEY_DISMISS_DIAG, "") ?: ""
    }

    fun loadLastAcceptRect(context: Context): Rect? {
        val s = prefs(context).getString(KEY_LAST_ACCEPT_RECT, null) ?: return null
        return try {
            val parts = s.split(",")
            if (parts.size != 4) return null
            Rect(
                parts[0].trim().toInt(),
                parts[1].trim().toInt(),
                parts[2].trim().toInt(),
                parts[3].trim().toInt()
            )
        } catch (_: Exception) {
            null
        }
    }

    fun saveLastAcceptRect(context: Context, rect: Rect) {
        saveLastAcceptRect(context, rect.left, rect.top, rect.right, rect.bottom)
    }

    fun saveLastAcceptRect(context: Context, left: Int, top: Int, right: Int, bottom: Int) {
        prefs(context).edit().putString(KEY_LAST_ACCEPT_RECT, "$left,$top,$right,$bottom").apply()
    }

    fun getLastAcceptRectString(context: Context): String {
        return prefs(context).getString(KEY_LAST_ACCEPT_RECT, "미설정") ?: "미설정"
    }

    fun resetStats(context: Context) {
        resetCounts(context)
    }

    fun resetCounts(context: Context) {
        prefs(context).edit()
            .putInt(KEY_ACCEPT_COUNT, 0)
            .putInt(KEY_EVENT_COUNT, 0)
            .putInt(KEY_CALL_COUNT, 0)
            .putInt(KEY_DISMISS_COUNT, 0)
            .putInt(KEY_ACCEPT_SCHEDULED, 0)
            .putInt(KEY_DISMISS_SCHEDULED, 0)
            .putInt(KEY_DISMISS_EXECUTED, 0)
            .remove(KEY_LAST_ACCEPT_RECT)
            .remove(KEY_DISMISS_DIAG)
            .apply()
    }

    fun calculateDelay(context: Context): Long {
        if (!isHumanMode(context)) {
            return 0L
        }
        val min = getMinDelayMs(context).toDouble()
        val max = getMaxDelayMs(context).toDouble()
        val mean = (min + max) / 2.0
        val stddev = (max - min) / 6.0
        var delay = gaussianRandom(mean, stddev)
        if (isMicroVariance(context)) {
            val variance = 0.15 * stddev * ((Math.random() * 2.0) - 1.0)
            delay += variance
        }
        return delay.toLong().coerceIn(min.toLong(), max.toLong())
    }

    private fun gaussianRandom(mean: Double, stddev: Double): Double {
        var u = 0.0
        while (u == 0.0) {
            u = Math.random()
        }
        var v = 0.0
        while (v == 0.0) {
            v = Math.random()
        }
        val z = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v)
        return (z * stddev) + mean
    }
}
