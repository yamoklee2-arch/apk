package com.uber.autoaccept

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

object LogBuffer {
    private const val LOG_FILE = "diagnostic_log.txt"
    private const val MAX_BYTES = 3000000L
    private val lock = Any()
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
    private val logExecutor = Executors.newSingleThreadExecutor()
    private val memoryLogs = mutableListOf<String>()
    private val listeners = mutableListOf<(String) -> Unit>()

    @JvmStatic
    fun addListener(listener: (String) -> Unit) {
        synchronized(lock) {
            listeners.add(listener)
        }
    }

    @JvmStatic
    fun removeListener(listener: (String) -> Unit) {
        synchronized(lock) {
            listeners.remove(listener)
        }
    }

    @JvmStatic
    fun diag(context: Context?, event: String, details: String) {
        val timeStr = fmt.format(Date())
        val line = "[$timeStr] [$event] $details"
        logInternal(context, line)
    }

    @JvmStatic
    fun log(context: Context?, tag: String, message: String) {
        if (message.isEmpty()) return
        val timeStr = fmt.format(Date())
        val line = "[$timeStr] [$tag] $message"
        logInternal(context, line)
    }

    private fun logInternal(context: Context?, line: String) {
        val listenersCopy = synchronized(lock) {
            if (memoryLogs.size > 1000) {
                memoryLogs.removeAt(0)
            }
            memoryLogs.add(line)
            ArrayList(listeners)
        }
        for (l in listenersCopy) {
            try {
                l.invoke(line)
            } catch (_: Throwable) {
            }
        }
        if (context == null) return
        logExecutor.execute {
            synchronized(lock) {
                try {
                    val file = File(context.filesDir, LOG_FILE)
                    val parentFile = file.parentFile
                    if (parentFile != null && !parentFile.exists()) {
                        parentFile.mkdirs()
                    }
                    if (!file.exists()) {
                        file.createNewFile()
                    }
                    if (file.length() > MAX_BYTES) {
                        val text = file.readText()
                        val half = text.substring(text.length / 2)
                        file.writeText(half)
                    }
                    file.appendText("$line\n")
                } catch (e: Exception) {
                    Log.e("LogBuffer", "LogBuffer 파일 쓰기 에러: ${e.javaClass.simpleName} - ${e.message}")
                }
            }
        }
    }

    @JvmStatic
    fun read(context: Context): String {
        return try {
            val file = File(context.filesDir, LOG_FILE)
            if (file.exists()) file.readText() else {
                synchronized(lock) {
                    memoryLogs.joinToString("\n")
                }
            }
        } catch (e: Exception) {
            synchronized(lock) {
                memoryLogs.joinToString("\n")
            }
        }
    }

    @JvmStatic
    fun getAll(context: Context? = null): List<String> {
        if (context != null) {
            val fileText = read(context)
            if (fileText.isNotEmpty()) {
                return fileText.lines().filter { it.isNotBlank() }
            }
        }
        synchronized(lock) {
            return ArrayList(memoryLogs)
        }
    }

    @JvmStatic
    fun getRecentLines(count: Int = 100): List<String> {
        synchronized(lock) {
            val size = memoryLogs.size
            return if (size <= count) {
                ArrayList(memoryLogs)
            } else {
                ArrayList(memoryLogs.subList(size - count, size))
            }
        }
    }

    @JvmStatic
    fun clear(context: Context) {
        val timeStr = fmt.format(Date())
        val resetLine = "[$timeStr] [DIAG-RESET] 진단 로그가 초기화되었습니다."
        val listenersCopy = synchronized(lock) {
            memoryLogs.clear()
            memoryLogs.add(resetLine)
            try {
                val file = File(context.filesDir, LOG_FILE)
                if (file.exists()) file.delete()
                file.writeText("$resetLine\n")
            } catch (_: Exception) {
            }
            ArrayList(listeners)
        }
        for (l in listenersCopy) {
            try {
                l.invoke(resetLine)
            } catch (_: Throwable) {
            }
        }
    }
}
