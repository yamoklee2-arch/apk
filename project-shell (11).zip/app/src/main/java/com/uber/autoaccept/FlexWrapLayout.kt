package com.uber.autoaccept

import android.content.Context
import android.view.View
import android.view.ViewGroup

class FlexWrapLayout(context: Context) : ViewGroup(context) {

    private val gap: Int = (8 * resources.displayMetrics.density).toInt()

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val maxWidth = MeasureSpec.getSize(widthSpec)
        var x = 0
        var y = 0
        var rowH = 0

        val count = childCount
        for (i in 0 until count) {
            val child = getChildAt(i)
            child.measure(0, 0)

            if (child.measuredWidth + x > maxWidth && x > 0) {
                x = 0
                y += gap + rowH
                rowH = 0
            }

            x += child.measuredWidth + gap
            rowH = maxOf(rowH, child.measuredHeight)
        }

        val totalHeight = y + rowH
        setMeasuredDimension(maxWidth, totalHeight + gap)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val maxWidth = r - l
        var x = 0
        var y = 0
        var rowH = 0

        val count = childCount
        for (i in 0 until count) {
            val child = getChildAt(i)
            if (child.measuredWidth + x > maxWidth && x > 0) {
                x = 0
                y += gap + rowH
                rowH = 0
            }
            child.layout(x, y, child.measuredWidth + x, child.measuredHeight + y)
            x += child.measuredWidth + gap
            rowH = maxOf(rowH, child.measuredHeight)
        }
    }
}
