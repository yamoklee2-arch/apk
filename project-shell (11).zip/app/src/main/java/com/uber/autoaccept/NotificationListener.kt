package com.uber.autoaccept

import android.content.Context
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import androidx.core.app.NotificationCompat

class NotificationListener : NotificationListenerService() {

    companion object {
        private const val TAG = "UberAutoAccept"
        private const val TTL_MS = 30000L
        private const val UBER_PKG = "com.ubercab.driver"

        @Volatile
        var lastCallText: String = ""
        @Volatile
        private var lastCallTextTime: Long = 0L

        fun getRecentCallText(): String {
            return if (System.currentTimeMillis() - lastCallTextTime < TTL_MS) lastCallText else ""
        }

        fun isEnabled(context: Context): Boolean {
            val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners") ?: return false
            return flat.contains(context.packageName)
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (sbn.packageName == UBER_PKG) {
            val extras = sbn.notification?.extras ?: return
            val title = extras.getCharSequence(NotificationCompat.EXTRA_TITLE)?.toString() ?: ""
            val text = extras.getCharSequence(NotificationCompat.EXTRA_TEXT)?.toString() ?: ""
            val bigText = extras.getCharSequence(NotificationCompat.EXTRA_BIG_TEXT)?.toString() ?: ""

            val list = listOf(title, text, bigText).filter { it.isNotBlank() }
            val combined = list.joinToString(" ")
            if (combined.isNotBlank()) {
                lastCallText = combined
                lastCallTextTime = System.currentTimeMillis()
                Log.d(TAG, "Uber 알림 감지: $combined")
            }
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn != null && sbn.packageName == UBER_PKG) {
            Log.d(TAG, "Uber 알림 제거됨")
        }
    }
}
