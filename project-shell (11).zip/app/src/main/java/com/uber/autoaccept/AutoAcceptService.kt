package com.uber.autoaccept

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.util.Log
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.io.File
import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class AutoAcceptService : AccessibilityService() {

    companion object {
        const val TAG = "AutoAcceptService"
        const val UBER_PKG = "com.ubercab.driver"
        private const val NOTIF_CHANNEL_ID = "uber_auto_accept_fg"
        private const val NOTIF_ID = 1001

        @Volatile
        var isRunning = false
            private set

        private var activeMediaPlayer: MediaPlayer? = null

        @JvmStatic
        fun stopSleepAlarm(context: Context? = null) {
            try {
                activeMediaPlayer?.let {
                    if (it.isPlaying) {
                        it.stop()
                    }
                    it.release()
                }
            } catch (_: Exception) {}
            activeMediaPlayer = null
            if (context != null) {
                LogBuffer.diag(context, "SLEEP-ALARM", "수면 알람 정지됨")
            }
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val ocrExecutor = Executors.newSingleThreadExecutor()
    private val isOcrProcessing = AtomicBoolean(false)
    private var lastOcrPollTime = 0L
    private var lastDismissTime = 0L
    private var lastAcceptTime = 0L

    private val ocrPollRunnable = object : Runnable {
        override fun run() {
            if (isRunning && PrefsManager.isActive(this@AutoAcceptService) && PrefsManager.isOcrPoll(this@AutoAcceptService)) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastOcrPollTime >= 1000L && !isOcrProcessing.get()) {
                    lastOcrPollTime = now
                    triggerOcrScan("POLL")
                }
            }
            mainHandler.postDelayed(this, 1000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        try {
            isRunning = true
            LogBuffer.diag(this, "SERVICE", "접근성 서비스 연결됨 (ONLINE)")
            showServiceNotification()
            mainHandler.post(ocrPollRunnable)
        } catch (e: Throwable) {
            Log.e(TAG, "onServiceConnected error: ${e.message}", e)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        stopSleepAlarm(this)
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(NOTIF_ID)
        } catch (_: Throwable) {}
        mainHandler.removeCallbacksAndMessages(null)
        LogBuffer.diag(this, "SERVICE", "접근성 서비스 종료됨 (OFFLINE)")
    }

    private fun showServiceNotification() {
        try {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    NOTIF_CHANNEL_ID,
                    "스마트알람 자동수락 서비스",
                    NotificationManager.IMPORTANCE_LOW
                )
                nm.createNotificationChannel(channel)
            }

            val notification: Notification = NotificationCompat.Builder(this, NOTIF_CHANNEL_ID)
                .setContentTitle("NEXUS 스마트알람 실행중")
                .setContentText("Uber 콜 모니터링 및 자동 수락 대기중")
                .setSmallIcon(R.drawable.bubble_icon)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .build()

            nm.notify(NOTIF_ID, notification)
        } catch (e: Throwable) {
            Log.e(TAG, "알림 표시 실패 (서비스는 정상 지속됨): ${e.message}")
        }
    }

    override fun onInterrupt() {
        LogBuffer.diag(this, "SERVICE", "접근성 서비스 인터럽트")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (!PrefsManager.isActive(this)) return

        val pkg = event.packageName?.toString() ?: return
        if (pkg != UBER_PKG && !pkg.contains("uber", ignoreCase = true)) {
            return
        }

        PrefsManager.incrementEventCount(this)
        val eventType = event.eventType
        if (eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
            eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            eventType == AccessibilityEvent.TYPE_VIEW_CLICKED ||
            eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED
        ) {
            processAccessibilityTree()
        }
    }

    private fun processAccessibilityTree() {
        val rootNode = rootInActiveWindow ?: return
        val nodes = mutableListOf<NodeSnap>()
        traverseNode(rootNode, nodes)

        val fullText = nodes.joinToString(" ") { it.text }
        if (fullText.isBlank()) return

        val notifText = NotificationListener.getRecentCallText()
        val combinedText = if (notifText.isNotBlank()) "$fullText $notifText" else fullText

        // Check if Uber call card is detected
        val isCallCard = isUberCallScreen(combinedText, nodes)
        if (!isCallCard) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastAcceptTime < 2500L) return

        PrefsManager.incrementCallCount(this)
        LogBuffer.diag(this, "CALL-DETECTED", "콜 감지됨! 텍스트=[${combinedText.take(60)}...]")

        val keywords = PrefsManager.getKeywords(this)
        val acceptAll = PrefsManager.isAcceptAll(this)
        val isBlacklist = PrefsManager.isBlacklistMode(this)

        var matched = false
        var matchedKw = ""
        if (acceptAll) {
            matched = true
            matchedKw = "[무조건 수락]"
        } else if (keywords.isNotEmpty()) {
            for (kw in keywords) {
                if (kw.isNotBlank() && combinedText.contains(kw, ignoreCase = true)) {
                    matched = true
                    matchedKw = kw
                    break
                }
            }
            if (isBlacklist) {
                matched = !matched
                matchedKw = if (matched) "[블랙리스트 통과]" else "[블랙리스트 차단: $matchedKw]"
            }
        }

        if (matched) {
            lastAcceptTime = now
            PrefsManager.incrementAcceptScheduled(this, "TreeMatch")
            LogBuffer.diag(this, "ACCEPT-MATCH", "키워드 매칭 성공: $matchedKw -> 수락 실행")
            executeAccept(nodes)
        } else {
            LogBuffer.diag(this, "CALL-MISMATCH", "키워드 불일치 (조건 안 맞음)")
            if (PrefsManager.isAutoDismiss(this)) {
                if (now - lastDismissTime > PrefsManager.getDismissCooldownMs(this)) {
                    lastDismissTime = now
                    PrefsManager.incrementDismissScheduled(this, "TreeMismatch")
                    executeDismiss(nodes)
                }
            }
        }
    }

    private fun isUberCallScreen(text: String, nodes: List<NodeSnap>): Boolean {
        if (text.contains("수락") || text.contains("Accept") ||
            text.contains("원") || text.contains("KRW") || text.contains("₩") ||
            text.contains("분") || text.contains("km") || text.contains("승객")
        ) {
            return true
        }
        for (n in nodes) {
            if (n.clickable && (n.text.contains("수락") || n.desc.contains("수락"))) {
                return true
            }
        }
        return false
    }

    private fun traverseNode(node: AccessibilityNodeInfo?, list: MutableList<NodeSnap>) {
        if (node == null) return
        val r = Rect()
        node.getBoundsInScreen(r)
        val text = node.text?.toString() ?: ""
        val desc = node.contentDescription?.toString() ?: ""
        val cls = node.className?.toString() ?: ""
        val viewId = node.viewIdResourceName ?: ""
        val clickable = node.isClickable

        list.add(NodeSnap(text, desc, cls, viewId, r, clickable))

        val count = node.childCount
        for (i in 0 until count) {
            val child = node.getChild(i) ?: continue
            traverseNode(child, list)
        }
    }

    private fun executeAccept(nodes: List<NodeSnap>) {
        val delay = if (PrefsManager.isAcceptNoDelay(this)) 0L else PrefsManager.calculateDelay(this)
        LogBuffer.diag(this, "ACCEPT-SCHEDULED", "수락 대기 시간: ${delay}ms")

        mainHandler.postDelayed({
            var clicked = false
            // Find accept button in nodes
            for (n in nodes) {
                if (n.clickable && (n.text.contains("수락") || n.desc.contains("수락") || n.viewId.contains("accept", ignoreCase = true))) {
                    val cx = n.bounds.centerX()
                    val cy = n.bounds.centerY()
                    PrefsManager.saveLastAcceptRect(this, n.bounds)
                    performClick(cx, cy)
                    clicked = true
                    LogBuffer.diag(this, "ACCEPT-CLICK", "수락 노드 탭: ($cx, $cy)")
                    break
                }
            }

            if (!clicked) {
                // Fallback to saved accept rect or screen lower area
                val savedRect = PrefsManager.loadLastAcceptRect(this)
                if (savedRect != null && !savedRect.isEmpty) {
                    val cx = savedRect.centerX()
                    val cy = savedRect.centerY()
                    performClick(cx, cy)
                    LogBuffer.diag(this, "ACCEPT-FALLBACK", "저장된 수락 위치 탭: ($cx, $cy)")
                } else {
                    val dm = resources.displayMetrics
                    val cx = dm.widthPixels / 2
                    val cy = (dm.heightPixels * 0.78).toInt()
                    performClick(cx, cy)
                    LogBuffer.diag(this, "ACCEPT-DEFAULT", "기본 하단 수락 위치 탭: ($cx, $cy)")
                }
            }

            PrefsManager.incrementAcceptCount(this, "ExecuteAccept")
            triggerVibration()
            triggerSleepAlarm()
            if (PrefsManager.isAcceptScreenshot(this)) {
                takeAcceptScreenshot()
            }
            sendBroadcast(Intent("com.uber.autoaccept.CALL_ACCEPTED"))
        }, delay)
    }

    private fun executeDismiss(nodes: List<NodeSnap>) {
        val dm = resources.displayMetrics
        val screenWidth = dm.widthPixels
        val screenHeight = dm.heightPixels

        var dismissNode: NodeSnap? = null
        for (n in nodes) {
            if (XCoordinateValidator.isValidXButton(n.bounds.left, n.bounds.top, n.bounds.right, n.bounds.bottom, screenWidth, screenHeight)) {
                dismissNode = n
                break
            }
        }

        if (dismissNode != null) {
            val cx = dismissNode.bounds.centerX()
            val cy = dismissNode.bounds.centerY()
            performClick(cx, cy)
            PrefsManager.incrementDismissExecuted(this, "NodeX")
            LogBuffer.diag(this, "DISMISS-EXEC", "거절 X 버튼 노드 탭: ($cx, $cy)")
        } else {
            val topQuarter = screenHeight / 4
            val xRange = (screenWidth * 0.02).toInt()..(screenWidth * 0.25).toInt()
            val xCandidates = nodes.filter { it.bounds.centerY() in 0..topQuarter && it.bounds.centerX() in xRange && it.clickable }
            if (xCandidates.isNotEmpty()) {
                val candidate = xCandidates.first()
                val cx = candidate.bounds.centerX()
                val cy = candidate.bounds.centerY()
                performClick(cx, cy)
                PrefsManager.incrementDismissExecuted(this, "FallbackCandidate")
                LogBuffer.diag(this, "DISMISS-EXEC", "상단 좌측 후보 노드 탭: ($cx, $cy)")
            } else {
                val cx = (screenWidth * 0.12).toInt()
                val cy = (screenHeight * 0.08).toInt()
                performClick(cx, cy)
                PrefsManager.incrementDismissExecuted(this, "DefaultCoord")
                LogBuffer.diag(this, "DISMISS-EXEC", "기본 X 좌표 탭: ($cx, $cy)")
            }
        }
    }

    private fun performClick(x: Int, y: Int) {
        // Try Shizuku first for ultra-fast input
        val isShizukuReady = try {
            Shizuku.pingBinder() && Shizuku.checkSelfPermission() == 0
        } catch (_: Throwable) {
            false
        }
        if (isShizukuReady) {
            try {
                val command = "input tap $x $y\n"
                val method = Shizuku::class.java.getDeclaredMethod(
                    "newProcess",
                    Array<String>::class.java,
                    Array<String>::class.java,
                    String::class.java
                )
                method.isAccessible = true
                val process = method.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
                process.waitFor()
                LogBuffer.diag(this, "TOUCH-SHIZUKU", "Shizuku 터치 성공: ($x, $y)")
                return
            } catch (e: Exception) {
                LogBuffer.diag(this, "TOUCH-SHIZUKU-ERR", "Shizuku 터치 실패, 제스처로 대체: ${e.message}")
            }
        }

        // Gesture fallback
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val path = Path().apply {
                moveTo(x.toFloat(), y.toFloat())
            }
            val stroke = GestureDescription.StrokeDescription(path, 0, 50)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    super.onCompleted(gestureDescription)
                    LogBuffer.diag(this@AutoAcceptService, "TOUCH-GESTURE", "접근성 제스처 터치 완료: ($x, $y)")
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    super.onCancelled(gestureDescription)
                    LogBuffer.diag(this@AutoAcceptService, "TOUCH-GESTURE-CANCEL", "접근성 제스처 취소됨")
                }
            }, null)
        }
    }

    private fun triggerOcrScan(source: String) {
        if (isOcrProcessing.getAndSet(true)) return
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            isOcrProcessing.set(false)
            return
        }

        takeScreenshot(Display.DEFAULT_DISPLAY, ocrExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(screenshotResult: ScreenshotResult) {
                try {
                    val hwBuffer = screenshotResult.hardwareBuffer
                    val colorSpace = screenshotResult.colorSpace
                    val bmp = Bitmap.wrapHardwareBuffer(hwBuffer, colorSpace)
                    hwBuffer.close()

                    if (bmp != null) {
                        val copyBmp = bmp.copy(Bitmap.Config.ARGB_8888, false)
                        bmp.recycle()
                        if (copyBmp != null) {
                            runMlKitOcr(copyBmp, source)
                            return
                        }
                    }
                } catch (e: Exception) {
                    LogBuffer.diag(this@AutoAcceptService, "OCR-SCREENSHOT-ERR", "스크린샷 변환 에러: ${e.message}")
                }
                isOcrProcessing.set(false)
            }

            override fun onFailure(errorCode: Int) {
                isOcrProcessing.set(false)
            }
        })
    }

    private fun runMlKitOcr(bitmap: Bitmap, source: String) {
        val recognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        val inputImage = InputImage.fromBitmap(bitmap, 0)

        recognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                bitmap.recycle()
                isOcrProcessing.set(false)
                val fullText = visionText.text
                if (fullText.isNotBlank() && (fullText.contains("수락") || fullText.contains("원") || fullText.contains("km"))) {
                    LogBuffer.diag(this, "OCR-MATCH", "[$source] OCR 텍스트 인식: ${fullText.replace("\n", " ").take(60)}")
                    processOcrResult(fullText)
                }
            }
            .addOnFailureListener { e ->
                bitmap.recycle()
                isOcrProcessing.set(false)
                LogBuffer.diag(this, "OCR-ERR", "OCR 실패: ${e.message}")
                MlKitComprehensiveDiagnostics.runComprehensiveDiagnostic(this, e)
            }
    }

    private fun processOcrResult(ocrText: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastAcceptTime < 2500L) return

        val keywords = PrefsManager.getKeywords(this)
        val acceptAll = PrefsManager.isAcceptAll(this)

        var matched = false
        var matchedKw = ""
        if (acceptAll) {
            matched = true
            matchedKw = "[무조건 수락]"
        } else {
            for (kw in keywords) {
                if (kw.isNotBlank() && ocrText.contains(kw, ignoreCase = true)) {
                    matched = true
                    matchedKw = kw
                    break
                }
            }
        }

        if (matched) {
            lastAcceptTime = now
            PrefsManager.incrementAcceptScheduled(this, "OcrMatch")
            LogBuffer.diag(this, "OCR-ACCEPT", "OCR 키워드 매칭 성공: $matchedKw -> 수락")
            executeAccept(emptyList())
        }
    }

    private fun triggerVibration() {
        if (!PrefsManager.isVibration(this)) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                val vib = vm.defaultVibrator
                vib.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val vib = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vib.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    vib.vibrate(300)
                }
            }
        } catch (_: Exception) {}
    }

    private fun triggerSleepAlarm() {
        if (!PrefsManager.isSleepAlarm(this)) return
        try {
            stopSleepAlarm(this)
            val alertUri: Uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            val mp = MediaPlayer().apply {
                setDataSource(this@AutoAcceptService, alertUri)
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                isLooping = true
                prepare()
                start()
            }
            activeMediaPlayer = mp
            LogBuffer.diag(this, "SLEEP-ALARM", "수면 알람 재생 시작됨 (무한 루프)")
        } catch (e: Exception) {
            LogBuffer.diag(this, "SLEEP-ALARM-ERR", "알람 재생 실패: ${e.message}")
        }
    }

    private fun takeAcceptScreenshot() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        takeScreenshot(Display.DEFAULT_DISPLAY, ocrExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(screenshotResult: ScreenshotResult) {
                try {
                    val hwBuffer = screenshotResult.hardwareBuffer
                    val colorSpace = screenshotResult.colorSpace
                    val bmp = Bitmap.wrapHardwareBuffer(hwBuffer, colorSpace)
                    hwBuffer.close()

                    if (bmp != null) {
                        val copyBmp = bmp.copy(Bitmap.Config.ARGB_8888, false)
                        bmp.recycle()
                        if (copyBmp != null) {
                            saveBitmapToGallery(copyBmp)
                        }
                    }
                } catch (e: Exception) {
                    LogBuffer.diag(this@AutoAcceptService, "SCREENSHOT-ERR", "캡처 저장 실패: ${e.message}")
                }
            }

            override fun onFailure(errorCode: Int) {
                LogBuffer.diag(this@AutoAcceptService, "SCREENSHOT-FAIL", "캡처 실패 코드: $errorCode")
            }
        })
    }

    private fun saveBitmapToGallery(bmp: Bitmap) {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val filename = "Uber_Accept_$timestamp.jpg"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/UberAutoAccept")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { os ->
                    bmp.compress(Bitmap.CompressFormat.JPEG, 90, os)
                }
                cv.clear()
                cv.put(MediaStore.Images.Media.IS_PENDING, 0)
                contentResolver.update(uri, cv, null, null)
                LogBuffer.diag(this, "SCREENSHOT-SAVED", "수락 스크린샷 갤러리 저장 완료: $filename")
            }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "UberAutoAccept")
            if (!dir.exists()) dir.mkdirs()
            val file = File(dir, filename)
            file.outputStream().use { os ->
                bmp.compress(Bitmap.CompressFormat.JPEG, 90, os)
            }
            LogBuffer.diag(this, "SCREENSHOT-SAVED", "수락 스크린샷 저장 완료: ${file.absolutePath}")
        }
        bmp.recycle()
    }
}
