package com.uber.autoaccept

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.NotificationCompat

class FloatingBubbleService : Service() {

    private var bubbleView: ImageView? = null
    private val watchdogHandler = Handler(Looper.getMainLooper())
    private var windowManager: WindowManager? = null

    private val watchdogRunnable = object : Runnable {
        private var lastAlertTime = 0L
        override fun run() {
            if (!isAccessibilityServiceEnabled()) {
                val now = System.currentTimeMillis()
                if (now - lastAlertTime > 300000) {
                    lastAlertTime = now
                    showWatchdogNotification()
                }
            }
            watchdogHandler.postDelayed(this, 60000L)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
        watchdogHandler.postDelayed(watchdogRunnable, 60000L)
    }

    private fun showBubble() {
        val size = dp(120)
        val imageView = ImageView(this).apply {
            setImageResource(R.drawable.bubble_icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            size,
            size,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = android.view.Gravity.TOP or android.view.Gravity.START
            x = dp(10)
            y = dp(90)
        }

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        imageView.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (Math.abs(dx) > 8 || Math.abs(dy) > 8) {
                        isDragging = true
                    }
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager?.updateViewLayout(imageView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        val touchYRatio = event.y / v.height.toFloat()
                        if (touchYRatio < 0.28f) {
                            PrefsManager.saveFloatingBubble(this, false)
                            stopSelf()
                        } else {
                            val intent = Intent(this, Class.forName("com.uber.autoaccept.MainActivity")).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                            }
                            startActivity(intent)
                        }
                    }
                    true
                }
                else -> false
            }
        }

        windowManager?.addView(imageView, params)
        bubbleView = imageView
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val componentName = "$packageName/${"com.uber.autoaccept.AutoAcceptService"}"
        val enabledServices = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return enabledServices.split(":").any { it.equals(componentName, ignoreCase = true) }
    }

    private fun showWatchdogNotification() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "watchdog_ch"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(channelId, "접근성 상태 경고", NotificationManager.IMPORTANCE_HIGH)
            nm.createNotificationChannel(ch)
        }

        val intent = Intent(this, Class.forName("com.uber.autoaccept.MainActivity")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pi = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notif = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.bubble_icon)
            .setContentTitle("자동 수락 비활성화됨")
            .setContentText("접근성 서비스가 꺼져 있습니다. 다시 켜주세요.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()

        nm.notify(9001, notif)
    }

    override fun onDestroy() {
        super.onDestroy()
        watchdogHandler.removeCallbacksAndMessages(null)
        bubbleView?.let {
            try {
                windowManager?.removeView(it)
            } catch (e: Exception) {
            }
        }
        bubbleView = null
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
