package com.uber.autoaccept

import android.app.ActivityManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import rikka.shizuku.Shizuku
import java.io.File

class MainActivity : AppCompatActivity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val handler = Handler(Looper.getMainLooper())
    private val keywords = mutableListOf<String>()
    private val presets = mutableListOf<KeywordPreset>()

    private val shizukuPermissionCode = 1001

    private lateinit var adapter: KeywordAdapter
    private lateinit var presetAdapter: PresetAdapter

    // Top Header
    private lateinit var tvStatusBadge: TextView

    // Bottom Navigation & Tabs
    private var currentTab = 0
    private lateinit var tabViews: List<ScrollView>
    private lateinit var navButtons: List<LinearLayout>
    private lateinit var navTexts: List<TextView>
    private lateinit var navIcons: List<TextView>

    // Tab 1: 자동수락 (Auto Accept)
    private lateinit var tvCallCount: TextView
    private lateinit var tvAcceptScheduled: TextView
    private lateinit var tvDismissScheduled: TextView
    private lateinit var tvAcceptButtonStatus: TextView
    private lateinit var btnResetStats: TextView

    private lateinit var btnToggleActive: Button
    private lateinit var btnToggleAcceptAll: Button
    private lateinit var btnToggleAutoDismiss: Button
    private lateinit var btnToggleAcceptScreenshot: Button
    private lateinit var btnToggleSleepAlarm: Button

    private lateinit var btnLogClear: Button
    private lateinit var btnLogShare: Button
    private lateinit var btnLogSave: Button
    private lateinit var tvLogStream: TextView

    // Tab 2: 키워드 (Keywords)
    private lateinit var etKeyword: EditText
    private lateinit var btnAdd: Button
    private lateinit var rvKeywords: RecyclerView
    private lateinit var rvPresets: RecyclerView
    private lateinit var tvKeywordEngineCount: TextView

    // Tab 3: 시스템 (System)
    private lateinit var tvAccessibilityBadge: TextView
    private lateinit var btnAccessibilitySettings: Button
    private lateinit var btnNotificationSettings: Button
    private lateinit var tvShizukuBadge: TextView
    private lateinit var btnShizukuRequest: Button
    private lateinit var tvDeviceTemp: TextView
    private lateinit var tvRamUsage: TextView
    private lateinit var btnRamClean: Button

    // Tab 4: 계정 (Account)
    private lateinit var etAccountEmail: EditText
    private lateinit var tvDeviceModel: TextView

    // Background kept switches / seekbars for complete backward compatibility
    private lateinit var switchActive: Switch
    private lateinit var switchAcceptAll: Switch
    private lateinit var switchAutoDismiss: Switch
    private lateinit var switchOcrPoll: Switch
    private lateinit var switchSleepAlarm: Switch
    private lateinit var switchBlacklistMode: Switch
    private lateinit var switchAirportMode: Switch
    private lateinit var switchAcceptNoDelay: Switch
    private lateinit var switchFloatingBubble: Switch
    private lateinit var switchHumanMode: Switch
    private lateinit var switchVibration: Switch
    private lateinit var switchAcceptScreenshot: Switch
    private lateinit var seekDismissCooldown: SeekBar
    private lateinit var seekMinDelay: SeekBar
    private lateinit var seekMaxDelay: SeekBar
    private lateinit var tvMinDelay: TextView
    private lateinit var tvMaxDelay: TextView
    private lateinit var tvDismissCooldown: TextView

    private val statsRefresher = object : Runnable {
        override fun run() {
            updateStats()
            updateAccessibilityStatus()
            updateShizukuStatus()
            updateSystemTelemetry()
            updateLogView()
            handler.postDelayed(this, 1500L)
        }
    }

    private val acceptReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            updateStats()
            updateLogView()
        }
    }

    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == shizukuPermissionCode) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Shizuku 권한 승인됨", Toast.LENGTH_SHORT).show()
                updateShizukuStatus()
            } else {
                Toast.makeText(this, "Shizuku 권한 거부됨", Toast.LENGTH_SHORT).show()
                updateShizukuStatus()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initHiddenCompatControls()
        buildNexusUI()
        loadSettings()
        setupListeners()
        requestShizukuPermission()
    }

    private fun initHiddenCompatControls() {
        switchActive = Switch(this)
        switchAcceptAll = Switch(this)
        switchAutoDismiss = Switch(this)
        switchOcrPoll = Switch(this)
        switchSleepAlarm = Switch(this)
        switchBlacklistMode = Switch(this)
        switchAirportMode = Switch(this)
        switchAcceptNoDelay = Switch(this)
        switchFloatingBubble = Switch(this)
        switchHumanMode = Switch(this)
        switchVibration = Switch(this)
        switchAcceptScreenshot = Switch(this)
        seekDismissCooldown = SeekBar(this).apply { max = 50; progress = 10 }
        seekMinDelay = SeekBar(this).apply { max = 50; progress = 10 }
        seekMaxDelay = SeekBar(this).apply { max = 50; progress = 30 }
        tvMinDelay = TextView(this)
        tvMaxDelay = TextView(this)
        tvDismissCooldown = TextView(this)
    }

    private fun requestShizukuPermission() {
        try {
            if (Shizuku.pingBinder()) {
                if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                    Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
                    Shizuku.requestPermission(shizukuPermissionCode)
                }
            }
        } catch (_: Throwable) {
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        SleepAlarmManager.stopAlarm()
        try {
            Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
        } catch (_: Throwable) {
        }
    }

    override fun onResume() {
        super.onResume()
        loadSettings()
        updateStats()
        updateAccessibilityStatus()
        updateShizukuStatus()
        updateSystemTelemetry()
        updateLogView()
        handler.post(statsRefresher)
        val filter = IntentFilter("com.uber.autoaccept.ACCEPT_EVENT")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(acceptReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(acceptReceiver, filter)
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(statsRefresher)
        try {
            unregisterReceiver(acceptReceiver)
        } catch (_: Exception) {
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun space(h: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(h))
    }

    private fun dividerV(margin: Int = 12): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(1)).apply {
            topMargin = dp(margin)
            bottomMargin = dp(margin)
        }
        setBackgroundColor(Color.parseColor("#152238"))
    }

    private fun nexusCard(pad: Int = 16, margin: Int = 8): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
            topMargin = dp(margin)
            bottomMargin = dp(margin)
        }
        background = GradientDrawable().apply {
            setColor(Color.parseColor("#0E1726"))
            setStroke(dp(1), Color.parseColor("#1A2840"))
            cornerRadius = dp(16).toFloat()
        }
        setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    }

    private fun roundRect(radiusDp: Int, color: Int, strokeDp: Int = 0, strokeColor: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusDp.toFloat()
            if (strokeDp > 0) {
                setStroke(dp(strokeDp), strokeColor)
            }
        }

    private fun buildNexusUI() {
        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(MATCH, MATCH)
            setBackgroundColor(Color.parseColor("#080D1A"))
        }

        // 0. Window Insets (Status bar, cutout, and Navigation bar safe area)
        ViewCompat.setOnApplyWindowInsetsListener(rootLayout) { view, insets ->
            val statusBarInsets = insets.getInsets(
                WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val navBarInsets = insets.getInsets(WindowInsetsCompat.Type.navigationBars())
            view.setPadding(0, statusBarInsets.top, 0, navBarInsets.bottom)
            insets
        }

        // 1. Top Header (NEXUS AUTOMATION SYSTEM + Status Badge)
        val headerBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                topMargin = dp(8)
                bottomMargin = dp(6)
                leftMargin = dp(16)
                rightMargin = dp(16)
            }
        }

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        val tvBrandTitle = TextView(this).apply {
            text = "NEXUS"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            letterSpacing = 0.05f
            try {
                typeface = Typeface.createFromAsset(assets, "fonts/Jua-Regular.ttf")
            } catch (_: Exception) {}
        }
        titleCol.addView(tvBrandTitle)

        val tvBrandSub = TextView(this).apply {
            text = "AUTOMATION SYSTEM"
            setTextColor(Color.parseColor("#38BDF8"))
            textSize = 10.5f
            setTypeface(typeface, Typeface.BOLD)
            letterSpacing = 0.12f
        }
        titleCol.addView(tvBrandSub)
        headerBar.addView(titleCol)

        tvStatusBadge = TextView(this).apply {
            text = "● STANDBY"
            setTextColor(Color.parseColor("#8E9CAE"))
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            background = roundRect(dp(16), Color.parseColor("#101928"), 1, Color.parseColor("#1E293B"))
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        headerBar.addView(tvStatusBadge)
        rootLayout.addView(headerBar)

        // 2. Tab Content Container (FrameLayout hosting 4 ScrollViews)
        val tabContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(MATCH, 0, 1f)
        }

        val scrollTab1 = ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(MATCH, MATCH)
            clipToPadding = false
            addView(buildTab1AutoAccept())
        }
        val scrollTab2 = ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(MATCH, MATCH)
            clipToPadding = false
            visibility = View.GONE
            addView(buildTab2Keywords())
        }
        val scrollTab3 = ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(MATCH, MATCH)
            clipToPadding = false
            visibility = View.GONE
            addView(buildTab3System())
        }
        val scrollTab4 = ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(MATCH, MATCH)
            clipToPadding = false
            visibility = View.GONE
            addView(buildTab4Account())
        }

        tabContainer.addView(scrollTab1)
        tabContainer.addView(scrollTab2)
        tabContainer.addView(scrollTab3)
        tabContainer.addView(scrollTab4)
        tabViews = listOf(scrollTab1, scrollTab2, scrollTab3, scrollTab4)
        rootLayout.addView(tabContainer)

        // 3. Bottom Navigation Bar
        val bottomNav = buildBottomNav()
        rootLayout.addView(bottomNav)

        setContentView(rootLayout)
    }

    // ==========================================
    // TAB 1: ⚡ 자동수락 (Auto Accept)
    // ==========================================
    private fun buildTab1AutoAccept(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(MATCH, WRAP)
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }

        // 1. HUD METRICS // CALL COUNTER
        val hudCard = nexusCard(pad = 14, margin = 4)
        val tvHudTitle = TextView(this).apply {
            text = "HUD METRICS // CALL COUNTER"
            setTextColor(Color.parseColor("#38BDF8"))
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            letterSpacing = 0.08f
        }
        hudCard.addView(tvHudTitle)
        hudCard.addView(space(10))

        val statRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        }

        fun makeMetricCol(label: String, colorHex: String): Pair<LinearLayout, TextView> {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            }
            val tvVal = TextView(this).apply {
                text = "0"
                setTextColor(Color.parseColor(colorHex))
                textSize = 22f
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
            }
            val tvLbl = TextView(this).apply {
                text = label
                setTextColor(Color.parseColor("#8E9CAE"))
                textSize = 11.5f
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                    topMargin = dp(4)
                }
            }
            col.addView(tvVal)
            col.addView(tvLbl)
            return Pair(col, tvVal)
        }

        val (c1, v1) = makeMetricCol("카드 인식", "#FFFFFF")
        tvCallCount = v1
        statRow.addView(c1)

        val vDiv1 = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(1), dp(32))
            setBackgroundColor(Color.parseColor("#1A2840"))
        }
        statRow.addView(vDiv1)

        val (c2, v2) = makeMetricCol("카드 수락", "#06C167")
        tvAcceptScheduled = v2
        statRow.addView(c2)

        val vDiv2 = View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(1), dp(32))
            setBackgroundColor(Color.parseColor("#1A2840"))
        }
        statRow.addView(vDiv2)

        val (c3, v3) = makeMetricCol("카드 취소", "#FF4B55")
        tvDismissScheduled = v3
        statRow.addView(c3)

        hudCard.addView(statRow)
        hudCard.addView(dividerV(10))

        val hudBottomRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        }

        btnResetStats = TextView(this).apply {
            text = "⟳ 리셋"
            setTextColor(Color.parseColor("#38BDF8"))
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            background = roundRect(dp(8), Color.parseColor("#0A192F"), 1, Color.parseColor("#0284C7"))
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener {
                PrefsManager.resetCounts(this@MainActivity)
                updateStats()
                Toast.makeText(this@MainActivity, "카운터가 리셋되었습니다", Toast.LENGTH_SHORT).show()
            }
        }
        hudBottomRow.addView(btnResetStats)

        tvAcceptButtonStatus = TextView(this).apply {
            text = "수락버튼 상태: 미감지"
            setTextColor(Color.parseColor("#8E9CAE"))
            textSize = 12f
            gravity = Gravity.END
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        hudBottomRow.addView(tvAcceptButtonStatus)

        hudCard.addView(hudBottomRow)
        root.addView(hudCard)

        // 2. Feature Button Cards with Big State Buttons (Per User Instruction Section 6)
        fun makeNexusToggleCard(
            title: String,
            desc: String,
            offText: String,
            onText: String,
            onColor: String = "#06C167"
        ): Pair<LinearLayout, Button> {
            val card = nexusCard(pad = 14, margin = 4)
            val tvT = TextView(this).apply {
                text = title
                setTextColor(Color.parseColor("#FFFFFF"))
                textSize = 15.5f
                setTypeface(typeface, Typeface.BOLD)
            }
            val tvD = TextView(this).apply {
                text = desc
                setTextColor(Color.parseColor("#8E9CAE"))
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                    topMargin = dp(2)
                    bottomMargin = dp(10)
                }
            }
            card.addView(tvT)
            card.addView(tvD)

            val btn = Button(this).apply {
                text = offText
                setTextColor(Color.parseColor("#8E9CAE"))
                textSize = 13.5f
                setTypeface(typeface, Typeface.BOLD)
                background = roundRect(dp(10), Color.parseColor("#0A101D"), 1, Color.parseColor("#1E293B"))
                layoutParams = LinearLayout.LayoutParams(MATCH, dp(44))
            }
            card.addView(btn)
            return Pair(card, btn)
        }

        // Card: 자동 수락
        val (cActive, btnActive) = makeNexusToggleCard(
            "자동 수락",
            "키워드가 일치하는 콜 자동 수락",
            "자동수락 OFF",
            "⚡ 자동수락 ON",
            "#06C167"
        )
        btnToggleActive = btnActive
        root.addView(cActive)

        // Card: ⚡ 전체 수락 모드
        val (cAcceptAll, btnAcceptAll) = makeNexusToggleCard(
            "⚡ 전체 수락 모드",
            "키워드 필터링 무시 — 모든 콜 무조건 수락",
            "전체 수락 모드 OFF",
            "⚡ 전체 수락 모드 ON",
            "#06C167"
        )
        btnToggleAcceptAll = btnAcceptAll
        root.addView(cAcceptAll)

        // Card: ✕ 불일치 콜 자동 닫기 (Cooldown Slider UI is removed per Section 5)
        val (cAutoDismiss, btnAutoDismiss) = makeNexusToggleCard(
            "✕ 불일치 콜 자동 닫기",
            "키워드 불일치 콜 — 우측 상단 X 버튼 자동 클릭",
            "불일치 콜 자동 닫기 OFF",
            "✕ 불일치 콜 자동 닫기 ON",
            "#FF4B55"
        )
        btnToggleAutoDismiss = btnAutoDismiss
        root.addView(cAutoDismiss)

        // Card: 📷 수락 시 스크린샷
        val (cAcceptScreen, btnAcceptScreen) = makeNexusToggleCard(
            "📷 수락 시 스크린샷",
            "콜 수락 시 화면을 DCIM/스마트알림/ 에 자동 저장",
            "수락 시 스크린샷 OFF",
            "📷 수락 시 스크린샷 ON",
            "#38BDF8"
        )
        btnToggleAcceptScreenshot = btnAcceptScreen
        root.addView(cAcceptScreen)

        // Card: 🌙 수면 모드 (SLEEP ALARM)
        val sleepCard = nexusCard(pad = 16, margin = 4)
        val tvSleepTitle = TextView(this).apply {
            text = "🌙 수면 모드 (SLEEP ALARM)"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 15.5f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        }
        val tvSleepSub = TextView(this).apply {
            text = "버튼을 누르면 수면 알람 모드가 활성화됩니다"
            setTextColor(Color.parseColor("#8E9CAE"))
            textSize = 12f
            gravity = Gravity.CENTER_HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                topMargin = dp(4)
                bottomMargin = dp(12)
            }
        }
        sleepCard.addView(tvSleepTitle)
        sleepCard.addView(tvSleepSub)

        btnToggleSleepAlarm = Button(this).apply {
            text = "🌙 수면모드 OFF"
            setTextColor(Color.parseColor("#8E9CAE"))
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            background = roundRect(dp(12), Color.parseColor("#0A101D"), 1, Color.parseColor("#1E293B"))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(50))
        }
        sleepCard.addView(btnToggleSleepAlarm)
        root.addView(sleepCard)

        // Card: ⚡ 실시간 진단 로그 스트림
        val logCard = nexusCard(pad = 14, margin = 4)
        val tvLogTitle = TextView(this).apply {
            text = "⚡ 실시간 진단 로그 스트림"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
        }
        val tvLogSub = TextView(this).apply {
            text = "엔진 이벤트 및 콜카드 판정 실시간 스트림"
            setTextColor(Color.parseColor("#8E9CAE"))
            textSize = 11.5f
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                topMargin = dp(2)
                bottomMargin = dp(10)
            }
        }
        logCard.addView(tvLogTitle)
        logCard.addView(tvLogSub)

        val logBtnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                bottomMargin = dp(10)
            }
        }

        btnLogClear = Button(this).apply {
            text = "로그 비우기"
            setTextColor(Color.parseColor("#E2E8F0"))
            textSize = 12f
            background = roundRect(dp(8), Color.parseColor("#162032"), 1, Color.parseColor("#1E293B"))
            layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f).apply {
                rightMargin = dp(4)
            }
            setPadding(0, 0, 0, 0)
            setOnClickListener {
                LogBuffer.clear(this@MainActivity)
                updateLogView()
                Toast.makeText(this@MainActivity, "로그가 비워졌습니다", Toast.LENGTH_SHORT).show()
            }
        }
        logBtnRow.addView(btnLogClear)

        btnLogShare = Button(this).apply {
            text = "로그 공유"
            setTextColor(Color.parseColor("#38BDF8"))
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            background = roundRect(dp(8), Color.parseColor("#0A2540"), 1, Color.parseColor("#0284C7"))
            layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f).apply {
                leftMargin = dp(2)
                rightMargin = dp(2)
            }
            setPadding(0, 0, 0, 0)
            setOnClickListener { exportLog() }
        }
        logBtnRow.addView(btnLogShare)

        btnLogSave = Button(this).apply {
            text = "파일 저장"
            setTextColor(Color.parseColor("#E2E8F0"))
            textSize = 12f
            background = roundRect(dp(8), Color.parseColor("#162032"), 1, Color.parseColor("#1E293B"))
            layoutParams = LinearLayout.LayoutParams(0, dp(38), 1f).apply {
                leftMargin = dp(4)
            }
            setPadding(0, 0, 0, 0)
            setOnClickListener {
                exportLog()
                Toast.makeText(this@MainActivity, "⚡ 로그 저장 중...", Toast.LENGTH_SHORT).show()
            }
        }
        logBtnRow.addView(btnLogSave)
        logCard.addView(logBtnRow)

        tvLogStream = TextView(this).apply {
            text = "[HUD SYSTEM READY — 새로운 콜 및 OCR 감지 대기 중...]"
            setTextColor(Color.parseColor("#00E676"))
            textSize = 11.5f
            typeface = Typeface.MONOSPACE
            background = roundRect(dp(8), Color.parseColor("#04070F"), 1, Color.parseColor("#1E293B"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(160))
            isVerticalScrollBarEnabled = true
        }
        logCard.addView(tvLogStream)
        root.addView(logCard)
        root.addView(space(28))

        return root
    }

    // ==========================================
    // TAB 2: 📋 키워드 (Keyword)
    // ==========================================
    private fun buildTab2Keywords(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(MATCH, WRAP)
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }

        // 1. ✈️ 공항 전용 퀵 키워드 Card
        val airportCard = nexusCard(pad = 14, margin = 4)
        val tvAirTitle = TextView(this).apply {
            text = "✈️ 공항 전용 퀵 키워드"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 15.5f
            setTypeface(typeface, Typeface.BOLD)
        }
        val tvAirSub = TextView(this).apply {
            text = "탭하여 공항 관련 주요 목적지 키워드를 즉시 추가합니다"
            setTextColor(Color.parseColor("#8E9CAE"))
            textSize = 12f
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                topMargin = dp(2)
                bottomMargin = dp(10)
            }
        }
        airportCard.addView(tvAirTitle)
        airportCard.addView(tvAirSub)

        val airportFlex = FlexWrapLayout(this)
        val airportList = listOf(
            "인천국제공항", "인천공항", "제1여객터미널",
            "제2여객터미널", "T1", "T2", "운서", "용유",
            "을왕", "공항로", "영종구", "김포공항"
        )
        for (kw in airportList) {
            val btnTag = TextView(this).apply {
                text = "+ $kw"
                setTextColor(Color.parseColor("#38BDF8"))
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                background = roundRect(dp(16), Color.parseColor("#0A1C2C"), 1, Color.parseColor("#0284C7"))
                setPadding(dp(12), dp(6), dp(12), dp(6))
                layoutParams = ViewGroup.MarginLayoutParams(WRAP, WRAP).apply {
                    rightMargin = dp(6)
                    bottomMargin = dp(6)
                }
                setOnClickListener { addKeyword(kw) }
            }
            airportFlex.addView(btnTag)
        }
        airportCard.addView(airportFlex)
        root.addView(airportCard)

        // 2. 목적지 키워드 입력 Card
        val inputCard = nexusCard(pad = 14, margin = 4)
        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        }

        etKeyword = EditText(this).apply {
            hint = "목적지 키워드 입력 (예: 강남)"
            setHintTextColor(Color.parseColor("#64748B"))
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 13.5f
            background = roundRect(dp(10), Color.parseColor("#070D18"), 1, Color.parseColor("#1E293B"))
            setPadding(dp(14), dp(10), dp(14), dp(10))
            imeOptions = EditorInfo.IME_ACTION_DONE
            setSingleLine(true)
            layoutParams = LinearLayout.LayoutParams(0, dp(46), 1f).apply {
                rightMargin = dp(8)
            }
        }
        inputRow.addView(etKeyword)

        btnAdd = Button(this).apply {
            text = "추가"
            setTextColor(Color.parseColor("#000000"))
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            background = roundRect(dp(10), Color.parseColor("#00E676"))
            layoutParams = LinearLayout.LayoutParams(dp(70), dp(46))
            setPadding(0, 0, 0, 0)
            setOnClickListener { addKeywordFromInput() }
        }
        inputRow.addView(btnAdd)
        inputCard.addView(inputRow)

        val quickFlex = FlexWrapLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                topMargin = dp(12)
            }
        }
        val quickCityList = listOf("강남", "잠실", "홍대", "서울역", "여의도", "판교", "수원")
        for (kw in quickCityList) {
            val btnTag = TextView(this).apply {
                text = "+ $kw"
                setTextColor(Color.parseColor("#E2E8F0"))
                textSize = 12f
                background = roundRect(dp(14), Color.parseColor("#0E1A2C"), 1, Color.parseColor("#1E293B"))
                setPadding(dp(12), dp(5), dp(12), dp(5))
                layoutParams = ViewGroup.MarginLayoutParams(WRAP, WRAP).apply {
                    rightMargin = dp(6)
                    bottomMargin = dp(6)
                }
                setOnClickListener { addKeyword(kw) }
            }
            quickFlex.addView(btnTag)
        }
        inputCard.addView(quickFlex)
        root.addView(inputCard)

        // 3. 📋 등록된 포함 키워드 Card
        val kwListCard = nexusCard(pad = 14, margin = 4)
        val kwHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                bottomMargin = dp(8)
            }
        }
        val tvKwHeader = TextView(this).apply {
            text = "📋 등록된 포함 키워드"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        kwHeaderRow.addView(tvKwHeader)

        val btnClearAll = TextView(this).apply {
            text = "전체 삭제"
            setTextColor(Color.parseColor("#F87171"))
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            background = roundRect(dp(6), Color.parseColor("#251118"), 1, Color.parseColor("#DC2626"))
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener {
                if (keywords.isNotEmpty()) {
                    keywords.clear()
                    adapter.notifyDataSetChanged()
                    PrefsManager.saveKeywords(this@MainActivity, keywords)
                    updateKeywordCountBadge()
                    Toast.makeText(this@MainActivity, "모든 키워드가 삭제되었습니다", Toast.LENGTH_SHORT).show()
                }
            }
        }
        kwHeaderRow.addView(btnClearAll)
        kwListCard.addView(kwHeaderRow)

        rvKeywords = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
            isNestedScrollingEnabled = false
        }
        adapter = KeywordAdapter(keywords) { pos ->
            if (pos >= 0 && pos < keywords.size) {
                keywords.removeAt(pos)
                adapter.notifyItemRemoved(pos)
                PrefsManager.saveKeywords(this, keywords)
                updateKeywordCountBadge()
            }
        }
        rvKeywords.adapter = adapter
        kwListCard.addView(rvKeywords)
        root.addView(kwListCard)

        // 4. 📄 키워드 프리셋 프로필 Card
        val presetCard = nexusCard(pad = 14, margin = 4)
        val presetHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                bottomMargin = dp(8)
            }
        }
        val presetCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        val tvPresetTitle = TextView(this).apply {
            text = "📄 키워드 프리셋 프로필"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
        }
        val tvPresetSub = TextView(this).apply {
            text = "상황별 키워드 세트를 원터치로 변경합니다"
            setTextColor(Color.parseColor("#8E9CAE"))
            textSize = 11.5f
        }
        presetCol.addView(tvPresetTitle)
        presetCol.addView(tvPresetSub)
        presetHeaderRow.addView(presetCol)

        val btnSavePreset = TextView(this).apply {
            text = "+ 저장"
            setTextColor(Color.parseColor("#38BDF8"))
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            background = roundRect(dp(8), Color.parseColor("#0A2540"), 1, Color.parseColor("#0284C7"))
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener { showSavePresetDialog() }
        }
        presetHeaderRow.addView(btnSavePreset)
        presetCard.addView(presetHeaderRow)

        rvPresets = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
            isNestedScrollingEnabled = false
        }
        presetAdapter = PresetAdapter(
            presets,
            onApply = { pos ->
                val p = presets[pos]
                keywords.clear()
                keywords.addAll(p.keywords)
                adapter.notifyDataSetChanged()
                PrefsManager.saveKeywords(this, keywords)
                updateKeywordCountBadge()
                Toast.makeText(this, "'${p.name}' 프리셋 적용됨", Toast.LENGTH_SHORT).show()
            },
            onEdit = { pos -> showEditPresetDialog(pos) },
            onDelete = { pos -> showDeletePresetDialog(pos) }
        )
        rvPresets.adapter = presetAdapter
        presetCard.addView(rvPresets)
        root.addView(presetCard)

        // 5. 키워드 엔진 상태 Card
        val statusCard = nexusCard(pad = 14, margin = 4)
        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        }
        val tvEngineLabel = TextView(this).apply {
            text = "키워드 엔진 상태"
            setTextColor(Color.parseColor("#8E9CAE"))
            textSize = 13.5f
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        statusRow.addView(tvEngineLabel)

        tvKeywordEngineCount = TextView(this).apply {
            text = "${keywords.size}개 등록됨"
            setTextColor(Color.parseColor("#00E676"))
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
        }
        statusRow.addView(tvKeywordEngineCount)
        statusCard.addView(statusRow)
        root.addView(statusCard)
        root.addView(space(28))

        return root
    }

    // ==========================================
    // TAB 3: ⚙️ 시스템 (System)
    // ==========================================
    private fun buildTab3System(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(MATCH, WRAP)
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }

        // 1. 접근성 서비스 (Accessibility) Card
        val accessCard = nexusCard(pad = 14, margin = 4)
        val accessTopRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                bottomMargin = dp(10)
            }
        }
        val accessCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        val tvAccTitle = TextView(this).apply {
            text = "접근성 서비스 (Accessibility)"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
        }
        val tvAccSub = TextView(this).apply {
            text = "콜카드 노드 탐색 및 자동 터치에 필수"
            setTextColor(Color.parseColor("#8E9CAE"))
            textSize = 11.5f
        }
        accessCol.addView(tvAccTitle)
        accessCol.addView(tvAccSub)
        accessTopRow.addView(accessCol)

        tvAccessibilityBadge = TextView(this).apply {
            text = "OFF ✕"
            setTextColor(Color.parseColor("#EF4444"))
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            background = roundRect(dp(8), Color.parseColor("#251118"), 1, Color.parseColor("#DC2626"))
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        accessTopRow.addView(tvAccessibilityBadge)
        accessCard.addView(accessTopRow)

        btnAccessibilitySettings = Button(this).apply {
            text = "접근성 서비스 설정 열기"
            setTextColor(Color.parseColor("#38BDF8"))
            textSize = 13.5f
            setTypeface(typeface, Typeface.BOLD)
            background = roundRect(dp(10), Color.parseColor("#0A2540"), 1, Color.parseColor("#0284C7"))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(46)).apply {
                bottomMargin = dp(8)
            }
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        accessCard.addView(btnAccessibilitySettings)

        btnNotificationSettings = Button(this).apply {
            text = "알림 접근 권한 설정 열기"
            setTextColor(Color.parseColor("#E2E8F0"))
            textSize = 13.5f
            background = roundRect(dp(10), Color.parseColor("#0E1726"), 1, Color.parseColor("#1E293B"))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(46))
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
        accessCard.addView(btnNotificationSettings)
        root.addView(accessCard)

        // 2. Shizuku ADB 엔진 Card
        val shizukuCard = nexusCard(pad = 14, margin = 4)
        val shizukuTopRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                bottomMargin = dp(10)
            }
        }
        val shizukuCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        val tvShTitle = TextView(this).apply {
            text = "Shizuku ADB 엔진"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
        }
        val tvShSub = TextView(this).apply {
            text = "0ms 초고속 가상 탭 인젝션 권한"
            setTextColor(Color.parseColor("#8E9CAE"))
            textSize = 11.5f
        }
        shizukuCol.addView(tvShTitle)
        shizukuCol.addView(tvShSub)
        shizukuTopRow.addView(shizukuCol)

        tvShizukuBadge = TextView(this).apply {
            text = "AUTHORIZED ✓"
            setTextColor(Color.parseColor("#06C167"))
            textSize = 11.5f
            setTypeface(typeface, Typeface.BOLD)
            background = roundRect(dp(8), Color.parseColor("#072A1C"), 1, Color.parseColor("#06C167"))
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        shizukuTopRow.addView(tvShizukuBadge)
        shizukuCard.addView(shizukuTopRow)

        btnShizukuRequest = Button(this).apply {
            text = "SHIZUKU 권한 다시 요청"
            setTextColor(Color.parseColor("#E2E8F0"))
            textSize = 13.5f
            setTypeface(typeface, Typeface.BOLD)
            background = roundRect(dp(10), Color.parseColor("#0E1726"), 1, Color.parseColor("#1E293B"))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(46))
            setOnClickListener { requestShizukuPermission() }
        }
        shizukuCard.addView(btnShizukuRequest)
        root.addView(shizukuCard)

        // 3. ML Kit OCR 엔진 상태 Card
        val ocrStatusCard = nexusCard(pad = 14, margin = 4)
        val ocrRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        }
        val ocrCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        val tvOcrTitle = TextView(this).apply {
            text = "ML Kit OCR 엔진 상태"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
        }
        val tvOcrSub = TextView(this).apply {
            text = "Google ML Kit Korean Vision Engine"
            setTextColor(Color.parseColor("#8E9CAE"))
            textSize = 11.5f
        }
        ocrCol.addView(tvOcrTitle)
        ocrCol.addView(tvOcrSub)
        ocrRow.addView(ocrCol)

        val tvOcrBadge = TextView(this).apply {
            text = "READY"
            setTextColor(Color.parseColor("#06C167"))
            textSize = 11.5f
            setTypeface(typeface, Typeface.BOLD)
            background = roundRect(dp(8), Color.parseColor("#072A1C"), 1, Color.parseColor("#06C167"))
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        ocrRow.addView(tvOcrBadge)
        ocrStatusCard.addView(ocrRow)
        root.addView(ocrStatusCard)

        // 4. 🌡️ 디바이스 온도 Card
        val tempCard = nexusCard(pad = 14, margin = 4)
        val tempRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        }
        val tempCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        val tvTempTitle = TextView(this).apply {
            text = "🌡️ 디바이스 온도"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
        }
        val tvTempSub = TextView(this).apply {
            text = "배터리 및 하드웨어 실시간 센서"
            setTextColor(Color.parseColor("#8E9CAE"))
            textSize = 11.5f
        }
        tempCol.addView(tvTempTitle)
        tempCol.addView(tvTempSub)
        tempRow.addView(tempCol)

        tvDeviceTemp = TextView(this).apply {
            text = "35.1 °C"
            setTextColor(Color.parseColor("#38BDF8"))
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
        }
        tempRow.addView(tvDeviceTemp)
        tempCard.addView(tempRow)
        root.addView(tempCard)

        // 5. 💾 시스템 메모리 (RAM) Card
        val ramCard = nexusCard(pad = 14, margin = 4)
        val ramTopRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                bottomMargin = dp(10)
            }
        }
        val ramCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        val tvRamTitle = TextView(this).apply {
            text = "💾 시스템 메모리 (RAM)"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 15f
            setTypeface(typeface, Typeface.BOLD)
        }
        val tvRamSub = TextView(this).apply {
            text = "실시간 RAM 가용량 및 GC 트리거"
            setTextColor(Color.parseColor("#8E9CAE"))
            textSize = 11.5f
        }
        ramCol.addView(tvRamTitle)
        ramCol.addView(tvRamSub)
        ramTopRow.addView(ramCol)

        tvRamUsage = TextView(this).apply {
            text = "8.6 / 10.9 GB (79%)"
            setTextColor(Color.parseColor("#06C167"))
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
        }
        ramTopRow.addView(tvRamUsage)
        ramCard.addView(ramTopRow)

        btnRamClean = Button(this).apply {
            text = "⚡ 메모리 정리 및 캐시 비우기"
            setTextColor(Color.parseColor("#E2E8F0"))
            textSize = 13.5f
            setTypeface(typeface, Typeface.BOLD)
            background = roundRect(dp(10), Color.parseColor("#0E1726"), 1, Color.parseColor("#1E293B"))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(46))
            setOnClickListener {
                System.gc()
                updateSystemTelemetry()
                Toast.makeText(this@MainActivity, "메모리 정리 및 GC가 완료되었습니다", Toast.LENGTH_SHORT).show()
            }
        }
        ramCard.addView(btnRamClean)
        root.addView(ramCard)
        root.addView(space(28))

        return root
    }

    // ==========================================
    // TAB 4: 👤 계정 (Account - Design Mockup Only)
    // ==========================================
    private fun buildTab4Account(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(MATCH, WRAP)
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }

        // 1. 🔑 서버 계정 인증 Card
        val authCard = nexusCard(pad = 14, margin = 4)
        val tvAuthTitle = TextView(this).apply {
            text = "🔑 서버 계정 인증"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 15.5f
            setTypeface(typeface, Typeface.BOLD)
        }
        val tvAuthSub = TextView(this).apply {
            text = "클라우드 동기화 및 라이선스 인증 센터"
            setTextColor(Color.parseColor("#8E9CAE"))
            textSize = 12f
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                topMargin = dp(2)
                bottomMargin = dp(10)
            }
        }
        authCard.addView(tvAuthTitle)
        authCard.addView(tvAuthSub)

        etAccountEmail = EditText(this).apply {
            setText("yamoklee2@gmail.com")
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 14f
            background = roundRect(dp(10), Color.parseColor("#070D18"), 1, Color.parseColor("#1E293B"))
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setSingleLine(true)
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(46)).apply {
                bottomMargin = dp(10)
            }
        }
        authCard.addView(etAccountEmail)

        val btnAccountSync = Button(this).apply {
            text = "계정 연동 완료 (정상)"
            setTextColor(Color.parseColor("#38BDF8"))
            textSize = 13.5f
            setTypeface(typeface, Typeface.BOLD)
            background = roundRect(dp(10), Color.parseColor("#0A2540"), 1, Color.parseColor("#0284C7"))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(46))
            setOnClickListener {
                Toast.makeText(this@MainActivity, "계정 연동이 확인되었습니다 (정상)", Toast.LENGTH_SHORT).show()
            }
        }
        authCard.addView(btnAccountSync)
        root.addView(authCard)

        // 2. Info Status Card Rows
        fun makeAccountInfoRow(label: String, value: String, valueColor: String): LinearLayout {
            val card = nexusCard(pad = 14, margin = 4)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
            }
            val tvL = TextView(this).apply {
                text = label
                setTextColor(Color.parseColor("#8E9CAE"))
                textSize = 13.5f
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            }
            val tvV = TextView(this).apply {
                text = value
                setTextColor(Color.parseColor(valueColor))
                textSize = 13.5f
                setTypeface(typeface, Typeface.BOLD)
            }
            row.addView(tvL)
            row.addView(tvV)
            card.addView(row)
            return card
        }

        root.addView(makeAccountInfoRow("계정 상태", "PRO DRIVER // ACTIVE", "#06C167"))
        root.addView(makeAccountInfoRow("사용 라이선스 기간", "LIFETIME UNLIMITED (평생)", "#38BDF8"))
        root.addView(makeAccountInfoRow("누적 엔진 가동시간", "33시간 가동 중", "#FBBF24"))

        val deviceModelName = "${Build.MANUFACTURER.uppercase()} ${Build.MODEL}"
        val deviceCard = makeAccountInfoRow("등록 디바이스", deviceModelName, "#FFFFFF")
        tvDeviceModel = deviceCard.getChildAt(0).let { (it as LinearLayout).getChildAt(1) as TextView }
        root.addView(deviceCard)

        // 3. 계정 연동 해제 / 로그아웃 Button
        val btnLogout = Button(this).apply {
            text = "계정 연동 해제 / 로그아웃"
            setTextColor(Color.parseColor("#EF4444"))
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            background = roundRect(dp(10), Color.parseColor("#1F0A10"), 1, Color.parseColor("#DC2626"))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(48)).apply {
                topMargin = dp(12)
            }
            setOnClickListener {
                Toast.makeText(this@MainActivity, "계정 연동 상태가 유지됩니다", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(btnLogout)
        root.addView(space(28))

        return root
    }

    // ==========================================
    // BOTTOM NAVIGATION
    // ==========================================
    private fun buildBottomNav(): View {
        val navLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(64))
            setBackgroundColor(Color.parseColor("#0B1322"))
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }

        val tabsData = listOf(
            Pair("⚡", "자동수락"),
            Pair("📋", "키워드"),
            Pair("⚙️", "시스템"),
            Pair("👤", "계정")
        )

        val buttons = mutableListOf<LinearLayout>()
        val texts = mutableListOf<TextView>()
        val icons = mutableListOf<TextView>()

        for (i in tabsData.indices) {
            val (icon, title) = tabsData[i]
            val tabBtn = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                    leftMargin = dp(3)
                    rightMargin = dp(3)
                }
            }

            val tvIcon = TextView(this).apply {
                text = icon
                textSize = 14f
            }
            val tvTitle = TextView(this).apply {
                text = " $title"
                textSize = 12.5f
                setTypeface(typeface, Typeface.BOLD)
            }

            tabBtn.addView(tvIcon)
            tabBtn.addView(tvTitle)

            tabBtn.setOnClickListener { switchTab(i) }

            buttons.add(tabBtn)
            icons.add(tvIcon)
            texts.add(tvTitle)
            navLayout.addView(tabBtn)
        }

        navButtons = buttons
        navIcons = icons
        navTexts = texts

        updateNavSelection(0)
        return navLayout
    }

    private fun switchTab(targetIndex: Int) {
        if (targetIndex == currentTab) return
        currentTab = targetIndex
        for (i in tabViews.indices) {
            tabViews[i].visibility = if (i == targetIndex) View.VISIBLE else View.GONE
        }
        updateNavSelection(targetIndex)
    }

    private fun updateNavSelection(selectedIndex: Int) {
        for (i in navButtons.indices) {
            val isSel = (i == selectedIndex)
            val btn = navButtons[i]
            val txt = navTexts[i]
            if (isSel) {
                btn.background = roundRect(dp(12), Color.parseColor("#0A1C24"), 1, Color.parseColor("#06C167"))
                txt.setTextColor(Color.parseColor("#00E676"))
            } else {
                btn.background = null
                txt.setTextColor(Color.parseColor("#64748B"))
            }
        }
    }

    // ==========================================
    // SETTINGS & LOGIC
    // ==========================================
    private fun loadSettings() {
        val active = PrefsManager.isActive(this)
        switchActive.isChecked = active
        updateActiveButtonUI(active)

        val acceptAll = PrefsManager.isAcceptAll(this)
        switchAcceptAll.isChecked = acceptAll
        updateToggleBtnUI(btnToggleAcceptAll, acceptAll, "전체 수락 모드 OFF", "⚡ 전체 수락 모드 ON", "#06C167")

        val autoDismiss = PrefsManager.isAutoDismiss(this)
        switchAutoDismiss.isChecked = autoDismiss
        updateToggleBtnUI(btnToggleAutoDismiss, autoDismiss, "불일치 콜 자동 닫기 OFF", "✕ 불일치 콜 자동 닫기 ON", "#FF4B55")

        val acceptScreen = PrefsManager.isAcceptScreenshot(this)
        switchAcceptScreenshot.isChecked = acceptScreen
        updateToggleBtnUI(btnToggleAcceptScreenshot, acceptScreen, "수락 시 스크린샷 OFF", "📷 수락 시 스크린샷 ON", "#38BDF8")

        val sleepAlarm = PrefsManager.isSleepAlarm(this)
        switchSleepAlarm.isChecked = sleepAlarm
        updateSleepAlarmBtnUI(sleepAlarm)

        switchOcrPoll.isChecked = PrefsManager.isOcrPoll(this)
        switchBlacklistMode.isChecked = PrefsManager.isBlacklistMode(this)
        switchAirportMode.isChecked = PrefsManager.isAirportMode(this)
        switchAcceptNoDelay.isChecked = PrefsManager.isAcceptNoDelay(this)
        switchFloatingBubble.isChecked = PrefsManager.isFloatingBubble(this)
        switchHumanMode.isChecked = PrefsManager.isHumanMode(this)
        switchVibration.isChecked = PrefsManager.isVibration(this)

        val minDelay = PrefsManager.getMinDelayMs(this)
        val maxDelay = PrefsManager.getMaxDelayMs(this)
        seekMinDelay.progress = (minDelay / 100).toInt()
        seekMaxDelay.progress = (maxDelay / 100).toInt()

        val cooldown = PrefsManager.getDismissCooldownMs(this)
        seekDismissCooldown.progress = ((cooldown - 500) / 100).coerceAtLeast(0).toInt()

        keywords.clear()
        keywords.addAll(PrefsManager.getKeywords(this))
        adapter.notifyDataSetChanged()
        updateKeywordCountBadge()

        presets.clear()
        presets.addAll(PrefsManager.getPresets(this))
        presetAdapter.notifyDataSetChanged()
    }

    private fun updateActiveButtonUI(active: Boolean) {
        if (active) {
            btnToggleActive.text = "⚡ 자동수락 ON"
            btnToggleActive.setTextColor(Color.parseColor("#06C167"))
            btnToggleActive.background = roundRect(dp(10), Color.parseColor("#072A1C"), 1, Color.parseColor("#06C167"))

            tvStatusBadge.text = "● ACTIVE"
            tvStatusBadge.setTextColor(Color.parseColor("#06C167"))
            tvStatusBadge.background = roundRect(dp(16), Color.parseColor("#072A1C"), 1, Color.parseColor("#06C167"))
        } else {
            btnToggleActive.text = "자동수락 OFF"
            btnToggleActive.setTextColor(Color.parseColor("#8E9CAE"))
            btnToggleActive.background = roundRect(dp(10), Color.parseColor("#0A101D"), 1, Color.parseColor("#1E293B"))

            tvStatusBadge.text = "● STANDBY"
            tvStatusBadge.setTextColor(Color.parseColor("#8E9CAE"))
            tvStatusBadge.background = roundRect(dp(16), Color.parseColor("#101928"), 1, Color.parseColor("#1E293B"))
        }
    }

    private fun updateToggleBtnUI(btn: Button, enabled: Boolean, offText: String, onText: String, onColorHex: String) {
        if (enabled) {
            btn.text = onText
            btn.setTextColor(Color.parseColor(onColorHex))
            btn.background = roundRect(dp(10), Color.parseColor("#0B202D"), 1, Color.parseColor(onColorHex))
        } else {
            btn.text = offText
            btn.setTextColor(Color.parseColor("#8E9CAE"))
            btn.background = roundRect(dp(10), Color.parseColor("#0A101D"), 1, Color.parseColor("#1E293B"))
        }
    }

    private fun updateSleepAlarmBtnUI(enabled: Boolean) {
        if (enabled) {
            btnToggleSleepAlarm.text = "🌙 수면모드 ON"
            btnToggleSleepAlarm.setTextColor(Color.parseColor("#FBBF24"))
            btnToggleSleepAlarm.background = roundRect(dp(12), Color.parseColor("#2D2305"), 1, Color.parseColor("#F59E0B"))
        } else {
            btnToggleSleepAlarm.text = "🌙 수면모드 OFF"
            btnToggleSleepAlarm.setTextColor(Color.parseColor("#8E9CAE"))
            btnToggleSleepAlarm.background = roundRect(dp(12), Color.parseColor("#0A101D"), 1, Color.parseColor("#1E293B"))
        }
    }

    private fun setupListeners() {
        btnToggleActive.setOnClickListener {
            val newState = !PrefsManager.isActive(this)
            PrefsManager.setActive(this, newState)
            switchActive.isChecked = newState
            updateActiveButtonUI(newState)
        }

        btnToggleAcceptAll.setOnClickListener {
            val newState = !PrefsManager.isAcceptAll(this)
            PrefsManager.setAcceptAll(this, newState)
            switchAcceptAll.isChecked = newState
            updateToggleBtnUI(btnToggleAcceptAll, newState, "전체 수락 모드 OFF", "⚡ 전체 수락 모드 ON", "#06C167")
        }

        btnToggleAutoDismiss.setOnClickListener {
            val newState = !PrefsManager.isAutoDismiss(this)
            PrefsManager.setAutoDismiss(this, newState)
            switchAutoDismiss.isChecked = newState
            updateToggleBtnUI(btnToggleAutoDismiss, newState, "불일치 콜 자동 닫기 OFF", "✕ 불일치 콜 자동 닫기 ON", "#FF4B55")
        }

        btnToggleAcceptScreenshot.setOnClickListener {
            val newState = !PrefsManager.isAcceptScreenshot(this)
            PrefsManager.saveAcceptScreenshot(this, newState)
            switchAcceptScreenshot.isChecked = newState
            updateToggleBtnUI(btnToggleAcceptScreenshot, newState, "수락 시 스크린샷 OFF", "📷 수락 시 스크린샷 ON", "#38BDF8")
        }

        btnToggleSleepAlarm.setOnClickListener {
            val newState = !PrefsManager.isSleepAlarm(this)
            PrefsManager.saveSleepAlarm(this, newState)
            switchSleepAlarm.isChecked = newState
            updateSleepAlarmBtnUI(newState)
            if (!newState) {
                SleepAlarmManager.stopAlarm()
            }
        }

        etKeyword.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                addKeywordFromInput()
                true
            } else false
        }
    }

    private fun updateKeywordCountBadge() {
        if (::tvKeywordEngineCount.isInitialized) {
            tvKeywordEngineCount.text = "${keywords.size}개 등록됨"
        }
    }

    private fun addKeywordFromInput() {
        val text = etKeyword.text.toString().trim()
        if (text.isNotEmpty()) {
            addKeyword(text)
            etKeyword.setText("")
        }
    }

    private fun addKeyword(kw: String) {
        if (!keywords.contains(kw)) {
            keywords.add(kw)
            adapter.notifyItemInserted(keywords.size - 1)
            PrefsManager.saveKeywords(this, keywords)
            updateKeywordCountBadge()
            Toast.makeText(this, "'$kw' 추가됨", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateStats() {
        if (::tvCallCount.isInitialized) {
            tvCallCount.text = "${PrefsManager.getCallCount(this)}"
            tvAcceptScheduled.text = "${PrefsManager.getAcceptScheduled(this)}"
            tvDismissScheduled.text = "${PrefsManager.getDismissScheduled(this)}"
            val lastRect = PrefsManager.getLastAcceptRectString(this)
            tvAcceptButtonStatus.text = if (lastRect.contains(",")) "수락버튼 상태: 감지됨" else "수락버튼 상태: $lastRect"
        }
    }

    private fun updateAccessibilityStatus() {
        if (!::tvAccessibilityBadge.isInitialized) return
        val serviceName = "$packageName/${AutoAcceptService::class.java.canonicalName}"
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        val isEnabled = enabledServices.split(":").any { it.equals(serviceName, ignoreCase = true) }
        if (isEnabled) {
            tvAccessibilityBadge.text = "ON ✓"
            tvAccessibilityBadge.setTextColor(Color.parseColor("#06C167"))
            tvAccessibilityBadge.background = roundRect(dp(8), Color.parseColor("#072A1C"), 1, Color.parseColor("#06C167"))
        } else {
            tvAccessibilityBadge.text = "OFF ✕"
            tvAccessibilityBadge.setTextColor(Color.parseColor("#EF4444"))
            tvAccessibilityBadge.background = roundRect(dp(8), Color.parseColor("#251118"), 1, Color.parseColor("#DC2626"))
        }
    }

    private fun updateShizukuStatus() {
        if (!::tvShizukuBadge.isInitialized) return
        try {
            if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                tvShizukuBadge.text = "AUTHORIZED ✓"
                tvShizukuBadge.setTextColor(Color.parseColor("#06C167"))
                tvShizukuBadge.background = roundRect(dp(8), Color.parseColor("#072A1C"), 1, Color.parseColor("#06C167"))
            } else {
                tvShizukuBadge.text = "UNAUTHORIZED"
                tvShizukuBadge.setTextColor(Color.parseColor("#F59E0B"))
                tvShizukuBadge.background = roundRect(dp(8), Color.parseColor("#2D2305"), 1, Color.parseColor("#F59E0B"))
            }
        } catch (_: Throwable) {
            tvShizukuBadge.text = "STANDBY"
            tvShizukuBadge.setTextColor(Color.parseColor("#8E9CAE"))
            tvShizukuBadge.background = roundRect(dp(8), Color.parseColor("#101928"), 1, Color.parseColor("#1E293B"))
        }
    }

    private fun updateSystemTelemetry() {
        if (::tvDeviceTemp.isInitialized) {
            try {
                val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val temp = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 350) ?: 350
                val tempC = temp / 10.0f
                tvDeviceTemp.text = String.format("%.1f °C", tempC)
            } catch (_: Exception) {
                tvDeviceTemp.text = "35.1 °C"
            }
        }

        if (::tvRamUsage.isInitialized) {
            try {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val memInfo = ActivityManager.MemoryInfo()
                am.getMemoryInfo(memInfo)
                val availGb = memInfo.availMem / (1024.0 * 1024.0 * 1024.0)
                val totalGb = memInfo.totalMem / (1024.0 * 1024.0 * 1024.0)
                val usedGb = totalGb - availGb
                val percent = ((usedGb / totalGb) * 100).toInt()
                tvRamUsage.text = String.format("%.1f / %.1f GB (%d%%)", usedGb, totalGb, percent)
            } catch (_: Exception) {
                tvRamUsage.text = "8.6 / 10.9 GB (79%)"
            }
        }
    }

    private fun updateLogView() {
        if (!::tvLogStream.isInitialized) return
        val logContent = LogBuffer.read(this)
        if (logContent.isNotBlank()) {
            val lines = logContent.trim().split("\n")
            val recentLines = lines.takeLast(15).joinToString("\n")
            tvLogStream.text = recentLines
        } else {
            tvLogStream.text = "[HUD SYSTEM READY — 새로운 콜 및 OCR 감지 대기 중...]"
        }
    }

    private fun showSavePresetDialog() {
        val input = EditText(this).apply {
            hint = "프리셋 이름 입력"
            setSingleLine(true)
            setTextColor(Color.parseColor("#FFFFFF"))
            setHintTextColor(Color.parseColor("#8E9CAE"))
        }
        AlertDialog.Builder(this)
            .setTitle("현재 키워드 프리셋 저장")
            .setView(input)
            .setPositiveButton("저장") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    val preset = KeywordPreset(name, keywords.toList())
                    presets.add(preset)
                    presetAdapter.notifyItemInserted(presets.size - 1)
                    PrefsManager.savePresets(this, presets)
                    Toast.makeText(this, "'$name' 저장됨", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun showEditPresetDialog(position: Int) {
        val preset = presets[position]
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val etName = EditText(this).apply {
            setText(preset.name)
            hint = "프리셋 이름"
            setTextColor(Color.parseColor("#FFFFFF"))
            setHintTextColor(Color.parseColor("#8E9CAE"))
        }
        val etKw = EditText(this).apply {
            setText(preset.keywords.joinToString(", "))
            hint = "키워드 (쉼표 구분)"
            setTextColor(Color.parseColor("#FFFFFF"))
            setHintTextColor(Color.parseColor("#8E9CAE"))
        }
        layout.addView(etName)
        layout.addView(etKw)

        AlertDialog.Builder(this)
            .setTitle("프리셋 수정")
            .setView(layout)
            .setPositiveButton("저장") { _, _ ->
                val newName = etName.text.toString().trim()
                val newKw = etKw.text.toString().split(",")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                if (newName.isNotEmpty()) {
                    presets[position] = KeywordPreset(newName, newKw)
                    presetAdapter.notifyItemChanged(position)
                    PrefsManager.savePresets(this, presets)
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun showDeletePresetDialog(position: Int) {
        val preset = presets[position]
        AlertDialog.Builder(this)
            .setTitle("프리셋 삭제")
            .setMessage("'${preset.name}' 프리셋을 삭제하시겠습니까?")
            .setPositiveButton("삭제") { _, _ ->
                presets.removeAt(position)
                presetAdapter.notifyItemRemoved(position)
                PrefsManager.savePresets(this, presets)
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun exportLog() {
        val logContent = LogBuffer.read(this)
        if (logContent.isEmpty()) {
            Toast.makeText(this, "저장된 로그가 없습니다", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val logDir = File(filesDir, "logs").apply { mkdirs() }
            val exportFile = File(logDir, "smart_notice_log.txt")
            exportFile.writeText(logContent)

            val uri = FileProvider.getUriForFile(
                this,
                "$packageName.fileprovider",
                exportFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "로그 공유"))
        } catch (e: Exception) {
            Toast.makeText(this, "로그 내보내기 실패: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
