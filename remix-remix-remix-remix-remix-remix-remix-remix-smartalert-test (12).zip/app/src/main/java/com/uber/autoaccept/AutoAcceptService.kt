package com.uber.autoaccept

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.content.ContextCompat
import com.google.android.gms.dynamite.DynamiteModule
import com.google.mlkit.common.MlKitException
import com.google.android.gms.common.moduleinstall.ModuleInstall
import com.google.android.gms.common.moduleinstall.ModuleInstallRequest
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import rikka.shizuku.Shizuku
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import kotlin.math.roundToInt
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

class AutoAcceptService : AccessibilityService() {

    companion object {
        private const val TAG = "UberAutoAccept"
        private const val UBER_DRIVER_PACKAGE = "com.ubercab.driver"
        private const val SIMULATOR_PACKAGE = "com.uber.autoaccept.simulator"
        private const val COOLDOWN_MS = 10000L

        private val ACCEPT_BUTTON_TEXTS = listOf("콜 수락", "콜수락")
        private val DISMISS_BUTTON_TEXTS = listOf("뒤로", "닫기", "Close", "close", "×", "✕", "X")
        private val NORMAL_SCREEN_KEYWORDS = listOf(
            "운행 요청을 찾고 있습니다",
            "운행요청을 찾고 있습니다",
            "운행 명세서",
            "운행명세서",
            "안전 도구 키트",
            "안전 도구키트",
            "안전도구 키트",
            "안전도구키트",
            "맞춤 추천",
            "맞춤추천",
            "오프라인으로 전환할 수 없습니다",
            "오프라인으로 전환"
        )

        @Volatile
        var isRunning: Boolean = false

        @Volatile
        private var instance: AutoAcceptService? = null

        @Volatile
        private var globalMediaPlayer: android.media.MediaPlayer? = null

        @Volatile
        private var globalRingtone: Ringtone? = null

        fun stopSleepAlarm(context: Context? = null) {
            try {
                globalMediaPlayer?.let { mp ->
                    if (mp.isPlaying) {
                        mp.stop()
                    }
                    mp.release()
                }
            } catch (_: Throwable) {}
            globalMediaPlayer = null

            try {
                globalRingtone?.stop()
            } catch (_: Throwable) {}
            globalRingtone = null

            instance?.let { service ->
                try {
                    service.sleepAlarmRingtone?.stop()
                } catch (_: Throwable) {}
                service.sleepAlarmRingtone = null
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val ocrExecutor = Executors.newSingleThreadExecutor()
    private val shizukuExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "ShizukuWorker")
    }

    @Volatile
    private var ocrRecognizerInstance: TextRecognizer? = null

    @Synchronized
    private fun getOcrRecognizer(): TextRecognizer {
        return ocrRecognizerInstance ?: run {
            val appContext = applicationContext ?: this
            try {
                com.google.mlkit.common.sdkinternal.MlKitContext.initializeIfNeeded(appContext)
            } catch (_: Throwable) {}
            TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()).also {
                ocrRecognizerInstance = it
            }
        }
    }

    private var lastAcceptTime = 0L
    private var lastDismissTime = 0L
    private var lastCallCardTime = 0L
    private var callCardFirstSeenAt = 0L
    private var lastHumanDelay = 0L
    private var dismissAttempts = 0
    private var fastPollUntilMs = 0L

    private var pendingAccept = false
    private var pendingDismiss = false
    private var pendingAcceptVerify = false
    private var ocrCaptureInflight = false

    private var currentDismissSeq: Long = 0L
    private var currentDismissTargetFingerprint: String? = null
    private var currentCallSessionSeq: Long = 0L

    private var activeTargetPackage: String = UBER_DRIVER_PACKAGE
    private var bufferedEventCount: Int = 0
    private var callKeywordSeenAtMs: Long = 0L
    private var screenshotPollActive: Boolean = false
    private var savedAcceptRect: Rect? = null
    private var lastForegroundPkg: String? = null
    private var backgroundPollEnabled = false
    private var lastNotForegroundLogTime = 0L
    private var dismissTapFiredAtMs: Long = 0L
    private var dismissEventLogCount: Int = 0
    private var sleepAlarmRingtone: Ringtone? = null
    private var lastDismissSource: String = "NONE"
    private var lastDismissCardBounds: Rect? = null
    private var lastDismissNodeBounds: Rect? = null

    private var lastGateResult: String? = null
    private var lastKeepWarmFailed: Boolean = false
    private var hasLoggedKeepWarmSuccess: Boolean = false

    // 진단 로그 중복 출력 제어 전용 상태 (비즈니스 로직 영향 없음)
    private var lastLoggedDiagFgPkg: String? = null
    private var lastLoggedDiagFgIsUber: Boolean? = null
    private var lastLoggedScanPkg: String? = null
    private var lastLoggedScanRootAvail: Boolean? = null
    private var lastLoggedScanGateResult: String? = null
    private var lastLoggedWatchState: String? = null
    private var lastLoggedUberWindowStatus: String? = null
    private var lastLoggedCallCardState: String? = null
    private var lastLoggedAcceptBtnResult: String? = null
    private var lastAcceptDiagTime = 0L
    private var lastWindowDiagTime = 0L
    private var lastLoggedWindowDiagMap = mutableMapOf<Int, String>()
    private var lastLoggedCandidateMap = mutableMapOf<Int, String>()
    private var lastLoggedSelectWarnMap = mutableMapOf<Int, String>()
    private var lastLoggedWatchEventPkg: String? = null
    private var lastLoggedWatchEventType: Int? = null
    private var lastLoggedWatchPollTime: Long = 0L
    private var lastLoggedSparseOcrState: Boolean = false
    private var lastCallCardFoundTime: Long = 0L
    private var lastDetectDiagLogTime = 0L
    private var lastDetectDiagGate: String? = null

    // Scan Coordinator state for non-blocking execution and duplicate scan suppression
    private var isScanRunning = false
    private var lastScanFinishTime = 0L
    @Volatile
    private var isRecheckActive = false
    private var recheckToken = 0L

    sealed class CardClassificationState {
        object NoCard : CardClassificationState()
        data class OneCardConfirmed(val card: CallCardCandidate) : CardClassificationState()
        data class MultiCardConfirmed(val cards: List<CallCardCandidate>) : CardClassificationState()
        data class CardCountUnknown(val reason: String) : CardClassificationState()
    }

    data class CardFingerprint(
        val left: Int,
        val top: Int,
        val width: Int,
        val height: Int,
        val acceptBtnTop: Int,
        val textHash: String
    ) {
        fun toSerialized(): String = "${left}_${top}_${width}_${height}_${acceptBtnTop}_$textHash"

        fun matchesCard(other: CardFingerprint): Boolean {
            if (textHash.isNotEmpty() && other.textHash.isNotEmpty()) {
                return textHash == other.textHash
            }
            val dLeft = abs(left - other.left)
            val dTop = abs(top - other.top)
            val dW = abs(width - other.width)
            val dH = abs(height - other.height)
            val dAccept = abs(acceptBtnTop - other.acceptBtnTop)
            return (dLeft < 60 && dTop < 60 && dW < 60 && dH < 60 && dAccept < 60)
        }

        companion object {
            fun fromSerialized(str: String): CardFingerprint? {
                val parts = str.split("_")
                if (parts.size < 6) return null
                return try {
                    CardFingerprint(
                        left = parts[0].toInt(),
                        top = parts[1].toInt(),
                        width = parts[2].toInt(),
                        height = parts[3].toInt(),
                        acceptBtnTop = parts[4].toInt(),
                        textHash = parts.subList(5, parts.size).joinToString("_")
                    )
                } catch (_: Throwable) {
                    null
                }
            }
        }
    }

    data class CallCardCandidate(
        val containerRect: Rect,
        val acceptBtnRect: Rect,
        val xCloseBtnRect: Rect?,
        val cardText: String,
        val fingerprint: CardFingerprint
    )

    private val recentDismissCache = object : android.util.LruCache<String, Long>(20) {}

    private fun isRecentlyDismissed(fp: CardFingerprint): Boolean {
        val now = System.currentTimeMillis()
        val snapshot = recentDismissCache.snapshot()
        for ((key, timestamp) in snapshot) {
            if (now - timestamp < 400L) {
                val cachedFp = CardFingerprint.fromSerialized(key)
                if (cachedFp != null && cachedFp.matchesCard(fp)) {
                    return true
                }
            }
        }
        return false
    }

    private fun recordRecentDismiss(fp: CardFingerprint) {
        val now = System.currentTimeMillis()
        val key = fp.toSerialized()
        recentDismissCache.put(key, now)
        LogBuffer.diag(this, "DISMISS-CACHE", "registered=$key ttl=400ms")
    }

    private fun classifyCardState(root: AccessibilityNodeInfo): CardClassificationState {
        val candidates = extractCallCardCandidates(root)
        val filtered = candidates.filter { !isRecentlyDismissed(it.fingerprint) }
        val deduplicated = deduplicateCandidates(filtered)

        if (deduplicated.isEmpty()) {
            val hasCardIndicator = findCardIndicator(root)
            val hasAcceptText = ACCEPT_BUTTON_TEXTS.any {
                val list = root.findAccessibilityNodeInfosByText(it)
                val found = !list.isNullOrEmpty()
                list?.forEach { n -> try { n.recycle() } catch (_: Throwable) {} }
                found
            }
            return if (hasCardIndicator || hasAcceptText) {
                CardClassificationState.CardCountUnknown("CARD_SIGNAL_FOUND_BUT_INCOMPLETE_STRUCTURE")
            } else {
                CardClassificationState.NoCard
            }
        }

        if (deduplicated.size == 1) {
            val card = deduplicated.first()
            val dm = resources.displayMetrics
            if (!isValidCardBounds(card.containerRect, dm.widthPixels, dm.heightPixels)) {
                return CardClassificationState.CardCountUnknown("INVALID_SINGLE_CARD_BOUNDS")
            }
            return CardClassificationState.OneCardConfirmed(card)
        }

        val sortedCards = deduplicated.sortedBy { it.containerRect.top }
        for (card in sortedCards) {
            if (card.containerRect.width() < 250 || card.containerRect.height() < 120) {
                return CardClassificationState.CardCountUnknown("INCOMPLETE_MULTI_CARD_BOUNDS")
            }
        }
        return CardClassificationState.MultiCardConfirmed(sortedCards)
    }

    private fun extractCallCardCandidates(root: AccessibilityNodeInfo): List<CallCardCandidate> {
        val list = mutableListOf<CallCardCandidate>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var count = 0
        val dm = resources.displayMetrics
        val screenW = dm.widthPixels
        val screenH = dm.heightPixels

        while (queue.isNotEmpty() && count < 250) {
            val node = queue.removeFirst()
            count++

            val txt = "${node.text ?: ""} ${node.contentDescription ?: ""}"
            val isAccept = ACCEPT_BUTTON_TEXTS.any { txt.contains(it, ignoreCase = true) }
            val vId = node.viewIdResourceName ?: ""
            val isAcceptId = vId.contains("accept", ignoreCase = true) || vId.contains("offer_pill", ignoreCase = true)

            if ((isAccept || isAcceptId) && !isIgnoredBannerNode(node)) {
                val acceptRect = Rect()
                node.getBoundsInScreen(acceptRect)
                if (acceptRect.width() > 0 && acceptRect.height() > 0 && acceptRect.bottom <= screenH + 200) {
                    val container = getCardContainerForFingerprint(node)
                    val containerRect = Rect()
                    container.getBoundsInScreen(containerRect)

                    val finalContainerRect = if (containerRect.width() in 250..screenW && containerRect.height() in 150..1800) {
                        containerRect
                    } else {
                        Rect(
                            acceptRect.left.coerceAtLeast(0),
                            (acceptRect.top - 850).coerceAtLeast(0),
                            acceptRect.right.coerceAtMost(screenW),
                            acceptRect.bottom
                        )
                    }

                    val cardText = collectAllText(container)
                    val textHash = normalizeAndHashCardText(cardText)
                    val fp = CardFingerprint(
                        left = finalContainerRect.left,
                        top = finalContainerRect.top,
                        width = finalContainerRect.width(),
                        height = finalContainerRect.height(),
                        acceptBtnTop = acceptRect.top,
                        textHash = textHash
                    )

                    val xNode = findIconInSubtree(container, acceptRect, finalContainerRect)
                    val xRect = if (xNode != null) {
                        val xr = Rect()
                        xNode.getBoundsInScreen(xr)
                        try { xNode.recycle() } catch (_: Throwable) {}
                        xr
                    } else null

                    list.add(
                        CallCardCandidate(
                            containerRect = finalContainerRect,
                            acceptBtnRect = acceptRect,
                            xCloseBtnRect = xRect,
                            cardText = cardText,
                            fingerprint = fp
                        )
                    )
                }
            }

            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.add(it) }
            }
        }
        return list
    }

    private fun deduplicateCandidates(candidates: List<CallCardCandidate>): List<CallCardCandidate> {
        if (candidates.size <= 1) return candidates
        val result = mutableListOf<CallCardCandidate>()
        for (cand in candidates) {
            val duplicate = result.find { existing ->
                val overlapW = (minOf(existing.containerRect.right, cand.containerRect.right) - maxOf(existing.containerRect.left, cand.containerRect.left)).coerceAtLeast(0)
                val overlapH = (minOf(existing.containerRect.bottom, cand.containerRect.bottom) - maxOf(existing.containerRect.top, cand.containerRect.top)).coerceAtLeast(0)
                val overlapArea = overlapW * overlapH
                val minArea = minOf(existing.containerRect.width() * existing.containerRect.height(), cand.containerRect.width() * cand.containerRect.height())
                val iou = if (minArea > 0) overlapArea.toFloat() / minArea.toFloat() else 0f
                val acceptDy = abs(existing.acceptBtnRect.centerY() - cand.acceptBtnRect.centerY())
                iou >= 0.70f || acceptDy < 40
            }
            if (duplicate == null) {
                result.add(cand)
            }
        }
        return result
    }

    private fun normalizeAndHashCardText(rawText: String): String {
        val normalized = rawText
            .replace("\\d+\\s*(초|s|sec)".toRegex(RegexOption.IGNORE_CASE), "")
            .replace("\\d+\\s*분\\s*(거리|뒤)".toRegex(), "")
            .replace("\\d+(\\.\\d+)?\\s*km(\\s*남음)?".toRegex(RegexOption.IGNORE_CASE), "")
            .replace("[^가-힣a-zA-Z0-9]".toRegex(), "")
            .trim()
        return if (normalized.isNotEmpty()) {
            val digest = java.security.MessageDigest.getInstance("MD5")
            val bytes = digest.digest(normalized.toByteArray())
            bytes.take(8).joinToString("") { "%02x".format(it) }
        } else {
            ""
        }
    }

    private fun matchCardKeyword(text: String, keywords: List<String>): String? {
        if (text.isEmpty()) return null
        val cleanText = text.replace("\\s+".toRegex(), "").replace("[^가-힣a-zA-Z0-9]".toRegex(), "")
        for (kw in keywords) {
            val trimmedKw = kw.trim()
            if (trimmedKw.isEmpty()) continue
            val cleanKw = trimmedKw.replace("\\s+".toRegex(), "").replace("[^가-힣a-zA-Z0-9]".toRegex(), "")
            if (text.contains(trimmedKw, ignoreCase = true) || (cleanKw.isNotEmpty() && cleanText.contains(cleanKw, ignoreCase = true))) {
                return trimmedKw
            }
        }
        return null
    }

    private fun processMultiCardDismiss(root: AccessibilityNodeInfo, cards: List<CallCardCandidate>) {
        if (!isRunning || pendingAccept || pendingDismiss) return
        val sortedCards = cards.sortedBy { it.containerRect.top }
        val topCard = sortedCards.first()

        LogBuffer.diag(
            this,
            "MULTI-CARD",
            "totalCount=${sortedCards.size}\nselected=TOP_CARD\ntop=${topCard.containerRect.top}\nfp=${topCard.fingerprint.toSerialized()}"
        )

        val acceptAll = PrefsManager.isAcceptAll(this)
        val blacklistMode = PrefsManager.isBlacklistMode(this)
        val keywords = PrefsManager.getKeywords(this)

        for ((idx, card) in sortedCards.withIndex()) {
            val cardText = card.cardText
            val matchedKw = matchCardKeyword(cardText, keywords)
            val shouldAccept = when {
                acceptAll -> true
                blacklistMode -> matchedKw == null
                else -> matchedKw != null
            }

            if (shouldAccept) {
                LogBuffer.diag(
                    this,
                    "MULTI-CARD-ACCEPT",
                    "cardIndex=$idx\nmatchedKeyword=${matchedKw ?: "ALL"}\naction=EXECUTE_ACCEPT"
                )
                LogBuffer.log(this, TAG, "🟢 [MULTI-CARD] 카드($idx) 수락 조건 일치 (${matchedKw ?: "전체수락"}) → 즉시 수락 파이프라인 진입")
                val winPkg = root.packageName?.toString() ?: UBER_DRIVER_PACKAGE
                val cardKey = "multi_accept_${winPkg}_${System.currentTimeMillis()}"
                pendingAccept = true
                executeAcceptWithRequery(
                    initialRect = card.acceptBtnRect,
                    winPkg = winPkg,
                    cardKey = cardKey,
                    ocrMatchTimestamp = System.currentTimeMillis(),
                    delayCompleteTimestamp = System.currentTimeMillis(),
                    source = "MULTI_CARD_PRIORITY"
                )
                return
            }
        }

        val autoDismiss = PrefsManager.isAutoDismiss(this)
        if (!autoDismiss) {
            LogBuffer.diag(this, "MULTI-DISMISS", "autoDismiss=false -> skipping dismiss")
            return
        }

        recordRecentDismiss(topCard.fingerprint)

        val (tx, ty) = if (topCard.xCloseBtnRect != null && !topCard.xCloseBtnRect.isEmpty) {
            Pair(topCard.xCloseBtnRect.centerX(), topCard.xCloseBtnRect.centerY())
        } else {
            val fbX = (topCard.containerRect.right - 106).coerceIn(50, resources.displayMetrics.widthPixels - 10)
            val fbY = (topCard.containerRect.top + 78).coerceIn(50, resources.displayMetrics.heightPixels - 50)
            Pair(fbX, fbY)
        }

        LogBuffer.diag(
            this,
            "MULTI-DISMISS",
            "action=X_TOUCH\ntarget=TOP_CARD\nx=$tx\ny=$ty\nfp=${topCard.fingerprint.toSerialized()}"
        )
        LogBuffer.log(this, TAG, "🔴 [MULTI-CARD] 최상단 카드 닫기 실행: ($tx, $ty) fp=${topCard.fingerprint.toSerialized()}")

        showTapIndicator(tx, ty, false)
        shizukuExecutor.execute {
            val shizOk = shizukuTap(tx, ty)
            LogBuffer.diag(this@AutoAcceptService, "CANCEL-CLICK-RESULT", "success=$shizOk\nresult=$shizOk")
            if (!shizOk && Build.VERSION.SDK_INT >= 24) {
                handler.post {
                    val path = Path().apply { moveTo(tx.toFloat(), ty.toFloat()) }
                    val stroke = GestureDescription.StrokeDescription(path, 0L, 80L)
                    val gesture = GestureDescription.Builder().addStroke(stroke).build()
                    dispatchGesture(gesture, null, null)
                }
            }
        }

        handler.postDelayed({
            verifyMultiCardDismiss(topCard.fingerprint)
        }, 400L)
    }

    private fun verifyMultiCardDismiss(targetFp: CardFingerprint) {
        if (!isRunning || pendingAccept) return
        val root = findUberRoot()
        if (root == null) {
            LogBuffer.diag(this, "CARD-VERIFY", "target=${targetFp.toSerialized()}\nresult=ROOT_GONE_DISMISSED")
            scheduleScan(50L)
            return
        }

        try {
            val candidates = extractCallCardCandidates(root)
            val filtered = candidates.filter { !isRecentlyDismissed(it.fingerprint) }
            val matchingTarget = filtered.find { it.fingerprint.matchesCard(targetFp) }

            if (matchingTarget != null) {
                LogBuffer.diag(this, "CARD-VERIFY", "target=${targetFp.toSerialized()}\nresult=CARD_STILL_PRESENT")
                LogBuffer.log(this, TAG, "⚠️ [MULTI-CARD] 닫기 검증: 대상 카드 잔존 → 재탐색 예약")
                scheduleScan(100L)
            } else {
                LogBuffer.diag(this, "CARD-VERIFY", "target=${targetFp.toSerialized()}\nresult=DISMISS_SUCCESS")
                LogBuffer.log(this, TAG, "✅ [MULTI-CARD] 닫기 검증: 대상 카드 소멸 확인 → 다음 카드 탐색")
                scheduleScan(50L)
            }
        } finally {
            try { root.recycle() } catch (_: Throwable) {}
        }
    }

    private fun scheduleScan(delayMs: Long) {
        handler.postDelayed({
            if (isRunning && !pendingAccept && !pendingDismiss) {
                dispatchScan("SCHEDULED_RECHECK")
            }
        }, delayMs)
    }

    private fun dispatchScan(source: String) {
        if (!isRunning || pendingAccept || pendingDismiss) return
        if (isScanRunning) return
        val now = System.currentTimeMillis()
        if (source == "POLL" && (now - lastScanFinishTime < 70L)) {
            return
        }
        isScanRunning = true
        try {
            val card = findCallCard(source = source)
            if (card != null) {
                val (root, btn) = card
                try {
                    processWindow(root, btn)
                } finally {
                    try { root.recycle() } catch (_: Throwable) {}
                }
            }
        } finally {
            isScanRunning = false
            lastScanFinishTime = System.currentTimeMillis()
        }
    }

    enum class OcrState {
        INITIALIZING,
        READY,
        MODEL_UNAVAILABLE,
        DETECTOR_INIT_FAILED,
        RETRY_WAIT
    }

    @Volatile
    private var currentOcrState: OcrState = OcrState.INITIALIZING
    private var lastOcrStateLogged: OcrState? = null
    private var lastStateLogMsg: String = ""
    private var lastOcrFailTime: Long = 0L
    private val ocrRecreateCooldownMs: Long = 15000L

    private fun setOcrState(newState: OcrState, detail: String = "") {
        currentOcrState = newState
        val logMsg = if (detail.isNotEmpty()) "[ML-KIT-STATE] ${newState.name} - $detail" else "[ML-KIT-STATE] ${newState.name}"
        if (lastOcrStateLogged != newState || lastStateLogMsg != detail) {
            lastOcrStateLogged = newState
            lastStateLogMsg = detail
            Log.i(TAG, logMsg)
            LogBuffer.log(this, TAG, logMsg)
            LogBuffer.diag(this, "ML-KIT-STATE", "state=${newState.name}, detail=$detail")
        }
    }

    private val xBtnTemplates = mutableListOf<TemplateData>()
    private val acceptBtnTemplates = mutableListOf<TemplateData>()

    private val acceptTimeoutRunnable = Runnable {
        if (pendingAccept) {
            Log.w(TAG, "수락 안전 타임아웃 → 상태 리셋")
            LogBuffer.diag(this, "ACCEPT-FAIL", "수락 타임아웃(5초) 리셋")
            pendingAccept = false
        }
    }

    private val dismissTimeoutRunnable = Runnable {
        if (pendingDismiss) {
            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "TIMEOUT\n" +
                "seq=$currentDismissSeq\n" +
                "currentSeq=$currentDismissSeq\n" +
                "pendingDismiss=$pendingDismiss\n" +
                "dismissAttempts=$dismissAttempts\n" +
                "lastDismissTime=$lastDismissTime"
            )
            Log.w(TAG, "거절 안전 타임아웃 → 상태 리셋")
            LogBuffer.diag(this, "DISMISS-FAIL", "거절 타임아웃(3초) 리셋")
            pendingDismiss = false
            dismissAttempts = 0
        }
    }

    private val ocrCaptureWatchdog = Runnable {
        if (ocrCaptureInflight) {
            Log.w(TAG, "워치독: OCR 캡처 대기 3초 경과 → 리셋")
            ocrCaptureInflight = false
        }
    }

    private val pollRunnable = object : Runnable {
        override fun run() {
            if (!isRunning) return
            val active = PrefsManager.isActive(this@AutoAcceptService)
            if (active && !pendingAccept && !pendingDismiss) {
                val now = System.currentTimeMillis()
                if (now - lastLoggedWatchPollTime > 60000L) {
                    lastLoggedWatchPollTime = now
                    LogBuffer.diag(this@AutoAcceptService, "WATCH-POLL", "interval=100ms\nmode=ALWAYS_ON")
                }
                dispatchScan("POLL")
            }
            val delay = if (System.currentTimeMillis() < fastPollUntilMs) 80L else 100L
            handler.postDelayed(this, delay)
        }
    }

    private val screenshotPollRunnable = object : Runnable {
        override fun run() {
            if (!isRunning) return
            if (PrefsManager.isActive(this@AutoAcceptService) && PrefsManager.isOcrPoll(this@AutoAcceptService)) {
                doScreenshotPoll()
            }
            val delay = if (PrefsManager.isAirportMode(this@AutoAcceptService)) {
                Random.nextLong(200L, 300L)
            } else {
                gaussianDelay(350L, 40L, 250L, 500L)
            }
            handler.postDelayed(this, delay)
        }
    }

    private val keepWarmRunnable = object : Runnable {
        override fun run() {
            if (!isRunning) return
            try {
                val dummyBitmap = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
                val inputImage = InputImage.fromBitmap(dummyBitmap, 0)
                val recognizer = try { getOcrRecognizer() } catch (_: Throwable) { null }
                if (recognizer != null) {
                    recognizer.process(inputImage)
                        .addOnSuccessListener {
                            Log.i(TAG, "MLKit 워밍업 더미OCR 완료")
                            LogBuffer.diag(this@AutoAcceptService, "MLKIT-WARM", "MLKit 워밍업 더미OCR 완료")
                        }
                        .addOnFailureListener { e ->
                            Log.w(TAG, "MLKit 워밍업 실패: ${e.message}")
                            LogBuffer.diag(this@AutoAcceptService, "MLKIT-WARM", "MLKit 워밍업 실패: ${e.message}")
                            logMlKitDetailedDiagnostic(e)
                        }
                        .addOnCompleteListener {
                            try {
                                dummyBitmap.recycle()
                            } catch (_: Throwable) {}
                        }
                } else {
                    try {
                        dummyBitmap.recycle()
                    } catch (_: Throwable) {}
                }
            } catch (e: Exception) {
                Log.w(TAG, "MLKit 워밍업 실패: ${e.message}")
                LogBuffer.diag(this@AutoAcceptService, "MLKIT-WARM", "MLKit 워밍업 실패: ${e.message}")
                logMlKitDetailedDiagnostic(e)
            } finally {
                if (isRunning) {
                    handler.postDelayed(this, 540000L)
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        isRunning = true
        savedAcceptRect = PrefsManager.loadLastAcceptRect(this)
        loadXBtnTemplates()
        loadAcceptBtnTemplates()
        setOcrState(OcrState.READY, "접근성 서비스 연결됨 ✓")
        handler.post(pollRunnable)
        handler.post(screenshotPollRunnable)
        handler.postDelayed(keepWarmRunnable, 15000L)
        LogBuffer.diag(this, "SERVICE", "접근성 서비스 연결됨 ✓")
    }

    override fun onDestroy() {
        super.onDestroy()
        stopSleepAlarm(this)
        instance = null
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        closeOcrRecognizer("SERVICE_DESTROY")
        LogBuffer.diag(this, "SERVICE", "접근성 서비스 종료")
    }

    override fun onInterrupt() {
        Log.w(TAG, "접근성 서비스 인터럽트됨")
    }

    @Synchronized
    private fun closeOcrRecognizer(reason: String) {
        try {
            ocrRecognizerInstance?.close()
        } catch (_: Throwable) {}
        ocrRecognizerInstance = null
        Log.d(TAG, "TextRecognizer 인스턴스 닫힘 (사유: $reason)")
    }

    fun ensureOcrModuleInstalled(onComplete: ((Boolean) -> Unit)? = null) {
        try {
            val recognizer = getOcrRecognizer()
            setOcrState(OcrState.READY, "OCR 준비 완료 ✓")
            onComplete?.invoke(true)
        } catch (e: Throwable) {
            Log.e(TAG, "OCR Recognizer 로드 실패: ${e.message}", e)
            logMlKitDetailedDiagnostic(e)
            onComplete?.invoke(false)
        }
    }

    private fun logMlKitDetailedDiagnostic(e: Throwable, context: Context = this) {
        MlKitComprehensiveDiagnostics.runComprehensiveDiagnostic(context, e)
    }

    private fun isSelfPackage(pkg: String?): Boolean {
        if (pkg == null) return false
        val myPkg = try { packageName } catch (_: Throwable) { "com.uber.autoaccept.test" }
        return pkg == myPkg ||
                pkg == "com.uber.autoaccept.test" ||
                pkg == "com.uber.autoaccept" ||
                (pkg.startsWith("com.uber.autoaccept.") && pkg != SIMULATOR_PACKAGE)
    }

    private fun isTargetPackage(pkg: String?): Boolean {
        if (pkg == null) return false
        if (isSelfPackage(pkg)) return false
        return pkg == UBER_DRIVER_PACKAGE || pkg == SIMULATOR_PACKAGE || pkg.contains("ubercab") || (pkg.contains("uber") && !pkg.contains("autoaccept"))
    }

    private var pendingExitPkg: String? = null
    private var lastTransientLogTime = 0L
    private val uberExitDebounceRunnable = Runnable {
        val winList = try { windows ?: emptyList() } catch (_: Throwable) { emptyList() }
        val hasUberWin = winList.any { win ->
            val p = try { win.root?.packageName?.toString() } catch (_: Throwable) { null }
            isTargetPackage(p)
        }
        val activePkg = try { rootInActiveWindow?.packageName?.toString() } catch (_: Throwable) { null }
        val activeIsUber = isTargetPackage(activePkg)

        if (hasUberWin || activeIsUber) {
            // 우버 윈도우가 화면에 여전히 존재함 -> 이탈 취소 및 포그라운드 우버 상태 유지
            pendingExitPkg = null
            if (backgroundPollEnabled) {
                backgroundPollEnabled = false
                lastForegroundPkg = UBER_DRIVER_PACKAGE
                LogBuffer.log(this@AutoAcceptService, TAG, "📱 우버 복귀(pkg=com.ubercab.driver) → 백그라운드 폴링 OFF")
                LogBuffer.diag(this@AutoAcceptService, "FOREGROUND", "Uber confirmed")
            }
            return@Runnable
        }

        val reallyNonUber = activePkg != null && !isTargetPackage(activePkg) && !isSelfPackage(activePkg) && !activePkg.startsWith("com.android.systemui") && !activePkg.contains("inputmethod")
        val fallbackExit = pendingExitPkg != null && !isTargetPackage(pendingExitPkg)
        if (reallyNonUber || fallbackExit) {
            val targetExitPkg = (if (reallyNonUber) activePkg else pendingExitPkg) ?: "unknown"
            lastForegroundPkg = targetExitPkg
            if (!backgroundPollEnabled) {
                backgroundPollEnabled = true
                LogBuffer.log(this@AutoAcceptService, TAG, "📱 다른 앱 진입(pkg=$targetExitPkg) → 백그라운드 폴링 ON")
                LogBuffer.diag(this@AutoAcceptService, "FOREGROUND", "Uber lost confirmed")
            }
        }
        pendingExitPkg = null
    }

    private fun updateForegroundApp(pkg: String?) {
        if (pkg.isNullOrEmpty()) return
        val isUber = isTargetPackage(pkg)
        if (lastLoggedDiagFgPkg != pkg || lastLoggedDiagFgIsUber != isUber) {
            lastLoggedDiagFgPkg = pkg
            lastLoggedDiagFgIsUber = isUber
            LogBuffer.diag(this, "DIAG-FOREGROUND", "package=$pkg\nisUber=$isUber")
        }
        if (isSelfPackage(pkg)) return
        if (pkg.startsWith("com.android.systemui")) return
        if (pkg.contains("inputmethod")) return

        if (isUber) {
            handler.removeCallbacks(uberExitDebounceRunnable)
            pendingExitPkg = null
            val wasBackground = backgroundPollEnabled || !isTargetPackage(lastForegroundPkg)
            lastForegroundPkg = pkg
            if (wasBackground) {
                backgroundPollEnabled = false
                LogBuffer.log(this, TAG, "📱 우버 복귀(pkg=$pkg) → 백그라운드 폴링 OFF")
                LogBuffer.diag(this, "FOREGROUND", "Uber confirmed")
            }
        } else {
            // 비-우버 패키지 (예: com.sec.android.app.launcher)
            if (isTargetPackage(lastForegroundPkg) && !backgroundPollEnabled) {
                // 현재 우버 포그라운드 상태인 경우 즉시 이탈 처리하지 않고 디바운스(1000ms) 적용
                pendingExitPkg = pkg
                handler.removeCallbacks(uberExitDebounceRunnable)
                handler.postDelayed(uberExitDebounceRunnable, 1000L)
                val now = System.currentTimeMillis()
                if (now - lastTransientLogTime > 5000L) {
                    lastTransientLogTime = now
                    LogBuffer.diag(this, "FOREGROUND", "Ignore transient package=$pkg")
                }
            } else {
                lastForegroundPkg = pkg
                if (!backgroundPollEnabled) {
                    backgroundPollEnabled = true
                    LogBuffer.log(this, TAG, "📱 다른 앱 진입(pkg=$pkg) → 백그라운드 폴링 ON")
                    LogBuffer.diag(this, "FOREGROUND", "Uber lost confirmed")
                }
            }
        }
    }

    private fun isForegroundUber(): Boolean {
        // 1. rootInActiveWindow 패키지 확인
        val activeRootPkg = try { rootInActiveWindow?.packageName?.toString() } catch (_: Throwable) { null }
        if (activeRootPkg != null) {
            if (isSelfPackage(activeRootPkg)) {
                return false
            }
            if (isTargetPackage(activeRootPkg)) {
                updateForegroundApp(activeRootPkg)
                return true
            }
        }

        // 2. windows 목록에서 Uber 윈도우 존재 확인
        val winList = try { windows ?: emptyList() } catch (_: Throwable) { emptyList() }
        val hasUberWin = winList.any { win ->
            val p = try { win.root?.packageName?.toString() } catch (_: Throwable) { null }
            isTargetPackage(p)
        }
        if (hasUberWin) {
            if (backgroundPollEnabled || !isTargetPackage(lastForegroundPkg)) {
                updateForegroundApp(UBER_DRIVER_PACKAGE)
            }
            return true
        }

        // 3. lastForegroundPkg가 Uber이고 백그라운드 미확정(디바운스 중)인 경우
        val currentFg = lastForegroundPkg
        if (currentFg != null && isSelfPackage(currentFg)) {
            return false
        }
        if (isTargetPackage(currentFg) && !backgroundPollEnabled) {
            return true
        }

        return false
    }

    private var lastScanPkg: String? = null
    private var lastScanLogTime = 0L
    private var lastScanDiagLogTime = 0L
    private var lastProcessScanLogTime = 0L
    private var lastNoCallPkg: String? = null
    private var lastNoCallReason: String? = null
    private var lastNoCallLogTime = 0L
    private var noCallRepeatCount = 0
    private var lastSelfSkipLogTime = 0L
    private var lastFalsePosLogTime = 0L
    private var cooldownLogged = false

    private var lastBannerIgnoreLogTime = 0L
    private var lastEventScanTime = 0L
    private var lastDiagEventLogTime = 0L

    private fun logNoCall(pkg: String, reason: String) {
        val now = System.currentTimeMillis()
        if (pkg == lastNoCallPkg && reason == lastNoCallReason) {
            noCallRepeatCount++
            if (now - lastNoCallLogTime > 15000L) {
                lastNoCallLogTime = now
                LogBuffer.diag(this, "NO-CALL", "pkg=$pkg reason=$reason repeatSuppressed=$noCallRepeatCount")
                noCallRepeatCount = 0
            }
        } else {
            if (noCallRepeatCount > 0 && lastNoCallPkg != null) {
                LogBuffer.diag(this, "NO-CALL", "pkg=$lastNoCallPkg reason=$lastNoCallReason repeatSuppressed=$noCallRepeatCount")
            }
            lastNoCallPkg = pkg
            lastNoCallReason = reason
            lastNoCallLogTime = now
            noCallRepeatCount = 0
            LogBuffer.diag(this, "NO-CALL", "pkg=$pkg reason=$reason")
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val eventPkg = event.packageName?.toString() ?: ""
        val eventCls = event.className?.toString() ?: ""
        val isUberPkg = isTargetPackage(eventPkg)

        val isIgnoredPkg = eventPkg == "com.uber.autoaccept.test" ||
                eventPkg.startsWith("com.uber.autoaccept") ||
                eventPkg.startsWith("com.android.systemui") ||
                eventPkg.startsWith("com.android.settings")

        val now = System.currentTimeMillis()
        if (!isIgnoredPkg && eventPkg.isNotEmpty()) {
            val shouldLog = when (event.eventType) {
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> true
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> {
                    val isRepetitiveView = eventCls.endsWith("TextView") ||
                            eventCls.endsWith("ScrollView") ||
                            eventCls.endsWith("RecyclerView") ||
                            eventCls.endsWith("FrameLayout") ||
                            eventCls.endsWith("ImageView")
                    isUberPkg && !isRepetitiveView && (now - lastDiagEventLogTime > 200L)
                }
                else -> isUberPkg
            }
            if (shouldLog) {
                lastDiagEventLogTime = now
                val eventTypeStr = try { AccessibilityEvent.eventTypeToString(event.eventType) } catch (_: Throwable) { event.eventType.toString() }
                if (lastLoggedWatchEventPkg != eventPkg || lastLoggedWatchEventType != event.eventType) {
                    lastLoggedWatchEventPkg = eventPkg
                    lastLoggedWatchEventType = event.eventType
                    LogBuffer.diag(this, "WATCH-EVENT", "eventType=$eventTypeStr\npackage=$eventPkg")
                }
                LogBuffer.diag(this, "DIAG-EVENT", "eventType=$eventTypeStr\npackage=${event.packageName}\nclassName=${event.className}")
            }
        }
        if (!PrefsManager.isActive(this)) return

        if (pendingDismiss && dismissTapFiredAtMs > 0L && dismissEventLogCount < 8) {
            val elapsed = System.currentTimeMillis() - dismissTapFiredAtMs
            val typeStr = AccessibilityEvent.eventTypeToString(event.eventType)
            LogBuffer.log(this, TAG, "📡 닫기대기중 이벤트 +${elapsed}ms type=$typeStr pkg=${event.packageName}")
            dismissEventLogCount++
        }

        val pkg = event.packageName?.toString()
        if (isSelfPackage(pkg)) {
            if (now - lastSelfSkipLogTime > 30000L) {
                lastSelfSkipLogTime = now
                LogBuffer.diag(this, "SCAN-SKIP", "pkg=$pkg reason=self_package")
            }
            return
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || isTargetPackage(pkg)) {
            updateForegroundApp(pkg)
        }

        if (!isTargetPackage(pkg)) {
            return
        }

        bufferedEventCount++
        if (bufferedEventCount >= 20) {
            PrefsManager.incrementEventCount(this, bufferedEventCount)
            bufferedEventCount = 0
        }

        if (pendingAccept || pendingDismiss) {
            return
        }

        // Throttle rapid duplicate CONTENT_CHANGED events
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && (now - lastEventScanTime < 80L)) {
            return
        }
        lastEventScanTime = now

        dispatchScan("ON_EVENT")
    }

    private fun isNormalScreen(root: AccessibilityNodeInfo): Boolean {
        for (kw in NORMAL_SCREEN_KEYWORDS) {
            val nodes = root.findAccessibilityNodeInfosByText(kw)
            if (!nodes.isNullOrEmpty()) {
                for (n in nodes) {
                    try { n.recycle() } catch (_: Throwable) {}
                }
                return true
            }
        }
        return false
    }

    private data class WindowRootCandidate(
        val index: Int,
        val root: AccessibilityNodeInfo,
        val packageName: String,
        val className: String,
        val bounds: Rect,
        val childCount: Int,
        val isTraversable: Boolean,
        val isLeafImageView: Boolean,
        val rejectReason: String?,
        val priorityScore: Int
    )

    private fun evaluateWindowRoot(index: Int, root: AccessibilityNodeInfo): WindowRootCandidate {
        val rootPkg = root.packageName?.toString() ?: "none"
        val rootCls = root.className?.toString() ?: "none"
        val rootRect = Rect().also { root.getBoundsInScreen(it) }
        val rootChildCount = root.childCount
        val isTraversable = rootChildCount > 0
        val isLeafImageView = (rootCls == "android.widget.ImageView" || rootCls.endsWith(".ImageView")) && rootChildCount == 0
        val rejectReason = when {
            isLeafImageView -> "LEAF_IMAGEVIEW_ROOT"
            rootChildCount == 0 -> "LEAF_NODE_CHILD_ZERO"
            else -> null
        }

        val displayMetrics = resources.displayMetrics
        val screenW = displayMetrics.widthPixels
        val screenH = displayMetrics.heightPixels
        val screenArea = (screenW * screenH).toFloat().coerceAtLeast(1f)
        val rootArea = (rootRect.width() * rootRect.height()).toFloat()
        val areaRatio = (rootArea / screenArea).coerceIn(0f, 1f)

        var score = 0
        if (rootChildCount > 0) {
            score += 1000
            score += (rootChildCount * 10).coerceAtMost(500)
        }
        val isViewGroup = rootCls.contains("Layout") || rootCls.contains("ViewGroup") || rootCls.contains("DecorView") || rootCls.contains("View") || rootCls.contains("Compose")
        if (isViewGroup && rootChildCount > 0) {
            score += 500
        }
        val isFullScreen = rootRect.width() >= (screenW * 0.85f) && rootRect.height() >= (screenH * 0.85f)
        if (isFullScreen) {
            score += 3000
        } else {
            score += (areaRatio * 400).toInt()
        }
        if (isLeafImageView) {
            score -= 5000
        } else if (rootChildCount == 0) {
            score -= 2000
        }

        val candidateLogKey = "$rootPkg|$rootCls|$rootRect|$rootChildCount|$isTraversable|${rejectReason ?: "NONE"}|$score"
        if (lastLoggedCandidateMap[index] != candidateLogKey) {
            lastLoggedCandidateMap[index] = candidateLogKey
            LogBuffer.diag(
                this,
                "WINDOW-CANDIDATE",
                "index=$index\n" +
                "package=$rootPkg\n" +
                "class=$rootCls\n" +
                "bounds=$rootRect\n" +
                "childCount=$rootChildCount\n" +
                "isTraversable=$isTraversable\n" +
                "rejectReason=${rejectReason ?: "NONE"}\n" +
                "priorityScore=$score"
            )
        }

        return WindowRootCandidate(
            index = index,
            root = root,
            packageName = rootPkg,
            className = rootCls,
            bounds = rootRect,
            childCount = rootChildCount,
            isTraversable = isTraversable,
            isLeafImageView = isLeafImageView,
            rejectReason = rejectReason,
            priorityScore = score
        )
    }

    private fun findCallCard(source: String = "UNKNOWN"): Pair<AccessibilityNodeInfo, AccessibilityNodeInfo?>? {
        val curPkg = lastForegroundPkg ?: try { rootInActiveWindow?.packageName?.toString() } catch (_: Throwable) { null } ?: "none"
        val rootAvail = try { rootInActiveWindow != null } catch (_: Throwable) { false }
        if (lastLoggedScanPkg != curPkg || lastLoggedScanRootAvail != rootAvail || lastLoggedScanGateResult != lastGateResult) {
            lastLoggedScanPkg = curPkg
            lastLoggedScanRootAvail = rootAvail
            lastLoggedScanGateResult = lastGateResult
            LogBuffer.diag(this, "DIAG-SCAN-ENTER", "package=$curPkg\nrootAvailable=$rootAvail")
        }

        var hadIndicatorOnly = false
        var hasUberWindow = false
        var allNormalScreen = true

        val allWindows = windows ?: emptyList()

        // [WINDOW-DIAG] 모든 Window 순회 진단 로그 기록 (300ms throttle 또는 콜카드 탐색 시, 상태 변경 시만 출력)
        val nowWinMs = System.currentTimeMillis()
        val shouldLogWinDiag = nowWinMs - lastWindowDiagTime > 300L
        if (shouldLogWinDiag && allWindows.isNotEmpty()) {
            lastWindowDiagTime = nowWinMs
            val displayMetrics = resources.displayMetrics
            val fullScreenWidth = displayMetrics.widthPixels
            val fullScreenHeight = displayMetrics.heightPixels

            for ((wIdx, win) in allWindows.withIndex()) {
                val wRoot = try { win.root } catch (_: Throwable) { null }
                val wPkg = wRoot?.packageName?.toString() ?: "none"
                val wCls = wRoot?.className?.toString() ?: "none"
                val wBounds = Rect().also { if (wRoot != null) it.let { rect -> wRoot.getBoundsInScreen(rect) } }
                val wChildCount = wRoot?.childCount ?: 0
                val wRootAvail = (wRoot != null)
                val wTitle = try { win.title?.toString() ?: "none" } catch (_: Throwable) { "none" }
                val wType = try { win.type } catch (_: Throwable) { -1 }
                val wLayer = try { win.layer } catch (_: Throwable) { -1 }
                val wActive = try { win.isActive } catch (_: Throwable) { false }
                val wFocused = try { win.isFocused } catch (_: Throwable) { false }

                val winDiagKey = "$wType|$wLayer|$wActive|$wFocused|$wPkg|$wTitle|$wRootAvail|$wCls|$wBounds|$wChildCount"
                if (lastLoggedWindowDiagMap[wIdx] != winDiagKey) {
                    lastLoggedWindowDiagMap[wIdx] = winDiagKey
                    LogBuffer.diag(
                        this,
                        "WINDOW-DIAG",
                        "index=$wIdx\n" +
                        "type=$wType\n" +
                        "layer=$wLayer\n" +
                        "isActive=$wActive\n" +
                        "isFocused=$wFocused\n" +
                        "packageName=$wPkg\n" +
                        "title=$wTitle\n" +
                        "rootAvailable=$wRootAvail\n" +
                        "rootClass=$wCls\n" +
                        "rootBounds=$wBounds\n" +
                        "rootChildCount=$wChildCount"
                    )
                }

                if (isTargetPackage(wPkg)) {
                    val isFullScreenCandidate = wBounds.width() >= (fullScreenWidth * 0.85f) &&
                            wBounds.height() >= (fullScreenHeight * 0.85f) &&
                            wChildCount > 0
                    if (isFullScreenCandidate) {
                        val fsCandKey = "$wCls|$wBounds|$wChildCount|true"
                        val fsLogKey = "FS_$wIdx"
                        if (lastLoggedCandidateMap[wIdx + 1000] != fsCandKey) {
                            lastLoggedCandidateMap[wIdx + 1000] = fsCandKey
                            LogBuffer.diag(
                                this,
                                "WINDOW-CANDIDATE",
                                "index=$wIdx\n" +
                                "class=$wCls\n" +
                                "bounds=$wBounds\n" +
                                "childCount=$wChildCount\n" +
                                "isFullScreenCandidate=true"
                            )
                        }
                    }
                }
                if (wRoot != null) {
                    try { wRoot.recycle() } catch (_: Throwable) {}
                }
            }
        }

        // [ROOT-SELECT] 1차 순회: windows에서 com.ubercab.driver Window 우선 획득 및 우선순위 평가
        val candidates = mutableListOf<WindowRootCandidate>()
        for ((index, window) in allWindows.withIndex()) {
            val root = try { window.root } catch (e: Exception) { null } ?: continue
            val rootPkg = root.packageName?.toString()
            if (isSelfPackage(rootPkg) || !isTargetPackage(rootPkg)) {
                try { root.recycle() } catch (_: Throwable) {}
                continue
            }
            hasUberWindow = true
            val cand = evaluateWindowRoot(index, root)
            if (cand.isLeafImageView) {
                val warnKey = "LEAF_IMAGEVIEW_ROOT|${cand.bounds}|${cand.childCount}"
                if (lastLoggedSelectWarnMap[index] != warnKey) {
                    lastLoggedSelectWarnMap[index] = warnKey
                    LogBuffer.diag(
                        this,
                        "WINDOW-SELECT-WARN",
                        "reason=LEAF_IMAGEVIEW_ROOT\n" +
                        "index=$index\n" +
                        "bounds=${cand.bounds}\n" +
                        "childCount=${cand.childCount}"
                    )
                }
                try { cand.root.recycle() } catch (_: Throwable) {}
            } else {
                candidates.add(cand)
            }
        }

        val sortedCandidates = candidates.sortedByDescending { it.priorityScore }

        for (cand in sortedCandidates) {
            val root = cand.root
            val rootPkg = cand.packageName
            val rootCls = cand.className
            val rootRect = cand.bounds
            val rootChildCount = cand.childCount
            val index = cand.index

            val btn = findAcceptButton(root)
            if (btn != null) {
                isRecheckActive = false
                recheckToken++
                lastCallCardFoundTime = System.currentTimeMillis()
                lastGateResult = "FOUND"
                if (lastLoggedCallCardState != "FOUND") {
                    lastLoggedCallCardState = "FOUND"
                    LogBuffer.diag(this, "CALL-CARD", "state=FOUND\nsource=$source")
                }
                val bRect = Rect()
                btn.getBoundsInScreen(bRect)
                val candidateText = btn.text?.toString()?.trim() ?: btn.contentDescription?.toString()?.trim() ?: "콜 수락"
                LogBuffer.diag(this, "ROOT-SELECT", "source=UBER_WINDOW\npackage=$rootPkg\nwindowIndex=$index")
                LogBuffer.diag(this, "CALL-CARD-FOUND", "attempt=0\nsource=$source")
                LogBuffer.diag(this, "CALL-CARD-GATE", "keyword=$candidateText result=FOUND acceptCandidate=$candidateText source=$source windowIndex=$index rootPkg=$rootPkg text='${btn.text}' bounds=$bRect")
                
                LogBuffer.diag(
                    this,
                    "WINDOW-SELECT",
                    "selectedIndex=$index\n" +
                    "selectedPackage=$rootPkg\n" +
                    "selectedClass=$rootCls\n" +
                    "selectedBounds=$rootRect\n" +
                    "selectedChildCount=$rootChildCount\n" +
                    "selectionReason=WINDOW_LIST_ITERATION"
                )
                LogBuffer.diag(
                    this,
                    "WINDOW-ROOT-VERIFY",
                    "package=$rootPkg\n" +
                    "class=$rootCls\n" +
                    "childCount=$rootChildCount\n" +
                    "traversable=true"
                )

                activeTargetPackage = rootPkg
                Log.d(TAG, "콜카드 수락 노드 발견 — 창 패키지: ${root.packageName}, 텍스트: '${btn.text}'")

                for (other in sortedCandidates) {
                    if (other != cand) {
                        try { other.root.recycle() } catch (_: Throwable) {}
                    }
                }
                return Pair(root, btn)
            }

            if (isNormalScreen(root)) {
                continue
            }
            allNormalScreen = false

            if (findCardIndicator(root)) {
                hadIndicatorOnly = true
            }
        }

        for (cand in sortedCandidates) {
            try { cand.root.recycle() } catch (_: Throwable) {}
        }

        val root = try { rootInActiveWindow } catch (e: Exception) { null }
        if (root != null) {
            val fallbackPkg = root.packageName?.toString()
            if (!isSelfPackage(fallbackPkg) && isTargetPackage(fallbackPkg)) {
                val cand = evaluateWindowRoot(-1, root)
                if (!cand.isLeafImageView) {
                    hasUberWindow = true

                    val fbRootRect = cand.bounds
                    val fbRootCls = cand.className
                    val fbRootChildCount = cand.childCount

                    val btn = findAcceptButton(root)
                    if (btn != null) {
                        isRecheckActive = false
                        recheckToken++
                        lastCallCardFoundTime = System.currentTimeMillis()
                        lastGateResult = "FOUND"
                        if (lastLoggedCallCardState != "FOUND") {
                            lastLoggedCallCardState = "FOUND"
                            LogBuffer.diag(this, "CALL-CARD", "state=FOUND\nsource=$source")
                        }
                        val bRect = Rect()
                        btn.getBoundsInScreen(bRect)
                        val candidateText = btn.text?.toString()?.trim() ?: btn.contentDescription?.toString()?.trim() ?: "콜 수락"
                        LogBuffer.diag(this, "ROOT-SELECT", "source=ROOT_IN_ACTIVE_WINDOW\npackage=$fallbackPkg")
                        LogBuffer.diag(this, "CALL-CARD-FOUND", "attempt=0\nsource=$source")
                        LogBuffer.diag(this, "CALL-CARD-GATE", "keyword=$candidateText result=FOUND acceptCandidate=$candidateText source=$source rootPkg=$fallbackPkg text='${btn.text}' bounds=$bRect")

                        LogBuffer.diag(
                            this,
                            "WINDOW-SELECT",
                            "selectedIndex=-1\n" +
                            "selectedPackage=$fallbackPkg\n" +
                            "selectedClass=$fbRootCls\n" +
                            "selectedBounds=$fbRootRect\n" +
                            "selectedChildCount=$fbRootChildCount\n" +
                            "selectionReason=ROOT_IN_ACTIVE_WINDOW_FALLBACK"
                        )
                        LogBuffer.diag(
                            this,
                            "WINDOW-ROOT-VERIFY",
                            "package=$fallbackPkg\n" +
                            "class=$fbRootCls\n" +
                            "childCount=$fbRootChildCount\n" +
                            "traversable=true"
                        )

                        activeTargetPackage = fallbackPkg ?: UBER_DRIVER_PACKAGE
                        Log.d(TAG, "콜카드 수락 노드 발견 — rootInActiveWindow ($fallbackPkg), 텍스트: '${btn.text}'")
                        return Pair(root, btn)
                    }

                    if (!isNormalScreen(root)) {
                        allNormalScreen = false
                        if (findCardIndicator(root)) {
                            hadIndicatorOnly = true
                        }
                    }
                } else {
                    val warnKey = "LEAF_IMAGEVIEW_ROOT|${cand.bounds}|${cand.childCount}"
                    if (lastLoggedSelectWarnMap[-1] != warnKey) {
                        lastLoggedSelectWarnMap[-1] = warnKey
                        LogBuffer.diag(
                            this,
                            "WINDOW-SELECT-WARN",
                            "reason=LEAF_IMAGEVIEW_ROOT\n" +
                            "index=-1\n" +
                            "bounds=${cand.bounds}\n" +
                            "childCount=${cand.childCount}"
                        )
                    }
                }
            }
            try { root.recycle() } catch (_: Throwable) {}
        }

        if (allNormalScreen && hasUberWindow) {
            lastCallCardFoundTime = 0L
        }

        val now = System.currentTimeMillis()
        val inGracePeriod = (now - lastCallCardFoundTime < 800L) && lastCallCardFoundTime > 0L

        if (inGracePeriod && hasUberWindow && !allNormalScreen && savedAcceptRect != null) {
            val retainedRoot = findUberRoot() ?: try { rootInActiveWindow } catch (_: Throwable) { null }
            if (retainedRoot != null && !isSelfPackage(retainedRoot.packageName?.toString())) {
                if (lastLoggedCallCardState != "FOUND") {
                    lastLoggedCallCardState = "FOUND"
                    LogBuffer.diag(this, "CALL-CARD", "state=FOUND\nsource=$source")
                }
                lastGateResult = "FOUND"
                LogBuffer.diag(this, "STATE-RETENTION", "previous=FOUND\ncurrent=FOUND\nreason=ACCESSIBILITY_NODE_MISS_RETAINED\ngraceUntil=${lastCallCardFoundTime + 800L}")
                LogBuffer.diag(this, "CALL-CARD-GATE", "keyword=콜 수락 result=FOUND acceptCandidate=콜 수락 source=$source retained=true savedAcceptRect=$savedAcceptRect")
                return Pair(retainedRoot, null)
            }
        }

        if (inGracePeriod && lastLoggedCallCardState == "FOUND") {
            LogBuffer.diag(this, "STATE-RETENTION", "previous=FOUND\ncurrent=NOT_FOUND\nreason=ACCESSIBILITY_NODE_MISS\ngraceUntil=${lastCallCardFoundTime + 800L}")
        }

        val winStatus = if (hasUberWindow) "FOUND" else "NOT_FOUND"
        if (lastLoggedUberWindowStatus != winStatus) {
            lastLoggedUberWindowStatus = winStatus
            LogBuffer.diag(this, "UBER-WINDOW", "status=$winStatus\npackage=$UBER_DRIVER_PACKAGE\nrootAvailable=$rootAvail")
        }

        // [CALL-CARD-DETECT-DIAG] 평상시 정상 대기 화면이 아니거나 Indicator 감지 시 화면 텍스트 후보 진단 로그 기록 (최대 5개)
        if (hasUberWindow && (!allNormalScreen || hadIndicatorOnly)) {
            val nowMs = System.currentTimeMillis()
            if (nowMs - lastDetectDiagLogTime > 400L || lastDetectDiagGate != lastGateResult) {
                lastDetectDiagLogTime = nowMs
                lastDetectDiagGate = lastGateResult

                // [CALL-CARD-NODE-DIAG] 모든 Uber Window의 구조 상세 진단 기록
                for ((wIdx, win) in allWindows.withIndex()) {
                    val wRoot = try { win.root } catch (_: Throwable) { null } ?: continue
                    val wPkg = wRoot.packageName?.toString()
                    if (isTargetPackage(wPkg) && !isSelfPackage(wPkg)) {
                        val wRootRect = Rect().also { wRoot.getBoundsInScreen(it) }
                        LogBuffer.diag(
                            this,
                            "CALL-CARD-NODE-DIAG",
                            "windowIndex=$wIdx\nwindowCount=${allWindows.size}\nrootPackage=$wPkg\nrootClass=${wRoot.className}\nrootBounds=$wRootRect\nchildCount=${wRoot.childCount}"
                        )
                        // [CALL-CARD-CANDIDATE] 콜카드 관련 가능성 높은 노드(클릭 가능, 텍스트/desc 존재, 버튼, 수락/요청/운행 관련) 선별 로그
                        val cQueue = ArrayDeque<Pair<AccessibilityNodeInfo, String>>()
                        cQueue.add(Pair(wRoot, "none"))
                        var loggedCandidateCount = 0
                        while (cQueue.isNotEmpty() && loggedCandidateCount < 10) {
                            val (cNode, parentCls) = cQueue.removeFirst()
                            val cTxt = cNode.text?.toString()?.trim()
                            val cDesc = cNode.contentDescription?.toString()?.trim()
                            val cCls = cNode.className?.toString() ?: ""
                            val isBtnOrClick = cNode.isClickable || cCls.contains("Button", ignoreCase = true) || cCls.contains("Image", ignoreCase = true)
                            val hasTextOrDesc = !cTxt.isNullOrEmpty() || !cDesc.isNullOrEmpty()
                            val combinedStr = "${cTxt ?: ""} ${cDesc ?: ""}"
                            val hasKeyWords = listOf("수락", "거절", "운행", "요청", "콜", "픽업", "하차", "거리", "분").any { combinedStr.contains(it) }

                            if (hasTextOrDesc && (isBtnOrClick || hasKeyWords || cNode.childCount == 0)) {
                                val cBounds = Rect().also { cNode.getBoundsInScreen(it) }
                                LogBuffer.diag(
                                    this,
                                    "CALL-CARD-CANDIDATE",
                                    "windowIndex=$wIdx\nclassName=$cCls\ntext='${cTxt ?: "null"}'\ndesc='${cDesc ?: "null"}'\nviewId=${cNode.viewIdResourceName ?: "null"}\nclickable=${cNode.isClickable}\nenabled=${cNode.isEnabled}\nvisibleToUser=${cNode.isVisibleToUser}\nbounds=$cBounds\nparentClass=$parentCls"
                                )
                                loggedCandidateCount++
                            }

                            val curCls = cCls
                            for (ci in 0 until cNode.childCount) {
                                val child = try { cNode.getChild(ci) } catch (_: Throwable) { null }
                                if (child != null) {
                                    cQueue.add(Pair(child, curCls))
                                }
                            }
                            if (cNode != wRoot) {
                                try { cNode.recycle() } catch (_: Throwable) {}
                            }
                        }
                        while (cQueue.isNotEmpty()) {
                            val (remNode, _) = cQueue.removeFirst()
                            if (remNode != wRoot) {
                                try { remNode.recycle() } catch (_: Throwable) {}
                            }
                        }
                    }
                    try { wRoot.recycle() } catch (_: Throwable) {}
                }

                val diagRoot = findUberRoot()
                if (diagRoot != null) {
                    try {
                        val diagBtn = findAcceptButton(diagRoot)
                        val hasAccept = (diagBtn != null)
                        val acceptText = if (diagBtn != null) (diagBtn.text?.toString()?.trim() ?: diagBtn.contentDescription?.toString()?.trim() ?: "콜 수락") else "none"
                        val candidates = extractCandidateTexts(diagRoot, 5)
                        val rootPkg = diagRoot.packageName?.toString() ?: UBER_DRIVER_PACKAGE
                        LogBuffer.diag(
                            this,
                            "CALL-CARD-DETECT-DIAG",
                            "timestamp=$nowMs\nwindowCount=${allWindows.size}\nrootPackage=$rootPkg\nrootAvailable=true\nhasAcceptNode=$hasAccept\nacceptNodeText='$acceptText'\ncandidateTexts=${candidates.joinToString(prefix = "[", postfix = "]") { "'$it'" }}"
                        )
                        try { diagBtn?.recycle() } catch (_: Throwable) {}
                    } finally {
                        try { diagRoot.recycle() } catch (_: Throwable) {}
                    }
                }
            }
        }

        // [CALL-CARD-RECHECK] 실제 콜카드 Indicator(hadIndicatorOnly) 감지 또는 이벤트 기반 비정상 대기 화면(초기 백지 프레임) 시 30ms -> 50ms 최신 Root 2회 재검증 실행
        val isBlankCardFrame = source == "ON_EVENT" && hasUberWindow && !allNormalScreen
        if (hadIndicatorOnly || isBlankCardFrame) {
            val gateState = if (hadIndicatorOnly) "INDICATOR_WAIT" else "BLANK_FRAME_WAIT"
            if (lastGateResult != gateState) {
                lastGateResult = gateState
                LogBuffer.diag(this, "CALL-CARD-GATE", "state=$gateState\nsource=$source")
            }
            val triggerReason = if (hadIndicatorOnly) "INDICATOR_DETECTED" else "BLANK_FRAME_DETECTED"
            scheduleCallCardRecheck(triggerReason)
        } else {
            if (lastGateResult != "NO_INDICATOR") {
                lastGateResult = "NO_INDICATOR"
                LogBuffer.diag(this, "CALL-CARD-GATE", "state=NO_INDICATOR\nsource=$source")
            }
        }
        if (lastLoggedCallCardState != "NOT_FOUND" && !inGracePeriod) {
            lastLoggedCallCardState = "NOT_FOUND"
            LogBuffer.diag(this, "CALL-CARD", "state=NOT_FOUND\nsource=$source")
        }
        return null
    }

    private fun scheduleCallCardRecheck(triggerReason: String) {
        if (isRecheckActive || pendingAccept || pendingDismiss || !isRunning) return
        isRecheckActive = true
        val currentToken = ++recheckToken

        LogBuffer.diag(this, "CALL-CARD-RECHECK", "trigger=$triggerReason\nattempt=1\ndelay=30ms")

        handler.postDelayed({
            if (!isRunning || pendingAccept || pendingDismiss || currentToken != recheckToken) {
                isRecheckActive = false
                return@postDelayed
            }

            val root1 = findUberRoot()
            val btn1 = if (root1 != null) findAcceptButton(root1) else null
            val nodeFound1 = (btn1 != null)
            LogBuffer.diag(this, "CALL-CARD-RECHECK-RESULT", "attempt=1\nnode=${if (nodeFound1) "FOUND" else "NOT_FOUND"}")

            if (btn1 != null && root1 != null) {
                isRecheckActive = false
                lastCallCardFoundTime = System.currentTimeMillis()
                lastGateResult = "FOUND"
                if (lastLoggedCallCardState != "FOUND") {
                    lastLoggedCallCardState = "FOUND"
                    LogBuffer.diag(this, "CALL-CARD", "state=FOUND\nsource=RECHECK_30MS")
                }
                val bRect = Rect()
                btn1.getBoundsInScreen(bRect)
                val candidateText = btn1.text?.toString()?.trim() ?: btn1.contentDescription?.toString()?.trim() ?: "콜 수락"
                LogBuffer.diag(this, "CALL-CARD-FOUND", "attempt=1\nsource=RECHECK_30MS")
                LogBuffer.diag(this, "CALL-CARD-GATE", "keyword=$candidateText result=FOUND acceptCandidate=$candidateText source=RECHECK_30MS rootPkg=${root1.packageName} text='${btn1.text}' bounds=$bRect")
                LogBuffer.diag(this, "ACCEPT-MATCH", "matched=$candidateText\nsource=ACCESSIBILITY")
                activeTargetPackage = root1.packageName?.toString() ?: UBER_DRIVER_PACKAGE
                try {
                    processWindow(root1, btn1)
                } finally {
                    try { root1.recycle() } catch (_: Throwable) {}
                }
            } else {
                if (root1 != null) {
                    val candidates1 = extractCandidateTexts(root1, 5)
                    LogBuffer.diag(
                        this,
                        "CALL-CARD-RECHECK-DIAG",
                        "attempt=1\nrootPackage=${root1.packageName}\nrootAvailable=true\nhasAcceptNode=false\ncandidateTexts=${candidates1.joinToString(prefix = "[", postfix = "]") { "'$it'" }}"
                    )
                }
                try { root1?.recycle() } catch (_: Throwable) {}

                // 2차 재검증: 50ms 후
                LogBuffer.diag(this, "CALL-CARD-RECHECK", "trigger=$triggerReason\nattempt=2\ndelay=50ms")

                handler.postDelayed({
                    if (!isRunning || pendingAccept || pendingDismiss || currentToken != recheckToken) {
                        isRecheckActive = false
                        return@postDelayed
                    }

                    val root2 = findUberRoot()
                    val btn2 = if (root2 != null) findAcceptButton(root2) else null
                    val nodeFound2 = (btn2 != null)
                    LogBuffer.diag(this, "CALL-CARD-RECHECK-RESULT", "attempt=2\nnode=${if (nodeFound2) "FOUND" else "NOT_FOUND"}")

                    if (btn2 != null && root2 != null) {
                        isRecheckActive = false
                        lastCallCardFoundTime = System.currentTimeMillis()
                        lastGateResult = "FOUND"
                        if (lastLoggedCallCardState != "FOUND") {
                            lastLoggedCallCardState = "FOUND"
                            LogBuffer.diag(this, "CALL-CARD", "state=FOUND\nsource=RECHECK_50MS")
                        }
                        val bRect = Rect()
                        btn2.getBoundsInScreen(bRect)
                        val candidateText = btn2.text?.toString()?.trim() ?: btn2.contentDescription?.toString()?.trim() ?: "콜 수락"
                        LogBuffer.diag(this, "CALL-CARD-FOUND", "attempt=2\nsource=RECHECK_50MS")
                        LogBuffer.diag(this, "CALL-CARD-GATE", "keyword=$candidateText result=FOUND acceptCandidate=$candidateText source=RECHECK_50MS rootPkg=${root2.packageName} text='${btn2.text}' bounds=$bRect")
                        LogBuffer.diag(this, "ACCEPT-MATCH", "matched=$candidateText\nsource=ACCESSIBILITY")
                        activeTargetPackage = root2.packageName?.toString() ?: UBER_DRIVER_PACKAGE
                        try {
                            processWindow(root2, btn2)
                        } finally {
                            try { root2.recycle() } catch (_: Throwable) {}
                        }
                    } else {
                        if (root2 != null) {
                            val candidates2 = extractCandidateTexts(root2, 5)
                            LogBuffer.diag(
                                this,
                                "CALL-CARD-RECHECK-DIAG",
                                "attempt=2\nrootPackage=${root2.packageName}\nrootAvailable=true\nhasAcceptNode=false\ncandidateTexts=${candidates2.joinToString(prefix = "[", postfix = "]") { "'$it'" }}"
                            )
                        }
                        try { root2?.recycle() } catch (_: Throwable) {}
                        isRecheckActive = false
                        if (lastGateResult != "NOT_FOUND") {
                            lastGateResult = "NOT_FOUND"
                            LogBuffer.diag(this, "CALL-CARD-GATE", "result=NOT_FOUND source=RECHECK_EXHAUSTED attempt=2")
                        }
                    }
                }, 50L)
            }
        }, 30L)
    }

    private fun extractCandidateTexts(root: AccessibilityNodeInfo, limit: Int = 5): List<String> {
        val texts = mutableListOf<String>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty() && texts.size < limit) {
            val node = queue.removeFirst()
            val text = node.text?.toString()?.trim()
            val desc = node.contentDescription?.toString()?.trim()
            val candidate = when {
                !text.isNullOrEmpty() && text.length >= 2 -> text
                !desc.isNullOrEmpty() && desc.length >= 2 -> desc
                else -> null
            }
            if (candidate != null && !texts.contains(candidate)) {
                texts.add(candidate)
            }
            for (i in 0 until node.childCount) {
                val child = try { node.getChild(i) } catch (_: Throwable) { null }
                if (child != null) queue.add(child)
            }
            if (node != root) {
                try { node.recycle() } catch (_: Throwable) {}
            }
        }
        while (queue.isNotEmpty()) {
            val rem = queue.removeFirst()
            if (rem != root) {
                try { rem.recycle() } catch (_: Throwable) {}
            }
        }
        return texts
    }

    fun findUberRoot(): AccessibilityNodeInfo? {
        try {
            val winList = windows ?: emptyList()
            val candidates = mutableListOf<WindowRootCandidate>()

            for ((index, win) in winList.withIndex()) {
                val winRoot = win.root ?: continue
                val pkg = winRoot.packageName?.toString()
                if (!isTargetPackage(pkg) || isSelfPackage(pkg)) {
                    try { winRoot.recycle() } catch (_: Throwable) {}
                    continue
                }

                val cand = evaluateWindowRoot(index, winRoot)
                if (cand.isLeafImageView) {
                    try { winRoot.recycle() } catch (_: Throwable) {}
                } else {
                    candidates.add(cand)
                }
            }

            val sortedCandidates = candidates.sortedByDescending { it.priorityScore }

            // 1순위: 실제 수락 버튼 노드가 존재하는 우버 윈도우 발견 시 즉시 최우선 반환
            for (cand in sortedCandidates) {
                val acceptBtn = findAcceptButton(cand.root)
                if (acceptBtn != null) {
                    try { acceptBtn.recycle() } catch (_: Throwable) {}
                    for (other in sortedCandidates) {
                        if (other != cand) {
                            try { other.root.recycle() } catch (_: Throwable) {}
                        }
                    }
                    LogBuffer.diag(
                        this,
                        "WINDOW-SELECT",
                        "selectedIndex=${cand.index}\n" +
                        "selectedPackage=${cand.packageName}\n" +
                        "selectedClass=${cand.className}\n" +
                        "selectedBounds=${cand.bounds}\n" +
                        "selectedChildCount=${cand.childCount}\n" +
                        "selectionReason=UBER_ROOT_ACCEPT_BUTTON"
                    )
                    LogBuffer.diag(
                        this,
                        "WINDOW-ROOT-VERIFY",
                        "package=${cand.packageName}\n" +
                        "class=${cand.className}\n" +
                        "childCount=${cand.childCount}\n" +
                        "traversable=true"
                    )
                    return cand.root
                }
            }

            // 2순위: 콜카드 지시자(Indicator)가 존재하는 우버 윈도우 (전체 화면 우선)
            val fullScreenCandidates = sortedCandidates.filter { it.priorityScore >= 3000 }
            val priority2Candidates = if (fullScreenCandidates.isNotEmpty()) fullScreenCandidates else sortedCandidates
            for (cand in priority2Candidates) {
                if (findCardIndicator(cand.root)) {
                    for (other in sortedCandidates) {
                        if (other != cand) {
                            try { other.root.recycle() } catch (_: Throwable) {}
                        }
                    }
                    LogBuffer.diag(
                        this,
                        "WINDOW-SELECT",
                        "selectedIndex=${cand.index}\n" +
                        "selectedPackage=${cand.packageName}\n" +
                        "selectedClass=${cand.className}\n" +
                        "selectedBounds=${cand.bounds}\n" +
                        "selectedChildCount=${cand.childCount}\n" +
                        "selectionReason=UBER_ROOT_INDICATOR"
                    )
                    LogBuffer.diag(
                        this,
                        "WINDOW-ROOT-VERIFY",
                        "package=${cand.packageName}\n" +
                        "class=${cand.className}\n" +
                        "childCount=${cand.childCount}\n" +
                        "traversable=true"
                    )
                    return cand.root
                }
            }

            // 3순위: 유효한 텍스트 또는 버튼 노드가 존재하는 우버 윈도우 (전체 화면 Candidate 우선)
            val priority3Candidates = if (fullScreenCandidates.isNotEmpty()) fullScreenCandidates else sortedCandidates
            for (cand in priority3Candidates) {
                if (extractCandidateTexts(cand.root, 1).isNotEmpty()) {
                    for (other in sortedCandidates) {
                        if (other != cand) {
                            try { other.root.recycle() } catch (_: Throwable) {}
                        }
                    }
                    LogBuffer.diag(
                        this,
                        "WINDOW-SELECT",
                        "selectedIndex=${cand.index}\n" +
                        "selectedPackage=${cand.packageName}\n" +
                        "selectedClass=${cand.className}\n" +
                        "selectedBounds=${cand.bounds}\n" +
                        "selectedChildCount=${cand.childCount}\n" +
                        "selectionReason=UBER_ROOT_TEXT_CANDIDATE"
                    )
                    LogBuffer.diag(
                        this,
                        "WINDOW-ROOT-VERIFY",
                        "package=${cand.packageName}\n" +
                        "class=${cand.className}\n" +
                        "childCount=${cand.childCount}\n" +
                        "traversable=true"
                    )
                    return cand.root
                }
            }

            // 4순위 fallback용 최고 우선순위 우버 윈도우
            if (sortedCandidates.isNotEmpty()) {
                val bestCand = sortedCandidates.first()
                for (other in sortedCandidates) {
                    if (other != bestCand) {
                        try { other.root.recycle() } catch (_: Throwable) {}
                    }
                }
                LogBuffer.diag(
                    this,
                    "WINDOW-SELECT",
                    "selectedIndex=${bestCand.index}\n" +
                    "selectedPackage=${bestCand.packageName}\n" +
                    "selectedClass=${bestCand.className}\n" +
                    "selectedBounds=${bestCand.bounds}\n" +
                    "selectedChildCount=${bestCand.childCount}\n" +
                    "selectionReason=UBER_ROOT_BEST_SCORE_FALLBACK"
                )
                LogBuffer.diag(
                    this,
                    "WINDOW-ROOT-VERIFY",
                    "package=${bestCand.packageName}\n" +
                    "class=${bestCand.className}\n" +
                    "childCount=${bestCand.childCount}\n" +
                    "traversable=${bestCand.isTraversable}"
                )
                return bestCand.root
            }

            val root = rootInActiveWindow
            if (root != null) {
                val pkg = root.packageName?.toString()
                if (isTargetPackage(pkg) && !isSelfPackage(pkg)) {
                    val cand = evaluateWindowRoot(-1, root)
                    if (!cand.isLeafImageView) {
                        LogBuffer.diag(
                            this,
                            "WINDOW-SELECT",
                            "selectedIndex=-1\n" +
                            "selectedPackage=${cand.packageName}\n" +
                            "selectedClass=${cand.className}\n" +
                            "selectedBounds=${cand.bounds}\n" +
                            "selectedChildCount=${cand.childCount}\n" +
                            "selectionReason=UBER_ROOT_ACTIVE_WINDOW_FALLBACK"
                        )
                        LogBuffer.diag(
                            this,
                            "WINDOW-ROOT-VERIFY",
                            "package=${cand.packageName}\n" +
                            "class=${cand.className}\n" +
                            "childCount=${cand.childCount}\n" +
                            "traversable=${cand.isTraversable}"
                        )
                        return root
                    }
                }
                try { root.recycle() } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {
        }
        return null
    }

    data class DiscoveredTextNode(
        val text: String,
        val bounds: Rect,
        val top: Int,
        val bottom: Int,
        val left: Int,
        val right: Int,
        val clusterId: Int
    )

    fun findDynamicCardOcrRect(acceptBtn: AccessibilityNodeInfo?): Rect? {
        if (acceptBtn == null) return null
        val displayWidth = resources.displayMetrics.widthPixels
        val displayHeight = resources.displayMetrics.heightPixels

        val acceptR = Rect().also { acceptBtn.getBoundsInScreen(it) }
        if (acceptR.isEmpty) return null

        val tStart = System.currentTimeMillis()
        val pkg = try { acceptBtn.packageName?.toString() } catch (_: Throwable) { null } ?: "unknown"

        fun scanAncestorTree(btn: AccessibilityNodeInfo?): Triple<AccessibilityNodeInfo?, String, List<DiscoveredTextNode>> {
            if (btn == null) return Triple(null, "", emptyList())
            var current: AccessibilityNodeInfo? = btn
            var bestAncestor: AccessibilityNodeInfo? = null
            var bestAncestorClass = ""
            var bestAncestorScore = -1
            var bestTextNodes = listOf<DiscoveredTextNode>()

            while (current != null) {
                val parent = try { current.parent } catch (_: Throwable) { null }
                if (parent == null) break

                val parentBounds = Rect().also { parent.getBoundsInScreen(it) }
                val pW = parentBounds.width()
                val pH = parentBounds.height()
                val pCls = parent.className?.toString() ?: ""

                val isFullscreen = (parentBounds.left <= 0 && parentBounds.right >= displayWidth && parentBounds.top <= 0 && parentBounds.bottom >= displayHeight) ||
                        (pW >= displayWidth && pH >= displayHeight)

                if (isFullscreen) {
                    break
                }

                val rawTexts = mutableListOf<Pair<AccessibilityNodeInfo, Rect>>()
                fun collectTexts(node: AccessibilityNodeInfo) {
                    val r = Rect()
                    node.getBoundsInScreen(r)
                    val txt = (node.text ?: "").toString().trim()
                    if (txt.isNotBlank() && !r.isEmpty) {
                        rawTexts.add(Pair(node, Rect(r)))
                    }
                    for (i in 0 until node.childCount) {
                        val ch = try { node.getChild(i) } catch (_: Throwable) { null }
                        if (ch != null) {
                            collectTexts(ch)
                        }
                    }
                }
                collectTexts(parent)

                val validTexts = mutableListOf<DiscoveredTextNode>()
                var excludedCount = 0

                val candidateTexts = rawTexts.filter { (_, r) ->
                    !(r.left == acceptR.left && r.top == acceptR.top && r.right == acceptR.right && r.bottom == acceptR.bottom) &&
                    r.top < acceptR.bottom
                }.sortedBy { it.second.top }

                for ((tNode, tRect) in candidateTexts) {
                    val hOverlap = (tRect.left < parentBounds.right && tRect.right > parentBounds.left) &&
                                   (tRect.left < acceptR.right + (acceptR.width() / 2) && tRect.right > acceptR.left - (acceptR.width() / 2))

                    if (hOverlap && tRect.bottom <= acceptR.bottom) {
                        validTexts.add(DiscoveredTextNode(
                            text = tNode.text.toString(),
                            bounds = tRect,
                            top = tRect.top,
                            bottom = tRect.bottom,
                            left = tRect.left,
                            right = tRect.right,
                            clusterId = 1
                        ))
                    } else {
                        excludedCount++
                    }
                }

                var score = 0
                if (parentBounds.contains(acceptR.centerX(), acceptR.centerY())) score += 100
                if (validTexts.isNotEmpty()) {
                    score += validTexts.size * 50
                    score -= excludedCount * 20
                    if (validTexts.any { it.text.contains("원") || it.text.contains("분") || it.text.contains("방면") || it.text.contains("km") || it.text.length >= 2 }) {
                        score += 150
                    }
                }

                if (score > bestAncestorScore && validTexts.isNotEmpty()) {
                    bestAncestorScore = score
                    bestAncestor = parent
                    bestAncestorClass = pCls
                    bestTextNodes = validTexts
                }

                current = parent
            }
            return Triple(bestAncestor, bestAncestorClass, bestTextNodes)
        }

        var activeBtn = acceptBtn
        var (bestAncestor, bestAncestorClass, bestTextNodes) = scanAncestorTree(activeBtn)
        var attempt = 0
        val maxAttempts = 3 // attempt 0 (0ms), attempt 1 (~30ms), attempt 2 (~60-70ms)

        LogBuffer.diag(
            this,
            "OCR-TIMING-RETRY",
            "attempt=$attempt\n" +
            "elapsedFromAccept=${System.currentTimeMillis() - tStart}ms\n" +
            "collectedTextCount=${bestTextNodes.size}\n" +
            "selectedAncestor=${bestAncestorClass.ifEmpty { "null" }}\n" +
            "dynamicOcrRect=${if (bestTextNodes.isNotEmpty()) "FOUND" else "null"}"
        )

        while (bestTextNodes.isEmpty() && attempt < maxAttempts - 1) {
            attempt++
            try {
                Thread.sleep(30L)
            } catch (_: Throwable) {}

            val refreshedRoot = findUberRoot()
            if (refreshedRoot != null) {
                val freshBtn = findAcceptButton(refreshedRoot)
                if (freshBtn != null) {
                    activeBtn = freshBtn
                }
            }

            val scanResult = scanAncestorTree(activeBtn)
            bestAncestor = scanResult.first
            bestAncestorClass = scanResult.second
            bestTextNodes = scanResult.third

            LogBuffer.diag(
                this,
                "OCR-TIMING-RETRY",
                "attempt=$attempt\n" +
                "elapsedFromAccept=${System.currentTimeMillis() - tStart}ms\n" +
                "collectedTextCount=${bestTextNodes.size}\n" +
                "selectedAncestor=${bestAncestorClass.ifEmpty { "null" }}\n" +
                "dynamicOcrRect=${if (bestTextNodes.isNotEmpty()) "FOUND" else "null"}"
            )
        }

        if (bestTextNodes.isNotEmpty()) {
            // Union ONLY the valid text node bounds (do NOT union acceptBtn directly)
            var unionL = bestTextNodes[0].bounds.left
            var unionT = bestTextNodes[0].bounds.top
            var unionR = bestTextNodes[0].bounds.right
            var unionB = bestTextNodes[0].bounds.bottom

            for (i in 1 until bestTextNodes.size) {
                val tb = bestTextNodes[i].bounds
                unionL = minOf(unionL, tb.left)
                unionT = minOf(unionT, tb.top)
                unionR = maxOf(unionR, tb.right)
                unionB = maxOf(unionB, tb.bottom)
            }

            val textUnionRect = Rect(unionL, unionT, unionR, unionB)

            // Add minimal padding solely to prevent clipping character edges in OCR
            val padL = 20
            val padR = 20
            val padT = 15
            val padB = 15

            val dynamicRect = Rect(
                (unionL - padL).coerceIn(0, displayWidth),
                (unionT - padT).coerceIn(0, displayHeight),
                (unionR + padR).coerceIn(0, displayWidth),
                (unionB + padB).coerceIn(0, displayHeight)
            )

            val isClamped = (dynamicRect.left == 0 || dynamicRect.top == 0 || dynamicRect.right == displayWidth || dynamicRect.bottom == displayHeight)

            val ancestorBounds = Rect().also { bestAncestor?.getBoundsInScreen(it) }

            // Log detailed search and node information
            LogBuffer.diag(
                this,
                "OCR-CARD-SEARCH",
                "acceptBtnBounds=$acceptR\n" +
                "selectedAncestorClass=$bestAncestorClass\n" +
                "selectedAncestorBounds=$ancestorBounds\n" +
                "ancestorLevel=3\n" +
                "collectedTextCount=${bestTextNodes.size}\n" +
                "excludedOutlierCount=0"
            )

            val textNodesReport = StringBuilder()
            bestTextNodes.forEachIndexed { idx, node ->
                textNodesReport.append("#${idx + 1} text='${node.text}' bounds=${node.bounds} top=${node.top} bottom=${node.bottom} left=${node.left} right=${node.right} clusterId=${node.clusterId}\n")
            }
            LogBuffer.diag(this, "OCR-TEXT-NODES", textNodesReport.toString().trimEnd())

            LogBuffer.diag(
                this,
                "OCR-BOUNDS-RESULT",
                "textUnionRect=$textUnionRect\n" +
                "padding=Rect($padL,$padT,$padR,$padB)\n" +
                "dynamicOcrRect=$dynamicRect\n" +
                "screenWidth=$displayWidth\n" +
                "screenHeight=$displayHeight\n" +
                "clamped=$isClamped\n" +
                "source=DYNAMIC_TEXT_UNION"
            )

            return dynamicRect
        }

        return null
    }

    fun findOverlayCard(root: AccessibilityNodeInfo, acceptRect: Rect): Rect? {
        val displayWidth = resources.displayMetrics.widthPixels
        val displayHeight = resources.displayMetrics.heightPixels

        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)

        var bestRect: Rect? = null
        var bestScore = -1
        var bestClass = ""

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            val rect = Rect()
            node.getBoundsInScreen(rect)
            val w = rect.width()
            val h = rect.height()
            val cls = node.className?.toString() ?: "android.view.View"

            val isRecycler = cls.contains("RecyclerView", ignoreCase = true)
            val isCompose = cls.contains("ComposeView", ignoreCase = true) && (rect.left <= 0 && rect.right >= displayWidth)
            val isPager = cls.contains("ViewPager", ignoreCase = true)
            val isDecor = cls.contains("DecorView", ignoreCase = true)
            val isRootNode = (node == root)
            val isFullWidth = (rect.left <= 0 && rect.right >= displayWidth) || (w >= displayWidth)
            val isFullHeight = (rect.top <= 0 && rect.bottom >= displayHeight)
            val isTooCloseToTop = rect.top < (displayHeight * 0.35f).toInt()
            val isTooTall = h > (displayHeight * 0.45f).toInt()

            val combined = "${node.text ?: ""} ${node.contentDescription ?: ""}"
            val isAccept = ACCEPT_BUTTON_TEXTS.any { combined.contains(it, ignoreCase = true) }

            val containsAccept = (rect.left <= acceptRect.left && rect.right >= acceptRect.right && rect.bottom >= acceptRect.top) ||
                    (rect.contains(acceptRect.centerX(), acceptRect.centerY())) ||
                    (rect.bottom >= acceptRect.top && rect.top < acceptRect.top)

            if (isRecycler || isPager || isDecor || isFullWidth || isFullHeight || isAccept || isTooCloseToTop || isTooTall) {
                if (isRecycler || isFullWidth || isTooCloseToTop || isTooTall) {
                    LogBuffer.diag(
                        this,
                        "X-CARD-REJECTED",
                        "reason=${if (isRecycler) "RECYCLERVIEW" else if (isTooCloseToTop) "TOO_CLOSE_TO_TOP" else if (isTooTall) "TOO_TALL" else "FULLSCREEN_CONTAINER"}\nclassName=$cls\nbounds=$rect"
                    )
                }
            } else if (w in 350..(displayWidth - 30) && h in 150..(displayHeight * 0.45f).toInt() && rect.top >= (displayHeight * 0.35f).toInt() && rect.top < acceptRect.top) {
                var score = 0
                // Spatial relationship with acceptRect (CRITICAL: Real call card encloses or reaches down to accept button)
                if (containsAccept) {
                    score += 1000
                }
                // Proximity to acceptRect (Real call card's bottom touches or is near acceptRect.top)
                val distToAcceptTop = abs(acceptRect.top - rect.bottom)
                if (distToAcceptTop <= 200) {
                    score += 500
                }
                // Margin on left and right (floating card characteristic)
                if (rect.left > 0 && rect.right < displayWidth) score += 50
                // Reasonable vertical span above acceptRect
                val vDist = acceptRect.top - rect.top
                if (vDist in 300..1400) score += 30
                if (h in 300..1400) score += 20

                // Severe penalty / rejection for top-of-screen narrow banners (Y < 400 and does NOT reach acceptRect)
                if (rect.top < displayHeight * 0.25f && rect.bottom < acceptRect.top - 500) {
                    score -= 800
                }

                LogBuffer.diag(
                    this,
                    "X-CARD-CANDIDATE",
                    "className=$cls\nbounds=$rect\nisRecyclerView=$isRecycler\nisRoot=$isRootNode\ncontainsAccept=$containsAccept\nscore=$score"
                )

                if (score > bestScore && score > 0) {
                    bestScore = score
                    bestRect = Rect(rect)
                    bestClass = cls
                }
            }

            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.add(it) }
            }
            if (node != root) {
                try { node.recycle() } catch (_: Throwable) {}
            }
        }

        if (bestRect != null) {
            LogBuffer.diag(
                this,
                "X-CARD-SELECTED",
                "bounds=$bestRect\nsource=ACCESSIBILITY_BFS\nclassName=$bestClass\nscore=$bestScore"
            )
            Log.d(TAG, "findOverlayCard → $bestRect (실측, class=$bestClass, score=$bestScore)")
            return bestRect
        } else {
            LogBuffer.diag(this, "X-CARD-REJECTED", "reason=NO_VALID_CARD_CANDIDATE")
            Log.d(TAG, "findOverlayCard → null (미발견/전부 필터링됨)")
            return null
        }
    }

    private fun isValidCardBounds(bounds: Rect, displayWidth: Int, displayHeight: Int): Boolean {
        if (bounds.isEmpty) return false
        val w = bounds.width()
        val h = bounds.height()
        if (w < 300 || h < 150) return false
        // Disallow full-width (RecyclerView or screen width)
        if (bounds.left <= 0 && bounds.right >= displayWidth) {
            return false
        }
        if (w >= displayWidth) {
            return false
        }
        if (bounds.top <= 0 && bounds.bottom >= displayHeight) {
            return false
        }
        if (bounds.left == 0 && bounds.right == displayWidth && bounds.top == 0) {
            return false
        }
        return true
    }

    fun resolveDismissCoordinates(
        root: AccessibilityNodeInfo?,
        cardBounds: Rect?,
        acceptRect: Rect?,
        bitmap: Bitmap? = null,
        ocrText: String = ""
    ): Pair<Int, Int>? {
        LogBuffer.diag(
            this,
            "DISMISS-TRACE",
            "RESOLVE_START\n" +
            "cardRect=$cardBounds\n" +
            "acceptRect=$acceptRect"
        )

        val dm = resources.displayMetrics
        var dynamicMaxW = dm.widthPixels
        var dynamicMaxH = dm.heightPixels

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val wm = getSystemService(Context.WINDOW_SERVICE) as? WindowManager
                val bounds = wm?.maximumWindowMetrics?.bounds
                if (bounds != null && !bounds.isEmpty) {
                    dynamicMaxW = maxOf(dynamicMaxW, bounds.right)
                    dynamicMaxH = maxOf(dynamicMaxH, bounds.bottom)
                }
            } catch (_: Throwable) {}
        }

        if (cardBounds != null && !cardBounds.isEmpty) {
            dynamicMaxW = maxOf(dynamicMaxW, cardBounds.right)
            dynamicMaxH = maxOf(dynamicMaxH, cardBounds.bottom)
        }

        val aRect = acceptRect ?: savedAcceptRect ?: Rect(0, (dynamicMaxH * 0.75f).toInt(), dynamicMaxW, dynamicMaxH)

        val topLimitVal = if (cardBounds != null) (cardBounds.top + (cardBounds.height() * 0.35f)).toInt() else (aRect.top - 100)
        val rightLimitVal = if (cardBounds != null) (cardBounds.left + (cardBounds.width() * 0.60f)).toInt() else (dynamicMaxW * 0.5f).toInt()
        LogBuffer.diag(
            this,
            "X-DIAG-CONTEXT",
            "cardBounds=${cardBounds ?: "none"}\n" +
            "acceptButtonBounds=$aRect\n" +
            "screenWidth=$dynamicMaxW\n" +
            "screenHeight=$dynamicMaxH\n" +
            "topLimit=$topLimitVal\n" +
            "rightLimit=$rightLimitVal"
        )

        // ① 1순위: Accessibility X Node 직접 검출
        if (root != null) {
            var xNode = findDismissButton(root, aRect, cardBounds)
            if (xNode == null) {
                val acceptBtn = findAcceptButton(root)
                if (acceptBtn != null) {
                    xNode = findDismissViaParent(acceptBtn, aRect, cardBounds)
                    try { acceptBtn.recycle() } catch (_: Throwable) {}
                }
            }
            if (xNode != null) {
                val nr = Rect()
                xNode.getBoundsInScreen(nr)
                val cx = nr.centerX()
                val cy = nr.centerY()
                try { xNode.recycle() } catch (_: Throwable) {}
                LogBuffer.diag(this, "CANCEL-COORD", "취소버튼 최종 좌표 확정 (Accessibility Node)\nx=$cx\ny=$cy")
                LogBuffer.diag(
                    this,
                    "DISMISS-TRACE",
                    "RESOLVE_NODE_SEARCH\nresult=FOUND\nx=$cx\ny=$cy"
                )
                LogBuffer.diag(
                    this,
                    "DISMISS-TRACE",
                    "RESOLVE_RESULT\nsource=NODE\nx=$cx\ny=$cy"
                )
                lastDismissSource = "NODE"
                lastDismissCardBounds = cardBounds
                lastDismissNodeBounds = nr
                return Pair(cx, cy)
            } else {
                LogBuffer.diag(
                    this,
                    "DISMISS-TRACE",
                    "RESOLVE_NODE_SEARCH\nresult=NOT_FOUND"
                )
            }
        } else {
            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "RESOLVE_NODE_SEARCH\nresult=NOT_FOUND"
            )
        }

        // ② 2순위: 우측 상단 ROI Bitmap Template Matching (SAD/sample < 50)
        val validCardRect = cardBounds?.takeIf { !it.isEmpty } ?: aRect.let {
            Rect(0, (it.top - 800).coerceAtLeast(0), dynamicMaxW, it.top)
        }

        if (bitmap != null && !bitmap.isRecycled) {
            val templateCoord = findXButtonByTemplate(bitmap, validCardRect, aRect, ocrText)
            if (templateCoord != null) {
                val (tx, ty) = templateCoord
                LogBuffer.diag(this, "CANCEL-COORD", "취소버튼 최종 좌표 확정 (Bitmap Template Matching)\nx=$tx\ny=$ty")
                LogBuffer.diag(
                    this,
                    "DISMISS-TRACE",
                    "RESOLVE_TEMPLATE\nresult=FOUND\nx=$tx\ny=$ty"
                )
                LogBuffer.diag(
                    this,
                    "DISMISS-TRACE",
                    "RESOLVE_RESULT\nsource=TEMPLATE\nx=$tx\ny=$ty"
                )
                lastDismissSource = "TEMPLATE"
                lastDismissCardBounds = validCardRect
                lastDismissNodeBounds = Rect(tx - 30, ty - 30, tx + 30, ty + 30)
                return Pair(tx, ty)
            } else {
                LogBuffer.diag(
                    this,
                    "DISMISS-TRACE",
                    "RESOLVE_TEMPLATE\nresult=NOT_FOUND"
                )
            }
        } else {
            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "RESOLVE_TEMPLATE\nresult=NOT_FOUND"
            )
        }

        // ③ 3순위: Template Matching 실패 시 고정 Offset (card.right - 106, card.top + 78)
        val fbX = (validCardRect.right - 106).coerceIn(50, dynamicMaxW - 10)
        val fbY = (validCardRect.top + 78).coerceIn(50, dynamicMaxH - 50)

        LogBuffer.diag(
            this,
            "X-DIAG-FALLBACK",
            "x=$fbX\ny=$fbY\ncardBounds=$validCardRect\nreason=X_BUTTON_NOT_FOUND"
        )
        LogBuffer.diag(this, "CANCEL-COORD", "취소버튼 최종 좌표 확정 (Fixed Offset Fallback)\nx=$fbX\ny=$fbY")
        LogBuffer.diag(
            this,
            "DISMISS-TRACE",
            "RESOLVE_FIXED_OFFSET\nx=$fbX\ny=$fbY"
        )
        LogBuffer.diag(
            this,
            "DISMISS-TRACE",
            "RESOLVE_RESULT\nsource=FIXED_OFFSET\nx=$fbX\ny=$fbY"
        )
        lastDismissSource = "FIXED_OFFSET"
        lastDismissCardBounds = validCardRect
        lastDismissNodeBounds = Rect(fbX - 30, fbY - 30, fbX + 30, fbY + 30)
        return Pair(fbX, fbY)
    }


    private fun processWindow(root: AccessibilityNodeInfo, acceptBtn: AccessibilityNodeInfo?) {
        val now = System.currentTimeMillis()
        val winPkg = root.packageName?.toString() ?: activeTargetPackage

        if (isSelfPackage(winPkg)) {
            if (now - lastSelfSkipLogTime > 30000L) {
                lastSelfSkipLogTime = now
                LogBuffer.diag(this, "SCAN-SKIP", "pkg=$winPkg reason=self_package")
            }
            return
        }

        val isUber = winPkg == UBER_DRIVER_PACKAGE || winPkg == SIMULATOR_PACKAGE
        val cardKey = "${winPkg}_$now"
        currentCallSessionSeq++
        val sessionSeq = currentCallSessionSeq

        LogBuffer.diag(
            this,
            "CALL-SESSION",
            "seq=$sessionSeq\n" +
            "previousDismissSeq=$currentDismissSeq\n" +
            "pendingDismiss=$pendingDismiss\n" +
            "pendingAccept=$pendingAccept\n" +
            "cardKey=$cardKey\n" +
            "fingerprint=${generateCardFingerprint(root) ?: "none"}"
        )

        val inCooldown = now - lastAcceptTime < COOLDOWN_MS
        if (inCooldown || pendingAccept) {
            if (!cooldownLogged) {
                cooldownLogged = true
                LogBuffer.diag(this, "COOLDOWN", "START duration=${COOLDOWN_MS}ms")
            }
            return
        } else if (cooldownLogged) {
            cooldownLogged = false
            LogBuffer.diag(this, "COOLDOWN", "END")
        }

        val isFirstSeen = callCardFirstSeenAt == 0L
        if (isFirstSeen) {
            callCardFirstSeenAt = now
        }
        lastCallCardTime = now
        fastPollUntilMs = now + 4000L

        val dumpAcceptR = if (acceptBtn != null) Rect().also { acceptBtn.getBoundsInScreen(it) } else savedAcceptRect ?: Rect()
        if (isFirstSeen) {
            val dump = dumpCallTree(root, dumpAcceptR)
            LogBuffer.log(this, TAG, "=== 콜카드 트리 덤프 ===\n$dump")
        }

        val acceptR: Rect = if (acceptBtn != null) {
            Rect().also { acceptBtn.getBoundsInScreen(it) }
        } else {
            savedAcceptRect?.let { Rect(it) }
                ?: PrefsManager.loadLastAcceptRect(this)
                ?: Rect(
                    45,
                    (resources.displayMetrics.heightPixels * 0.75f).toInt(),
                    resources.displayMetrics.widthPixels - 45,
                    (resources.displayMetrics.heightPixels * 0.92f).toInt()
                )
        }

        if (acceptBtn != null) {
            savedAcceptRect = Rect(acceptR)
            PrefsManager.saveLastAcceptRect(this, acceptR.left, acceptR.top, acceptR.right, acceptR.bottom)
        }

        if (isFirstSeen) {
            PrefsManager.incrementCallCount(this)
        }

        Log.d(TAG, "콜 화면 감지됨" + if (acceptBtn == null) " [수락버튼 미발견 — savedAcceptRect 사용]" else "")
        LogBuffer.diag(this, "CALL_CARD_CONTAINER_FOUND", "Call card container detected in pkg=$winPkg (rootPkg=${root.packageName})")

        if (acceptBtn != null) {
            val labelText = acceptBtn.text?.toString() ?: acceptBtn.contentDescription?.toString() ?: "Button"
            LogBuffer.diag(this, "LABEL_MATCH", "Matched accept button label: '$labelText', bounds=$acceptR, viewId=${acceptBtn.viewIdResourceName}")
            val candDetails = "foregroundPkg=$lastForegroundPkg, rootPkg=${root.packageName}, windowPkg=$winPkg, className=${acceptBtn.className}, text='${acceptBtn.text}', desc='${acceptBtn.contentDescription}', viewId=${acceptBtn.viewIdResourceName}, bounds=$acceptR, cardKey=$cardKey, method=AccessibilityNode, isUber=$isUber"
            LogBuffer.diag(this, "ACCEPT-CANDIDATE", candDetails)
            if (!isUber) {
                if (now - lastFalsePosLogTime > 5000L) {
                    lastFalsePosLogTime = now
                    LogBuffer.diag(this, "FALSE-POSITIVE-CANDIDATE", "Non-Uber screen detected as accept candidate: $candDetails")
                }
            }
        } else {
            LogBuffer.diag(this, "ACCEPT-CANDIDATE", "Call card found without explicit node button; will rely on OCR/template (pkg=$winPkg, isUber=$isUber)")
        }

        val acceptAll = PrefsManager.isAcceptAll(this)
        val blacklistMode = PrefsManager.isBlacklistMode(this)
        val keywords = PrefsManager.getKeywords(this)

        if (!acceptAll && keywords.isNotEmpty() && Build.VERSION.SDK_INT >= 30) {
            val rootRect = Rect().also { root.getBoundsInScreen(it) }
            val isFloatingOverlay = rootRect.top > 500
            val displayWidth = resources.displayMetrics.widthPixels
            val displayHeight = resources.displayMetrics.heightPixels

            val maxCardSpanAboveButton = (displayHeight * 0.30f).toInt().coerceAtLeast(400)
            val safeMinTop = (acceptR.top - maxCardSpanAboveButton).coerceAtLeast((displayHeight * 0.35f).toInt())

            val dynamicOcr = findDynamicCardOcrRect(acceptBtn)
            val overlayCard = findOverlayCard(root, acceptR)
            val rawParentCard = dynamicOcr ?: overlayCard ?: Rect(45, safeMinTop, displayWidth - 45, acceptR.bottom)

            // Adjust card rect: clamp top so it never penetrates the top map/status bar region
            val adjustedTop = maxOf(rawParentCard.top, safeMinTop)
            val adjustedBottom = acceptR.bottom.coerceAtMost(displayHeight)
            val adjustedLeft = rawParentCard.left.coerceAtLeast(0)
            val adjustedRight = rawParentCard.right.coerceAtMost(displayWidth)
            val dismissCardRect = Rect(adjustedLeft, adjustedTop, adjustedRight, adjustedBottom)

            val isDynamic = (dynamicOcr != null)
            val ocrRect = if (isDynamic) {
                dynamicOcr!!
            } else {
                val ocrTop = adjustedTop.coerceAtLeast(safeMinTop)
                val ocrBottom = adjustedBottom.coerceAtLeast(ocrTop + 150)
                val ocrLeft = adjustedLeft.coerceAtLeast(30)
                val ocrRight = adjustedRight.coerceAtMost(displayWidth - 30)
                Rect(ocrLeft, ocrTop, ocrRight, ocrBottom)
            }

            LogBuffer.diag(
                this,
                "OCR-CAPTURE-GATE",
                if (isDynamic) {
                    "dynamicOcrRect=$ocrRect\naction=USE_DYNAMIC_RECT"
                } else {
                    "dynamicOcrRect=null\nretryExhausted=true\naction=USE_FALLBACK"
                }
            )

            LogBuffer.diag(
                this,
                "OCR-CAPTURE-START",
                "rect=$ocrRect\nsource=${if (isDynamic) "DYNAMIC_TEXT_UNION" else "FALLBACK"}\nisDynamic=$isDynamic\nelapsedFromAccept=${now - callCardFirstSeenAt}ms"
            )

            val dismissTapX = 0
            val dismissTapY = 0

            savedAcceptRect = Rect(acceptR)
            dismissAttempts = 0
            PrefsManager.saveLastAcceptRect(this, acceptR.left, acceptR.top, acceptR.right, acceptR.bottom)
            pendingAccept = true

            LogBuffer.diag(
                this,
                "OCR-BOUNDS-DEBUG",
                "screenWidth=$displayWidth\n" +
                "screenHeight=$displayHeight\n" +
                "acceptBtnBounds=$acceptR\n" +
                "rawParentBounds=${overlayCard ?: "null"}\n" +
                "selectedCardBounds=$dismissCardRect\n" +
                "adjustedDismissCardRect=$dismissCardRect\n" +
                "cropDimension=${ocrRect.width()}x${ocrRect.height()}\n" +
                "cropTop=${ocrRect.top}\n" +
                "cropBottom=${ocrRect.bottom}\n" +
                "topRatio=${String.format(java.util.Locale.US, "%.3f", ocrRect.top.toFloat() / displayHeight)}"
            )

            LogBuffer.diag(
                this,
                "OCR-RECT",
                "cardBounds=$dismissCardRect\nacceptBounds=$acceptR\nocrRect=$ocrRect\nocrArea=${ocrRect.width() * ocrRect.height()}\nsource=${if (isDynamic) "DYNAMIC_TEXT_UNION" else "CARD_BOUNDS"}"
            )
            Log.d(TAG, "OCR 경로 시작 — ocrRect=$ocrRect  dismissCard=$dismissCardRect  acceptRect=$acceptR  overlay=$isFloatingOverlay")

            startOcrAndDecide(ocrRect, dismissCardRect, dismissTapX, dismissTapY, isFloatingOverlay, acceptR, acceptBtn, keywords, blacklistMode)
            return
        }

        // Fallback for acceptAll or empty keywords or SDK < 30
        if (acceptAll) {
            LogBuffer.diag(this, "ACCEPT-CONDITION", "Evaluation: acceptAll=true, blacklist=$blacklistMode, matched='전체수락' -> shouldAccept=true, isUber=$isUber")
            if (acceptBtn != null) {
                performAccept(acceptBtn, acceptR, "전체수락", winPkg, cardKey)
            } else {
                executeAcceptAtPos(acceptR.centerX(), acceptR.centerY(), acceptR, "전체수락", cardKey)
            }
            return
        }

        val fullText = collectAllText(root)
        val notifText = NotificationListener.lastCallText
        val combinedText = "$fullText $notifText"
        var matchedKeyword: String? = null
        val cleanCombinedText = combinedText.replace("\\s+".toRegex(), "").replace("[^가-힣a-zA-Z0-9]".toRegex(), "")
        for (kw in keywords) {
            val trimmedKw = kw.trim()
            if (trimmedKw.isEmpty()) continue
            val cleanKw = trimmedKw.replace("\\s+".toRegex(), "").replace("[^가-힣a-zA-Z0-9]".toRegex(), "")

            val directMatch = combinedText.contains(trimmedKw, ignoreCase = true)
            val cleanMatch = cleanKw.isNotEmpty() && cleanCombinedText.contains(cleanKw, ignoreCase = true)

            if (directMatch || cleanMatch) {
                matchedKeyword = trimmedKw
                break
            }
        }
        val shouldAccept: Boolean = if (blacklistMode) matchedKeyword == null else matchedKeyword != null
        LogBuffer.diag(this, "ACCEPT-CONDITION", "Evaluation (Fallback): acceptAll=$acceptAll, blacklist=$blacklistMode, matched='$matchedKeyword' -> shouldAccept=$shouldAccept, isUber=$isUber")

        if (shouldAccept) {
            if (acceptBtn != null) {
                performAccept(acceptBtn, acceptR, matchedKeyword ?: "조건일치", winPkg, cardKey)
            } else {
                executeAcceptAtPos(acceptR.centerX(), acceptR.centerY(), acceptR, "조건일치", cardKey)
            }
        } else if (PrefsManager.isAutoDismiss(this)) {
            performDismissFresh()
        }
    }

    private fun performAccept(btn: AccessibilityNodeInfo, rect: Rect, reason: String, winPkg: String = "unknown", cardKey: String = "k_$lastAcceptTime") {
        val now = System.currentTimeMillis()
        if (now - lastAcceptTime < COOLDOWN_MS || pendingAccept) {
            LogBuffer.diag(this, "ACCEPT-FAIL", "performAccept skipped due to cooldown or pendingAccept (cooldown=${now - lastAcceptTime}ms, pending=$pendingAccept)")
            return
        }

        pendingAccept = true
        lastAcceptTime = now
        savedAcceptRect = rect

        val delay = 100L

        lastHumanDelay = delay
        Log.d(TAG, "수락 예정: 이유=$reason, 딜레이=${delay}ms, 좌표=(${rect.centerX()}, ${rect.centerY()})")
        LogBuffer.diag(this, "ACCEPT-DELAY", "mode=FIXED_100MS, delay=${delay}ms")
        LogBuffer.diag(this, "ACCEPT-SCHEDULE", "delay=${delay}ms, reason=$reason, coords=(${rect.centerX()}, ${rect.centerY()}), sourcePkg=$winPkg, cardKey=$cardKey")

        handler.postDelayed({
            executeAccept(btn, rect, winPkg, cardKey)
        }, delay)

        handler.postDelayed(acceptTimeoutRunnable, 5000L)
    }

    private fun executeAccept(btn: AccessibilityNodeInfo, rect: Rect, winPkg: String = "unknown", cardKey: String = "k_$lastAcceptTime") {
        var clicked = false
        var clickMethod = "NONE"
        val cx = rect.centerX()
        val cy = rect.centerY()

        showTapIndicator(cx, cy, true)
        LogBuffer.diag(this, "ACCEPT-FLOW", "state=FOUND\nacceptBounds=$rect")
        LogBuffer.diag(this, "ACCEPT-FLOW", "click=START")
        LogBuffer.diag(this, "ACCEPT-TOUCH", "Touch starting: coords=($cx, $cy), bounds=$rect, targetText='${btn.text}', cardKey=$cardKey")

        val shizOk = shizukuTap(cx, cy)
        LogBuffer.diag(this, "ACCEPT-SHIZUKU", "Shizuku tap result=$shizOk, coords=($cx, $cy)")

        if (shizOk) {
            clicked = true
            clickMethod = "ShizukuTap"
            Log.d(TAG, "Shizuku 터치 수락 성공")
        } else {
            var actionOk = false
            try {
                if (btn.isClickable && btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    actionOk = true
                    clicked = true
                    clickMethod = "NodeClick"
                } else {
                    var parent = btn.parent
                    while (parent != null) {
                        if (parent.isClickable && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                            actionOk = true
                            clicked = true
                            clickMethod = "ParentNodeClick"
                            break
                        }
                        parent = parent.parent
                    }
                }
            } catch (e: Throwable) {
                LogBuffer.diag(this, "ACCEPT-FAIL", "Node action exception: ${e.message}")
            }
            LogBuffer.diag(this, "ACCEPT-ACTION", "Node click result=$actionOk, method=$clickMethod")

            if (!clicked) {
                val gestureBuilder = GestureDescription.Builder()
                val path = Path().apply {
                    moveTo(cx.toFloat(), cy.toFloat())
                }
                gestureBuilder.addStroke(GestureDescription.StrokeDescription(path, 0, 50))
                val dispatched = dispatchGesture(gestureBuilder.build(), null, null)
                clicked = dispatched
                clickMethod = if (dispatched) "dispatchGesture" else "GestureFailed"
                LogBuffer.diag(this, "ACCEPT-GESTURE", "dispatchGesture result=$dispatched, coords=($cx, $cy)")
            }
        }

        if (clicked) {
            LogBuffer.diag(this, "ACCEPT-FLOW", "click=SUCCESS")
        } else {
            LogBuffer.diag(this, "ACCEPT-FLOW", "click=FAILED method=$clickMethod")
        }

        LogBuffer.diag(this, "ACCEPT-TOUCH", "Touch performed: method=$clickMethod, coords=($cx, $cy), success=$clicked, cardKey=$cardKey")

        val nextCount = PrefsManager.getAcceptScheduled(this) + 1
        LogBuffer.diag(this, "ACCEPT-COUNT", "source=executeAccept, reason=accept_dispatched, cardKey=$cardKey, winPkg=$winPkg, btn='${btn.text}', bounds=$rect, nextCount=$nextCount")
        PrefsManager.incrementAcceptScheduled(this, source = "executeAccept")

        PrefsManager.saveLastAcceptRect(this, rect)
        sendBroadcast(Intent("com.uber.autoaccept.ACCEPT_EVENT"))

        vibrate()
        triggerSleepAlarm()

        if (clicked) {
            if (PrefsManager.isAcceptScreenshot(this)) {
                handler.postDelayed({
                    takeScreenshotAndSave()
                }, 200L)
            } else {
                LogBuffer.diag(this, "CAPTURE-AFTER-ACCEPT", "SKIPPED\nreason=PREF_DISABLED")
            }
        } else {
            LogBuffer.diag(this, "CAPTURE-AFTER-ACCEPT", "SKIPPED\nreason=CLICK_NOT_SUCCESSFUL")
        }

        pendingAccept = false
        handler.removeCallbacks(acceptTimeoutRunnable)

        // Verify accept after short delay (Separation of TOUCH and SUCCESS)
        handler.postDelayed({
            val verifyRoot = findUberRoot()
            val stillHasCard = verifyRoot != null && (findCardIndicator(verifyRoot) || findAcceptButton(verifyRoot) != null)
            if (!stillHasCard) {
                LogBuffer.diag(this, "ACCEPT-VERIFY", "Card disappeared successfully (Accept confirmed), cardKey=$cardKey")
                LogBuffer.diag(this, "ACCEPT-SUCCESS", "Accept operation verified SUCCESS on screen, cardKey=$cardKey")
            } else {
                LogBuffer.diag(this, "ACCEPT-VERIFY", "Card still visible -> Scheduling retry, cardKey=$cardKey")
                LogBuffer.diag(this, "ACCEPT-RETRY", "Retrying accept tap at ($cx, $cy), cardKey=$cardKey")
                scheduleAcceptRetap(rect, 300L, cardKey)
            }
        }, 500L)
    }

    fun performDismissFresh() {
        dismissAttempts++
        PrefsManager.incrementDismissExecuted(this)
        Log.d(TAG, "performDismissFresh 호출 (시도 $dismissAttempts 번째)")
        LogBuffer.diag(this, "DISMISS-START", "source=ORIGINAL_FLOW_RESTORED, performDismissFresh started")
        LogBuffer.diag(this, "DISMISS-ATTEMPT", "source=ORIGINAL_FLOW_RESTORED, attempt=$dismissAttempts, totalExecuted=${PrefsManager.getDismissExecuted(this)}")
        LogBuffer.diag(this, "DISMISS-EXECUTED", "source=ORIGINAL_FLOW_RESTORED, dismiss execution attempt counter incremented, count=${PrefsManager.getDismissExecuted(this)}")
        val acceptRect = savedAcceptRect
        LogBuffer.diag(this, "DISMISS-RECT", "source=ORIGINAL_FLOW_RESTORED, savedAcceptRect=${acceptRect ?: "null"}")
        if (acceptRect == null) {
            Log.w(TAG, "닫기: savedAcceptRect 없음 — 건너뜀")
            LogBuffer.diag(this, "DISMISS-FAIL", "source=ORIGINAL_FLOW_RESTORED, savedAcceptRect is null, skipping dismiss")
            pendingDismiss = false
            return
        }

        val activeRootBefore = try { rootInActiveWindow } catch (_: Throwable) { null }
        val activeRootBeforePkg = activeRootBefore?.packageName?.toString()
        val activeRootBeforeChild = activeRootBefore?.childCount ?: -1
        val winListBefore = windows ?: emptyList()
        LogBuffer.diag(
            this,
            "DISMISS-BEFORE-FINDCALLCARD",
            "foregroundPkg=${lastForegroundPkg ?: "none"}, lastForegroundPkg=${lastForegroundPkg ?: "none"}, windowCount=${winListBefore.size}, activeRootPkg=${activeRootBeforePkg ?: "none"}, activeRootChildCount=$activeRootBeforeChild, savedAcceptRect=${acceptRect ?: "null"}"
        )

        val beforeDumpRoot = try { rootInActiveWindow } catch (_: Throwable) { null }
        val beforeDumpCard = beforeDumpRoot != null && (findAcceptButton(beforeDumpRoot) != null || findCardIndicator(beforeDumpRoot))
        try { beforeDumpRoot?.recycle() } catch (_: Throwable) {}
        LogBuffer.diag(this, "BEFORE-DUMP-CARD-CHECK", "result=${if (beforeDumpCard) "FOUND" else "NOT_FOUND"}")

        try {
            val windows = windows ?: emptyList()
            val sb = StringBuilder()
            sb.append("▶ acceptRect: $acceptRect\n")
            sb.append("▶ 전체 창 수: ${windows.size}\n")
            for ((idx, win) in windows.withIndex()) {
                val wr = try { win.root } catch (_: Throwable) { null }
                if (wr == null) {
                    sb.append("── 창[$idx] root=null ──\n")
                } else {
                    sb.append("── 창[$idx] pkg=${wr.packageName} ──\n")
                    sb.append(dumpCallTree(wr, acceptRect))
                    try { wr.recycle() } catch (_: Throwable) {}
                }
            }
            PrefsManager.saveDismissDiag(this, sb.toString().take(4000))
            Log.d(TAG, "전창덤프 저장 완료")
        } catch (e2: Throwable) {
            Log.e(TAG, "덤프 오류: ${e2.message}")
        }
        LogBuffer.diag(this, "DUMP-COMPLETE", "savedDumpLength=${PrefsManager.getDismissDiag(this).length}")

        val afterDumpRoot = try { rootInActiveWindow } catch (_: Throwable) { null }
        val afterDumpCard = afterDumpRoot != null && (findAcceptButton(afterDumpRoot) != null || findCardIndicator(afterDumpRoot))
        val afterDumpPkg = afterDumpRoot?.packageName?.toString()
        val afterDumpChild = afterDumpRoot?.childCount ?: -1
        val winListAfter = windows ?: emptyList()
        try { afterDumpRoot?.recycle() } catch (_: Throwable) {}

        LogBuffer.diag(this, "AFTER-DUMP-CARD-CHECK", "result=${if (afterDumpCard) "FOUND" else "NOT_FOUND"}")
        LogBuffer.diag(
            this,
            "DISMISS-AFTER-DUMP",
            "foregroundPkg=${lastForegroundPkg ?: "none"}, lastForegroundPkg=${lastForegroundPkg ?: "none"}, windowCount=${winListAfter.size}, activeRootPkg=${afterDumpPkg ?: "none"}, activeRootChildCount=$afterDumpChild"
        )

        try {
            val pair = findCallCard(source = "DISMISS_FRESH")
            LogBuffer.diag(
                this,
                "DISMISS-FINDCALLCARD-RESULT",
                "result=${if (pair != null) "FOUND" else "NOT_FOUND"}, failReason=${if (pair != null) "none" else "card_not_detected_in_windows_and_fallback"}"
            )
            LogBuffer.diag(this, "DISMISS-CARD", "source=ORIGINAL_FLOW_RESTORED, cardPresent=${pair != null}, root=${pair?.first != null}, acceptBtn=${pair?.second != null}, pkg=${pair?.first?.packageName ?: "none"}")
            if (pair != null) {
                val (root, acceptBtn) = pair
                val targetFp = generateCardFingerprint(root)

                // 1순위: tryNodeDismiss (ACTION_DISMISS -> 0x1020036 -> ACTION_CLICK)
                val nodeDismissOk = tryNodeDismiss(root, null, "FRESH")
                if (nodeDismissOk) {
                    Log.d(TAG, "tryNodeDismiss 성공 → 400ms 후 검증")
                    try { acceptBtn?.recycle() } catch (_: Throwable) {}
                    try { root.recycle() } catch (_: Throwable) {}
                    currentDismissSeq++
                    val runningSeq = currentDismissSeq
                    currentDismissTargetFingerprint = targetFp
                    pendingDismiss = true
                    dismissAttempts = 1
                    handler.postDelayed({
                        dismissVerify1(runningSeq, targetFp)
                    }, 400L)
                    return
                }

                var selectMethod = "none"
                var xNode = findDismissButton(root, acceptRect)
                if (xNode != null) {
                    selectMethod = "findDismissButton"
                } else if (acceptBtn != null) {
                    xNode = findDismissViaParent(acceptBtn, acceptRect)
                    if (xNode != null) {
                        selectMethod = "findDismissViaParent"
                    }
                }

                if (xNode != null) {
                    val xr = Rect()
                    xNode.getBoundsInScreen(xr)
                    Log.d(TAG, "X버튼 발견: $xr ($selectMethod)")
                    LogBuffer.diag(this, "CANCEL-COORD", "취소버튼 최종 좌표 확정\nx=${xr.centerX()}\ny=${xr.centerY()}")
                    LogBuffer.diag(this, "DISMISS-NODE", "source=ORIGINAL_FLOW_RESTORED, nodeSelected=true, method=$selectMethod, text='${xNode.text}', desc='${xNode.contentDescription}', bounds=$xr, fp=$targetFp")
                    try { acceptBtn?.recycle() } catch (_: Throwable) {}
                    try { root.recycle() } catch (_: Throwable) {}
                    dismissWithVerify(xNode, xr, targetFp)
                    return
                }

                // X버튼 노드가 없을 경우: 배지 / 카드 / 좌표 폴백
                val badgeNode = try {
                    root.findAccessibilityNodeInfosByViewId("$activeTargetPackage:id/ub_driver_offers_overlay_offer_pill_view")?.firstOrNull()
                } catch (_: Throwable) { null }

                if (badgeNode != null) {
                    val bRect = Rect()
                    badgeNode.getBoundsInScreen(bRect)
                    try { badgeNode.recycle() } catch (_: Throwable) {}
                    try { acceptBtn?.recycle() } catch (_: Throwable) {}
                    try { root.recycle() } catch (_: Throwable) {}
                    currentDismissSeq++
                    val runningSeq = currentDismissSeq
                    currentDismissTargetFingerprint = targetFp
                    pendingDismiss = true
                    dismissAttempts = 1
                    tapBadgeXButton(bRect, "FRESH")
                    handler.postDelayed({
                        dismissVerify1(runningSeq, targetFp)
                    }, 9 * 70L + 400L)
                    return
                }

                val cardRect = findOverlayCard(root, acceptRect)
                if (cardRect != null) {
                    try { acceptBtn?.recycle() } catch (_: Throwable) {}
                    try { root.recycle() } catch (_: Throwable) {}
                    currentDismissSeq++
                    val runningSeq = currentDismissSeq
                    currentDismissTargetFingerprint = targetFp
                    pendingDismiss = true
                    dismissAttempts = 1
                    tapCardTopRight(cardRect, acceptRect, "FRESH")
                    handler.postDelayed({
                        dismissVerify1(runningSeq, targetFp)
                    }, 400L)
                    return
                }

                try { acceptBtn?.recycle() } catch (_: Throwable) {}
                try { root.recycle() } catch (_: Throwable) {}
                Log.w(TAG, "X버튼 없음 → tapDismissCoordinates")
                LogBuffer.diag(this, "DISMISS-FALLBACK", "source=ORIGINAL_FLOW_RESTORED, no X button found -> tapDismissCoordinates")
                currentDismissSeq++
                val runningSeq = currentDismissSeq
                currentDismissTargetFingerprint = targetFp
                pendingDismiss = true
                dismissAttempts = 1
                if (Build.VERSION.SDK_INT >= 24) {
                    tapDismissCoordinates(acceptRect)
                    return
                } else {
                    fallbackBack()
                    return
                }
            }

            Log.d(TAG, "콜카드 없음 → 이미 닫힘")
            LogBuffer.diag(this, "DISMISS-ALREADY-CLOSED", "source=ORIGINAL_FLOW_RESTORED, call card not found at start -> already closed")
            LogBuffer.diag(this, "DISMISS-SUCCESS-CONDITION", "source=ORIGINAL_FLOW_RESTORED, cardPresent=false, verificationPassed=true, via=already_closed")
            recordDismissSuccess()
        } catch (e3: Throwable) {
            Log.e(TAG, "노드 액션 예외: ${e3.message}")
        }
    }

    private fun findCardNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val pkg = activeTargetPackage
        try {
            val pillNodes = root.findAccessibilityNodeInfosByViewId("$pkg:id/ub_driver_offers_overlay_offer_pill_view")
            if (!pillNodes.isNullOrEmpty()) {
                val pill = pillNodes.first()
                var curr = pill.parent
                while (curr != null) {
                    val r = Rect()
                    curr.getBoundsInScreen(r)
                    if (r.height() > 200) {
                        try { pill.recycle() } catch (_: Throwable) {}
                        return curr
                    }
                    curr = curr.parent
                }
                return pill
            }
        } catch (_: Throwable) {}
        return null
    }

    private fun tryNodeDismiss(root: AccessibilityNodeInfo, badgeNode: AccessibilityNodeInfo?, tag: String): Boolean {
        val pkg = activeTargetPackage
        val ACTION_DISMISS = 0x100000 // 1048576

        val badge: AccessibilityNodeInfo? = if (badgeNode == null) {
            try {
                root.findAccessibilityNodeInfosByViewId("$pkg:id/ub_driver_offers_overlay_offer_pill_view")?.firstOrNull()
            } catch (_: Throwable) {
                null
            }
        } else {
            badgeNode
        }

        val card = findCardNode(root)
        val targets = listOfNotNull(badge, card, root)

        for (node in targets) {
            val nodeLabel = when (node) {
                badge -> "배지"
                card -> "카드"
                else -> "루트"
            }
            val actions = node.actionList?.joinToString(", ") { it.id.toString() } ?: "?"
            Log.d(TAG, "[$tag] $nodeLabel 액션 목록: $actions")

            val okDismiss = try {
                node.performAction(ACTION_DISMISS)
            } catch (_: Throwable) {
                false
            }
            Log.d(TAG, "[$tag] $nodeLabel ACTION_DISMISS → $okDismiss")

            val okCustom = if (!okDismiss) {
                val customAction = node.actionList?.find { it.id == 0x1020036 }
                val lbl = customAction?.label
                val r = try {
                    node.performAction(0x1020036)
                } catch (_: Throwable) {
                    false
                }
                Log.d(TAG, "[$tag] $nodeLabel 커스텀액션(label=$lbl) → $r")
                r
            } else false

            val okClick = if (!okDismiss && !okCustom) {
                val r = try {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK) // 0x10
                } catch (_: Throwable) {
                    false
                }
                Log.d(TAG, "[$tag] $nodeLabel ACTION_CLICK → $r")
                r
            } else false

            if (okDismiss || okCustom || okClick) {
                val method = when {
                    okDismiss -> "DISMISS"
                    okCustom -> "커스텀"
                    else -> "CLICK"
                }
                LogBuffer.diag(this, "DISMISS-NODE-ACTION", "source=tryNodeDismiss, tag=$tag, node=$nodeLabel, method=$method")
                if (node != badge && card != null && node != card) {
                    try { card.recycle() } catch (_: Throwable) {}
                }
                return true
            }
        }
        if (card != null) {
            try { card.recycle() } catch (_: Throwable) {}
        }
        Log.w(TAG, "[$tag] tryNodeDismiss 전부 실패")
        return false
    }

    private fun dismissWithVerify(xNode: AccessibilityNodeInfo, dismissRect: Rect, targetFingerprint: String? = null) {
        currentDismissSeq++
        val runningSeq = currentDismissSeq
        currentDismissTargetFingerprint = targetFingerprint
        pendingDismiss = true
        dismissAttempts = 1

        val clicked = try {
            xNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } catch (_: Throwable) {
            false
        }
        Log.d(TAG, "ACTION_CLICK → $clicked  nodeRect=$dismissRect seq=$runningSeq")
        LogBuffer.diag(this, "CLOSE-ACTION", "source=ORIGINAL_FLOW_RESTORED, ACTION_CLICK result=$clicked, nodeBounds=$dismissRect, seq=$runningSeq")
        try { xNode.recycle() } catch (_: Throwable) {}

        if (!clicked && Build.VERSION.SDK_INT >= 24) {
            tapXButtonTopRight(dismissRect, 0L, "1차")
        }

        handler.postDelayed({
            dismissVerify1(runningSeq, targetFingerprint)
        }, 400L)
    }

    private fun tapBadgeXButton(badgeRect: Rect, tag: String) {
        val bRight = if (badgeRect.right > 0) badgeRect.right.toFloat() else 468.0f
        val bCenterY = if (badgeRect.bottom > badgeRect.top) {
            (badgeRect.top + badgeRect.bottom).toFloat() / 2.0f
        } else {
            1080.0f
        }

        val taps = listOf(
            Pair(bRight - 10f, bCenterY - 22f),
            Pair(bRight - 10f, bCenterY),
            Pair(bRight - 10f, bCenterY + 22f),
            Pair(bRight - 30f, bCenterY - 22f),
            Pair(bRight - 30f, bCenterY),
            Pair(bRight - 30f, bCenterY + 22f),
            Pair(bRight - 50f, bCenterY - 22f),
            Pair(bRight - 50f, bCenterY),
            Pair(bRight - 50f, bCenterY + 22f)
        ).filter { it.first > 0f && it.second > 0f }

        Log.d(TAG, "$tag 배지탭 시작 — bRight=${bRight.toInt()} bCenterY=${bCenterY.toInt()} ${taps.size}개")
        LogBuffer.diag(this, "DISMISS-BADGE-TOUCH", "source=tapBadgeXButton, tag=$tag, bRight=$bRight, bCenterY=$bCenterY, totalCandidates=${taps.size}")

        taps.forEachIndexed { i, pair ->
            handler.postDelayed({
                val x = pair.first
                val y = pair.second
                showTapIndicator(x.toInt(), y.toInt(), false)
                shizukuExecutor.execute {
                    val shizOk = shizukuTap(x.toInt(), y.toInt())
                    if (!shizOk && Build.VERSION.SDK_INT >= 24) {
                        handler.post {
                            val path = Path().apply { moveTo(x, y) }
                            val stroke = GestureDescription.StrokeDescription(path, 0L, 80L)
                            val gesture = GestureDescription.Builder().addStroke(stroke).build()
                            dispatchGesture(gesture, null, null)
                        }
                    }
                }
            }, i * 70L)
        }
    }

    private fun tapCardTopRight(cardRect: Rect, acceptRect: Rect, tag: String) {
        val screenW = resources.displayMetrics.widthPixels.toFloat()
        val baseX = minOf(cardRect.right.toFloat(), screenW - 20f)
        val baseY = cardRect.top.toFloat()

        val taps = listOf(
            Pair(baseX - 15f, baseY + 25f),
            Pair(baseX - 15f, baseY + 15f),
            Pair(baseX - 15f, baseY + 10f),
            Pair(baseX - 20f, baseY + 15f),
            Pair(baseX - 10f, baseY + 15f),
            Pair(baseX - 15f, baseY + 5f)
        ).filter { it.first > 0f && it.second > 0f && it.second < acceptRect.top - 50 }

        Log.d(TAG, "$tag 카드상단탭 시작 — cardTop=${cardRect.top} cardRight=${cardRect.right} ${taps.size}개")
        LogBuffer.diag(this, "DISMISS-CARD-TOP-RIGHT", "source=tapCardTopRight, tag=$tag, cardTop=${cardRect.top}, cardRight=${cardRect.right}, totalCandidates=${taps.size}")

        val firstTap = taps.firstOrNull()
        if (firstTap != null) {
            showTapIndicator(firstTap.first.toInt(), firstTap.second.toInt(), false)
            shizukuExecutor.execute {
                for (pair in taps) {
                    val shizOk = shizukuTap(pair.first.toInt(), pair.second.toInt())
                    if (!shizOk && Build.VERSION.SDK_INT >= 24) {
                        handler.post {
                            val path = Path().apply { moveTo(pair.first, pair.second) }
                            val stroke = GestureDescription.StrokeDescription(path, 0L, 80L)
                            val gesture = GestureDescription.Builder().addStroke(stroke).build()
                            dispatchGesture(gesture, null, null)
                        }
                    }
                }
            }
        }
    }

    private fun tapXButtonTopRight(headerRect: Rect, startDelay: Long, tag: String) {
        val cx = headerRect.centerX().toFloat()
        val cy = headerRect.centerY().toFloat()
        val taps = listOf(
            Pair(cx, cy),
            Pair(cx + 15f, cy),
            Pair(cx - 15f, cy),
            Pair(cx, cy - 15f),
            Pair(cx, cy + 15f),
            Pair(cx + 25f, cy - 10f),
            Pair(cx - 25f, cy - 10f),
            Pair(cx + 25f, cy + 10f)
        ).filter { it.first > 0f && it.second > 0f }

        Log.d(TAG, "$tag 탭 시작 — 노드중심=(${cx.toInt()},${cy.toInt()}) bounds=$headerRect ${taps.size}개")
        LogBuffer.diag(this, "CANCEL-COORD", "취소버튼 최종 좌표 확정\nx=${cx.toInt()}\ny=${cy.toInt()}")
        LogBuffer.diag(this, "DISMISS-TOUCH", "source=ORIGINAL_FLOW_RESTORED, tag=$tag, coord=(${cx.toInt()},${cy.toInt()}), targetBounds=$headerRect")
        handler.postDelayed({
            showTapIndicator(cx.toInt(), cy.toInt(), false)
            shizukuExecutor.execute {
                LogBuffer.diag(this, "CANCEL-CLICK", "Shizuku 터치 실행\nx=${cx.toInt()}\ny=${cy.toInt()}")
                val shizOk = shizukuTap(cx.toInt(), cy.toInt())
                LogBuffer.diag(this, "CANCEL-CLICK-RESULT", "success=$shizOk\nresult=$shizOk")
                Log.d(TAG, "$tag Shizuku중심탭 (${cx.toInt()},${cy.toInt()}) → $shizOk")
                LogBuffer.diag(this, "CLOSE-SHIZUKU", "source=ORIGINAL_FLOW_RESTORED, tag=$tag, coord=(${cx.toInt()},${cy.toInt()}), result=$shizOk")
                if (!shizOk) {
                    handler.post {
                        taps.forEachIndexed { i, pair ->
                            handler.postDelayed({
                                if (Build.VERSION.SDK_INT >= 24) {
                                    val path = Path().apply { moveTo(pair.first, pair.second) }
                                    val stroke = GestureDescription.StrokeDescription(path, 0L, 80L)
                                    val gesture = GestureDescription.Builder().addStroke(stroke).build()
                                    val gestOk = dispatchGesture(gesture, null, null)
                                    LogBuffer.diag(this, "CLOSE-GESTURE", "source=ORIGINAL_FLOW_RESTORED, tag=$tag, idx=$i, coord=(${pair.first.toInt()},${pair.second.toInt()}), result=$gestOk (request dispatched, NOT verified success)")
                                }
                            }, i * 70L)
                        }
                    }
                }
            }
        }, startDelay)
    }

    private fun tapDismissCoordinates(acceptRect: Rect) {
        val screenW = resources.displayMetrics.widthPixels.toFloat()
        val xPositions = listOf(
            screenW - 55f,
            acceptRect.right - 30f,
            acceptRect.right - 68f,
            acceptRect.right - 110f
        ).distinct()

        val yOffsets = (100..1600 step 150).map { it.toFloat() }
        val priorityY = yOffsets.filter { it in 300f..900f }
        val remainderY = yOffsets.filter { it !in 300f..900f }

        val tapPositions = mutableListOf<Pair<Float, Float>>()
        for (dy in priorityY) {
            for (x in xPositions) {
                tapPositions.add(Pair(x, acceptRect.top - dy))
            }
        }
        for (dy in remainderY) {
            tapPositions.add(Pair(xPositions.first(), acceptRect.top - dy))
        }

        val validTaps = tapPositions.filter { (x, y) -> x > 0f && y in 50f..3000f }
        Log.d(TAG, "좌표탭 시작 — screenW=$screenW acceptRight=${acceptRect.right} top=${acceptRect.top} → ${validTaps.size}개")
        LogBuffer.diag(this, "CLOSE-FALLBACK", "source=ORIGINAL_FLOW_RESTORED, starting coordinate tap fallback, totalCandidates=${validTaps.size}")

        var delay = 0L
        for (pair in validTaps) {
            val x = pair.first
            val y = pair.second
            LogBuffer.diag(this, "CLOSE-FALLBACK-CANDIDATE", "source=ORIGINAL_FLOW_RESTORED, candidate=(${x.toInt()},${y.toInt()})")
            handler.postDelayed({
                if (Build.VERSION.SDK_INT >= 24) {
                    val path = Path().apply { moveTo(x, y) }
                    val stroke = GestureDescription.StrokeDescription(path, 0L, 80L)
                    val gesture = GestureDescription.Builder().addStroke(stroke).build()
                    val ok = dispatchGesture(gesture, null, null)
                    LogBuffer.diag(this, "CLOSE-FALLBACK-GESTURE", "source=ORIGINAL_FLOW_RESTORED, candidate=(${x.toInt()},${y.toInt()}), result=$ok (request dispatched, NOT verified success)")
                    if (!ok) {
                        Log.w(TAG, "dispatchGesture false @ (${String.format(Locale.US, "%.0f", x)}, ${String.format(Locale.US, "%.0f", y)})")
                    }
                }
            }, delay)
            delay += 80L
        }

        handler.postDelayed({
            Log.d(TAG, "좌표 탭 완료 → 400ms 후 검증")
            dismissVerify1(currentDismissSeq, currentDismissTargetFingerprint)
        }, delay + 400L)
    }

    private fun fallbackBack() {
        val pair = findCallCard(source = "FALLBACK_BACK")
        if (pair == null) {
            Log.d(TAG, "폴백: 카드 이미 없음 → 성공 처리")
            LogBuffer.diag(this, "CANCEL-VERIFY", "취소 성공 확인\ncardGone=true")
            LogBuffer.diag(this, "DISMISS-VERIFY-FINAL", "source=ORIGINAL_FLOW_RESTORED, fallbackBack check: card already gone")
            LogBuffer.diag(this, "DISMISS-SUCCESS-CONDITION", "source=ORIGINAL_FLOW_RESTORED, cardPresent=false, verificationPassed=true, via=fallback_already_gone")
            recordDismissSuccess()
            return
        }
        try { pair.first.recycle() } catch (_: Throwable) {}
        LogBuffer.diag(this, "CANCEL-VERIFY", "취소 결과 확인\ncardGone=false")
        try { pair.second?.recycle() } catch (_: Throwable) {}
        if (dismissAttempts >= 3) {
            Log.w(TAG, "폴백: 3회 실패 → 포기 (뒤로가기 사용 안 함)")
            LogBuffer.diag(this, "DISMISS-FAIL", "source=ORIGINAL_FLOW_RESTORED, fallbackBack: 3 attempts failed -> give up")
            recordDismissSuccess()
            return
        }
        Log.w(TAG, "폴백: 카드 아직 있음, 재시도 예정 ($dismissAttempts/3)")
        LogBuffer.diag(this, "DISMISS-RETRY", "source=ORIGINAL_FLOW_RESTORED, fallbackBack: card still exists, retry scheduled ($dismissAttempts/3)")
        val rect = savedAcceptRect
        if (rect == null) {
            Log.w(TAG, "savedAcceptRect 없어 재시도 불가 → 포기")
            recordDismissSuccess()
        } else {
            handler.postDelayed({
                performDismissFresh()
            }, 2500L)
        }
    }

    private fun abortDismissSession(reason: String) {
        val pendingBefore = pendingDismiss
        val seqBefore = currentDismissSeq
        val dismissAttemptsBefore = dismissAttempts
        currentDismissSeq++
        currentDismissTargetFingerprint = null
        callCardFirstSeenAt = 0L
        pendingDismiss = false
        dismissAttempts = 0
        handler.removeCallbacks(dismissTimeoutRunnable)
        Log.d(TAG, "거절 세션 안전 종료 (사유: $reason, seq=$currentDismissSeq)")
        LogBuffer.diag(this, "DISMISS-ABORT", "reason=$reason, seq=$currentDismissSeq")
        LogBuffer.diag(
            this,
            "DISMISS-TRACE",
            "ABORT_SESSION\n" +
            "reason=$reason\n" +
            "seq=$seqBefore\n" +
            "currentSeq=$currentDismissSeq\n" +
            "pendingDismiss_before=$pendingBefore\n" +
            "pendingDismiss_after=$pendingDismiss\n" +
            "pendingAccept=$pendingAccept\n" +
            "dismissAttempts=$dismissAttemptsBefore"
        )
        if (reason == "NEW_CARD_PROTECTED" || reason == "UNKNOWN_FAIL_SAFE" || reason == "CARD_STILL_VISIBLE_AFTER_RETRY") {
            handler.removeCallbacks(pollRunnable)
            handler.postDelayed(pollRunnable, 50L)
            handler.postDelayed({ dispatchScan("DISMISS_HANDOVER") }, 50L)
        }
    }

    private fun recordDismissSuccess() {
        val pendingBefore = pendingDismiss
        val seqBefore = currentDismissSeq
        val dismissAttemptsBefore = dismissAttempts
        LogBuffer.diag(
            this,
            "DISMISS-TRACE",
            "SUCCESS_START\n" +
            "seq=$seqBefore\n" +
            "pendingDismiss_before=$pendingBefore\n" +
            "dismissAttempts=$dismissAttemptsBefore"
        )
        currentDismissSeq++
        currentDismissTargetFingerprint = null
        lastDismissTime = System.currentTimeMillis()
        PrefsManager.incrementDismissCount(this)
        savedAcceptRect = null
        pendingDismiss = false
        dismissAttempts = 0
        handler.removeCallbacks(dismissTimeoutRunnable)
        Log.d(TAG, "닫기 완료 — 총 ${PrefsManager.getDismissCount(this)}회")
        LogBuffer.diag(this, "DISMISS-SUCCESS", "source=ORIGINAL_FLOW_RESTORED, dismiss verified success on screen")
        LogBuffer.diag(this, "DISMISS-SUCCESS-COUNT", "source=ORIGINAL_FLOW_RESTORED, totalSuccessCount=${PrefsManager.getDismissCount(this)}")
        LogBuffer.diag(
            this,
            "DISMISS-TRACE",
            "SUCCESS_RESET\n" +
            "pendingDismiss_after=$pendingDismiss\n" +
            "dismissAttempts_after=$dismissAttempts\n" +
            "lastDismissTime=$lastDismissTime\n" +
            "savedAcceptRect=${savedAcceptRect ?: "null"}\n" +
            "pollResumeDelay=200"
        )
        sendBroadcast(Intent("com.uber.autoaccept.ACCEPT_EVENT"))
        handler.removeCallbacks(pollRunnable)
        handler.postDelayed(pollRunnable, 200L)
    }

    data class ShizukuResult(val isAvail: Boolean, val hasPerm: Boolean, val success: Boolean, val exitCode: Int, val elapsedMs: Long, val stderr: String = "", val exception: String = "")

    fun performShizukuTap(x: Int, y: Int): ShizukuResult {
        val t0 = System.currentTimeMillis()
        var ping = false
        var perm = false
        var success = false
        var exit = -1
        var errStr = ""
        var excStr = ""

        LogBuffer.diag(this, "SHIZUKU-TOUCH", "x=$x\ny=$y")

        try {
            ping = Shizuku.pingBinder()
            perm = (Shizuku.checkSelfPermission() == 0)
            if (ping && perm) {
                val cmd = arrayOf("input", "tap", x.toString(), y.toString())
                val method = Shizuku::class.java.getDeclaredMethod(
                    "newProcess",
                    Array<String>::class.java,
                    Array<String>::class.java,
                    String::class.java
                )
                method.isAccessible = true
                val process = method.invoke(null, cmd, null, null) as? Process
                if (process != null) {
                    val stderrReader = java.io.BufferedReader(java.io.InputStreamReader(process.errorStream))
                    val stdoutReader = java.io.BufferedReader(java.io.InputStreamReader(process.inputStream))
                    exit = process.waitFor()
                    val stdout = stdoutReader.readText().trim()
                    val stderr = stderrReader.readText().trim()
                    errStr = if (stderr.isNotEmpty()) stderr else if (stdout.isNotEmpty()) "stdout: $stdout" else ""
                    success = (exit == 0)
                } else {
                    errStr = "process is null after reflection invoke"
                }
            } else {
                errStr = "pingBinder=$ping, permission=$perm"
            }
        } catch (e: Throwable) {
            excStr = e.message ?: e.javaClass.simpleName
            Log.w(TAG, "Shizuku tap 실패: ${e.message}")
        }

        val elapsed = System.currentTimeMillis() - t0
        LogBuffer.diag(this, "SHIZUKU-RESULT", "success=$success\nexitCode=$exit\npingBinder=$ping\npermission=$perm\nelapsed=${elapsed}ms")
        if (!success) {
            LogBuffer.diag(this, "SHIZUKU-ERROR", "stderr=$errStr\nexception=$excStr")
        }
        LogBuffer.diag(this, "TOUCH-A-SHIZUKU", "pingBinder=$ping\npermission=$perm\nsuccess=$success\nexitCode=$exit\nelapsedMs=$elapsed")
        return ShizukuResult(ping, perm, success, exit, elapsed, errStr, excStr)
    }

    fun shizukuTap(x: Int, y: Int): Boolean {
        return performShizukuTap(x, y).success
    }

    private fun showTapIndicator(x: Int, y: Int, isAccept: Boolean) {
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val size = (40 * resources.displayMetrics.density).toInt()
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (isAccept) Color.parseColor("#8006C167") else Color.parseColor("#80E11900"))
                    setStroke((2 * resources.displayMetrics.density).toInt(), Color.WHITE)
                }
            }
            val lp = WindowManager.LayoutParams(
                size, size,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                this.x = x - size / 2
                this.y = y - size / 2
            }
            wm.addView(dot, lp)
            handler.postDelayed({
                try {
                    wm.removeView(dot)
                } catch (_: Throwable) {
                }
            }, 600L)
        } catch (_: Throwable) {
        }
    }

    fun normalizeOcrForFingerprint(text: String): String {
        return text.filter { c ->
            c.isLetterOrDigit() || "가맹전용일반호출콜분뒤픽업가능거리km남음구로종로용산구중구장거리경유지".contains(c)
        }
    }

    private fun startOcrAndDecide(
        ocrRect: Rect,
        dismissCardRect: Rect,
        dismissTapX: Int,
        dismissTapY: Int,
        isOverlay: Boolean,
        acceptRect: Rect,
        acceptNode: AccessibilityNodeInfo?,
        keywords: List<String>,
        blacklistMode: Boolean,
        retryCount: Int = 0
    ) {
        ocrCaptureInflight = true
        handler.removeCallbacks(ocrCaptureWatchdog)
        handler.postDelayed(ocrCaptureWatchdog, 5000L)

        try {
            takeScreenshot(0, ContextCompat.getMainExecutor(this), OcrScreenshotCallback(
                ocrRect, dismissCardRect, dismissTapX, dismissTapY, isOverlay, acceptRect, acceptNode, keywords, blacklistMode, retryCount
            ))
        } catch (e: Exception) {
            Log.w(TAG, "OCR takeScreenshot 호출 실패: ${e.message}")
            handler.removeCallbacks(ocrCaptureWatchdog)
            ocrCaptureInflight = false
            pendingAccept = false
        }
    }

    private inner class OcrScreenshotCallback(
        private val cardRect: Rect,
        private val dismissCardRect: Rect,
        private val dismissTapX: Int,
        private val dismissTapY: Int,
        private val isOverlay: Boolean,
        private val acceptRect: Rect,
        private val acceptNode: AccessibilityNodeInfo?,
        private val keywords: List<String>,
        private val blacklistMode: Boolean,
        private val retryCount: Int
    ) : TakeScreenshotCallback {
        override fun onSuccess(screenshot: ScreenshotResult) {
            ocrCaptureInflight = false
            handler.removeCallbacks(ocrCaptureWatchdog)
            val hwBm = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
            if (hwBm == null) {
                pendingAccept = false
                return
            }
            val t0 = System.currentTimeMillis()
            val softBm = hwBm.copy(Bitmap.Config.ARGB_8888, false)
            hwBm.recycle()

            val cropX = cardRect.left.coerceAtLeast(0)
            val cropY = cardRect.top.coerceAtLeast(0)
            val cw = cardRect.width().coerceAtMost(softBm.width - cropX).coerceAtLeast(1)
            val ch = cardRect.height().coerceAtMost(softBm.height - cropY).coerceAtLeast(1)
            val cropped = Bitmap.createBitmap(softBm, cropX, cropY, cw, ch)
            val cropBitmapSuccess = (cropped != null)

            val currentRoot = findUberRoot()
            val rootAvail = (currentRoot != null)
            try { currentRoot?.recycle() } catch (_: Throwable) {}

            LogBuffer.diag(
                this@AutoAcceptService,
                "OCR-DIAG-START",
                "timestamp=$t0\nrect=Rect($cropX,$cropY - ${cropX + cw},${cropY + ch})\nwidth=$cw\nheight=$ch\nbitmapSuccess=$cropBitmapSuccess\nrootAvailable=$rootAvail"
            )

            LogBuffer.diag(
                this@AutoAcceptService,
                "OCR-EXEC-START",
                "acceptBtnBounds=$acceptRect\n" +
                "ocrRect=Rect($cropX,$cropY - ${cropX + cw},${cropY + ch})\n" +
                "source=${if (cardRect.height() < 500) "DYNAMIC_TEXT_UNION" else "CARD_BOUNDS"}\n" +
                "collectedTextCount=${if (cardRect.height() < 500) 3 else 0}\n" +
                "isFallback=${cardRect.height() >= 500}"
            )

            val t1 = System.currentTimeMillis()
            Log.d(TAG, "크롭 소요: ${t1 - t0}ms")
            LogBuffer.log(this@AutoAcceptService, TAG, "크롭 소요: ${t1 - t0}ms")

            val image = InputImage.fromBitmap(cropped, 0)
            val recognizer = try { getOcrRecognizer() } catch (_: Throwable) { null }
            if (recognizer == null) {
                LogBuffer.log(this@AutoAcceptService, TAG, "OCR Recognizer 미준비 상태 — 초기화 요청")
                ensureOcrModuleInstalled()
                cropped.recycle()
                try { softBm.recycle() } catch (_: Throwable) {}
                ocrCaptureInflight = false
                return
            }
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val t2 = System.currentTimeMillis()
                    val ocrElapsed = t2 - t1
                    val fullElapsed = t2 - t0
                    cropped.recycle()

                    val rawOcr = visionText.text
                    val ocrText = rawOcr.replace("\\s+".toRegex(), " ").trim()
                    setOcrState(OcrState.READY, "OCR 텍스트 인식 성공 (${ocrElapsed}ms)")
                    Log.d(TAG, "⏱️ ML Kit OCR: ${ocrElapsed}ms (전체 ${fullElapsed}ms) — 텍스트='$ocrText'")
                    LogBuffer.log(this@AutoAcceptService, TAG, "⏱️ ML Kit OCR: ${ocrElapsed}ms (전체 ${fullElapsed}ms) — 텍스트='$ocrText'")

                    LogBuffer.diag(
                        this@AutoAcceptService,
                        "OCR-DIAG-RESULT",
                        "timestamp=$t2\nelapsed=${ocrElapsed}ms\ntext='$ocrText'\nchars=${ocrText.length}"
                    )

                    if (PrefsManager.isAcceptScreenshot(this@AutoAcceptService)) {
                        val bmCopy = softBm.copy(Bitmap.Config.ARGB_8888, false)
                        Thread {
                            try {
                                saveAcceptScreenshotToGallery(bmCopy)
                            } catch (_: Throwable) {
                            }
                        }.start()
                    }

                    try { softBm.recycle() } catch (_: Throwable) {}

                    handler.post {
                        processOcrDecision(
                            ocrText = ocrText,
                            acceptRect = acceptRect,
                            acceptNode = acceptNode,
                            dismissCardRect = dismissCardRect,
                            dismissTapX = dismissTapX,
                            dismissTapY = dismissTapY,
                            isOverlay = isOverlay,
                            keywords = keywords,
                            blacklistMode = blacklistMode,
                            xFromPixels = null,
                            startTime = t0
                        )
                    }
                }
                .addOnFailureListener { e ->
                    val causeMsg = e.cause?.message ?: e.message ?: "unknown"
                    lastOcrFailTime = System.currentTimeMillis()
                    setOcrState(OcrState.DETECTOR_INIT_FAILED, "OCR 실패: ${e.javaClass.simpleName} - $causeMsg")
                    Log.e(TAG, "💥 [OCR-FAILURE] Exception=${e.javaClass.name}, Message=${e.message}, Cause=$causeMsg")
                    LogBuffer.log(this@AutoAcceptService, TAG, "💥 [OCR-FAILURE] ${e.javaClass.simpleName}: $causeMsg")
                    logMlKitDetailedDiagnostic(e)

                    try { cropped.recycle() } catch (_: Throwable) {}
                    try { softBm.recycle() } catch (_: Throwable) {}
                    pendingAccept = false
                }
        }

        override fun onFailure(errorCode: Int) {
            ocrCaptureInflight = false
            handler.removeCallbacks(ocrCaptureWatchdog)
            Log.w(TAG, "OCR takeScreenshot onFailure: errorCode=$errorCode")
            LogBuffer.log(this@AutoAcceptService, TAG, "OCR takeScreenshot onFailure: errorCode=$errorCode")
            pendingAccept = false
        }
    }

    private fun processOcrDecision(
        ocrText: String,
        acceptRect: Rect,
        acceptNode: AccessibilityNodeInfo?,
        dismissCardRect: Rect,
        dismissTapX: Int,
        dismissTapY: Int,
        isOverlay: Boolean,
        keywords: List<String>,
        blacklistMode: Boolean,
        xFromPixels: Pair<Int, Int>?,
        startTime: Long
    ) {
        val now = System.currentTimeMillis()
        val winPkg = lastForegroundPkg ?: UBER_DRIVER_PACKAGE
        val cardKey = "ocr_${winPkg}_$now"

        // Guard against OCR text originating from queue position notice banner / app UI
        val isQueueBannerText = (ocrText.contains("순번제 배차") || ocrText.contains("입국장 1C 또는 10C") || ocrText.contains("예약등을 켜주세요") || ocrText.contains("대기장소")) &&
                (ocrText.contains("대기 시간") || ocrText.contains("차량 180대") || ocrText.contains("일렬로 대기") || ocrText.contains("운행 리스트"))
        if (isQueueBannerText) {
            Log.d(TAG, "🛡️ 공항 순번제 배너 OCR 텍스트 감지 → 무시 (콜카드 아님)")
            LogBuffer.diag(this, "BANNER-IGNORE", "package=$winPkg\nreason=OCR_QUEUE_BANNER_TEXT")
            pendingAccept = false
            try { acceptNode?.recycle() } catch (_: Throwable) {}
            return
        }

        var matchedKeyword: String? = null
        val cleanOcrText = ocrText.replace("\\s+".toRegex(), "").replace("[^가-힣a-zA-Z0-9]".toRegex(), "")
        for (kw in keywords) {
            val trimmedKw = kw.trim()
            if (trimmedKw.isEmpty()) continue
            val cleanKw = trimmedKw.replace("\\s+".toRegex(), "").replace("[^가-힣a-zA-Z0-9]".toRegex(), "")

            val directMatch = ocrText.contains(trimmedKw, ignoreCase = true)
            val cleanMatch = cleanKw.isNotEmpty() && cleanOcrText.contains(cleanKw, ignoreCase = true)

            if (directMatch || cleanMatch) {
                matchedKeyword = trimmedKw
                break
            }
        }

        val keywordFound = matchedKeyword != null
        val isAirport = keywordFound
        val shouldAccept = if (blacklistMode) !keywordFound else keywordFound

        val matchReason = if (matchedKeyword != null) "KEYWORD_FOUND" else "NO_KEYWORDS_MATCHED"
        val ocrMismatch = !shouldAccept
        Log.d(TAG, "블랙리스트모드=$blacklistMode keywordFound=$keywordFound → shouldAccept=$shouldAccept")
        LogBuffer.log(this, TAG, if (shouldAccept) "🟢 OCR 키워드 일치 → 수락 (블랙리스트=$blacklistMode)" else "🔴 OCR 키워드 불일치 → 닫기 (블랙리스트=$blacklistMode)")

        LogBuffer.diag(
            this,
            "CALL-DECISION",
            "seq=$currentCallSessionSeq\n" +
            "cardKey=$cardKey\n" +
            "shouldAccept=$shouldAccept\n" +
            "ocrMismatch=$ocrMismatch\n" +
            "autoDismiss=${PrefsManager.isAutoDismiss(this)}\n" +
            "pendingDismiss=$pendingDismiss\n" +
            "pendingAccept=$pendingAccept"
        )

        LogBuffer.diag(
            this,
            "ACCEPT-DECISION",
            "matched=${matchedKeyword ?: "null"}\n" +
            "shouldAccept=$shouldAccept\n" +
            "ocrMismatch=$ocrMismatch\n" +
            "autoDismiss=${PrefsManager.isAutoDismiss(this)}\n" +
            "ocrText='$ocrText'\n" +
            "activeKeywords=${keywords.joinToString(",")}"
        )

        LogBuffer.diag(
            this,
            "OCR-TEXT-DEBUG",
            "ocrRawText='$ocrText'\n" +
            "matchedKeyword='${matchedKeyword ?: "null"}'\n" +
            "shouldAccept=$shouldAccept\n" +
            "ocrMismatch=$ocrMismatch"
        )

        LogBuffer.diag(
            this,
            "OCR-EXEC-END",
            "elapsedMs=${now - startTime}\n" +
            "rawText='$ocrText'\n" +
            "matchedKeyword=${matchedKeyword ?: "null"}\n" +
            "shouldAccept=$shouldAccept"
        )

        LogBuffer.diag(
            this,
            "OCR-DIAG-MATCH",
            "text='$ocrText'\nmatched=${matchedKeyword ?: "null"}\nreason=$matchReason"
        )

        LogBuffer.diag(
            this,
            "CALLCARD-KEYWORD",
            "candidateTexts='$ocrText', matched=${matchedKeyword ?: "null"}, matchSource=ocr, matchReason=$matchReason"
        )

        LogBuffer.diag(
            this,
            "ACCEPT-CONDITION",
            "OCR Evaluation: acceptAll=false, blacklist=$blacklistMode, matched='$matchedKeyword' -> shouldAccept=$shouldAccept [공항=$isAirport]"
        )

        val cardMarkerList = listOf("분 거리", "분거리", "km 남음", "km남음", "★", "⭐", "*", "분 뒤", "이내 도착", "픽업 가능", "분", "km", "거리", "남음", "운행", "도착", "픽업", "콜", "호출")
        val markerHits = cardMarkerList.count { ocrText.contains(it) }
        val hasCallAcceptText = ocrText.contains("콜 수락") || ocrText.contains("콜수락")
        val matchedAcceptKw = when {
            ocrText.contains("콜 수락") -> "콜 수락"
            ocrText.contains("콜수락") -> "콜수락"
            else -> null
        }
        if (matchedAcceptKw != null) {
            LogBuffer.diag(this, "ACCEPT-MATCH", "matched=$matchedAcceptKw\nsource=OCR")
        } else {
            LogBuffer.diag(this, "ACCEPT-MISS", "reason=NO_EXACT_ACCEPT_KEYWORD\nsource=OCR")
        }

        LogBuffer.diag(
            this,
            "OCR-SOURCE",
            "totalChars=${ocrText.length}\ncardRegionChars=${ocrText.length}\nmarkerHits=$markerHits\nhasCallAcceptText=$hasCallAcceptText\nmatchReason=$matchReason"
        )

        if (shouldAccept) {
            val isUberPkg = winPkg == UBER_DRIVER_PACKAGE
            val hasCardMarker = hasCallAcceptText || markerHits >= 1
            if (!isUberPkg && !hasCardMarker) {
                LogBuffer.log(this, TAG, "🛡️ 가짜 매칭 차단 → 수락 취소 (pkg=$winPkg uber=$isUberPkg 카드마커=$hasCardMarker)")
                Log.w(TAG, "가짜 매칭 차단: pkg=$winPkg uber=$isUberPkg 카드마커=$hasCardMarker ocr=${ocrText.take(120)}")
                pendingAccept = false
                try { acceptNode?.recycle() } catch (_: Throwable) {}
                return
            }
            val delay = 570L
            val ocrMatchTimestamp = System.currentTimeMillis()
            LogBuffer.diag(this, "ACCEPT-DELAY", "delay=570ms")
            val cx = acceptRect.centerX()
            val cy = acceptRect.centerY()
            val tmplLog = "tmpl=생략(옵션A)→노드($cx,$cy)"

            Log.d(TAG, "OCR 키워드 일치 → ${delay}ms 후 수락 ($tmplLog) [공항=$isAirport]")
            LogBuffer.log(this, TAG, "OCR 키워드 일치 → ${delay}ms 후 수락 ($cx,$cy) [공항=$isAirport]")

            val newCount = PrefsManager.getAcceptScheduled(this) + 1
            LogBuffer.diag(this, "ACCEPT-COUNT", "source=processOcrDecision, reason=ocr_match, cardKey=$cardKey, coords=($cx, $cy), totalCount=$newCount")
            PrefsManager.incrementAcceptScheduled(this, source = "ocr")

            // Release old initial acceptNode reference before delay
            try { acceptNode?.recycle() } catch (_: Throwable) {}

            handler.postDelayed({
                val delayCompleteTimestamp = System.currentTimeMillis()
                lastAcceptTime = delayCompleteTimestamp
                LogBuffer.diag(
                    this,
                    "ACCEPT-TIMING",
                    "ocrMatchTimestamp=$ocrMatchTimestamp\ndelayMs=$delay\ndelayCompleteTimestamp=$delayCompleteTimestamp"
                )
                executeAcceptWithRequery(
                    initialRect = acceptRect,
                    winPkg = winPkg,
                    cardKey = cardKey,
                    ocrMatchTimestamp = ocrMatchTimestamp,
                    delayCompleteTimestamp = delayCompleteTimestamp,
                    source = "OCR"
                )
            }, delay)
        } else {
            Log.d(TAG, "OCR 키워드 불일치 → 거절 (overlay=$isOverlay tap=$dismissTapX,$dismissTapY)")
            try { acceptNode?.recycle() } catch (_: Throwable) {}
            pendingAccept = false

            val autoDismiss = PrefsManager.isAutoDismiss(this)

            LogBuffer.diag(
                this,
                "DISMISS-DECISION",
                "shouldAccept=false\n" +
                "ocrMismatch=true\n" +
                "autoDismiss=$autoDismiss\n" +
                "reason=KEYWORD_MISMATCH"
            )

            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "OCR_DECISION_START\n" +
                "reason=KEYWORD_MISMATCH\n" +
                "pendingAccept=$pendingAccept\n" +
                "pendingDismiss=$pendingDismiss\n" +
                "currentDismissSeq=$currentDismissSeq\n" +
                "lastDismissTime=$lastDismissTime\n" +
                "now=$now\n" +
                "elapsedSinceLastDismiss=${now - lastDismissTime}"
            )

            if (now - lastAcceptTime < 5000L) {
                Log.d(TAG, "수락 쿨다운 중 → 거절 건너뜀 (${(now - lastAcceptTime) / 1000}s)")
                return
            }

            LogBuffer.diag(
                this,
                "DISMISS-UI-BIND",
                "uiAutoDismiss=$autoDismiss\n" +
                "resolvedAutoDismiss=$autoDismiss\n" +
                "preferenceKey=auto_dismiss\n" +
                "source=PREFS_MANAGER"
            )
            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "DISMISS_GATE_CHECK\n" +
                "autoDismiss=$autoDismiss\n" +
                "blacklistMode=$blacklistMode\n" +
                "shouldAccept=false\n" +
                "ocrMismatch=true\n" +
                "reason=KEYWORD_MISMATCH\n" +
                "pendingAccept=$pendingAccept\n" +
                "pendingDismiss=$pendingDismiss\n" +
                "currentDismissSeq=$currentDismissSeq\n" +
                "lastDismissTime=$lastDismissTime"
            )

            if (!autoDismiss) {
                LogBuffer.diag(
                    this,
                    "DISMISS-GATE",
                    "autoDismiss=false\n" +
                    "ocrMismatch=true\n" +
                    "action=SKIP_DISMISS\n" +
                    "reason=AUTO_DISMISS_DISABLED"
                )
                LogBuffer.diag(
                    this,
                    "DISMISS-TRACE",
                    "DISMISS_GATE_BLOCKED\n" +
                    "action=SKIP_DISMISS\n" +
                    "reason=AUTO_DISMISS_DISABLED"
                )
                Log.d(TAG, "불일치 콜 자동 닫기 비활성화(OFF) → 닫기 건너뜀")
                LogBuffer.log(this, TAG, "⏸️ 불일치 콜 자동 닫기 OFF → 닫기 건너뜀")
                return
            }

            LogBuffer.diag(
                this,
                "DISMISS-GATE",
                "autoDismiss=true\n" +
                "ocrMismatch=true\n" +
                "action=PROCEED_DISMISS\n" +
                "reason=KEYWORD_MISMATCH"
            )
            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "DISMISS_GATE_PASS\n" +
                "action=PROCEED_DISMISS_RESOLVE"
            )

            // Sparse OCR safety check: only hold if image OCR returned virtually no text / card markers
            val hasCardSignal = hasCallAcceptText || markerHits >= 1 || ocrText.length in 8..150
            if (!hasCardSignal && ocrText.length < 8) {
                pendingAccept = false
                if (!lastLoggedSparseOcrState) {
                    lastLoggedSparseOcrState = true
                    LogBuffer.diag(this, "OCR-RETRY", "빈약 OCR → 다음 사이클 재확인 (마커=$markerHits 길이=${ocrText.length})")
                    LogBuffer.log(this, TAG, "⏸️ OCR 빈약 → 닫기 보류, 다음 사이클 대기 (마커=$markerHits 길이=${ocrText.length})")
                }
                return
            }
            lastLoggedSparseOcrState = false

            PrefsManager.incrementDismissScheduled(this)

            LogBuffer.diag(this, "DIAG-CANCEL-ENTER", "cancel button search entered")
            LogBuffer.diag(this, "CANCEL-SEARCH", "취소버튼 탐색 시작")
            LogBuffer.log(this, TAG, "🔴 OCR 키워드 불일치 → 닫기 (블랙리스트=$blacklistMode)")

            val root = findUberRoot()
            val coords = resolveDismissCoordinates(root, dismissCardRect, acceptRect)
            try { root?.recycle() } catch (_: Throwable) {}

            if (coords != null) {
                val (dx, dy) = coords
                LogBuffer.log(this, TAG, "🎯 콜카드 우측 상단 X좌표로 닫기: ($dx, $dy) [card=(${dismissCardRect.left},${dismissCardRect.top} ~ ${dismissCardRect.right},${dismissCardRect.bottom})]")
                executeDismissAtPos(dx, dy)
            } else {
                LogBuffer.log(this, TAG, "🛡️ 유효한 콜카드 bounds 미확인 → 닫기 시도 중단 (임의 좌표 터치 방지)")
                abortDismissSession("INVALID_CARD_BOUNDS")
            }
        }
    }

    fun doScreenshotPoll() {
        if (ocrCaptureInflight) return
        if (!isForegroundUber()) return
        dispatchScan("OCR_POLL")
    }

    private fun processOcrText(text: Text, bitmap: Bitmap) {
        try {
            if (!isForegroundUber()) {
                return
            }
            val winPkg = lastForegroundPkg ?: UBER_DRIVER_PACKAGE

            val ocrStr = text.text
            val fullText = ocrStr.replace("\\s+".toRegex(), " ")
            val now = System.currentTimeMillis()
            val isUber = winPkg == UBER_DRIVER_PACKAGE || winPkg == SIMULATOR_PACKAGE
            val cardKey = "ocr_${winPkg}_$now"

            if (now - lastAcceptTime < COOLDOWN_MS || pendingAccept) {
                bitmap.recycle()
                return
            }

            val acceptAll = PrefsManager.isAcceptAll(this)
            val blacklistMode = PrefsManager.isBlacklistMode(this)
            val keywords = PrefsManager.getKeywords(this)

            var hasAcceptKeyword = false
            for (btnText in ACCEPT_BUTTON_TEXTS) {
                if (fullText.contains(btnText, ignoreCase = true)) {
                    hasAcceptKeyword = true
                    break
                }
            }

            if (!hasAcceptKeyword) {
                bitmap.recycle()
                return
            }

            var matchedKw: String? = null
            for (kw in keywords) {
                if (kw.isNotEmpty() && fullText.contains(kw, ignoreCase = true)) {
                    matchedKw = kw
                    break
                }
            }

            val shouldAccept = when {
                acceptAll -> true
                blacklistMode -> matchedKw == null
                else -> matchedKw != null
            }

            LogBuffer.diag(this, "ACCEPT-CONDITION", "OCR Evaluation: acceptAll=$acceptAll, blacklist=$blacklistMode, matched='$matchedKw' -> shouldAccept=$shouldAccept, isUber=$isUber")

            if (shouldAccept) {
                var acceptPos: Pair<Int, Int>? = null
                for (block in text.textBlocks) {
                    for (line in block.lines) {
                        for (element in line.elements) {
                            if (ACCEPT_BUTTON_TEXTS.any { element.text.contains(it, ignoreCase = true) }) {
                                val box = element.boundingBox
                                if (box != null) {
                                    acceptPos = Pair(box.centerX(), box.centerY())
                                    break
                                }
                            }
                        }
                        if (acceptPos != null) break
                    }
                    if (acceptPos != null) break
                }

                if (acceptPos == null) {
                    acceptPos = findAcceptButtonByTemplate(bitmap)
                }

                if (acceptPos != null) {
                    val rect = Rect(acceptPos.first - 50, acceptPos.second - 20, acceptPos.first + 50, acceptPos.second + 20)
                    savedAcceptRect = rect
                    val candDetails = "foregroundPkg=$lastForegroundPkg, windowPkg=$winPkg, target=(${acceptPos.first}, ${acceptPos.second}), bounds=$rect, cardKey=$cardKey, method=OCR/Template, isUber=$isUber"
                    LogBuffer.diag(this, "ACCEPT-CANDIDATE", candDetails)
                    if (!isUber) {
                        LogBuffer.diag(this, "FALSE-POSITIVE-CANDIDATE", "Non-Uber screen detected as OCR candidate: $candDetails")
                    }
                    executeAcceptAtPos(acceptPos.first, acceptPos.second, rect, "OCR/Template", cardKey)
                }
            } else {
                val autoDismiss = PrefsManager.isAutoDismiss(this)
                if (autoDismiss && !pendingDismiss && !pendingAccept) {
                    LogBuffer.diag(this, "DIAG-CANCEL-ENTER", "cancel button search entered")
                    LogBuffer.diag(this, "CANCEL-SEARCH", "취소버튼 탐색 시작")
                    LogBuffer.log(this, TAG, "🔴 OCR 키워드 불일치 → 닫기 (블랙리스트=$blacklistMode)")
                    val isSparseOcr = fullText.length < 10
                    val root = findUberRoot()
                    val cardRect = savedAcceptRect?.let { Rect(0, (it.top - 800).coerceAtLeast(0), bitmap.width, it.top) }
                    val coords = resolveDismissCoordinates(root, cardRect, savedAcceptRect, bitmap, fullText)
                    try { root?.recycle() } catch (_: Throwable) {}

                    if (coords != null) {
                        val (x, y) = coords
                        LogBuffer.log(this, TAG, "📸 스크린샷폴링 닫기 X=($x,$y)")
                        executeDismissAtPos(x, y)
                    } else {
                        LogBuffer.log(this, TAG, "🛡️ 유효한 콜카드 bounds 미확인 → 닫기 시도 중단")
                        abortDismissSession("INVALID_CARD_BOUNDS")
                    }
                }
            }
        } finally {
            bitmap.recycle()
        }
    }

    private fun executeAcceptWithRequery(
        initialRect: Rect,
        winPkg: String,
        cardKey: String,
        ocrMatchTimestamp: Long,
        delayCompleteTimestamp: Long,
        source: String = "OCR"
    ) {
        val ocrToDelayComplete = delayCompleteTimestamp - ocrMatchTimestamp
        val targetRect = savedAcceptRect?.takeIf { !it.isEmpty } ?: initialRect.takeIf { !it.isEmpty }

        // 정상 백업본 복원: 이미 최초 콜카드 탐지 단계에서 확보된 유효 좌표가 존재하면 570ms 만료 직후 즉시 터치 실행
        if (targetRect != null && targetRect.width() > 0 && targetRect.height() > 0) {
            val cx = targetRect.centerX()
            val cy = targetRect.centerY()
            val tExecute = System.currentTimeMillis()
            LogBuffer.diag(
                this,
                "ACCEPT-DIRECT",
                "source=$source\ncoords=($cx, $cy)\nbounds=$targetRect\nsavedRectUsed=true"
            )
            performAcceptExecution(
                cx = cx,
                cy = cy,
                targetRect = targetRect,
                targetBtnText = "콜 수락",
                winPkg = winPkg,
                cardKey = cardKey,
                source = source,
                ocrToDelayComplete = ocrToDelayComplete,
                delayCompleteToRoot = 0L,
                rootToNode = 0L,
                tNodeFound = tExecute
            )
            return
        }

        val tRequeryStart = System.currentTimeMillis()

        // 1. 최신 Uber Root 재획득 (예외적으로 최초 좌표가 전혀 없는 경우에만 fallback으로 실행)
        val root = findUberRoot()
        val tRootAcquired = System.currentTimeMillis()
        val delayCompleteToRoot = tRootAcquired - delayCompleteTimestamp

        val rootPkg = root?.packageName?.toString() ?: "none"
        val rootFound = (root != null)
        LogBuffer.diag(this, "ACCEPT-REQUERY", "timestamp=$tRootAcquired\nroot=${if (rootFound) "FOUND" else "NOT_FOUND"}\npackage=$rootPkg")

        // 2. 최신 Root에서 수락 버튼 재탐색
        val acceptBtn = if (root != null) findAcceptButton(root) else null
        val tNodeFound = System.currentTimeMillis()
        val rootToNode = tNodeFound - tRootAcquired

        val nodeFound = (acceptBtn != null)
        LogBuffer.diag(this, "ACCEPT-REQUERY", "node=${if (nodeFound) "FOUND" else "NOT_FOUND"}")

        if (nodeFound && acceptBtn != null) {
            // CASE A, C, D: 최신 Node 발견 → 최신 bounds 확인 및 중심 좌표 계산
            val freshBounds = Rect()
            acceptBtn.getBoundsInScreen(freshBounds)
            val cx = freshBounds.centerX()
            val cy = freshBounds.centerY()

            LogBuffer.diag(this, "ACCEPT-REQUERY", "bounds=$freshBounds\ncenterX=$cx\ncenterY=$cy")

            val targetBtnText = acceptBtn.text?.toString() ?: acceptBtn.contentDescription?.toString() ?: "콜 수락"
            try { acceptBtn.recycle() } catch (_: Throwable) {}
            try { root?.recycle() } catch (_: Throwable) {}

            performAcceptExecution(
                cx = cx,
                cy = cy,
                targetRect = freshBounds,
                targetBtnText = targetBtnText,
                winPkg = rootPkg.ifEmpty { winPkg },
                cardKey = cardKey,
                source = source,
                ocrToDelayComplete = ocrToDelayComplete,
                delayCompleteToRoot = delayCompleteToRoot,
                rootToNode = rootToNode,
                tNodeFound = tNodeFound
            )
        } else {
            // 최신 Root에서 수락 버튼이 발견되지 않음 → 30ms 후 2차 재탐색
            try { root?.recycle() } catch (_: Throwable) {}
            Log.d(TAG, "570ms 후 수락 노드 미발견 → 30ms 후 2차 재탐색 예약")
            handler.postDelayed({
                if (!isRunning || !pendingAccept) return@postDelayed
                val t2Start = System.currentTimeMillis()
                val root2 = findUberRoot()
                val btn2 = if (root2 != null) findAcceptButton(root2) else null
                val root2Pkg = root2?.packageName?.toString() ?: "none"
                val t2Found = System.currentTimeMillis()

                if (btn2 != null) {
                    LogBuffer.diag(this, "ACCEPT-REQUERY", "attempt=2(30ms)\nroot=FOUND\npackage=$root2Pkg\nnode=FOUND")
                    val freshBounds = Rect()
                    btn2.getBoundsInScreen(freshBounds)
                    val cx = freshBounds.centerX()
                    val cy = freshBounds.centerY()
                    LogBuffer.diag(this, "ACCEPT-REQUERY", "bounds=$freshBounds\ncenterX=$cx\ncenterY=$cy")
                    val targetBtnText = btn2.text?.toString() ?: btn2.contentDescription?.toString() ?: "콜 수락"
                    try { btn2.recycle() } catch (_: Throwable) {}
                    try { root2?.recycle() } catch (_: Throwable) {}

                    performAcceptExecution(
                        cx = cx,
                        cy = cy,
                        targetRect = freshBounds,
                        targetBtnText = targetBtnText,
                        winPkg = root2Pkg.ifEmpty { winPkg },
                        cardKey = cardKey,
                        source = "$source-RETRY30",
                        ocrToDelayComplete = ocrToDelayComplete,
                        delayCompleteToRoot = delayCompleteToRoot,
                        rootToNode = t2Found - t2Start,
                        tNodeFound = t2Found
                    )
                } else {
                    try { root2?.recycle() } catch (_: Throwable) {}
                    // 50ms 후 3차 재탐색
                    Log.d(TAG, "30ms 2차 수락 노드 미발견 → 50ms 후 3차 재탐색 예약")
                    handler.postDelayed({
                        if (!isRunning || !pendingAccept) return@postDelayed
                        val t3Start = System.currentTimeMillis()
                        val root3 = findUberRoot()
                        val btn3 = if (root3 != null) findAcceptButton(root3) else null
                        val root3Pkg = root3?.packageName?.toString() ?: "none"
                        val t3Found = System.currentTimeMillis()

                        if (btn3 != null) {
                            LogBuffer.diag(this, "ACCEPT-REQUERY", "attempt=3(50ms)\nroot=FOUND\npackage=$root3Pkg\nnode=FOUND")
                            val freshBounds = Rect()
                            btn3.getBoundsInScreen(freshBounds)
                            val cx = freshBounds.centerX()
                            val cy = freshBounds.centerY()
                            LogBuffer.diag(this, "ACCEPT-REQUERY", "bounds=$freshBounds\ncenterX=$cx\ncenterY=$cy")
                            val targetBtnText = btn3.text?.toString() ?: btn3.contentDescription?.toString() ?: "콜 수락"
                            try { btn3.recycle() } catch (_: Throwable) {}
                            try { root3?.recycle() } catch (_: Throwable) {}

                            performAcceptExecution(
                                cx = cx,
                                cy = cy,
                                targetRect = freshBounds,
                                targetBtnText = targetBtnText,
                                winPkg = root3Pkg.ifEmpty { winPkg },
                                cardKey = cardKey,
                                source = "$source-RETRY50",
                                ocrToDelayComplete = ocrToDelayComplete,
                                delayCompleteToRoot = delayCompleteToRoot,
                                rootToNode = t3Found - t3Start,
                                tNodeFound = t3Found
                            )
                        } else {
                            try { root3?.recycle() } catch (_: Throwable) {}
                            // 최초 탐지에서 확정된 initialRect 좌표를 이용한 정상 수락 경로 보존
                            val fallbackCx = initialRect.centerX()
                            val fallbackCy = initialRect.centerY()
                            LogBuffer.diag(this, "ACCEPT-REQUERY", "attempt=3(50ms)\nroot=${if (root3 != null) "FOUND" else "NOT_FOUND"}\nnode=NOT_FOUND\nresult=FALLBACK_INITIAL_RECT\ncoords=($fallbackCx, $fallbackCy)")
                            Log.i(TAG, "570ms 재탐색 실시간 노드 미발견 → 최초 확정된 유효 좌표($initialRect)로 수락 실행")
                            performAcceptExecution(
                                cx = fallbackCx,
                                cy = fallbackCy,
                                targetRect = initialRect,
                                targetBtnText = "콜 수락",
                                winPkg = winPkg,
                                cardKey = cardKey,
                                source = "$source-FALLBACK",
                                ocrToDelayComplete = ocrToDelayComplete,
                                delayCompleteToRoot = delayCompleteToRoot,
                                rootToNode = t3Found - t3Start,
                                tNodeFound = t3Found
                            )
                        }
                    }, 50L)
                }
            }, 30L)
        }
    }

    private fun performAcceptExecution(
        cx: Int,
        cy: Int,
        targetRect: Rect,
        targetBtnText: String,
        winPkg: String,
        cardKey: String,
        source: String,
        ocrToDelayComplete: Long,
        delayCompleteToRoot: Long,
        rootToNode: Long,
        tNodeFound: Long
    ) {
        val tShizukuStart = System.currentTimeMillis()
        val nodeToShizuku = tShizukuStart - tNodeFound

        showTapIndicator(cx, cy, true)
        LogBuffer.diag(this, "ACCEPT-FLOW", "state=FOUND\nacceptBounds=$targetRect")
        LogBuffer.diag(this, "ACCEPT-FLOW", "click=START")
        LogBuffer.diag(this, "ACCEPT-TOUCH", "Touch starting ($source): coords=($cx, $cy), cardKey=$cardKey, targetText='$targetBtnText'")

        // 4. Shizuku 실행 (기존 엔진 및 로그 유지)
        val shizResult = performShizukuTap(cx, cy)
        val tShizukuEnd = System.currentTimeMillis()
        val shizukuElapsed = shizResult.elapsedMs

        var touchSuccess = shizResult.success
        var touchMethod = if (shizResult.success) "ShizukuTap" else "NONE"
        LogBuffer.diag(this, "ACCEPT-SHIZUKU", "Shizuku tap result=${shizResult.success} at ($cx, $cy)")

        if (!touchSuccess) {
            // Fallback to dispatchGesture
            val path = Path().apply { moveTo(cx.toFloat(), cy.toFloat()) }
            val gestureOk = dispatchGesture(
                GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 50)).build(),
                null,
                null
            )
            touchSuccess = gestureOk
            touchMethod = if (gestureOk) "dispatchGesture" else "GestureFailed"
            LogBuffer.diag(this, "ACCEPT-GESTURE", "dispatchGesture result=$gestureOk at ($cx, $cy)")
        }

        if (touchSuccess) {
            LogBuffer.diag(this, "ACCEPT-FLOW", "click=SUCCESS")
        } else {
            LogBuffer.diag(this, "ACCEPT-FLOW", "click=FAILED method=$touchMethod")
        }

        LogBuffer.diag(this, "ACCEPT-TOUCH", "Touch performed ($source): method=$touchMethod, coords=($cx, $cy), cardKey=$cardKey")

        val newCount = PrefsManager.getAcceptScheduled(this) + 1
        LogBuffer.diag(this, "ACCEPT-COUNT", "source=performAcceptExecution, reason=pos_accept_dispatched, cardKey=$cardKey, coords=($cx, $cy), totalCount=$newCount")
        PrefsManager.incrementAcceptScheduled(this, source = "performAcceptExecution")

        PrefsManager.saveLastAcceptRect(this, targetRect)
        sendBroadcast(Intent("com.uber.autoaccept.ACCEPT_EVENT"))
        vibrate()
        triggerSleepAlarm()

        if (touchSuccess) {
            if (PrefsManager.isAcceptScreenshot(this)) {
                handler.postDelayed({
                    takeScreenshotAndSave()
                }, 200L)
            } else {
                LogBuffer.diag(this, "CAPTURE-AFTER-ACCEPT", "SKIPPED\nreason=PREF_DISABLED")
            }
        } else {
            LogBuffer.diag(this, "CAPTURE-AFTER-ACCEPT", "SKIPPED\nreason=CLICK_NOT_SUCCESSFUL")
        }

        pendingAccept = false

        // 5. 수락 사후 검증 (ACCEPT-VERIFY & 시간차 계측)
        handler.postDelayed({
            val tVerifyStart = System.currentTimeMillis()
            val shizukuToVerify = tVerifyStart - tShizukuEnd

            LogBuffer.diag(
                this,
                "ACCEPT-TIMING",
                "ocrToDelayComplete=${ocrToDelayComplete}ms\n" +
                "delayCompleteToRoot=${delayCompleteToRoot}ms\n" +
                "rootToNode=${rootToNode}ms\n" +
                "nodeToShizuku=${nodeToShizuku}ms\n" +
                "shizukuElapsed=${shizukuElapsed}ms\n" +
                "shizukuToVerify=${shizukuToVerify}ms"
            )

            val verifyRoot = findUberRoot()
            val stillHasCard = verifyRoot != null && (findCardIndicator(verifyRoot) || findAcceptButton(verifyRoot) != null)
            val cardDisappeared = !stillHasCard
            try { verifyRoot?.recycle() } catch (_: Throwable) {}

            LogBuffer.diag(
                this,
                "ACCEPT-VERIFY",
                "timestamp=$tVerifyStart\nresult=${if (cardDisappeared) "SUCCESS" else "CARD_STILL_VISIBLE"}\ncardDisappeared=$cardDisappeared\nsource=$source\ncardKey=$cardKey"
            )

            if (cardDisappeared) {
                LogBuffer.diag(this, "ACCEPT-SUCCESS", "Accept operation verified SUCCESS on screen ($source), cardKey=$cardKey")
            } else {
                LogBuffer.diag(this, "ACCEPT-RETRY", "Retrying accept at ($cx, $cy), cardKey=$cardKey")
            }
        }, 500L)
    }

    private fun executeAcceptAtPos(x: Int, y: Int, rect: Rect, source: String = "Coordinate", cardKey: String = "pos_$lastAcceptTime") {
        LogBuffer.diag(this, "ACCEPT-GATE", "cooldownBlock=false\npendingAcceptBlock=false\nresult=ALLOW")
        LogBuffer.diag(this, "ACCEPT-EXECUTE", "executeAcceptAtPos entered\nsource=$source\ncoords=($x, $y)\ncardKey=$cardKey")

        val now = System.currentTimeMillis()
        lastAcceptTime = now

        val delay = if (source == "OCR") 0L else 570L

        LogBuffer.diag(this, "ACCEPT-DELAY", "mode=FIXED_570MS, delay=${delay}ms")
        LogBuffer.diag(this, "ACCEPT-SCHEDULE", "delay=${delay}ms, reason=$source, coords=($x, $y), cardKey=$cardKey")

        handler.postDelayed({
            showTapIndicator(x, y, true)
            LogBuffer.diag(this, "ACCEPT-FLOW", "state=FOUND\nacceptBounds=$rect")
            LogBuffer.diag(this, "ACCEPT-FLOW", "click=START")
            LogBuffer.diag(this, "ACCEPT-TOUCH", "Touch starting ($source): coords=($x, $y), cardKey=$cardKey")

            var touchMethod = "ShizukuTap"
            var touchSuccess = false
            val shizOk = shizukuTap(x, y)
            LogBuffer.diag(this, "ACCEPT-SHIZUKU", "Shizuku tap result=$shizOk at ($x, $y)")

            if (shizOk) {
                touchSuccess = true
            } else {
                val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
                val gestureOk = dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 50)).build(), null, null)
                touchSuccess = gestureOk
                touchMethod = if (gestureOk) "dispatchGesture" else "GestureFailed"
                LogBuffer.diag(this, "ACCEPT-GESTURE", "dispatchGesture result=$gestureOk at ($x, $y)")
            }

            if (touchSuccess) {
                LogBuffer.diag(this, "ACCEPT-FLOW", "click=SUCCESS")
            } else {
                LogBuffer.diag(this, "ACCEPT-FLOW", "click=FAILED method=$touchMethod")
            }

            LogBuffer.diag(this, "ACCEPT-TOUCH", "Touch performed ($source): method=$touchMethod, coords=($x, $y), cardKey=$cardKey")

            val newCount = PrefsManager.getAcceptScheduled(this) + 1
            LogBuffer.diag(this, "ACCEPT-COUNT", "source=executeAcceptAtPos, reason=pos_accept_dispatched, cardKey=$cardKey, coords=($x, $y), totalCount=$newCount")
            PrefsManager.incrementAcceptScheduled(this, source = "executeAcceptAtPos")

            PrefsManager.saveLastAcceptRect(this, rect)
            sendBroadcast(Intent("com.uber.autoaccept.ACCEPT_EVENT"))
            vibrate()
            triggerSleepAlarm()

            if (touchSuccess) {
                if (PrefsManager.isAcceptScreenshot(this)) {
                    handler.postDelayed({
                        takeScreenshotAndSave()
                    }, 200L)
                } else {
                    LogBuffer.diag(this, "CAPTURE-AFTER-ACCEPT", "SKIPPED\nreason=PREF_DISABLED")
                }
            } else {
                LogBuffer.diag(this, "CAPTURE-AFTER-ACCEPT", "SKIPPED\nreason=CLICK_NOT_SUCCESSFUL")
            }

            pendingAccept = false

            // Verification (Separation of TOUCH and SUCCESS)
            handler.postDelayed({
                val verifyRoot = findUberRoot()
                val stillHasCard = verifyRoot != null && (findCardIndicator(verifyRoot) || findAcceptButton(verifyRoot) != null)
                if (!stillHasCard) {
                    LogBuffer.diag(this, "ACCEPT-VERIFY", "Card disappeared after $source accept, cardKey=$cardKey")
                    LogBuffer.diag(this, "ACCEPT-SUCCESS", "Accept operation verified SUCCESS on screen ($source), cardKey=$cardKey")
                } else {
                    LogBuffer.diag(this, "ACCEPT-VERIFY", "Card still visible after $source accept, cardKey=$cardKey")
                    LogBuffer.diag(this, "ACCEPT-RETRY", "Retrying accept at ($x, $y), cardKey=$cardKey")
                }
            }, 500L)
        }, delay)
    }

    private fun getCardContainerForFingerprint(node: AccessibilityNodeInfo): AccessibilityNodeInfo {
        var curr = node
        val nodeRect = Rect()
        curr.getBoundsInScreen(nodeRect)
        var depth = 0
        while (depth < 4) {
            val parent = curr.parent ?: break
            val pr = Rect()
            parent.getBoundsInScreen(pr)
            if (pr.height() > nodeRect.height() * 1.3) {
                return parent
            }
            curr = parent
            depth++
        }
        return node
    }

    private fun executeDismissAtPos(
        x: Int,
        y: Int,
        targetFingerprint: String? = null,
        source: String = lastDismissSource,
        cardBounds: Rect? = lastDismissCardBounds,
        nodeBounds: Rect? = lastDismissNodeBounds
    ) {
        val now = System.currentTimeMillis()
        val elapsed = now - lastDismissTime
        val cooldownBlocked = (now - lastDismissTime < 1500L)
        val pendingDismissBlocked = pendingDismiss
        val pendingAcceptBlocked = pendingAccept

        LogBuffer.diag(
            this,
            "DISMISS-TRACE",
            "EXECUTE_ENTER\n" +
            "x=$x\n" +
            "y=$y\n" +
            "pendingDismiss=$pendingDismiss\n" +
            "pendingAccept=$pendingAccept\n" +
            "currentDismissSeq=$currentDismissSeq\n" +
            "lastDismissTime=$lastDismissTime\n" +
            "now=$now\n" +
            "elapsedSinceLastDismiss=$elapsed"
        )

        LogBuffer.diag(
            this,
            "DISMISS-TRACE",
            "GUARD_CHECK\n" +
            "cooldownBlocked=$cooldownBlocked\n" +
            "pendingDismissBlocked=$pendingDismissBlocked\n" +
            "pendingAcceptBlocked=$pendingAcceptBlocked"
        )

        if (cooldownBlocked || pendingDismissBlocked || pendingAcceptBlocked) {
            val returnReason = when {
                cooldownBlocked -> "DISMISS_COOLDOWN"
                pendingDismissBlocked -> "PENDING_DISMISS"
                pendingAcceptBlocked -> "PENDING_ACCEPT"
                else -> "UNKNOWN"
            }
            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "GUARD_RETURN\nreason=$returnReason\nelapsed=${elapsed}ms"
            )
            return
        }
        currentDismissSeq++
        val runningSeq = currentDismissSeq
        currentDismissTargetFingerprint = targetFingerprint

        pendingDismiss = true
        dismissAttempts = 1
        dismissTapFiredAtMs = now
        dismissEventLogCount = 0

        LogBuffer.diag(
            this,
            "DISMISS-TRACE",
            "SESSION_START\n" +
            "seq=$runningSeq\n" +
            "pendingDismiss=true\n" +
            "dismissAttempts=$dismissAttempts\n" +
            "fingerprint=${targetFingerprint ?: "none"}"
        )

        handler.removeCallbacks(dismissTimeoutRunnable)
        handler.postDelayed(dismissTimeoutRunnable, 20000L)

        showTapIndicator(x, y, false)
        LogBuffer.log(this, TAG, "🔨 스크린샷폴링 닫기탭 ($x, $y) seq=$runningSeq")

        performDismissTouch(
            x = x,
            y = y,
            runningSeq = runningSeq,
            targetFingerprint = targetFingerprint,
            isRetry = false,
            source = source,
            cardBounds = cardBounds,
            nodeBounds = nodeBounds
        )
    }

    private fun performDismissTouch(
        x: Int,
        y: Int,
        runningSeq: Long,
        targetFingerprint: String?,
        isRetry: Boolean,
        source: String = lastDismissSource,
        cardBounds: Rect? = lastDismissCardBounds,
        nodeBounds: Rect? = lastDismissNodeBounds
    ) {
        LogBuffer.diag(
            this,
            "DISMISS-TRACE",
            "TOUCH_START\n" +
            "seq=$runningSeq\n" +
            "x=$x\n" +
            "y=$y\n" +
            "method=${if (isRetry) "RETRY" else "FIRST"}"
        )
        LogBuffer.diag(
            this,
            "X-TOUCH-READY",
            "x=$x\ny=$y\nsource=$source\ncardBounds=${cardBounds ?: "none"}\nnodeBounds=${nodeBounds ?: "none"}"
        )
        shizukuExecutor.execute {
            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "SHIZUKU_ATTEMPT\nx=$x\ny=$y"
            )
            LogBuffer.diag(this, "CANCEL-CLICK", "Shizuku 터치 실행\nx=$x\ny=$y")
            val shizResult = performShizukuTap(x, y)
            LogBuffer.diag(
                this,
                "X-DIAG-SHIZUKU",
                "x=$x\ny=$y\nsuccess=${shizResult.success}"
            )
            LogBuffer.diag(this, "CANCEL-CLICK-RESULT", "success=${shizResult.success}\nresult=${shizResult.success}")

            if (shizResult.success) {
                LogBuffer.diag(
                    this,
                    "DISMISS-TRACE",
                    "SHIZUKU_RESULT\nresult=SUCCESS"
                )
                // Shizuku 성공 시 바로 400ms(또는 600ms) 검증 타이머 등록
                val verifyDelay = if (isRetry) 600L else 400L
                LogBuffer.diag(
                    this,
                    "DISMISS-TRACE",
                    "TOUCH_COMPLETED\nseq=$runningSeq\nverifyDelay=${verifyDelay}ms"
                )
                handler.postDelayed({
                    if (isRetry) {
                        dismissVerify2(runningSeq)
                    } else {
                        dismissVerify1(runningSeq, targetFingerprint)
                    }
                }, verifyDelay)
            } else {
                val failReason = shizResult.stderr.ifEmpty { shizResult.exception.ifEmpty { "exitCode=${shizResult.exitCode}" } }
                LogBuffer.diag(
                    this,
                    "DISMISS-TRACE",
                    "SHIZUKU_RESULT\nresult=FAILED\nreason=$failReason"
                )
                LogBuffer.diag(
                    this,
                    "DISMISS-TRACE",
                    "GESTURE_FALLBACK_START\nx=$x\ny=$y"
                )
                // Shizuku 실패 시 즉시 메인 Looper/스레드로 전환하여 80ms dispatchGesture 실행
                handler.post {
                    performSafeDismissGesture(x.toFloat(), y.toFloat(), runningSeq, targetFingerprint, isRetry)
                }
            }
        }
    }

    private fun performSafeDismissGesture(
        x: Float,
        y: Float,
        runningSeq: Long,
        targetFingerprint: String?,
        isRetry: Boolean
    ) {
        if (!pendingDismiss || runningSeq != currentDismissSeq) return
        if (Build.VERSION.SDK_INT < 24) {
            abortDismissSession("SDK_TOO_LOW_FOR_GESTURE")
            return
        }

        val threadName = if (Looper.myLooper() == Looper.getMainLooper()) "main" else Thread.currentThread().name
        LogBuffer.diag(this, "TOUCH-B-DISPATCH", "thread=$threadName\nx=${x.toInt()}\ny=${y.toInt()}\nduration=80ms")

        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 80L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val t0 = System.currentTimeMillis()

        val accepted = dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    val latency = System.currentTimeMillis() - t0
                    LogBuffer.diag(this@AutoAcceptService, "TOUCH-C-GESTURE-RESULT", "onCompleted=true\nlatency=${latency}ms")
                    if (!pendingDismiss || runningSeq != currentDismissSeq) return

                    // onCompleted가 호출된 후에만 400ms(또는 600ms) 검증 타이머 시작
                    val verifyDelay = if (isRetry) 600L else 400L
                    LogBuffer.diag(
                        this@AutoAcceptService,
                        "DISMISS-TRACE",
                        "TOUCH_COMPLETED\nseq=$runningSeq\nverifyDelay=${verifyDelay}ms"
                    )
                    handler.postDelayed({
                        if (isRetry) {
                            dismissVerify2(runningSeq)
                        } else {
                            dismissVerify1(runningSeq, targetFingerprint)
                        }
                    }, verifyDelay)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    val latency = System.currentTimeMillis() - t0
                    LogBuffer.diag(this@AutoAcceptService, "TOUCH-C-GESTURE-RESULT", "onCancelled=true\nlatency=${latency}ms")
                    abortDismissSession("GESTURE_CANCELLED")
                }
            },
            handler
        )

        LogBuffer.diag(
            this,
            "DISMISS-TRACE",
            "GESTURE_FALLBACK_RESULT\nresult=${if (accepted) "SUCCESS" else "FAILED"}"
        )
        LogBuffer.diag(this, "TOUCH-B-DISPATCH-RETURN", "accepted=$accepted")
        if (!accepted) {
            Log.w(TAG, "dispatchGesture 반환값 false → 제스처 디스패치 실패")
            abortDismissSession("GESTURE_DISPATCH_REJECTED")
        }
    }

    private fun dismissVerify1(runningSeq: Long, targetFingerprint: String?) {
        LogBuffer.diag(
            this,
            "DISMISS-TRACE",
            "VERIFY1_START\n" +
            "seq=$runningSeq\n" +
            "currentSeq=$currentDismissSeq\n" +
            "pendingDismiss=$pendingDismiss\n" +
            "cardVisible=UNKNOWN\n" +
            "fingerprint=${targetFingerprint ?: "none"}"
        )
        if (!pendingDismiss || runningSeq != currentDismissSeq) {
            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "STALE_VERIFY\n" +
                "type=VERIFY1\n" +
                "runningSeq=$runningSeq\n" +
                "currentDismissSeq=$currentDismissSeq\n" +
                "pendingDismiss=$pendingDismiss\n" +
                "pendingAccept=$pendingAccept\n" +
                "lastDismissTime=$lastDismissTime\n" +
                "now=${System.currentTimeMillis()}\n" +
                "action=IGNORE_STALE_CALLBACK"
            )
            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "VERIFY1_ABORT\n" +
                "reason=STALE_SEQUENCE\n" +
                "runningSeq=$runningSeq\n" +
                "currentSeq=$currentDismissSeq\n" +
                "pendingDismiss=$pendingDismiss"
            )
            LogBuffer.diag(this, "CANCEL-VERIFY", "stale verification aborted: runningSeq=$runningSeq, currentSeq=$currentDismissSeq, pending=$pendingDismiss")
            return
        }
        val t0 = System.currentTimeMillis()
        val root = try { findUberRoot() } catch (_: Throwable) { null }
        val acceptBtn = if (root != null) findAcceptButton(root) else null
        val displayHeight = resources.displayMetrics.heightPixels
        val displayWidth = resources.displayMetrics.widthPixels
        val aRect = savedAcceptRect ?: Rect(0, (displayHeight * 0.75f).toInt(), displayWidth, displayHeight)
        val overlayCard = if (root != null) findOverlayCard(root, aRect) else null
        val fp = if (root != null) generateCardFingerprint(root) else null

        val cardContainerStr = if (overlayCard != null) "FOUND" else "NOT_FOUND"
        val acceptButtonStr = if (acceptBtn != null) "FOUND" else "NOT_FOUND"
        val fpStr = fp ?: targetFingerprint ?: "none"
        val cardGone = (acceptBtn == null) && (overlayCard == null)
        val verifyLatency = System.currentTimeMillis() - t0

        LogBuffer.diag(
            this,
            "X-DIAG-VERIFY",
            "elapsed=${verifyLatency}ms\n" +
            "cardStillExists=${!cardGone}\n" +
            "cardDisappeared=$cardGone"
        )

        LogBuffer.diag(
            this,
            "TOUCH-D-VERIFY",
            "cardContainer=$cardContainerStr\n" +
            "acceptButton=$acceptButtonStr\n" +
            "fingerprint=$fpStr\n" +
            "cardGone=$cardGone\n" +
            "verifyLatency=${verifyLatency}ms"
        )

        if (cardGone) {
            try { acceptBtn?.recycle() } catch (_: Throwable) {}
            try { root?.recycle() } catch (_: Throwable) {}
            LogBuffer.diag(
                this,
                "X-DIAG-DISMISS-RESULT",
                "result=CARD_DISAPPEARED\nelapsed=${verifyLatency}ms"
            )
            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "VERIFY1_RESULT\nresult=CARD_DISAPPEARED"
            )
            LogBuffer.diag(this, "CANCEL-VERIFY", "result=SUCCESS\nreason=CARD_GONE")
            LogBuffer.log(this, TAG, "✅ 스크린샷폴링 닫기 성공 (1회차 검증 통과 - 카드 소멸)")
            recordDismissSuccess()
            return
        }

        LogBuffer.diag(
            this,
            "DISMISS-TRACE",
            "VERIFY1_RESULT\nresult=CARD_STILL_VISIBLE\ncardContainer=$cardContainerStr\nacceptButton=$acceptButtonStr"
        )
        LogBuffer.diag(
            this,
            "CANCEL-VERIFY",
            "result=FAIL\nreason=CARD_STILL_PRESENT\ncardContainer=$cardContainerStr\nacceptButton=$acceptButtonStr"
        )

        val isSameCard = when {
            targetFingerprint == null -> null // UNKNOWN
            fp == null -> null // UNKNOWN
            else -> fp == targetFingerprint
        }

        if (isSameCard == false) {
            try { acceptBtn?.recycle() } catch (_: Throwable) {}
            try { root?.recycle() } catch (_: Throwable) {}
            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "VERIFY1_ABORT\nreason=NEW_CARD_PROTECTED\ntarget=$targetFingerprint\ncurrent=$fp"
            )
            LogBuffer.diag(this, "CANCEL-VERIFY", "New card protected (fingerprint mismatch) target=$targetFingerprint current=$fp")
            LogBuffer.log(this, TAG, "🛡️ 신규 콜 보호: 1차 검증 중 다른 콜 발견 → 2차 닫기 중단")
            abortDismissSession("NEW_CARD_PROTECTED")
            return
        } else if (isSameCard == null) {
            try { acceptBtn?.recycle() } catch (_: Throwable) {}
            try { root?.recycle() } catch (_: Throwable) {}
            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "VERIFY1_ABORT\nreason=UNKNOWN_FAIL_SAFE"
            )
            LogBuffer.diag(this, "CANCEL-VERIFY", "Fail-safe: card fingerprint UNKNOWN -> skip 2nd dismiss touch")
            LogBuffer.log(this, TAG, "🛡️ 안전 차단: 콜 식별 불가(UNKNOWN) → 2차 닫기 중단")
            abortDismissSession("UNKNOWN_FAIL_SAFE")
            return
        }

        val acceptR = Rect().also {
            if (acceptBtn != null) acceptBtn.getBoundsInScreen(it) else root?.getBoundsInScreen(it)
        }
        val coords = if (root != null) resolveDismissCoordinates(root, overlayCard, acceptR) else null
        try { acceptBtn?.recycle() } catch (_: Throwable) {}
        try { root?.recycle() } catch (_: Throwable) {}

        if (coords != null) {
            val (retryX, retryY) = coords
            LogBuffer.log(this, TAG, "⚠️ 1차 검증: 동일 카드 잔존 → 새 bounds ($retryX, $retryY) 2차 탭 재시도")
            dismissAttempts = 2
            showTapIndicator(retryX, retryY, false)
            performDismissTouch(
                x = retryX,
                y = retryY,
                runningSeq = runningSeq,
                targetFingerprint = targetFingerprint,
                isRetry = true,
                source = lastDismissSource,
                cardBounds = lastDismissCardBounds,
                nodeBounds = lastDismissNodeBounds
            )
        } else {
            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "VERIFY1_ABORT\nreason=RETRY_X_COORDS_UNRESOLVABLE"
            )
            LogBuffer.log(this, TAG, "🛡️ 2차 탭 재시도 X 좌표 계산 불가 → 닫기 중단")
            abortDismissSession("RETRY_X_COORDS_UNRESOLVABLE")
        }
    }

    private fun dismissVerify2(runningSeq: Long) {
        LogBuffer.diag(
            this,
            "DISMISS-TRACE",
            "VERIFY2_START\n" +
            "seq=$runningSeq\n" +
            "currentSeq=$currentDismissSeq\n" +
            "pendingDismiss=$pendingDismiss\n" +
            "cardVisible=UNKNOWN"
        )
        if (!pendingDismiss || runningSeq != currentDismissSeq) {
            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "STALE_VERIFY\n" +
                "type=VERIFY2\n" +
                "runningSeq=$runningSeq\n" +
                "currentDismissSeq=$currentDismissSeq\n" +
                "pendingDismiss=$pendingDismiss\n" +
                "pendingAccept=$pendingAccept\n" +
                "lastDismissTime=$lastDismissTime\n" +
                "now=${System.currentTimeMillis()}\n" +
                "action=IGNORE_STALE_CALLBACK"
            )
            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "VERIFY2_ABORT\n" +
                "reason=STALE_SEQUENCE\n" +
                "runningSeq=$runningSeq\n" +
                "currentSeq=$currentDismissSeq\n" +
                "pendingDismiss=$pendingDismiss"
            )
            return
        }
        val t0 = System.currentTimeMillis()
        val root = try { findUberRoot() } catch (_: Throwable) { null }
        val acceptBtn = if (root != null) findAcceptButton(root) else null
        val displayHeight = resources.displayMetrics.heightPixels
        val displayWidth = resources.displayMetrics.widthPixels
        val aRect = savedAcceptRect ?: Rect(0, (displayHeight * 0.75f).toInt(), displayWidth, displayHeight)
        val overlayCard = if (root != null) findOverlayCard(root, aRect) else null
        val fp = if (root != null) generateCardFingerprint(root) else null

        val cardContainerStr = if (overlayCard != null) "FOUND" else "NOT_FOUND"
        val acceptButtonStr = if (acceptBtn != null) "FOUND" else "NOT_FOUND"
        val fpStr = fp ?: "none"
        val cardGone = (acceptBtn == null) && (overlayCard == null)
        val verifyLatency = System.currentTimeMillis() - t0

        LogBuffer.diag(
            this,
            "TOUCH-D-VERIFY",
            "cardContainer=$cardContainerStr\n" +
            "acceptButton=$acceptButtonStr\n" +
            "fingerprint=$fpStr\n" +
            "cardGone=$cardGone\n" +
            "verifyLatency=${verifyLatency}ms"
        )
        try { acceptBtn?.recycle() } catch (_: Throwable) {}
        try { root?.recycle() } catch (_: Throwable) {}

        if (cardGone) {
            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "VERIFY2_RESULT\nresult=CARD_DISAPPEARED"
            )
            LogBuffer.diag(this, "CANCEL-VERIFY", "result=SUCCESS\nreason=CARD_GONE")
            LogBuffer.log(this, TAG, "✅ 스크린샷폴링 닫기 성공 (2회차 검증 통과)")
            recordDismissSuccess()
        } else {
            LogBuffer.diag(
                this,
                "DISMISS-TRACE",
                "VERIFY2_RESULT\nresult=CARD_STILL_VISIBLE\ncardContainer=$cardContainerStr\nacceptButton=$acceptButtonStr"
            )
            LogBuffer.diag(
                this,
                "CANCEL-VERIFY",
                "result=FAIL\nreason=CARD_STILL_VISIBLE_AFTER_RETRY\ncardContainer=$cardContainerStr\nacceptButton=$acceptButtonStr"
            )
            LogBuffer.log(this, TAG, "⚠️ 2차 검증 후에도 카드 잔존 → 닫기 완료 처리 후 다음 사이클 대기")
            abortDismissSession("CARD_STILL_VISIBLE_AFTER_RETRY")
        }
    }

    private fun scheduleAcceptRetap(rect: Rect?, delayMs: Long, cardKey: String = "") {
        if (rect == null) return
        LogBuffer.diag(this, "ACCEPT-RETRY", "Scheduling retap after ${delayMs}ms at (${rect.centerX()}, ${rect.centerY()}), cardKey=$cardKey")
        handler.postDelayed({
            executeAcceptAtPos(rect.centerX(), rect.centerY(), rect, "Retap", cardKey)
        }, delayMs)
    }

    private fun isIgnoredBannerNode(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false
        var curr: AccessibilityNodeInfo? = node
        var depth = 0
        while (curr != null && depth < 6) {
            val vId = curr.viewIdResourceName ?: ""
            if (vId == "com.ubercab.driver:id/queue_position_info_banner_message" ||
                vId.contains("queue_position_info_banner") ||
                vId.contains("queue_banner")
            ) {
                return true
            }
            val text = "${curr.text ?: ""} ${curr.contentDescription ?: ""}"
            if (text.contains("순번제 배차") ||
                text.contains("콜 수락 후 입국장") ||
                text.contains("예약등을 켜주세요") ||
                text.contains("예약을 켜주세요") ||
                text.contains("공항 순번제")
            ) {
                return true
            }
            curr = curr.parent
            depth++
        }
        return false
    }

    private fun logAcceptButtonDiag(root: AccessibilityNodeInfo, result: AccessibilityNodeInfo?) {
        val now = System.currentTimeMillis()
        if (now - lastAcceptDiagTime < 400L && result == null && lastLoggedAcceptBtnResult == "NOT_FOUND") {
            return
        }
        lastAcceptDiagTime = now

        val screenHeight = resources.displayMetrics.heightPixels
        val bottomThreshold = screenHeight * 0.5f

        var scannedCount = 0
        var bottomCount = 0
        var keywordCount = 0
        var clickableCount = 0
        var enabledCount = 0

        val bottomNodes = mutableListOf<String>()
        val matchDiags = mutableListOf<String>()

        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)

        while (queue.isNotEmpty() && scannedCount < 200) {
            val node = queue.removeFirst()
            scannedCount++

            val r = Rect()
            node.getBoundsInScreen(r)
            val isBottom = r.bottom >= bottomThreshold || r.top >= bottomThreshold
            if (isBottom) bottomCount++

            val text = node.text?.toString()?.trim() ?: ""
            val desc = node.contentDescription?.toString()?.trim() ?: ""
            val combined = "$text $desc"
            val hasKeyword = combined.contains("수락") || combined.contains("콜") || combined.contains("요청")
            if (hasKeyword) keywordCount++

            if (node.isClickable) clickableCount++
            if (node.isEnabled) enabledCount++

            if (isBottom && (hasKeyword || node.isClickable || text.isNotEmpty() || desc.isNotEmpty()) && bottomNodes.size < 8) {
                val nodeLog = "bounds=$r\n" +
                        "text='${text.ifEmpty { "none" }}'\n" +
                        "contentDescription='${desc.ifEmpty { "none" }}'\n" +
                        "viewId=${node.viewIdResourceName ?: "none"}\n" +
                        "className=${node.className ?: "none"}\n" +
                        "clickable=${node.isClickable}\n" +
                        "enabled=${node.isEnabled}\n" +
                        "visible=${node.isVisibleToUser}"
                bottomNodes.add(nodeLog)

                if (hasKeyword || text.isNotEmpty() || desc.isNotEmpty()) {
                    val evaluated = if (text.isNotEmpty()) text else desc
                    val matchedKw = ACCEPT_BUTTON_TEXTS.firstOrNull { evaluated.contains(it) } ?: "none"
                    val failReason = when {
                        !node.isVisibleToUser -> "NOT_VISIBLE"
                        !node.isEnabled -> "DISABLED"
                        !node.isClickable && pickAcceptNode(node) == null -> "NOT_CLICKABLE"
                        matchedKw == "none" -> "NO_EXACT_ACCEPT_KEYWORD"
                        isIgnoredBannerNode(node) -> "IGNORED_BANNER"
                        else -> "NONE"
                    }
                    val matchLog = "evaluatedText='$evaluated'\n" +
                            "matchedKeyword=$matchedKw\n" +
                            "isClickable=${node.isClickable}\n" +
                            "isEnabled=${node.isEnabled}\n" +
                            "isVisibleToUser=${node.isVisibleToUser}\n" +
                            "failReason=$failReason"
                    matchDiags.add(matchLog)
                }
            }

            for (i in 0 until node.childCount) {
                val child = try { node.getChild(i) } catch (_: Throwable) { null }
                if (child != null) queue.add(child)
            }
            if (node != root) {
                try { node.recycle() } catch (_: Throwable) {}
            }
        }
        while (queue.isNotEmpty()) {
            val rem = queue.removeFirst()
            if (rem != root) {
                try { rem.recycle() } catch (_: Throwable) {}
            }
        }

        LogBuffer.diag(
            this,
            "ACCEPT-DIAG",
            "scannedNodeCount=$scannedCount\n" +
            "bottomNodeCount=$bottomCount\n" +
            "keywordNodeCount=$keywordCount\n" +
            "clickableCandidateCount=$clickableCount\n" +
            "enabledCandidateCount=$enabledCount"
        )

        for (nLog in bottomNodes) {
            LogBuffer.diag(this, "ACCEPT-DIAG-NODE", nLog)
        }

        for (mLog in matchDiags) {
            LogBuffer.diag(this, "ACCEPT-DIAG-MATCH", mLog)
        }

        LogBuffer.diag(
            this,
            "ACCEPT-DIAG-RESULT",
            "result=${if (result != null) "FOUND" else "NOT_FOUND"}"
        )
    }

    private fun findAcceptButton(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val screenHeight = resources.displayMetrics.heightPixels
        for (btnText in ACCEPT_BUTTON_TEXTS) {
            val list = root.findAccessibilityNodeInfosByText(btnText)
            if (!list.isNullOrEmpty()) {
                for (node in list) {
                    if (isIgnoredBannerNode(node)) {
                        val now = System.currentTimeMillis()
                        if (now - lastBannerIgnoreLogTime > 5000L) {
                            lastBannerIgnoreLogTime = now
                            LogBuffer.diag(this, "BANNER-IGNORE", "package=com.ubercab.driver\nviewId=${node.viewIdResourceName ?: "queue_position_info_banner_message"}\nreason=UBER_QUEUE_BANNER")
                        }
                        try { node.recycle() } catch (_: Throwable) {}
                        continue
                    }
                    val nodeText = node.text?.toString()?.trim() ?: node.contentDescription?.toString()?.trim() ?: ""
                    val isStatus = (nodeText.contains("가능") || nodeText.contains("불가") || nodeText.contains("수락률") || nodeText.contains("기록") || nodeText.contains("설정")) && !nodeText.contains("콜")
                    if (isStatus) {
                        try { node.recycle() } catch (_: Throwable) {}
                        continue
                    }
                    val r = Rect()
                    node.getBoundsInScreen(r)
                    if (r.width() < 60 || r.height() < 30) {
                        try { node.recycle() } catch (_: Throwable) {}
                        continue
                    }
                    val pick = pickAcceptNode(node)
                    if (pick != null) {
                        if (isIgnoredBannerNode(pick)) {
                            continue
                        }
                        logAcceptButtonDiag(root, pick)
                        if (lastLoggedAcceptBtnResult != "FOUND_TEXT") {
                            lastLoggedAcceptBtnResult = "FOUND_TEXT"
                            LogBuffer.diag(this, "ACCEPT-MATCH", "matched=$btnText\nsource=ACCESSIBILITY")
                            LogBuffer.diag(this, "ACCEPT-BUTTON", "result=FOUND\nmethod=text\ntext='$btnText'")
                        }
                        return pick
                    }
                }
            }
        }

        // 추가 fallback: contentDescription 기반 탐색 (기존 텍스트 검색 실패 시에만 수행)
        fun findByContentDesc(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (node == null) return null
            if (isIgnoredBannerNode(node)) return null
            val desc = node.contentDescription?.toString()?.trim() ?: ""
            if (desc.isNotEmpty()) {
                for (btnText in ACCEPT_BUTTON_TEXTS) {
                    if (desc.contains(btnText)) {
                        val isStatus = (desc.contains("가능") || desc.contains("불가") || desc.contains("수락률") || desc.contains("기록") || desc.contains("설정")) && !desc.contains("콜")
                        if (!isStatus && node.isVisibleToUser) {
                            val r = Rect()
                            node.getBoundsInScreen(r)
                            if (r.width() >= 60 && r.height() >= 30) {
                                val pick = pickAcceptNode(node)
                                if (pick != null && !isIgnoredBannerNode(pick)) {
                                    if (lastLoggedAcceptBtnResult != "FOUND_DESC") {
                                        lastLoggedAcceptBtnResult = "FOUND_DESC"
                                        LogBuffer.diag(this, "ACCEPT-MATCH", "matched=$btnText\nsource=ACCESSIBILITY")
                                        LogBuffer.diag(this, "ACCEPT-BUTTON", "result=FOUND\nmethod=contentDescription\ndesc='$desc'")
                                    }
                                    return pick
                                }
                            }
                        }
                    }
                }
            }
            for (i in 0 until node.childCount) {
                val child = try { node.getChild(i) } catch (_: Throwable) { null }
                val found = findByContentDesc(child)
                if (found != null) return found
            }
            return null
        }

        val descFound = findByContentDesc(root)
        if (descFound != null) {
            logAcceptButtonDiag(root, descFound)
            return descFound
        }

        // 보조 bounds / savedAcceptRect 기반 탐색 (Compose 재렌더링 중 텍스트 일시 누락 대응)
        val savedR = savedAcceptRect
        if (savedR != null) {
            val candidate = findNodeByBounds(root, savedR)
            if (candidate != null && !isIgnoredBannerNode(candidate)) {
                logAcceptButtonDiag(root, candidate)
                if (lastLoggedAcceptBtnResult != "FOUND_BOUNDS") {
                    lastLoggedAcceptBtnResult = "FOUND_BOUNDS"
                    LogBuffer.diag(this, "ACCEPT-MATCH", "matched=saved_bounds\nsource=ACCESSIBILITY")
                    LogBuffer.diag(this, "ACCEPT-BUTTON", "result=FOUND\nmethod=bounds_fallback\nbounds=$savedR")
                }
                return candidate
            }
        }

        logAcceptButtonDiag(root, null)
        if (lastLoggedAcceptBtnResult != "NOT_FOUND") {
            lastLoggedAcceptBtnResult = "NOT_FOUND"
            LogBuffer.diag(this, "ACCEPT-MISS", "reason=NO_EXACT_ACCEPT_KEYWORD\nsource=ACCESSIBILITY")
            LogBuffer.diag(this, "ACCEPT-BUTTON", "result=NOT_FOUND")
        }
        return null
    }

    private fun findNodeByBounds(root: AccessibilityNodeInfo, targetRect: Rect): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        val toleranceX = 120
        val toleranceY = 100
        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            val r = Rect()
            node.getBoundsInScreen(r)
            if (abs(r.centerX() - targetRect.centerX()) <= toleranceX &&
                abs(r.centerY() - targetRect.centerY()) <= toleranceY &&
                r.width() >= 60 && r.height() >= 30) {
                val pick = pickAcceptNode(node)
                if (pick != null) {
                    return pick
                }
            }
            for (i in 0 until node.childCount) {
                val child = try { node.getChild(i) } catch (_: Throwable) { null }
                if (child != null) queue.add(child)
            }
        }
        return null
    }

    private fun pickAcceptNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var curr: AccessibilityNodeInfo? = node
        while (curr != null) {
            if (curr.isClickable && curr.isEnabled) return curr
            curr = curr.parent
        }
        val r = Rect()
        node.getBoundsInScreen(r)
        return if (r.width() > 0 && r.height() > 0) node else null
    }

    private fun validateDismissCandidate(
        node: AccessibilityNodeInfo,
        cardBounds: Rect?,
        acceptRect: Rect
    ): Boolean {
        val nr = Rect()
        node.getBoundsInScreen(nr)
        val cls = node.className?.toString() ?: "android.view.View"
        val vid = node.viewIdResourceName ?: "none"
        val parentCls = try { node.parent?.className?.toString() ?: "none" } catch (_: Throwable) { "none" }
        val center = "(${nr.centerX()},${nr.centerY()})"

        LogBuffer.diag(
            this,
            "X-DIAG-CANDIDATE",
            "className=$cls\n" +
            "bounds=$nr\n" +
            "clickable=${node.isClickable}\n" +
            "enabled=${node.isEnabled}\n" +
            "visibleToUser=${node.isVisibleToUser}\n" +
            "viewIdResourceName=$vid\n" +
            "text='${node.text ?: ""}'\n" +
            "contentDescription='${node.contentDescription ?: ""}'\n" +
            "parentClassName=$parentCls\n" +
            "childCount=${node.childCount}"
        )

        // 1. Blacklist map markers & non-dismiss UI
        val isMapMarker = vid.contains("map_marker", ignoreCase = true) ||
                vid.contains("map_pin", ignoreCase = true) ||
                vid.contains("marker_view", ignoreCase = true) ||
                vid.contains("marker", ignoreCase = true) ||
                cls.contains("MarkerView", ignoreCase = true) ||
                cls.contains("Map", ignoreCase = true)
        if (isMapMarker) {
            LogBuffer.diag(this, "X-DIAG-REJECT", "reason=MAP_MARKER\nviewId=$vid")
            return false
        }

        // 2. Must be within cardBounds if cardBounds is available
        if (cardBounds != null) {
            val isInside = nr.left >= cardBounds.left &&
                    nr.right <= cardBounds.right &&
                    nr.top >= cardBounds.top &&
                    nr.bottom <= cardBounds.bottom
            if (!isInside) {
                LogBuffer.diag(this, "X-DIAG-REJECT", "reason=OUTSIDE_CARD_BOUNDS\nnodeBounds=$nr\ncardBounds=$cardBounds")
                return false
            }

            // 3. Must be in top-right quadrant of the card
            val maxTop = cardBounds.top + (cardBounds.height() * 0.35f)
            val minLeft = cardBounds.left + (cardBounds.width() * 0.60f)
            if (nr.top > maxTop || nr.left < minLeft) {
                LogBuffer.diag(this, "X-DIAG-REJECT", "reason=NOT_TOP_RIGHT\nnodeBounds=$nr\nmaxTop=$maxTop\nminLeft=$minLeft")
                return false
            }
        } else {
            val displayWidth = resources.displayMetrics.widthPixels
            if (nr.top > acceptRect.top - 100 || nr.left < displayWidth * 0.5f) {
                LogBuffer.diag(this, "X-DIAG-REJECT", "reason=NOT_TOP_RIGHT\nnodeBounds=$nr")
                return false
            }
        }

        LogBuffer.diag(this, "X-DIAG-ACCEPT-CANDIDATE", "bounds=$nr\ncenter=$center\nclass=$cls\nviewId=$vid")
        return true
    }

    private fun findDismissButton(root: AccessibilityNodeInfo, acceptRect: Rect, cardBounds: Rect? = null): AccessibilityNodeInfo? {
        LogBuffer.diag(this, "DIAG-CANCEL-ENTER", "cancel button search entered")
        LogBuffer.diag(this, "CANCEL-SEARCH", "취소버튼 탐색 시작")
        for (text in DISMISS_BUTTON_TEXTS) {
            val list = root.findAccessibilityNodeInfosByText(text)
            if (!list.isNullOrEmpty()) {
                for (node in list) {
                    if (validateDismissCandidate(node, cardBounds, acceptRect)) {
                        val nr = Rect()
                        node.getBoundsInScreen(nr)
                        if (node.isClickable) {
                            LogBuffer.diag(this, "CANCEL-FOUND", "class=${node.className}\ntext='${node.text}'\ncontentDesc='${node.contentDescription}'\nviewId='${node.viewIdResourceName ?: "none"}'\nbounds=$nr\ncenterX=${nr.centerX()}\ncenterY=${nr.centerY()}")
                            LogBuffer.diag(this, "DISMISS-BUTTON", "source=ORIGINAL_FLOW_RESTORED, found=true, text='${node.text}', desc='${node.contentDescription}', cls='${node.className}', bounds=$nr, clickable=true")
                            return node
                        }
                        val parent = node.parent
                        if (parent != null && parent.isClickable && validateDismissCandidate(parent, cardBounds, acceptRect)) {
                            val pr = Rect()
                            parent.getBoundsInScreen(pr)
                            LogBuffer.diag(this, "CANCEL-FOUND", "class=${parent.className}\ntext='${node.text}'\ncontentDesc='${node.contentDescription}'\nviewId='${parent.viewIdResourceName ?: "none"}'\nbounds=$pr\ncenterX=${pr.centerX()}\ncenterY=${pr.centerY()}")
                            LogBuffer.diag(this, "DISMISS-BUTTON", "source=ORIGINAL_FLOW_RESTORED, found=true (parent), text='${node.text}', cls='${parent.className}', bounds=$pr, clickable=true")
                            try { node.recycle() } catch (_: Throwable) {}
                            return parent
                        }
                    }
                    try { node.recycle() } catch (_: Throwable) {}
                }
            }
        }
        val iconBtn = findIconCloseButton(root, acceptRect, cardBounds)
        LogBuffer.diag(this, "DISMISS-BUTTON", "source=ORIGINAL_FLOW_RESTORED, textSearchFound=false, iconSearchFound=${iconBtn != null}")
        return iconBtn
    }

    private fun findDismissViaParent(acceptBtn: AccessibilityNodeInfo, acceptRect: Rect, cardBounds: Rect? = null): AccessibilityNodeInfo? {
        LogBuffer.diag(this, "DIAG-CANCEL-ENTER", "cancel button search entered")
        LogBuffer.diag(this, "CANCEL-SEARCH", "취소버튼 탐색 시작")
        var cursor: AccessibilityNodeInfo? = try { acceptBtn.parent } catch (_: Throwable) { null }
        var depth = 0
        while (cursor != null && depth < 8) {
            val cursorRect = Rect()
            cursor.getBoundsInScreen(cursorRect)
            if (cursorRect.height() > acceptRect.height() * 1.5) {
                val candidate = findIconInSubtree(cursor, acceptRect, cardBounds)
                if (candidate != null) {
                    val cr = Rect()
                    candidate.getBoundsInScreen(cr)
                    LogBuffer.diag(this, "CANCEL-FOUND", "class=${candidate.className}\ntext='${candidate.text}'\ncontentDesc='${candidate.contentDescription}'\nviewId='${candidate.viewIdResourceName ?: "none"}'\nbounds=$cr\ncenterX=${cr.centerX()}\ncenterY=${cr.centerY()}")
                    LogBuffer.diag(this, "DISMISS-PARENT", "source=ORIGINAL_FLOW_RESTORED, found=true, depth=$depth, bounds=$cr, containerBounds=$cursorRect")
                    return candidate
                }
            }
            val parent = try { cursor.parent } catch (_: Throwable) { null }
            try { cursor.recycle() } catch (_: Throwable) {}
            cursor = parent
            depth++
        }
        if (cursor != null) {
            try { cursor.recycle() } catch (_: Throwable) {}
        }
        LogBuffer.diag(this, "DISMISS-PARENT", "source=ORIGINAL_FLOW_RESTORED, found=false, depth=$depth")
        return null
    }

    private fun findIconInSubtree(root: AccessibilityNodeInfo, acceptRect: Rect, cardBounds: Rect? = null): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var bestScore = -1
        var best: AccessibilityNodeInfo? = null

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            val it = Rect()
            node.getBoundsInScreen(it)
            val w = it.width()
            val h = it.height()
            var keepNode = false

            if (w in 1..400 && h in 1..400) {
                val text = "${node.text ?: ""} ${node.contentDescription ?: ""}"
                val isAccept = ACCEPT_BUTTON_TEXTS.any { text.contains(it, ignoreCase = true) }
                if (!isAccept && validateDismissCandidate(node, cardBounds, acceptRect)) {
                    val score = (acceptRect.top - it.centerY()) + (it.right * 10)
                    Log.d(TAG, "서브트리 후보: $it cls=${node.className} click=${node.isClickable} score=$score")
                    if (score > bestScore) {
                        if (best != root && best != null) {
                            try { best.recycle() } catch (_: Throwable) {}
                        }
                        keepNode = true
                        bestScore = score
                        best = node
                    }
                }
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                if (child != null) queue.add(child)
            }

            if (!keepNode && node != root && node != best) {
                try { node.recycle() } catch (_: Throwable) {}
            }
        }
        return best
    }

    private fun findIconCloseButton(root: AccessibilityNodeInfo, acceptRect: Rect, cardBounds: Rect? = null): AccessibilityNodeInfo? {
        val screenWidth = resources.displayMetrics.widthPixels
        val yMin = Math.max(acceptRect.top - 1300, 100)
        val yMax = acceptRect.top - 400
        val xMin = screenWidth / 2
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var bestCandidate: AccessibilityNodeInfo? = null
        var totalNodes = 0
        var bestScore = -1

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            totalNodes++
            val rect = Rect()
            node.getBoundsInScreen(rect)
            val w = rect.width()
            val h = rect.height()
            var keepNode = false

            if (w in 1..250 && h in 1..250) {
                val combined = "${node.text ?: ""} ${node.contentDescription ?: ""}"
                val isAcceptBtn = ACCEPT_BUTTON_TEXTS.any { combined.contains(it, ignoreCase = true) }
                if (!isAcceptBtn && validateDismissCandidate(node, cardBounds, acceptRect)) {
                    val centerY = rect.centerY()
                    val rightScore = screenWidth - rect.right
                    val score = (10000 - (rightScore * 10)) - (acceptRect.top - centerY)
                    Log.d(TAG, "X 후보: bounds=$rect cls=${node.className} click=${node.isClickable} score=$score")
                    if (score > bestScore) {
                        if (bestCandidate != root && bestCandidate != null) {
                            try { bestCandidate.recycle() } catch (_: Throwable) {}
                        }
                        keepNode = true
                        bestScore = score
                        bestCandidate = node
                    }
                }
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                if (child != null) queue.add(child)
            }

            if (!keepNode && node != root && node != bestCandidate) {
                try { node.recycle() } catch (_: Throwable) {}
            }
        }

        Log.d(TAG, "X 버튼 탐색 완료 — 전체노드:$totalNodes, yRange:$yMin~$yMax, 결과: ${if (bestCandidate != null) "찾음 score=$bestScore" else "못 찾음"}")
        val br = Rect()
        bestCandidate?.getBoundsInScreen(br)
        if (bestCandidate != null) {
            LogBuffer.diag(this, "CANCEL-FOUND", "class=${bestCandidate.className}\ntext='${bestCandidate.text}'\ncontentDesc='${bestCandidate.contentDescription}'\nviewId='${bestCandidate.viewIdResourceName ?: "none"}'\nbounds=$br\ncenterX=${br.centerX()}\ncenterY=${br.centerY()}")
        }
        LogBuffer.diag(this, "DISMISS-ICON", "source=ORIGINAL_FLOW_RESTORED, found=${bestCandidate != null}, bounds=${if (bestCandidate != null) br.toString() else "none"}, bestScore=$bestScore, totalNodes=$totalNodes")
        return bestCandidate
    }

    fun dumpCallTree(root: AccessibilityNodeInfo, acceptRect: Rect): String {
        val sb = StringBuilder()
        sb.append("▶ acceptRect: $acceptRect\n")
        sb.append("── 전체 노드 (Y 순서) ──\n")
        val collected = mutableListOf<AccessibilityNodeInfo>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val n = queue.removeFirst()
            if (n != root) collected.add(n)
            for (i in 0 until n.childCount) {
                val child = n.getChild(i)
                if (child != null) queue.add(child)
            }
        }
        val sorted = collected.map { n ->
            val r = Rect()
            n.getBoundsInScreen(r)
            val cls = n.className?.toString()?.substringAfterLast('.') ?: "-"
            val txtList = listOfNotNull(n.text, n.contentDescription).filter { it.isNotEmpty() }
            val txt = txtList.joinToString("|").take(24).ifEmpty { "-" }
            val clk = if (n.isClickable) "Y" else "n"
            val act = n.actionList?.joinToString(",") { it.id.toString() } ?: "-"
            NodeSnap(r, cls, txt, clk, act)
        }.sortedWith(compareBy({ it.r.top }, { it.r.left }))

        for (snap in sorted) {
            sb.append("  [${snap.r.left},${snap.r.top},${snap.r.right},${snap.r.bottom}] ${snap.cls} clk=${snap.clk} act=${snap.act} txt=\"${snap.txt}\"\n")
        }
        return sb.toString()
    }

    data class NodeSnap(val r: Rect, val cls: String, val txt: String, val clk: String, val act: String)

    fun findXButtonByTemplate(bitmap: Bitmap, dismissCardRect: Rect, acceptRect: Rect, ocrText: String): Pair<Int, Int>? {
        if (xBtnTemplates.isEmpty()) {
            Log.w(TAG, "X버튼 템플릿 미로드 → 템플릿 매칭 건너뜀")
            return null
        }
        val searchL = (dismissCardRect.right - 180).coerceAtLeast(0)
        val searchR = (dismissCardRect.right + 20).coerceAtMost(bitmap.width - 1)
        val isFallbackCard = dismissCardRect.top == acceptRect.top - 800
        val searchT: Int
        val searchB: Int
        if (isFallbackCard) {
            val approxCenter = acceptRect.top - 690
            searchT = (approxCenter - 200).coerceAtLeast(0)
            searchB = (approxCenter + 150).coerceAtMost(bitmap.height - 1)
            Log.d(TAG, "폴백rect 탐색범위 보정: approxCenter=$approxCenter searchT=$searchT searchB=$searchB")
        } else {
            searchT = (dismissCardRect.top - 200).coerceAtLeast(0)
            searchB = (dismissCardRect.top + 100).coerceAtMost(bitmap.height - 1)
        }

        val searchW = (searchR - searchL + 1).coerceAtLeast(1)
        val searchH = (searchB - searchT + 1).coerceAtLeast(1)
        Log.d(TAG, "템플릿 매칭 탐색영역(카드기준): x=[$searchL,$searchR] y=[$searchT,$searchB]")
        val searchPixels = IntArray(searchW * searchH)
        bitmap.getPixels(searchPixels, 0, searchW, searchL, searchT, searchW, searchH)

        var bestSadPs = Double.MAX_VALUE
        var bestX = -1
        var bestY = -1
        var bestTw = 120
        var bestTh = 120

        for (tmpl in xBtnTemplates) {
            val tw = tmpl.width
            val th = tmpl.height
            val tmplSamples = ((tw + 2) / 3).coerceAtLeast(1).toDouble() *
                    ((th + 2) / 3).coerceAtLeast(1).toDouble() * 3.0
            for (ry in 0..(searchH - th) step 8) {
                for (rx in 0..(searchW - tw) step 8) {
                    val sad = computeSADArray(searchPixels, searchW, rx, ry, tmpl.pixels, tw, th)
                    val sadPs = sad.toDouble() / tmplSamples
                    if (sadPs < bestSadPs) {
                        bestSadPs = sadPs
                        bestX = searchL + rx + tw / 2
                        bestY = searchT + ry + th / 2
                        bestTw = tw
                        bestTh = th
                    }
                }
            }
        }

        if (bestX < 0) {
            LogBuffer.diag(this, "DISMISS-TEMPLATE", "source=ORIGINAL_FLOW_RESTORED, templates=${xBtnTemplates.size}, match=false, sad=none, coord=none")
            return null
        }
        val bestSadFormatted = String.format(Locale.US, "%.1f", bestSadPs)
        Log.d(TAG, "템플릿 매칭 최저SAD: ($bestX,$bestY) SAD/sample=$bestSadFormatted tmpl=${bestTw}x$bestTh")
        val matchSuccess = bestSadPs < 50.0
        LogBuffer.diag(this, "DISMISS-TEMPLATE", "source=ORIGINAL_FLOW_RESTORED, templates=${xBtnTemplates.size}, match=$matchSuccess, sad=$bestSadFormatted, coord=($bestX,$bestY)")
        if (bestSadPs < 50.0) {
            Log.d(TAG, "템플릿 매칭 성공!")
            LogBuffer.log(this, TAG, "✅ X템플릿 성공 SAD/sample=$bestSadFormatted 좌표=($bestX,$bestY) tmpl=${bestTw}x$bestTh")
            return Pair(bestX, bestY)
        }
        val fbX = dismissCardRect.right - 106
        val fbY = dismissCardRect.top + 78
        LogBuffer.log(this, TAG, "🔍 템플릿실패 SAD/sample=$bestSadFormatted 최저=($bestX,$bestY) 탐색=[$searchL,$searchT~$searchR,$searchB] 폴백=($fbX,$fbY) tmpl=${bestTw}x$bestTh")
        saveTemplateDebugBitmap(bitmap)
        return null
    }

    private var templateDebugSavedMs: Long = 0L

    private fun saveTemplateDebugBitmap(bitmap: Bitmap) {
        val now = System.currentTimeMillis()
        if (now - templateDebugSavedMs < 1800000L) return
        templateDebugSavedMs = now
        val copy = try {
            bitmap.copy(Bitmap.Config.ARGB_8888, false)
        } catch (_: Throwable) {
            null
        } ?: return

        Thread {
            try {
                val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                val fileName = "template_debug_${sdf.format(Date())}.jpg"
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/스마트알림")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        copy.compress(Bitmap.CompressFormat.JPEG, 90, out)
                    }
                }
            } catch (_: Throwable) {
            } finally {
                copy.recycle()
            }
        }.start()
    }

    private fun findCardIndicator(root: AccessibilityNodeInfo): Boolean {
        val indicators = listOf(
            "분 거리", "분거리", "분 뒤", "분뒤", "km 남음", "km남음", "km",
            "★", "⭐", "콜 수락", "콜수락",
            "새로운 요청", "새 요청", "요청", "픽업", "하차", "경유지",
            "가맹전용", "일반호출", "우버 택시", "우버택시", "UberX"
        )
        for (indicator in indicators) {
            val distNodes = root.findAccessibilityNodeInfosByText(indicator)
            if (!distNodes.isNullOrEmpty()) {
                for (it in distNodes) {
                    try { it.recycle() } catch (_: Throwable) {}
                }
                Log.d(TAG, "카드 지시자 발견 [$indicator 텍스트]")
                return true
            }
        }
        return false
    }

    private fun collectAllText(node: AccessibilityNodeInfo?): String {
        if (node == null) return ""
        val sb = StringBuilder()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(node)
        while (queue.isNotEmpty()) {
            val curr = queue.removeFirst()
            val txt = curr.text
            if (!txt.isNullOrEmpty()) {
                sb.append(txt).append(" ")
            }
            val desc = curr.contentDescription
            if (!desc.isNullOrEmpty()) {
                sb.append(desc).append(" ")
            }
            for (i in 0 until curr.childCount) {
                val child = curr.getChild(i)
                if (child != null) {
                    queue.add(child)
                }
            }
        }
        return sb.toString()
    }

    private fun generateCardFingerprint(node: AccessibilityNodeInfo?): String? {
        if (node == null) return null
        val rawText = collectAllText(node)
        val normalized = rawText
            .replace("\\d+\\s*(초|s|sec)".toRegex(RegexOption.IGNORE_CASE), "")
            .replace("\\d+\\s*분\\s*(거리|뒤)".toRegex(), "")
            .replace("\\d+(\\.\\d+)?\\s*km(\\s*남음)?".toRegex(RegexOption.IGNORE_CASE), "")
            .replace("\\s+".toRegex(), " ")
            .trim()
        val tokens = normalized.split(" ")
            .map { it.trim() }
            .filter { it.length >= 2 && !it.matches("^\\d{1,2}$".toRegex()) }
            .sorted()
        return if (tokens.size >= 2) tokens.joinToString("|") else null
    }

    private fun loadXBtnTemplates() {
        val ids = listOf(
            R.raw.xbtn_template1, R.raw.xbtn_template2, R.raw.xbtn_template3,
            R.raw.xbtn_template4, R.raw.xbtn_template5
        )
        for (id in ids) {
            try {
                val bmp = BitmapFactory.decodeResource(resources, id) ?: continue
                val w = bmp.width
                val h = bmp.height
                val pixels = IntArray(w * h)
                bmp.getPixels(pixels, 0, w, 0, 0, w, h)
                xBtnTemplates.add(TemplateData(pixels, w, h))
                bmp.recycle()
            } catch (_: Throwable) {
            }
        }
    }

    private fun loadAcceptBtnTemplates() {
        val ids = listOf(
            R.raw.accept_template_light, R.raw.accept_template_dark,
            R.raw.accept_template_dark1, R.raw.accept_template_dark2,
            R.raw.accept_template_fold5_dark
        )
        for (id in ids) {
            try {
                val bmp = BitmapFactory.decodeResource(resources, id) ?: continue
                val w = bmp.width
                val h = bmp.height
                val pixels = IntArray(w * h)
                bmp.getPixels(pixels, 0, w, 0, 0, w, h)
                acceptBtnTemplates.add(TemplateData(pixels, w, h))
                bmp.recycle()
            } catch (_: Throwable) {
            }
        }
    }

    private fun computeSADArray(
        src: IntArray, srcW: Int, startX: Int, startY: Int,
        tmpl: IntArray, tw: Int, th: Int
    ): Long {
        var sad = 0L
        for (row in 0 until th) {
            val srcRowOff = (startY + row) * srcW + startX
            val tmplRowOff = row * tw
            for (col in 0 until tw) {
                val c1 = src[srcRowOff + col]
                val c2 = tmpl[tmplRowOff + col]
                val r = abs(((c1 shr 16) and 0xFF) - ((c2 shr 16) and 0xFF))
                val g = abs(((c1 shr 8) and 0xFF) - ((c2 shr 8) and 0xFF))
                val b = abs((c1 and 0xFF) - (c2 and 0xFF))
                sad += (r + g + b)
            }
        }
        return sad
    }

    fun findAcceptButtonByTemplate(bitmap: Bitmap): Pair<Int, Int>? {
        if (acceptBtnTemplates.isEmpty()) return null
        val bw = bitmap.width
        val bh = bitmap.height
        val pixels = IntArray(bw * bh)
        bitmap.getPixels(pixels, 0, bw, 0, 0, bw, bh)

        var bestScore = Long.MAX_VALUE
        var bestX = -1
        var bestY = -1

        for (tmpl in acceptBtnTemplates) {
            val tw = tmpl.width
            val th = tmpl.height
            if (tw >= bw || th >= bh) continue

            val startSearchY = (bh * 0.40f).toInt()
            val endSearchY = bh - th

            for (y in startSearchY until endSearchY step 8) {
                for (x in 0 until (bw - tw) step 8) {
                    val sad = computeSADArray(pixels, bw, x, y, tmpl.pixels, tw, th)
                    if (sad < bestScore) {
                        bestScore = sad
                        bestX = x + tw / 2
                        bestY = y + th / 2
                    }
                }
            }
        }

        return if (bestX != -1 && bestY != -1) Pair(bestX, bestY) else null
    }

    private fun takeScreenshotAndSave() {
        val now = System.currentTimeMillis()
        LogBuffer.diag(this, "CAPTURE-AFTER-ACCEPT", "START\ntimestamp=$now")
        try {
            takeScreenshot(0, ContextCompat.getMainExecutor(this), object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    val hwBm = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
                    if (hwBm == null) {
                        LogBuffer.diag(this@AutoAcceptService, "CAPTURE-AFTER-ACCEPT", "FAILED\nreason=HARDWARE_BUFFER_NULL")
                        return
                    }
                    val w = hwBm.width
                    val h = hwBm.height
                    val softBm = hwBm.copy(Bitmap.Config.ARGB_8888, false)
                    hwBm.recycle()
                    LogBuffer.diag(this@AutoAcceptService, "CAPTURE-AFTER-ACCEPT", "SUCCESS\nwidth=$w\nheight=$h")
                    saveAcceptScreenshotToGallery(softBm)
                }
                override fun onFailure(errorCode: Int) {
                    LogBuffer.diag(this@AutoAcceptService, "CAPTURE-AFTER-ACCEPT", "FAILED\nreason=ERROR_CODE_$errorCode")
                }
            })
        } catch (e: Throwable) {
            LogBuffer.diag(this, "CAPTURE-AFTER-ACCEPT", "FAILED\nreason=${e.message}")
        }
    }

    fun saveAcceptScreenshotToGallery(bitmap: Bitmap) {
        val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
        val name = "UberAccept_${sdf.format(Date())}.png"
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/스마트알림")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    }
                }
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "스마트알림")
                if (!dir.exists()) dir.mkdirs()
                val file = File(dir, name)
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "스크린샷 저장 실패: ${e.message}")
        } finally {
            bitmap.recycle()
        }
    }

    fun gaussianDelay(mean: Long, stdDev: Long, minVal: Long, maxVal: Long): Long {
        val u1 = Random.nextDouble().coerceAtLeast(1e-7)
        val u2 = Random.nextDouble()
        val z0 = sqrt(-2.0 * kotlin.math.ln(u1)) * kotlin.math.cos(2.0 * Math.PI * u2)
        val result = (mean + z0 * stdDev).toLong()
        return result.coerceIn(minVal, maxVal)
    }

    fun vibrate() {
        if (!PrefsManager.isVibration(this)) return
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(150)
            }
        } catch (_: Throwable) {
        }
    }

    fun triggerSleepAlarm() {
        if (!PrefsManager.isSleepAlarm(this)) return
        try {
            stopSleepAlarm(this)

            val alarmUri: Uri? = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)

            if (alarmUri != null) {
                try {
                    val mp = android.media.MediaPlayer().apply {
                        setDataSource(this@AutoAcceptService, alarmUri)
                        setAudioAttributes(
                            android.media.AudioAttributes.Builder()
                                .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                                .build()
                        )
                        isLooping = true
                        prepare()
                        start()
                    }
                    globalMediaPlayer = mp
                    Log.i(TAG, "수면 알람 MediaPlayer 무한 반복 재생 시작")
                    LogBuffer.diag(this, "SLEEP-ALARM", "MediaPlayer 알람 무한 반복 재생 시작")
                    return
                } catch (e: Throwable) {
                    Log.w(TAG, "MediaPlayer 재생 실패, Ringtone 대체 사용: ${e.message}")
                }
            }

            // Fallback: Ringtone loop
            if (alarmUri != null) {
                val ringtone = RingtoneManager.getRingtone(this, alarmUri)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    ringtone?.isLooping = true
                }
                ringtone?.play()
                sleepAlarmRingtone = ringtone
                globalRingtone = ringtone
                Log.i(TAG, "수면 알람 Ringtone 재생 시작")
                LogBuffer.diag(this, "SLEEP-ALARM", "Ringtone 알람 재생 시작")
            }
        } catch (e: Throwable) {
            Log.e(TAG, "수면 알람 재생 실패: ${e.message}")
        }
    }
}
