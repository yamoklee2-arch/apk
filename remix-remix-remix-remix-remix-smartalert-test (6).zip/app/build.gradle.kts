plugins {
    alias(libs.plugins.android.application)
}

android {
    namespace = "com.uber.autoaccept"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.uber.autoaccept.test"
        minSdk = 23
        targetSdk = 34
        versionCode = 52
        versionName = "1.51"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures {
        viewBinding = true
    }
    @Suppress("DEPRECATION")
    aaptOptions {
        noCompress(
            "tflite",
            "binarypb",
            "fb",
            "pb",
            "bincfg"
        )
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.recyclerview)
    implementation(libs.androidx.activity.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.google.material)
    implementation(libs.google.gson)
    implementation(libs.shizuku.api)
    implementation(libs.shizuku.provider)
    implementation(libs.mlkit.text.korean)
    implementation(libs.mlkit.common)
    implementation(libs.mlkit.text.recognition.bundled.common)
    implementation(libs.play.services.base)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.coroutines.core)

    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
}
