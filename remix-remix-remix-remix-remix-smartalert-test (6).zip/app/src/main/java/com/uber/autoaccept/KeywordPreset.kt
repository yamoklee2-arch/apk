package com.uber.autoaccept

data class KeywordPreset(
    var name: String,
    val keywords: List<String>
)
