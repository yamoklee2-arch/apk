package com.uber.autoaccept

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Build
import android.util.Log
import com.google.android.gms.common.moduleinstall.InstallStatusListener
import com.google.android.gms.common.moduleinstall.ModuleInstall
import com.google.android.gms.common.moduleinstall.ModuleInstallRequest
import com.google.android.gms.common.moduleinstall.ModuleInstallStatusUpdate
import com.google.mlkit.common.MlKitException
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.TextRecognizerOptionsInterface
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions

object KoreanOcrManager {
    private const val TAG = "KoreanOcrManager"

    enum class OcrState {
        UNINITIALIZED,
        INITIALIZING,
        MODULE_INSTALL_REQUESTED,
        MODULE_DOWNLOADING,
        MODULE_INSTALLING,
        MODULE_READY,
        DETECTOR_INITIALIZING,
        OCR_READY,
        DETECTOR_INIT_FAILED,
        MODULE_INSTALL_FAILED,
        FAILED,
        RETRY_WAIT
    }

    @Volatile
    var currentState: OcrState = OcrState.UNINITIALIZED
        private set

    @Volatile
    var recognizer: TextRecognizer? = null
        private set

    @Volatile
    private var isInitializing: Boolean = false

    private var initAttemptCount: Int = 0
    private var lastFailTime: Long = 0L
    private const val RETRY_COOLDOWN_MS = 15000L

    private val listeners = mutableListOf<(OcrState, String) -> Unit>()
    private val pendingCallbacks = mutableListOf<(Boolean) -> Unit>()

    fun addStateListener(listener: (OcrState, String) -> Unit) {
        synchronized(listeners) {
            listeners.add(listener)
            listener(currentState, "")
        }
    }

    private fun setState(state: OcrState, msg: String, context: Context? = null) {
        currentState = state
        LogBuffer.log(context, TAG, "[ML-KIT-STATE] $state - $msg")
        synchronized(listeners) {
            listeners.forEach { it(state, msg) }
        }
    }

    private fun logErrorDetails(context: Context?, action: String, throwable: Throwable) {
        val mlkitCode = (throwable as? MlKitException)?.errorCode
            ?: (throwable.cause as? MlKitException)?.errorCode
            ?: -1
        val causeClass = throwable.cause?.javaClass?.name ?: "None"
        val causeMsg = throwable.cause?.message ?: "None"
        val stackPreview = throwable.stackTrace.take(5).joinToString(" | ") {
            "${it.className}.${it.methodName}:${it.lineNumber}"
        }
        val gmsVersion = try {
            val pi = context?.packageManager?.getPackageInfo("com.google.android.gms", 0)
            "${pi?.versionName} (${if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) pi?.longVersionCode else pi?.versionCode})"
        } catch (_: Throwable) {
            "Unavailable"
        }

        val detailLog = "[OCR-ERR-DETAIL] action=$action, attempt=$initAttemptCount, mlkitCode=$mlkitCode, msg=${throwable.message}, causeClass=$causeClass, causeMsg=$causeMsg, androidSdk=${Build.VERSION.SDK_INT}, gmsVer=$gmsVersion, thread=${Thread.currentThread().name}, stack=$stackPreview"
        Log.e(TAG, detailLog)
        LogBuffer.log(context, TAG, detailLog)
    }

    @Synchronized
    fun ensureInitialized(context: Context, onComplete: ((Boolean) -> Unit)? = null) {
        val now = System.currentTimeMillis()

        // 1. 이미 정상 초기화된 인스턴스가 존재하면 즉시 재사용
        if (currentState == OcrState.OCR_READY && recognizer != null) {
            onComplete?.invoke(true)
            return
        }

        // 2. 이미 초기화 진행 중인 경우 중복 Task 생성을 완전히 차단하고 콜백만 대기열에 추가
        if (isInitializing) {
            Log.d(TAG, "초기화 이미 진행 중 (isInitializing=true) -> 중복 호출 차단 및 콜백 등록")
            if (onComplete != null) {
                synchronized(pendingCallbacks) {
                    pendingCallbacks.add(onComplete)
                }
            }
            return
        }

        // 3. 최근 실패 후 쿨다운 기간 동안 재시도 차단
        if (currentState == OcrState.FAILED || currentState == OcrState.MODULE_INSTALL_FAILED || currentState == OcrState.DETECTOR_INIT_FAILED) {
            if (now - lastFailTime < RETRY_COOLDOWN_MS) {
                val remainingSec = (RETRY_COOLDOWN_MS - (now - lastFailTime)) / 1000
                setState(OcrState.RETRY_WAIT, "재시도 쿨다운 중 (${remainingSec}초 대기)", context)
                onComplete?.invoke(false)
                return
            }
        }

        // 상태 잠금 활성화
        isInitializing = true
        initAttemptCount++
        if (onComplete != null) {
            synchronized(pendingCallbacks) {
                pendingCallbacks.add(onComplete)
            }
        }

        setState(OcrState.INITIALIZING, "Korean OCR 초기화 파이프라인 시작 (시도 #$initAttemptCount)", context)

        // 일회성 독립 진단 프로브 실행 (Latin vs Korean 각각 테스트)
        runDiagnosticProbe(context)

        try {
            val moduleInstallClient = ModuleInstall.getClient(context.applicationContext)
            val optionalApi = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())

            val statusListener = object : InstallStatusListener {
                override fun onInstallStatusUpdated(update: ModuleInstallStatusUpdate) {
                    when (update.installState) {
                        ModuleInstallStatusUpdate.InstallState.STATE_DOWNLOADING -> {
                            val progress = update.progressInfo?.let {
                                val total = it.totalBytesToDownload
                                if (total > 0) "${(it.bytesDownloaded * 100 / total)}%" else "${it.bytesDownloaded} bytes"
                            } ?: ""
                            setState(OcrState.MODULE_DOWNLOADING, "GMS 모듈 다운로드 중 $progress", context)
                        }
                        ModuleInstallStatusUpdate.InstallState.STATE_INSTALLING -> {
                            setState(OcrState.MODULE_INSTALLING, "GMS 모듈 설치 중...", context)
                        }
                        ModuleInstallStatusUpdate.InstallState.STATE_COMPLETED -> {
                            setState(OcrState.MODULE_READY, "GMS 모듈 설치 완료 (STATE_COMPLETED) ✓", context)
                            initDetectorAndWarmup(context, optionalApi)
                        }
                        ModuleInstallStatusUpdate.InstallState.STATE_FAILED -> {
                            handleFailure(context, "GMS_INSTALL_FAILED", RuntimeException("GMS module install state failed: code=${update.errorCode}"))
                        }
                        ModuleInstallStatusUpdate.InstallState.STATE_CANCELED -> {
                            handleFailure(context, "GMS_INSTALL_CANCELED", RuntimeException("GMS module install was canceled"))
                        }
                    }
                }
            }

            val request = ModuleInstallRequest.newBuilder()
                .addApi(optionalApi)
                .setListener(statusListener)
                .build()

            moduleInstallClient.areModulesAvailable(optionalApi)
                .addOnSuccessListener { response ->
                    if (response.areModulesAvailable()) {
                        setState(OcrState.MODULE_READY, "GMS 모듈 이미 설치되어 있음 ✓", context)
                        initDetectorAndWarmup(context, optionalApi)
                    } else {
                        setState(OcrState.MODULE_INSTALL_REQUESTED, "GMS 모듈 다운로드 및 설치 요청 전송", context)
                        moduleInstallClient.installModules(request)
                            .addOnSuccessListener { installResponse ->
                                if (installResponse.areModulesAlreadyInstalled()) {
                                    setState(OcrState.MODULE_READY, "GMS 모듈 설치 확인 완료 ✓", context)
                                    initDetectorAndWarmup(context, optionalApi)
                                } else {
                                    setState(OcrState.MODULE_DOWNLOADING, "GMS 모듈 다운로드 세션 시작 (session: ${installResponse.sessionId})", context)
                                }
                            }
                            .addOnFailureListener { e ->
                                handleFailure(context, "INSTALL_MODULES_REQUEST_FAIL", e)
                            }
                    }
                }
                .addOnFailureListener { e ->
                    handleFailure(context, "ARE_MODULES_AVAILABLE_FAIL", e)
                }
        } catch (t: Throwable) {
            handleFailure(context, "ENSURE_INIT_EXCEPTION", t)
        }
    }

    private fun initDetectorAndWarmup(context: Context, rec: TextRecognizer) {
        setState(OcrState.DETECTOR_INITIALIZING, "Korean TextRecognizer 웜업 시작...", context)
        try {
            val dummy = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888).apply {
                eraseColor(Color.WHITE)
                val canvas = Canvas(this)
                val paint = Paint().apply {
                    color = Color.BLACK
                    textSize = 28f
                    isAntiAlias = true
                }
                canvas.drawText("TEST", 30f, 70f, paint)
            }

            rec.process(InputImage.fromBitmap(dummy, 0))
                .addOnSuccessListener {
                    try { dummy.recycle() } catch (_: Throwable) {}
                    recognizer = rec
                    setState(OcrState.OCR_READY, "Korean OCR ready (Korean + Latin + digits)", context)
                    finishInitialization(true)
                }
                .addOnFailureListener { e ->
                    try { dummy.recycle() } catch (_: Throwable) {}
                    handleFailure(context, "WARMUP_PROCESS_FAIL", e)
                }
        } catch (t: Throwable) {
            handleFailure(context, "WARMUP_EXCEPTION", t)
        }
    }

    @Synchronized
    private fun handleFailure(context: Context?, action: String, throwable: Throwable) {
        lastFailTime = System.currentTimeMillis()
        logErrorDetails(context, action, throwable)
        val causeMsg = throwable.cause?.let { "${it.javaClass.simpleName}: ${it.message}" } ?: throwable.message ?: "unknown"
        setState(OcrState.DETECTOR_INIT_FAILED, "초기화 실패 ($action): $causeMsg", context)
        finishInitialization(false)
    }

    @Synchronized
    private fun finishInitialization(success: Boolean) {
        isInitializing = false
        val callbacks = synchronized(pendingCallbacks) {
            val list = pendingCallbacks.toList()
            pendingCallbacks.clear()
            list
        }
        callbacks.forEach { cb ->
            try {
                cb.invoke(success)
            } catch (t: Throwable) {
                Log.w(TAG, "콜백 실행 예외: ${t.message}")
            }
        }
    }

    @Synchronized
    fun getOcrRecognizer(): TextRecognizer? {
        return recognizer
    }

    @Synchronized
    fun close() {
        try {
            recognizer?.close()
        } catch (_: Throwable) {}
        recognizer = null
        currentState = OcrState.UNINITIALIZED
        isInitializing = false
        synchronized(pendingCallbacks) {
            pendingCallbacks.clear()
        }
    }

    private fun runDiagnosticProbe(context: Context) {
        val dummy = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888).apply {
            eraseColor(Color.WHITE)
            val canvas = Canvas(this)
            val paint = Paint().apply {
                color = Color.BLACK
                textSize = 28f
                isAntiAlias = true
            }
            canvas.drawText("TEST 123", 20f, 60f, paint)
        }
        val img = InputImage.fromBitmap(dummy, 0)

        // 1. Latin TextRecognizer 독립 테스트
        try {
            val latinOptionsClass = try {
                Class.forName("com.google.mlkit.vision.text.latin.TextRecognizerOptions")
            } catch (_: ClassNotFoundException) {
                null
            }

            if (latinOptionsClass != null) {
                val defaultOptions = latinOptionsClass.getField("DEFAULT_OPTIONS").get(null) as TextRecognizerOptionsInterface
                val latinRec = TextRecognition.getClient(defaultOptions)
                latinRec.process(img)
                    .addOnSuccessListener { visionText ->
                        LogBuffer.log(context, TAG, "[OCR-DIAG-LATIN] SUCCESS - text='${visionText.text.trim()}'")
                    }
                    .addOnFailureListener { e ->
                        val causeMsg = e.cause?.let { "${it.javaClass.simpleName}: ${it.message}" } ?: e.message ?: "None"
                        LogBuffer.log(context, TAG, "[OCR-DIAG-LATIN] FAILED - ${e.javaClass.simpleName}: ${e.message} (cause: $causeMsg)")
                    }
            } else {
                LogBuffer.log(context, TAG, "[OCR-DIAG-LATIN] FAILED - ClassNotFound: com.google.mlkit.vision.text.latin.TextRecognizerOptions (Latin artifact not in classpath)")
            }
        } catch (t: Throwable) {
            val causeMsg = t.cause?.let { "${it.javaClass.simpleName}: ${it.message}" } ?: t.message ?: "None"
            LogBuffer.log(context, TAG, "[OCR-DIAG-LATIN] EXCEPTION - ${t.javaClass.simpleName}: ${t.message} (cause: $causeMsg)")
        }

        // 2. Korean TextRecognizer 독립 테스트
        try {
            val koreanRec = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            koreanRec.process(img)
                .addOnSuccessListener { visionText ->
                    LogBuffer.log(context, TAG, "[OCR-DIAG-KOREAN] SUCCESS - text='${visionText.text.trim()}'")
                }
                .addOnFailureListener { e ->
                    val causeMsg = e.cause?.let { "${it.javaClass.simpleName}: ${it.message}" } ?: e.message ?: "None"
                    LogBuffer.log(context, TAG, "[OCR-DIAG-KOREAN] FAILED - ${e.javaClass.simpleName}: ${e.message} (cause: $causeMsg)")
                }
        } catch (t: Throwable) {
            val causeMsg = t.cause?.let { "${it.javaClass.simpleName}: ${it.message}" } ?: t.message ?: "None"
            LogBuffer.log(context, TAG, "[OCR-DIAG-KOREAN] EXCEPTION - ${t.javaClass.simpleName}: ${t.message} (cause: $causeMsg)")
        }
    }
}
