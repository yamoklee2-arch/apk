package com.uber.autoaccept

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PresetAdapter(
    private val items: MutableList<KeywordPreset>,
    private val onApply: (Int) -> Unit,
    private val onEdit: (Int) -> Unit,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<PresetAdapter.VH>() {

    companion object {
        private const val BG = -15198184 // #181818
        private const val ACCENT = -16334489 // #06C167
        private const val SEC = -7829368 // #888888
    }

    class VH(val row: LinearLayout) : RecyclerView.ViewHolder(row) {
        val tvName: TextView = row.findViewWithTag("name")
        val tvKw: TextView = row.findViewWithTag("kw")
        val btnApply: Button = row.findViewWithTag("apply")
        val btnEdit: Button = row.findViewWithTag("edit")
        val btnDel: Button = row.findViewWithTag("del")
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val density = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(8), dp(8), dp(8))
            gravity = android.view.Gravity.CENTER_VERTICAL
            val bg = GradientDrawable().apply {
                setColor(BG)
                cornerRadius = dp(8).toFloat()
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(6)
            }
        }

        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val tvName = TextView(ctx).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            tag = "name"
        }
        val tvKw = TextView(ctx).apply {
            textSize = 11f
            setTextColor(SEC)
            tag = "kw"
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(2)
            }
        }
        col.addView(tvName)
        col.addView(tvKw)
        row.addView(col)

        val btnApply = Button(ctx).apply {
            text = "적용"
            textSize = 11f
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                setColor(ACCENT)
                cornerRadius = dp(8).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(32)).apply {
                marginStart = dp(6)
            }
            setPadding(0, 0, 0, 0)
            tag = "apply"
        }
        row.addView(btnApply)

        val btnEdit = Button(ctx).apply {
            text = "✏️"
            textSize = 14f
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1A2A3A"))
                cornerRadius = dp(8).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(32)).apply {
                marginStart = dp(4)
            }
            setPadding(0, 0, 0, 0)
            tag = "edit"
        }
        row.addView(btnEdit)

        val btnDel = Button(ctx).apply {
            text = "🗑️"
            textSize = 14f
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2A1515"))
                cornerRadius = dp(8).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(32)).apply {
                marginStart = dp(4)
            }
            setPadding(0, 0, 0, 0)
            tag = "del"
        }
        row.addView(btnDel)

        return VH(row)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = items[position]
        holder.tvName.text = p.name
        holder.tvKw.text = p.keywords.joinToString(" · ")
        holder.btnApply.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                onApply(pos)
            }
        }
        holder.btnEdit.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                onEdit(pos)
            }
        }
        holder.btnDel.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                onDelete(pos)
            }
        }
    }

    override fun getItemCount(): Int = items.size
}
