package com.uber.autoaccept

import android.graphics.Rect

data class NodeSnap(
    val r: Rect,
    val cls: String,
    val txt: String,
    val clk: String,
    val act: String
)
