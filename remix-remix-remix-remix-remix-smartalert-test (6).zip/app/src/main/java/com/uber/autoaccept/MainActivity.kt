package com.uber.autoaccept

import android.app.ActivityManager
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.PointerIconCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import rikka.shizuku.Shizuku
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    // Top Header & Status
    private lateinit var tvStatus: TextView
    private lateinit var tvCallCount: TextView
    private lateinit var tvAcceptScheduled: TextView
    private lateinit var tvDismissScheduled: TextView
    private lateinit var tvDismissDebug: TextView

    // Tab Navigation Containers
    private lateinit var tabContainerAuto: ScrollView
    private lateinit var tabContainerKeyword: ScrollView
    private lateinit var tabContainerSystem: ScrollView
    private lateinit var tabContainerAccount: ScrollView
    private val tabButtons = mutableListOf<TextView>()
    private var currentTabIndex = 0

    // Tab 1: Auto Accept Controls
    private lateinit var switchActive: Switch
    private lateinit var switchAcceptAll: Switch
    private lateinit var switchOcrPoll: Switch
    private lateinit var switchAutoDismiss: Switch
    private lateinit var switchAcceptScreenshot: Switch
    private lateinit var switchSleepAlarm: Switch

    // Tab 1: Diagnostic Logs (At the bottom of Tab 1)
    private lateinit var tvDiagLog: TextView
    private lateinit var svDiagLog: ScrollView
    private lateinit var btnClearDiagLog: Button
    private lateinit var btnShareDiagLog: Button

    // Tab 2: Keyword Controls
    private lateinit var etKeyword: EditText
    private lateinit var btnAdd: Button
    private lateinit var tvKeywordCountBadge: TextView
    private lateinit var rvKeywords: RecyclerView
    private lateinit var adapter: KeywordAdapter
    private lateinit var rvPresets: RecyclerView
    private lateinit var presetAdapter: PresetAdapter

    // Tab 3: System Status Controls
    private lateinit var tvAccessibilityStatusBadge: TextView
    private lateinit var tvShizukuStatusBadge: TextView
    private lateinit var tvOcrStatusBadge: TextView
    private lateinit var tvDeviceTemp: TextView
    private lateinit var tvRamStatus: TextView
    private lateinit var btnAccessibility: Button
    private lateinit var btnNotification: Button

    // Hidden/Preserved background variables (logic unchanged)
    private lateinit var switchBlacklistMode: Switch
    private lateinit var switchAirportMode: Switch
    private lateinit var switchAcceptNoDelay: Switch
    private lateinit var switchFloatingBubble: Switch
    private lateinit var switchHumanMode: Switch
    private lateinit var switchVibration: Switch
    private lateinit var tvDismissCooldown: TextView
    private lateinit var seekDismissCooldown: SeekBar
    private lateinit var tvMinDelay: TextView
    private lateinit var seekMinDelay: SeekBar
    private lateinit var tvMaxDelay: TextView
    private lateinit var seekMaxDelay: SeekBar

    private val keywords = mutableListOf<String>()
    private val presets = mutableListOf<KeywordPreset>()

    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    // Cyberpunk × Uber Color Palette
    private val COLOR_BG = Color.parseColor("#090A0F")
    private val COLOR_SURFACE = Color.parseColor("#12141C")
    private val COLOR_CARD = Color.parseColor("#171A24")
    private val COLOR_BORDER = Color.parseColor("#252A38")
    private val COLOR_NEON_GREEN = Color.parseColor("#00FFA3")
    private val COLOR_NEON_CYAN = Color.parseColor("#00E5FF")
    private val COLOR_NEON_AMBER = Color.parseColor("#FFB800")
    private val COLOR_NEON_PURPLE = Color.parseColor("#B388FF")
    private val COLOR_NEON_RED = Color.parseColor("#FF3366")
    private val COLOR_TEXT_PRI = Color.parseColor("#FFFFFF")
    private val COLOR_TEXT_SEC = Color.parseColor("#8A93A6")
    private val COLOR_TEXT_MUTED = Color.parseColor("#4C5566")

    private val handler = Handler(Looper.getMainLooper())
    private val statsRefresher = object : Runnable {
        override fun run() {
            updateStats()
            updateSystemTabMetrics()
            handler.postDelayed(this, 1500L)
        }
    }

    private val acceptReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            updateStats()
        }
    }

    private val shizukuPermissionCode = PointerIconCompat.TYPE_CONTEXT_MENU
    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (grantResult == 0) {
            Toast.makeText(this@MainActivity, "Shizuku 권한 허용됨 ✓", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this@MainActivity, "Shizuku 권한 거부됨 — 자동 클릭 불가", Toast.LENGTH_LONG).show()
        }
        updateSystemTabMetrics()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUI()

        keywords.addAll(PrefsManager.getKeywords(this))
        adapter.notifyDataSetChanged()

        presets.addAll(PrefsManager.getPresets(this))
        presetAdapter.notifyDataSetChanged()

        loadSettings()
        setupListeners()
        updateStats()
        updateAccessibilityStatus()
        updateSystemTabMetrics()

        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
        requestShizukuPermission()
    }

    private fun requestShizukuPermission() {
        try {
            if (Shizuku.pingBinder()) {
                if (Shizuku.checkSelfPermission() != 0) {
                    if (Shizuku.shouldShowRequestPermissionRationale()) {
                        Toast.makeText(this, "Shizuku 권한이 필요합니다", Toast.LENGTH_SHORT).show()
                    }
                    Shizuku.requestPermission(shizukuPermissionCode)
                }
            }
        } catch (_: Exception) {}
    }

    private fun isLogScrolledToBottom(): Boolean {
        if (!::svDiagLog.isInitialized) return true
        val child = svDiagLog.getChildAt(0) ?: return true
        val diff = child.bottom - (svDiagLog.height + svDiagLog.scrollY)
        return diff <= dp(32)
    }

    private fun scrollLogToBottom() {
        if (!::svDiagLog.isInitialized) return
        svDiagLog.post {
            val child = svDiagLog.getChildAt(0) ?: return@post
            val scrollAmount = child.bottom - svDiagLog.height
            if (scrollAmount > 0) {
                svDiagLog.scrollTo(0, scrollAmount)
            }
        }
    }

    private val logListener: (String) -> Unit = { line ->
        handler.post {
            if (::tvDiagLog.isInitialized) {
                val wasAtBottom = isLogScrolledToBottom()
                tvDiagLog.append(line + "\n")
                if (wasAtBottom) {
                    scrollLogToBottom()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        LogBuffer.removeListener(logListener)
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
    }

    override fun onResume() {
        super.onResume()
        updateAccessibilityStatus()
        updateDiagLogUI()
        updateSystemTabMetrics()
        LogBuffer.addListener(logListener)
        handler.post(statsRefresher)

        if (::etKeyword.isInitialized) {
            etKeyword.clearFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            currentFocus?.let {
                imm?.hideSoftInputFromWindow(it.windowToken, 0)
            }
        }

        val filter = IntentFilter("com.uber.autoaccept.CALL_ACCEPTED")
        registerReceiver(acceptReceiver, filter, 4)

        if (PrefsManager.isFloatingBubble(this) && Settings.canDrawOverlays(this)) {
            startService(Intent(this, FloatingBubbleService::class.java))
        }
    }

    override fun onPause() {
        super.onPause()
        LogBuffer.removeListener(logListener)
        handler.removeCallbacks(statsRefresher)
        try {
            unregisterReceiver(acceptReceiver)
        } catch (_: Exception) {}
    }

    // =========================================================================
    // UI BUILDER (Cyberpunk × Uber HUD Style)
    // =========================================================================

    private fun buildUI() {
        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(COLOR_BG)
            setPadding(0, dp(32), 0, 0)
        }

        // Top App Header
        val headerBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10))
        }

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }

        val tvBrand = TextView(this).apply {
            text = "SMART ALERT // HUD"
            textSize = 10f
            setTextColor(COLOR_NEON_CYAN)
            typeface = Typeface.MONOSPACE
            letterSpacing = 0.15f
        }
        val tvTitle = TextView(this).apply {
            text = "스마트 알림"
            textSize = 22f
            setTextColor(COLOR_TEXT_PRI)
            typeface = Typeface.DEFAULT_BOLD
        }
        titleCol.addView(tvBrand)
        titleCol.addView(tvTitle)
        headerBar.addView(titleCol)

        tvStatus = TextView(this).apply {
            text = "● STANDBY"
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT_SEC)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = roundRect(COLOR_SURFACE, dp(20), COLOR_BORDER)
        }
        headerBar.addView(tvStatus)
        rootLayout.addView(headerBar)

        // 4 Horizontal Navigation Tabs (Always Accessible at Top)
        val tabLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(COLOR_SURFACE)
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }

        val tabTitles = listOf("① 자동수락", "② 키워드", "③ 시스템", "④ 계정")
        tabButtons.clear()

        for (i in tabTitles.indices) {
            val tabBtn = TextView(this).apply {
                text = tabTitles[i]
                textSize = 13f
                gravity = android.view.Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(10), dp(10), dp(10), dp(10))
                layoutParams = LinearLayout.LayoutParams(0, WRAP).apply {
                    weight = 1f
                    setMargins(dp(2), 0, dp(2), 0)
                }
                setOnClickListener { switchTab(i) }
            }
            tabButtons.add(tabBtn)
            tabLayout.addView(tabBtn)
        }
        rootLayout.addView(tabLayout)
        rootLayout.addView(dividerH(COLOR_BORDER))

        // Main Tab Content View Container (FrameLayout)
        val contentContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(MATCH, MATCH)
        }

        // Build 4 Sub-Tabs
        tabContainerAuto = buildAutoAcceptTab()
        tabContainerKeyword = buildKeywordTab()
        tabContainerSystem = buildSystemTab()
        tabContainerAccount = buildAccountTab()

        contentContainer.addView(tabContainerAuto)
        contentContainer.addView(tabContainerKeyword)
        contentContainer.addView(tabContainerSystem)
        contentContainer.addView(tabContainerAccount)

        rootLayout.addView(contentContainer)
        setContentView(rootLayout)

        // Initialize background hidden variables so logic remains safe
        initBackgroundVariables()

        // Set default active tab
        switchTab(0)
    }

    private fun switchTab(index: Int) {
        currentTabIndex = index
        tabContainerAuto.visibility = if (index == 0) View.VISIBLE else View.GONE
        tabContainerKeyword.visibility = if (index == 1) View.VISIBLE else View.GONE
        tabContainerSystem.visibility = if (index == 2) View.VISIBLE else View.GONE
        tabContainerAccount.visibility = if (index == 3) View.VISIBLE else View.GONE

        for (i in tabButtons.indices) {
            val btn = tabButtons[i]
            if (i == index) {
                btn.setTextColor(COLOR_NEON_GREEN)
                btn.background = roundRect(COLOR_CARD, dp(8), COLOR_NEON_GREEN)
            } else {
                btn.setTextColor(COLOR_TEXT_SEC)
                btn.background = roundRect(Color.TRANSPARENT, dp(8))
            }
        }
    }

    // =========================================================================
    // ① 자동수락 탭 (순서: 카운터 → 자동수락 → OCR → 전체수락 → 닫기 → 스크린샷 → 수면모드 → 로그)
    // =========================================================================

    private fun buildAutoAcceptTab(): ScrollView {
        val sv = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(80))
        }

        // 1. 카운터 (Cyberpunk HUD Status & Stats)
        val statsCard = card(COLOR_CARD, COLOR_BORDER)
        val statsTitle = TextView(this).apply {
            text = "HUD METRICS // CALL COUNTER"
            textSize = 10f
            setTextColor(COLOR_NEON_CYAN)
            typeface = Typeface.MONOSPACE
        }
        statsCard.addView(statsTitle)
        statsCard.addView(space(8))

        val statsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val (callView, col1) = buildStatView(COLOR_TEXT_PRI, COLOR_TEXT_SEC, "콜 감지")
        tvCallCount = callView
        val (acceptSchView, col2) = buildStatView(COLOR_NEON_GREEN, COLOR_TEXT_SEC, "수락 완료")
        tvAcceptScheduled = acceptSchView
        val (dismissSchView, col3) = buildStatView(COLOR_NEON_RED, COLOR_TEXT_SEC, "닫기 실행")
        tvDismissScheduled = dismissSchView

        statsRow.addView(col1)
        statsRow.addView(dividerV(COLOR_BORDER))
        statsRow.addView(col2)
        statsRow.addView(dividerV(COLOR_BORDER))
        statsRow.addView(col3)
        statsCard.addView(statsRow)

        val btnResetStats = TextView(this).apply {
            text = "↻ 카운터 초기화"
            textSize = 11f
            setTextColor(COLOR_TEXT_SEC)
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
            setOnClickListener {
                PrefsManager.resetCounts(this@MainActivity)
                updateStats()
            }
        }
        statsCard.addView(btnResetStats)

        tvDismissDebug = TextView(this).apply {
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_TEXT_MUTED)
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
            text = "수락버튼: 미감지 | 노드: -"
            setOnClickListener { showDiagDialog() }
        }
        statsCard.addView(tvDismissDebug)
        layout.addView(statsCard)
        layout.addView(space(10))

        // 2. 자동수락 (Master Switch)
        switchActive = Switch(this)
        layout.addView(buildToggleCard(
            title = "자동 수락",
            subtitle = "키워드가 일치하는 콜 자동 수락",
            switch = switchActive,
            accentColor = COLOR_NEON_GREEN
        ))
        layout.addView(space(8))

        // 3. OCR 자동수락
        switchOcrPoll = Switch(this)
        layout.addView(buildToggleCard(
            title = "📸 OCR 자동수락",
            subtitle = "스크린샷으로 키워드 인식 → 수락버튼 즉시 탭",
            switch = switchOcrPoll,
            accentColor = COLOR_NEON_PURPLE
        ))
        layout.addView(space(8))

        // 4. 전체수락
        switchAcceptAll = Switch(this)
        layout.addView(buildToggleCard(
            title = "⚡ 전체 수락 모드",
            subtitle = "키워드 필터링 무시 — 모든 콜 무조건 수락",
            switch = switchAcceptAll,
            accentColor = COLOR_NEON_AMBER
        ))
        layout.addView(space(8))

        // 5. 닫기 (불일치 콜 자동 닫기)
        switchAutoDismiss = Switch(this)
        layout.addView(buildToggleCard(
            title = "✕ 불일치 콜 자동 닫기",
            subtitle = "키워드 불일치 콜 — 우측 상단 X 버튼 자동 클릭",
            switch = switchAutoDismiss,
            accentColor = Color.parseColor("#FF6B35")
        ))
        layout.addView(space(8))

        // 6. 스크린샷
        switchAcceptScreenshot = Switch(this)
        layout.addView(buildToggleCard(
            title = "📷 수락 시 스크린샷",
            subtitle = "콜 수락 시 화면을 DCIM/스마트알림/ 에 자동 저장",
            switch = switchAcceptScreenshot,
            accentColor = COLOR_NEON_CYAN
        ))
        layout.addView(space(8))

        // 7. 수면모드
        switchSleepAlarm = Switch(this)
        layout.addView(buildToggleCard(
            title = "🌙 수면 모드",
            subtitle = "수면 중 수락 시 기상나팔 알람 최대 음량 무한 재생",
            switch = switchSleepAlarm,
            accentColor = Color.parseColor("#00BFFF")
        ))
        layout.addView(space(14))

        // 8. 실시간 진단 로그 (반드시 1번 탭의 맨 아래에 배치)
        val diagLogCard = card(COLOR_CARD, COLOR_BORDER)
        val diagHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val diagTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvDiagTitle = TextView(this).apply {
            text = "⚡ 실시간 진단 로그 스트림"
            textSize = 14f
            setTextColor(COLOR_TEXT_PRI)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvDiagSub = TextView(this).apply {
            text = "엔진 이벤트 및 콜카드 판정 스트림"
            textSize = 11f
            setTextColor(COLOR_TEXT_SEC)
        }
        diagTextCol.addView(tvDiagTitle)
        diagTextCol.addView(tvDiagSub)
        diagHeaderRow.addView(diagTextCol)
        diagLogCard.addView(diagHeaderRow)
        diagLogCard.addView(space(10))

        val diagBtnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        btnClearDiagLog = Button(this).apply {
            text = "로그 비우기"
            textSize = 12f
            setTextColor(COLOR_TEXT_PRI)
            background = roundRect(COLOR_SURFACE, dp(8), COLOR_BORDER)
            layoutParams = LinearLayout.LayoutParams(0, dp(38)).apply {
                weight = 1f
                rightMargin = dp(4)
            }
            setOnClickListener {
                LogBuffer.clear(this@MainActivity)
                updateDiagLogUI()
                Toast.makeText(this@MainActivity, "로그가 비워졌습니다", Toast.LENGTH_SHORT).show()
            }
        }
        btnShareDiagLog = Button(this).apply {
            text = "로그 공유"
            textSize = 12f
            setTextColor(COLOR_TEXT_PRI)
            background = roundRect(Color.parseColor("#1B3A57"), dp(8), COLOR_NEON_CYAN)
            layoutParams = LinearLayout.LayoutParams(0, dp(38)).apply {
                weight = 1f
                leftMargin = dp(4)
            }
            setOnClickListener { shareDiagnosticLog() }
        }
        val btnExportLog = Button(this).apply {
            text = "파일 저장"
            textSize = 12f
            setTextColor(COLOR_TEXT_PRI)
            background = roundRect(COLOR_SURFACE, dp(8), COLOR_BORDER)
            layoutParams = LinearLayout.LayoutParams(0, dp(38)).apply {
                weight = 1f
                leftMargin = dp(4)
            }
            setOnClickListener { exportLog() }
        }
        diagBtnRow.addView(btnClearDiagLog)
        diagBtnRow.addView(btnShareDiagLog)
        diagBtnRow.addView(btnExportLog)
        diagLogCard.addView(diagBtnRow)
        diagLogCard.addView(space(8))

        svDiagLog = ScrollView(this).apply {
            background = roundRect(Color.parseColor("#050608"), dp(8), COLOR_BORDER)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(220))
            isScrollbarFadingEnabled = false
            isFocusable = false
            descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
            setOnTouchListener { v, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> v.parent?.requestDisallowInterceptTouchEvent(true)
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.parent?.requestDisallowInterceptTouchEvent(false)
                }
                false
            }
        }

        tvDiagLog = TextView(this).apply {
            textSize = 10.5f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_NEON_GREEN)
            text = "[HUD SYSTEM READY — 로깅 대기 중...]\n"
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        }
        svDiagLog.addView(tvDiagLog)
        diagLogCard.addView(svDiagLog)

        layout.addView(diagLogCard)
        sv.addView(layout)
        return sv
    }

    // =========================================================================
    // ② 키워드 탭 (순서: 공항 키워드 → 키워드 추가/삭제 → 포함 키워드 → 매칭 방식 → 키워드 상태)
    // =========================================================================

    private fun buildKeywordTab(): ScrollView {
        val sv = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(80))
        }

        // 1. 공항 키워드 프리셋 칩
        val airportCard = card(COLOR_CARD, COLOR_BORDER)
        val tvAirportHeader = TextView(this).apply {
            text = "✈️ 공항 전용 퀵 키워드"
            textSize = 14f
            setTextColor(COLOR_TEXT_PRI)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvAirportSub = TextView(this).apply {
            text = "탭하여 공항 관련 키워드를 즉시 추가합니다"
            textSize = 11f
            setTextColor(COLOR_TEXT_SEC)
        }
        airportCard.addView(tvAirportHeader)
        airportCard.addView(tvAirportSub)
        airportCard.addView(space(10))

        val airportFlow = FlexWrapLayout(this)
        val airportKws = listOf("인천공항", "김포공항", "공항", "제1여객터미널", "제2여객터미널", "T1", "T2")
        for (kw in airportKws) {
            val chip = TextView(this).apply {
                text = "+ $kw"
                textSize = 12f
                setTextColor(COLOR_NEON_CYAN)
                background = roundRect(Color.parseColor("#0C1A24"), dp(8), COLOR_NEON_CYAN)
                setPadding(dp(10), dp(6), dp(10), dp(6))
                setOnClickListener { addKeyword(kw) }
            }
            airportFlow.addView(chip)
        }
        airportCard.addView(airportFlow)
        layout.addView(airportCard)
        layout.addView(space(10))

        // 2. 키워드 추가/삭제 (입력창 + 자주 쓰는 목적지)
        val addCard = card(COLOR_CARD, COLOR_BORDER)
        val addRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        etKeyword = EditText(this).apply {
            hint = "목적지 키워드 입력"
            setHintTextColor(COLOR_TEXT_MUTED)
            setTextColor(COLOR_TEXT_PRI)
            textSize = 14f
            background = roundRect(COLOR_SURFACE, dp(8), COLOR_BORDER)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setSingleLine(true)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply {
                weight = 1f
                marginEnd = dp(8)
            }
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                    addKeywordFromInput()
                    true
                } else false
            }
        }
        addRow.addView(etKeyword)

        btnAdd = Button(this).apply {
            text = "추가"
            textSize = 13f
            setTextColor(COLOR_BG)
            typeface = Typeface.DEFAULT_BOLD
            background = roundRect(COLOR_NEON_GREEN, dp(8))
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(44))
            setOnClickListener { addKeywordFromInput() }
        }
        addRow.addView(btnAdd)
        addCard.addView(addRow)
        addCard.addView(space(10))

        val popularFlow = FlexWrapLayout(this)
        val popularKws = listOf("강남", "잠실", "홍대", "서울역", "여의도", "판교", "수원")
        for (kw in popularKws) {
            val chip = TextView(this).apply {
                text = "+ $kw"
                textSize = 12f
                setTextColor(COLOR_TEXT_PRI)
                background = roundRect(COLOR_SURFACE, dp(8), COLOR_BORDER)
                setPadding(dp(10), dp(6), dp(10), dp(6))
                setOnClickListener { addKeyword(kw) }
            }
            popularFlow.addView(chip)
        }
        addCard.addView(popularFlow)
        layout.addView(addCard)
        layout.addView(space(10))

        // 3. 포함 키워드 목록
        val kwHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(6) }
        }
        val tvKwHeader = TextView(this).apply {
            text = "📋 등록된 포함 키워드"
            textSize = 13f
            setTextColor(COLOR_TEXT_PRI)
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        kwHeaderRow.addView(tvKwHeader)

        val btnClearAll = Button(this).apply {
            text = "전체 삭제"
            textSize = 11f
            setTextColor(COLOR_NEON_RED)
            background = roundRect(Color.parseColor("#261118"), dp(6), COLOR_NEON_RED)
            setPadding(dp(10), dp(2), dp(10), dp(2))
            layoutParams = LinearLayout.LayoutParams(WRAP, dp(32))
            setOnClickListener {
                if (keywords.isEmpty()) {
                    Toast.makeText(this@MainActivity, "삭제할 키워드가 없습니다", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("키워드 전체 삭제")
                    .setMessage("등록된 모든 키워드를 삭제할까요?")
                    .setPositiveButton("삭제") { _, _ ->
                        val count = keywords.size
                        keywords.clear()
                        adapter.notifyItemRangeRemoved(0, count)
                        PrefsManager.saveKeywords(this@MainActivity, keywords)
                        updateStats()
                        Toast.makeText(this@MainActivity, "${count}개 삭제됨", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("취소", null)
                    .show()
            }
        }
        kwHeaderRow.addView(btnClearAll)
        layout.addView(kwHeaderRow)

        rvKeywords = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
        }
        adapter = KeywordAdapter(keywords) { pos ->
            keywords.removeAt(pos)
            adapter.notifyItemRemoved(pos)
            PrefsManager.saveKeywords(this, keywords)
            updateStats()
        }
        rvKeywords.adapter = adapter
        layout.addView(rvKeywords)
        layout.addView(space(12))

        // 4. 매칭 방식 및 프리셋 카드
        val presetCard = card(COLOR_CARD, COLOR_BORDER)
        val presetHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val presetTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvPresetTitle = TextView(this).apply {
            text = "📑 키워드 프리셋 프로필"
            textSize = 14f
            setTextColor(COLOR_TEXT_PRI)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvPresetSub = TextView(this).apply {
            text = "상황별 키워드 세트를 원터치로 변경합니다"
            textSize = 11f
            setTextColor(COLOR_TEXT_SEC)
        }
        presetTextCol.addView(tvPresetTitle)
        presetTextCol.addView(tvPresetSub)
        presetHeaderRow.addView(presetTextCol)

        val btnSavePreset = Button(this).apply {
            text = "+ 저장"
            textSize = 12f
            setTextColor(COLOR_TEXT_PRI)
            background = roundRect(Color.parseColor("#1B3A57"), dp(8), COLOR_NEON_CYAN)
            layoutParams = LinearLayout.LayoutParams(WRAP, dp(34))
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener { showSavePresetDialog() }
        }
        presetHeaderRow.addView(btnSavePreset)
        presetCard.addView(presetHeaderRow)
        presetCard.addView(space(8))

        rvPresets = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            isNestedScrollingEnabled = false
        }
        presetAdapter = PresetAdapter(
            presets,
            onApply = { pos ->
                val p = presets[pos]
                keywords.clear()
                keywords.addAll(p.keywords)
                adapter.notifyDataSetChanged()
                PrefsManager.saveKeywords(this@MainActivity, keywords)
                updateStats()
                Toast.makeText(this@MainActivity, "「${p.name}」 적용됨", Toast.LENGTH_SHORT).show()
            },
            onEdit = { pos -> showEditPresetDialog(pos) },
            onDelete = { pos -> showDeletePresetDialog(pos) }
        )
        rvPresets.adapter = presetAdapter
        presetCard.addView(rvPresets)
        layout.addView(presetCard)
        layout.addView(space(10))

        // 5. 키워드 상태 HUD
        val statusCard = card(COLOR_CARD, COLOR_BORDER)
        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val statusLabel = TextView(this).apply {
            text = "키워드 엔진 상태"
            textSize = 13f
            setTextColor(COLOR_TEXT_SEC)
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        tvKeywordCountBadge = TextView(this).apply {
            text = "0개 활성"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(COLOR_NEON_GREEN)
        }
        statusRow.addView(statusLabel)
        statusRow.addView(tvKeywordCountBadge)
        statusCard.addView(statusRow)
        layout.addView(statusCard)

        sv.addView(layout)
        return sv
    }

    // =========================================================================
    // ③ 시스템 탭 (순서: 접근성 → Shizuku 상태 → OCR/서비스 상태 → 휴대폰 온도 → 메모리 상태 → 메모리 관리)
    // =========================================================================

    private fun buildSystemTab(): ScrollView {
        val sv = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(80))
        }

        // 1. 접근성 상태 및 설정
        val accCard = card(COLOR_CARD, COLOR_BORDER)
        val accRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val accTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvAccTitle = TextView(this).apply {
            text = "접근성 서비스 (Accessibility)"
            textSize = 14f
            setTextColor(COLOR_TEXT_PRI)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvAccSub = TextView(this).apply {
            text = "콜카드 노드 탐색 및 자동 터치에 필수"
            textSize = 11f
            setTextColor(COLOR_TEXT_SEC)
        }
        accTextCol.addView(tvAccTitle)
        accTextCol.addView(tvAccSub)
        accRow.addView(accTextCol)

        tvAccessibilityStatusBadge = TextView(this).apply {
            text = "확인 중"
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        accRow.addView(tvAccessibilityStatusBadge)
        accCard.addView(accRow)
        accCard.addView(space(10))

        btnAccessibility = Button(this).apply {
            text = "접근성 서비스 설정 열기"
            textSize = 13f
            setTextColor(COLOR_TEXT_PRI)
            background = roundRect(Color.parseColor("#1A3B66"), dp(8), COLOR_NEON_CYAN)
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(44))
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        accCard.addView(btnAccessibility)
        accCard.addView(space(6))

        btnNotification = Button(this).apply {
            text = "알림 접근 권한 설정 열기"
            textSize = 13f
            setTextColor(COLOR_TEXT_PRI)
            background = roundRect(COLOR_SURFACE, dp(8), COLOR_BORDER)
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(44))
            setOnClickListener { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        }
        accCard.addView(btnNotification)
        layout.addView(accCard)
        layout.addView(space(10))

        // 2. Shizuku 상태
        val shizukuCard = card(COLOR_CARD, COLOR_BORDER)
        val shizukuRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val shizukuTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvShizukuTitle = TextView(this).apply {
            text = "Shizuku ADB 엔진"
            textSize = 14f
            setTextColor(COLOR_TEXT_PRI)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvShizukuSub = TextView(this).apply {
            text = "0ms 초고속 가상 탭 인젝션 권한"
            textSize = 11f
            setTextColor(COLOR_TEXT_SEC)
        }
        shizukuTextCol.addView(tvShizukuTitle)
        shizukuTextCol.addView(tvShizukuSub)
        shizukuRow.addView(shizukuTextCol)

        tvShizukuStatusBadge = TextView(this).apply {
            text = "확인 중"
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        shizukuRow.addView(tvShizukuStatusBadge)
        shizukuCard.addView(shizukuRow)
        shizukuCard.addView(space(10))

        val btnShizukuReq = Button(this).apply {
            text = "Shizuku 권한 다시 요청"
            textSize = 13f
            setTextColor(COLOR_TEXT_PRI)
            background = roundRect(COLOR_SURFACE, dp(8), COLOR_BORDER)
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(40))
            setOnClickListener { requestShizukuPermission() }
        }
        shizukuCard.addView(btnShizukuReq)
        layout.addView(shizukuCard)
        layout.addView(space(10))

        // 3. OCR / 서비스 상태
        val ocrStatusCard = card(COLOR_CARD, COLOR_BORDER)
        val ocrStatusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val ocrStatusTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvOcrStatusTitle = TextView(this).apply {
            text = "ML Kit OCR 엔진 상태"
            textSize = 14f
            setTextColor(COLOR_TEXT_PRI)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvOcrStatusSub = TextView(this).apply {
            text = "Google ML Kit Korean Vision Engine"
            textSize = 11f
            setTextColor(COLOR_TEXT_SEC)
        }
        ocrStatusTextCol.addView(tvOcrStatusTitle)
        ocrStatusTextCol.addView(tvOcrStatusSub)
        ocrStatusRow.addView(ocrStatusTextCol)

        tvOcrStatusBadge = TextView(this).apply {
            text = "READY"
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_NEON_GREEN)
            background = roundRect(Color.parseColor("#0C2417"), dp(6), COLOR_NEON_GREEN)
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        ocrStatusRow.addView(tvOcrStatusBadge)
        ocrStatusCard.addView(ocrStatusRow)
        layout.addView(ocrStatusCard)
        layout.addView(space(10))

        // 4. 휴대폰 온도 (실시간)
        val tempCard = card(COLOR_CARD, COLOR_BORDER)
        val tempRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val tempTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvTempTitle = TextView(this).apply {
            text = "🌡️ 디바이스 온도"
            textSize = 14f
            setTextColor(COLOR_TEXT_PRI)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvTempSub = TextView(this).apply {
            text = "배터리 및 하드웨어 실시간 센서"
            textSize = 11f
            setTextColor(COLOR_TEXT_SEC)
        }
        tempTextCol.addView(tvTempTitle)
        tempTextCol.addView(tvTempSub)
        tempRow.addView(tempTextCol)

        tvDeviceTemp = TextView(this).apply {
            text = "-- °C"
            textSize = 16f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_NEON_CYAN)
        }
        tempRow.addView(tvDeviceTemp)
        tempCard.addView(tempRow)
        layout.addView(tempCard)
        layout.addView(space(10))

        // 5. 메모리 상태 & 6. 메모리 관리
        val memCard = card(COLOR_CARD, COLOR_BORDER)
        val memRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val memTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvMemTitle = TextView(this).apply {
            text = "💾 시스템 메모리 (RAM)"
            textSize = 14f
            setTextColor(COLOR_TEXT_PRI)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvMemSub = TextView(this).apply {
            text = "실시간 RAM 가용량 및 GC 트리거"
            textSize = 11f
            setTextColor(COLOR_TEXT_SEC)
        }
        memTextCol.addView(tvMemTitle)
        memTextCol.addView(tvMemSub)
        memRow.addView(memTextCol)

        tvRamStatus = TextView(this).apply {
            text = "-- / -- GB"
            textSize = 14f
            typeface = Typeface.MONOSPACE
            setTextColor(COLOR_NEON_GREEN)
        }
        memRow.addView(tvRamStatus)
        memCard.addView(memRow)
        memCard.addView(space(10))

        val btnCleanMem = Button(this).apply {
            text = "⚡ 메모리 정리 및 캐시 비우기"
            textSize = 13f
            setTextColor(COLOR_TEXT_PRI)
            background = roundRect(COLOR_SURFACE, dp(8), COLOR_BORDER)
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(40))
            setOnClickListener {
                System.gc()
                Runtime.getRuntime().gc()
                updateSystemTabMetrics()
                Toast.makeText(this@MainActivity, "메모리 최적화가 실행되었습니다", Toast.LENGTH_SHORT).show()
            }
        }
        memCard.addView(btnCleanMem)
        layout.addView(memCard)

        sv.addView(layout)
        return sv
    }

    // =========================================================================
    // ④ 계정 탭 (순서: 계정 로그인 → 계정 상태 → 사용기간 → 사용시간 → 등록 기기 → 로그아웃)
    // =========================================================================

    private fun buildAccountTab(): ScrollView {
        val sv = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(80))
        }

        // 1. 계정 로그인 카드 (Placeholder)
        val loginCard = card(COLOR_CARD, COLOR_BORDER)
        val tvLoginTitle = TextView(this).apply {
            text = "🔑 서버 계정 인증"
            textSize = 15f
            setTextColor(COLOR_TEXT_PRI)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvLoginSub = TextView(this).apply {
            text = "클라우드 동기화 및 라이선스 인증 센터"
            textSize = 11f
            setTextColor(COLOR_TEXT_SEC)
        }
        loginCard.addView(tvLoginTitle)
        loginCard.addView(tvLoginSub)
        loginCard.addView(space(12))

        val etAccountId = EditText(this).apply {
            hint = "기사 아이디 또는 이메일"
            setHintTextColor(COLOR_TEXT_MUTED)
            setTextColor(COLOR_TEXT_PRI)
            textSize = 14f
            background = roundRect(COLOR_SURFACE, dp(8), COLOR_BORDER)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setSingleLine(true)
            isEnabled = false
            setText("yamoklee2@gmail.com")
        }
        loginCard.addView(etAccountId)
        loginCard.addView(space(8))

        val btnLogin = Button(this).apply {
            text = "계정 연동 완료 (정상)"
            textSize = 13f
            setTextColor(COLOR_TEXT_PRI)
            typeface = Typeface.DEFAULT_BOLD
            background = roundRect(Color.parseColor("#1B3A57"), dp(8), COLOR_NEON_CYAN)
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(42))
            setOnClickListener {
                Toast.makeText(this@MainActivity, "현재 로컬 라이선스로 정상 인증되어 있습니다", Toast.LENGTH_SHORT).show()
            }
        }
        loginCard.addView(btnLogin)
        layout.addView(loginCard)
        layout.addView(space(10))

        // 2. 계정 상태
        layout.addView(buildAccountInfoCard("계정 상태", "PRO DRIVER // ACTIVE", COLOR_NEON_GREEN))
        layout.addView(space(8))

        // 3. 사용기간
        layout.addView(buildAccountInfoCard("사용 라이선스 기간", "LIFETIME UNLIMITED (평생)", COLOR_NEON_CYAN))
        layout.addView(space(8))

        // 4. 사용시간
        val runHours = (SystemClock.elapsedRealtime() / (1000 * 60 * 60)).coerceAtLeast(1)
        layout.addView(buildAccountInfoCard("누적 엔진 가동시간", "${runHours}시간 가동 중", COLOR_NEON_AMBER))
        layout.addView(space(8))

        // 5. 등록 기기
        val deviceModel = "${Build.MANUFACTURER.uppercase(Locale.getDefault())} ${Build.MODEL}"
        layout.addView(buildAccountInfoCard("등록 디바이스", deviceModel, COLOR_TEXT_PRI))
        layout.addView(space(14))

        // 6. 로그아웃 버튼 (Placeholder)
        val btnLogout = Button(this).apply {
            text = "계정 연동 해제 / 로그아웃"
            textSize = 13f
            setTextColor(COLOR_NEON_RED)
            background = roundRect(Color.parseColor("#261118"), dp(8), COLOR_NEON_RED)
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(44))
            setOnClickListener {
                Toast.makeText(this@MainActivity, "백엔드 인증 서버가 곧 연결될 예정입니다", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(btnLogout)

        sv.addView(layout)
        return sv
    }

    private fun buildAccountInfoCard(title: String, value: String, valueColor: Int): LinearLayout {
        val c = card(COLOR_CARD, COLOR_BORDER)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val tvT = TextView(this).apply {
            text = title
            textSize = 13f
            setTextColor(COLOR_TEXT_SEC)
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvV = TextView(this).apply {
            text = value
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setTextColor(valueColor)
        }
        row.addView(tvT)
        row.addView(tvV)
        c.addView(row)
        return c
    }

    // =========================================================================
    // UI Helpers & Components
    // =========================================================================

    private fun buildToggleCard(title: String, subtitle: String, switch: Switch, accentColor: Int): LinearLayout {
        val c = card(COLOR_CARD, COLOR_BORDER)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvT = TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(COLOR_TEXT_PRI)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvSub = TextView(this).apply {
            text = subtitle
            textSize = 11.5f
            setTextColor(COLOR_TEXT_SEC)
        }
        textCol.addView(tvT)
        textCol.addView(tvSub)
        row.addView(textCol)

        switch.apply {
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(accentColor, Color.parseColor("#333A4A"))
            )
        }
        row.addView(switch)
        c.addView(row)
        return c
    }

    private fun buildStatView(textColor: Int, secColor: Int, label: String): Pair<TextView, LinearLayout> {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
            setPadding(dp(6), dp(8), dp(6), dp(8))
        }
        val tvValue = TextView(this).apply {
            text = "0"
            textSize = 20f
            gravity = android.view.Gravity.CENTER
            setTextColor(textColor)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvLabel = TextView(this).apply {
            text = label
            textSize = 11f
            gravity = android.view.Gravity.CENTER
            setTextColor(secColor)
        }
        col.addView(tvValue)
        col.addView(tvLabel)
        return Pair(tvValue, col)
    }

    private fun initBackgroundVariables() {
        switchBlacklistMode = Switch(this).apply { isChecked = PrefsManager.isBlacklistMode(this@MainActivity) }
        switchAirportMode = Switch(this).apply { isChecked = PrefsManager.isAirportMode(this@MainActivity) }
        switchAcceptNoDelay = Switch(this).apply { isChecked = PrefsManager.isAcceptNoDelay(this@MainActivity) }
        switchFloatingBubble = Switch(this).apply { isChecked = PrefsManager.isFloatingBubble(this@MainActivity) }
        switchHumanMode = Switch(this).apply { isChecked = PrefsManager.isHumanMode(this@MainActivity) }
        switchVibration = Switch(this).apply { isChecked = PrefsManager.isVibration(this@MainActivity) }

        tvDismissCooldown = TextView(this)
        seekDismissCooldown = SeekBar(this)
        tvMinDelay = TextView(this)
        seekMinDelay = SeekBar(this)
        tvMaxDelay = TextView(this)
        seekMaxDelay = SeekBar(this)
    }

    private fun setupListeners() {
        switchActive.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setActive(this, isChecked)
            updateAccessibilityStatus()
        }
        switchAcceptAll.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setAcceptAll(this, isChecked)
        }
        switchBlacklistMode.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setBlacklistMode(this, isChecked)
        }
        switchOcrPoll.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setOcrPoll(this, isChecked)
        }
        switchAutoDismiss.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setAutoDismiss(this, isChecked)
        }
        switchSleepAlarm.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.saveSleepAlarm(this, isChecked)
        }
        switchAirportMode.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.saveAirportMode(this, isChecked)
        }
        switchAcceptNoDelay.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.saveAcceptNoDelay(this, isChecked)
        }
        switchAcceptScreenshot.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.saveAcceptScreenshot(this, isChecked)
        }
        switchFloatingBubble.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.saveFloatingBubble(this, isChecked)
            if (isChecked) {
                if (Settings.canDrawOverlays(this)) {
                    startService(Intent(this, FloatingBubbleService::class.java))
                } else {
                    switchFloatingBubble.isChecked = false
                    PrefsManager.saveFloatingBubble(this, false)
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    startActivity(intent)
                }
            } else {
                stopService(Intent(this, FloatingBubbleService::class.java))
            }
        }
        switchHumanMode.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setHumanMode(this, isChecked)
        }
        switchVibration.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setVibration(this, isChecked)
        }
    }

    private fun loadSettings() {
        switchActive.isChecked = PrefsManager.isActive(this)
        switchAcceptAll.isChecked = PrefsManager.isAcceptAll(this)
        switchOcrPoll.isChecked = PrefsManager.isOcrPoll(this)
        switchAutoDismiss.isChecked = PrefsManager.isAutoDismiss(this)
        switchSleepAlarm.isChecked = PrefsManager.isSleepAlarm(this)
        switchAcceptScreenshot.isChecked = PrefsManager.isAcceptScreenshot(this)
    }

    private fun updateStats() {
        if (::tvCallCount.isInitialized) {
            tvCallCount.text = PrefsManager.getCallCount(this).toString()
            tvAcceptScheduled.text = PrefsManager.getAcceptScheduled(this).toString()
            tvDismissScheduled.text = PrefsManager.getDismissExecuted(this).toString()

            val rectStr = PrefsManager.getLastAcceptRectString(this)
            val diagStr = PrefsManager.getDismissDiag(this)
            val hasTree = diagStr.contains("노드수:")
            val nodeCount = if (hasTree) {
                val match = Regex("노드수: (\\d+)").find(diagStr)
                match?.groupValues?.getOrNull(1) ?: "?"
            } else "-"
            tvDismissDebug.text = "수락버튼: $rectStr  |  노드: $nodeCount"
        }
        if (::tvKeywordCountBadge.isInitialized) {
            tvKeywordCountBadge.text = "${keywords.size}개 등록됨"
        }
    }

    private fun updateSystemTabMetrics() {
        // Accessibility
        val enabled = AutoAcceptService.isRunning
        if (::tvAccessibilityStatusBadge.isInitialized) {
            if (enabled) {
                tvAccessibilityStatusBadge.text = "RUNNING ✓"
                tvAccessibilityStatusBadge.setTextColor(COLOR_NEON_GREEN)
                tvAccessibilityStatusBadge.background = roundRect(Color.parseColor("#0C2417"), dp(6), COLOR_NEON_GREEN)
            } else {
                tvAccessibilityStatusBadge.text = "OFF ✕"
                tvAccessibilityStatusBadge.setTextColor(COLOR_NEON_RED)
                tvAccessibilityStatusBadge.background = roundRect(Color.parseColor("#261118"), dp(6), COLOR_NEON_RED)
            }
        }

        // Shizuku
        if (::tvShizukuStatusBadge.isInitialized) {
            try {
                if (Shizuku.pingBinder()) {
                    if (Shizuku.checkSelfPermission() == 0) {
                        tvShizukuStatusBadge.text = "AUTHORIZED ✓"
                        tvShizukuStatusBadge.setTextColor(COLOR_NEON_GREEN)
                        tvShizukuStatusBadge.background = roundRect(Color.parseColor("#0C2417"), dp(6), COLOR_NEON_GREEN)
                    } else {
                        tvShizukuStatusBadge.text = "PERMISSION NEEDED"
                        tvShizukuStatusBadge.setTextColor(COLOR_NEON_AMBER)
                        tvShizukuStatusBadge.background = roundRect(Color.parseColor("#262011"), dp(6), COLOR_NEON_AMBER)
                    }
                } else {
                    tvShizukuStatusBadge.text = "DISCONNECTED"
                    tvShizukuStatusBadge.setTextColor(COLOR_TEXT_SEC)
                    tvShizukuStatusBadge.background = roundRect(COLOR_SURFACE, dp(6), COLOR_BORDER)
                }
            } catch (_: Throwable) {
                tvShizukuStatusBadge.text = "UNKNOWN"
            }
        }

        // Battery / Temp
        if (::tvDeviceTemp.isInitialized) {
            val batteryStatus: Intent? = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val temp = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
            val tempC = temp / 10.0
            tvDeviceTemp.text = String.format(Locale.getDefault(), "%.1f °C", tempC)
        }

        // RAM Info
        if (::tvRamStatus.isInitialized) {
            val actManager = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            actManager?.getMemoryInfo(memInfo)
            val availGb = memInfo.availMem / (1024.0 * 1024.0 * 1024.0)
            val totalGb = memInfo.totalMem / (1024.0 * 1024.0 * 1024.0)
            val usedPercent = (((totalGb - availGb) / totalGb) * 100).toInt()
            tvRamStatus.text = String.format(Locale.getDefault(), "%.1f / %.1f GB (%d%%)", (totalGb - availGb), totalGb, usedPercent)
        }
    }

    private fun addKeywordFromInput() {
        if (!::etKeyword.isInitialized) return
        addKeyword(etKeyword.text.toString())
        etKeyword.text.clear()
    }

    private fun addKeyword(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        if (keywords.any { it.equals(trimmed, ignoreCase = true) }) {
            Toast.makeText(this, "이미 등록된 키워드입니다", Toast.LENGTH_SHORT).show()
            return
        }
        keywords.add(0, trimmed)
        adapter.notifyItemInserted(0)
        PrefsManager.saveKeywords(this, keywords)
        updateStats()
    }

    private fun updateStatus(active: Boolean) {
        if (!::tvStatus.isInitialized) return
        if (active) {
            tvStatus.text = "● ACTIVE"
            tvStatus.setTextColor(COLOR_NEON_GREEN)
            tvStatus.background = roundRect(Color.parseColor("#0C2417"), dp(20), COLOR_NEON_GREEN)
        } else {
            tvStatus.text = "● STANDBY"
            tvStatus.setTextColor(COLOR_TEXT_SEC)
            tvStatus.background = roundRect(COLOR_SURFACE, dp(20), COLOR_BORDER)
        }
    }

    private fun updateAccessibilityStatus() {
        val enabled = AutoAcceptService.isRunning
        val active = PrefsManager.isActive(this)
        updateStatus(active && enabled)
        if (::switchActive.isInitialized) {
            switchActive.isChecked = active
        }

        val notifOk = NotificationListener.isEnabled(this)
        if (::btnNotification.isInitialized) {
            btnNotification.text = if (notifOk) "알림 접근 권한 허용됨 ✓" else "알림 접근 권한 설정 열기"
        }
    }

    private fun updateDiagLogUI() {
        if (::tvDiagLog.isInitialized) {
            val allLogs = LogBuffer.getAll(this)
            val text = if (allLogs.isEmpty()) {
                "[HUD SYSTEM READY — 새로운 콜 및 OCR 감지 대기 중...]\n"
            } else {
                allLogs.joinToString("\n") + "\n"
            }
            tvDiagLog.text = text
            scrollLogToBottom()
        }
    }

    private fun shareDiagnosticLog() {
        val logText = LogBuffer.read(this)
        if (logText.isBlank()) {
            Toast.makeText(this, "공유할 진단 로그가 없습니다", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val shareFile = File(cacheDir, "diagnostic_log_$timestamp.txt")
            shareFile.writeText(logText)

            val fileUri = androidx.core.content.FileProvider.getUriForFile(
                this,
                "com.uber.autoaccept.test.fileprovider",
                shareFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "스마트알림 HUD 진단 로그 ($timestamp)")
                putExtra(Intent.EXTRA_TEXT, logText)
                putExtra(Intent.EXTRA_STREAM, fileUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "진단 로그 공유"))
        } catch (e: Exception) {
            Toast.makeText(this, "로그 공유 실패: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportLog() {
        Toast.makeText(this, "로그 저장 중...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                val output = LogBuffer.read(this)
                if (output.isBlank()) {
                    runOnUiThread {
                        Toast.makeText(this, "로그가 없습니다.\n앱이 실행된 후 콜을 받으면 자동으로 기록됩니다.", Toast.LENGTH_LONG).show()
                    }
                    return@Thread
                }
                val content = "=== 스마트알림 HUD 로그 $timestamp ===\n\n$output"
                val fileName = "smart_alarm_$timestamp.txt"
                val saved = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val cv = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                        put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                    if (uri != null) {
                        contentResolver.openOutputStream(uri)?.use { os ->
                            os.write(content.toByteArray(Charsets.UTF_8))
                        }
                        cv.clear()
                        cv.put(MediaStore.Downloads.IS_PENDING, 0)
                        contentResolver.update(uri, cv, null, null)
                        true
                    } else false
                } else {
                    val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    dir.mkdirs()
                    File(dir, fileName).writeText(content)
                    true
                }
                runOnUiThread {
                    if (saved) {
                        Toast.makeText(this, "다운로드 폴더에 저장됨:\n$fileName", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "저장 실패 — 다시 시도하세요.", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "로그 저장 실패: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun showDiagDialog() {
        val diag = PrefsManager.getDismissDiag(this)
        val tv = TextView(this).apply {
            text = diag
            textSize = 9f
            setTextColor(Color.parseColor("#CCCCCC"))
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val sv = ScrollView(this).apply { addView(tv) }
        AlertDialog.Builder(this)
            .setTitle("닫기 진단 — 접근성 트리 덤프")
            .setView(sv)
            .setPositiveButton("닫기", null)
            .show()
    }

    private fun showSavePresetDialog() {
        val nameInput = EditText(this).apply {
            hint = "프리셋 이름 (예: 공항 전용)"
            setHintTextColor(COLOR_TEXT_MUTED)
            setTextColor(COLOR_TEXT_PRI)
            textSize = 14f
            background = roundRect(COLOR_SURFACE, dp(8), COLOR_BORDER)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }

        if (keywords.isEmpty()) {
            Toast.makeText(this, "저장할 키워드가 없습니다", Toast.LENGTH_SHORT).show()
            return
        }

        AlertDialog.Builder(this)
            .setTitle("프리셋으로 저장")
            .setMessage("현재 키워드: ${keywords.joinToString(", ")}")
            .setView(nameInput)
            .setPositiveButton("저장") { _, _ ->
                val name = nameInput.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(this, "이름을 입력해주세요", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val existing = presets.indexOfFirst { it.name == name }
                val preset = KeywordPreset(name, keywords.toList())
                if (existing >= 0) {
                    presets[existing] = preset
                    presetAdapter.notifyItemChanged(existing)
                } else {
                    presets.add(preset)
                    presetAdapter.notifyItemInserted(presets.size - 1)
                }
                PrefsManager.savePresets(this, presets)
                Toast.makeText(this, "「${name}」 저장됨", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun showEditPresetDialog(pos: Int) {
        val p = presets[pos]
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        val nameInput = EditText(this).apply {
            setText(p.name)
            setTextColor(COLOR_TEXT_PRI)
            textSize = 14f
            background = roundRect(COLOR_SURFACE, dp(8), COLOR_BORDER)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            hint = "프리셋 이름"
            setHintTextColor(COLOR_TEXT_MUTED)
        }
        val kwInput = EditText(this).apply {
            setText(p.keywords.joinToString(", "))
            setTextColor(COLOR_TEXT_PRI)
            textSize = 14f
            background = roundRect(COLOR_SURFACE, dp(8), COLOR_BORDER)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            hint = "키워드 (쉼표 구분)"
            setHintTextColor(COLOR_TEXT_MUTED)
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10) }
        }

        container.addView(nameInput)
        container.addView(kwInput)

        AlertDialog.Builder(this)
            .setTitle("프리셋 수정")
            .setView(container)
            .setPositiveButton("저장") { _, _ ->
                val name = nameInput.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(this, "이름을 입력해주세요", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val kws = kwInput.text.toString().split(",").map { it.trim() }.filter { it.isNotEmpty() }
                presets[pos] = KeywordPreset(name, kws)
                presetAdapter.notifyItemChanged(pos)
                PrefsManager.savePresets(this, presets)
                Toast.makeText(this, "「${name}」 수정됨", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun showDeletePresetDialog(pos: Int) {
        val name = presets[pos].name
        AlertDialog.Builder(this)
            .setTitle("프리셋 삭제")
            .setMessage("「${name}」을 삭제할까요?\n이 작업은 되돌릴 수 없습니다.")
            .setPositiveButton("삭제") { _, _ ->
                presets.removeAt(pos)
                presetAdapter.notifyItemRemoved(pos)
                PrefsManager.savePresets(this, presets)
                Toast.makeText(this, "「${name}」 삭제됨", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    private fun space(dp: Int): View {
        return View(this).apply { layoutParams = LinearLayout.LayoutParams(MATCH, dp(dp)) }
    }

    private fun card(bgColor: Int, borderColor: Int): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = roundRect(bgColor, dp(12), borderColor)
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        }
    }

    private fun roundRect(color: Int, radius: Int, strokeColor: Int = Color.TRANSPARENT, strokeWidth: Int = 1): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (strokeColor != Color.TRANSPARENT) {
                setStroke(dp(strokeWidth), strokeColor)
            }
        }
    }

    private fun dividerV(color: Int): View {
        return View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(1), MATCH)
            setBackgroundColor(color)
        }
    }

    private fun dividerH(color: Int): View {
        return View(this).apply {
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(1))
            setBackgroundColor(color)
        }
    }
}
