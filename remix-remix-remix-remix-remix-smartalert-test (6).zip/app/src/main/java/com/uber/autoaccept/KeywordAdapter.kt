package com.uber.autoaccept

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class KeywordAdapter(
    private val items: MutableList<String>,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<KeywordAdapter.VH>() {

    inner class VH(val row: LinearLayout) : RecyclerView.ViewHolder(row) {
        val tvText: TextView
        val btnDel: Button
        init {
            val density = row.context.resources.displayMetrics.density
            val p8 = (8 * density).toInt()
            val p12 = (12 * density).toInt()
            val p6 = (6 * density).toInt()

            row.orientation = LinearLayout.HORIZONTAL
            row.setPadding(p12, p8, p8, p8)
            val bg = GradientDrawable()
            bg.setColor(Color.parseColor("#1e1e1e"))
            bg.cornerRadius = 8 * density
            row.background = bg

            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = (6 * density).toInt()
            row.layoutParams = lp

            tvText = TextView(row.context).apply {
                setTextColor(Color.WHITE)
                textSize = 14f
                typeface = Typeface.DEFAULT_BOLD
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            row.addView(tvText)

            btnDel = Button(row.context).apply {
                text = "삭제"
                setTextColor(Color.parseColor("#ff5252"))
                textSize = 12f
                val btnBg = GradientDrawable()
                btnBg.setColor(Color.parseColor("#2a1a1a"))
                btnBg.cornerRadius = 6 * density
                background = btnBg
                val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (36 * density).toInt())
                layoutParams = blp
            }
            row.addView(btnDel)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val row = LinearLayout(parent.context)
        return VH(row)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.tvText.text = item
        holder.btnDel.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                onDelete(pos)
            }
        }
    }

    override fun getItemCount(): Int = items.size
}
