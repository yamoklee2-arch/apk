package com.uber.autoaccept

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Path
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import rikka.shizuku.Shizuku
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

class AutoAcceptService : AccessibilityService() {

    companion object {
        private const val TAG = "UberAutoAccept"
        private const val UBER_DRIVER_PACKAGE = "com.ubercab.driver"
        private const val SIMULATOR_PACKAGE = "com.uber.autoaccept.simulator"
        private const val COOLDOWN_MS = 10000L

        private val ACCEPT_BUTTON_TEXTS = listOf("콜 수락", "수락", "수락하려면 탭", "수락하기", "Accept", "ACCEPT", "Tap to accept", "TAP TO ACCEPT")
        private val DISMISS_BUTTON_TEXTS = listOf("뒤로", "닫기", "Close", "close", "×", "✕", "X")

        @Volatile
        var isRunning: Boolean = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private val ocrExecutor = Executors.newSingleThreadExecutor()
    private val shizukuExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "ShizukuWorker")
    }

    private var ocrRecognizer: TextRecognizer? = null

    private var lastAcceptTime = 0L
    private var lastDismissTime = 0L
    private var lastCallCardTime = 0L
    private var callCardFirstSeenAt = 0L
    private var lastHumanDelay = 0L
    private var dismissAttempts = 0
    private var fastPollUntilMs = 0L

    private var pendingAccept = false
    private var pendingDismiss = false
    private var pendingAcceptVerify = false
    private var ocrCaptureInflight = false

    private var savedAcceptRect: Rect? = null
    private var lastForegroundPkg: String? = null
    private var sleepAlarmRingtone: Ringtone? = null

    private val xBtnTemplates = mutableListOf<TemplateData>()
    private val acceptBtnTemplates = mutableListOf<TemplateData>()

    private val acceptTimeoutRunnable = Runnable {
        if (pendingAccept) {
            Log.w(TAG, "수락 안전 타임아웃 → 상태 리셋")
            LogBuffer.diag(this, "ACCEPT-FAIL", "수락 타임아웃(5초) 리셋")
            pendingAccept = false
        }
    }

    private val dismissTimeoutRunnable = Runnable {
        if (pendingDismiss) {
            Log.w(TAG, "거절 안전 타임아웃 → 상태 리셋")
            LogBuffer.diag(this, "DISMISS-FAIL", "거절 타임아웃(3초) 리셋")
            pendingDismiss = false
            dismissAttempts = 0
        }
    }

    private val ocrCaptureWatchdog = Runnable {
        if (ocrCaptureInflight) {
            Log.w(TAG, "워치독: OCR 캡처 대기 3초 경과 → 리셋")
            ocrCaptureInflight = false
        }
    }

    private val pollRunnable = object : Runnable {
        override fun run() {
            if (!isRunning) return
            val active = PrefsManager.isActive(this@AutoAcceptService)
            if (active) {
                try {
                    val root = findUberRoot()
                    if (root != null) {
                        processWindow(root, null)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "폴링 중 오류: ${e.message}")
                }
            }
            val delay = if (System.currentTimeMillis() < fastPollUntilMs) 100L else 500L
            handler.postDelayed(this, delay)
        }
    }

    private val screenshotPollRunnable = object : Runnable {
        override fun run() {
            if (!isRunning) return
            if (PrefsManager.isActive(this@AutoAcceptService) && PrefsManager.isOcrPoll(this@AutoAcceptService)) {
                doScreenshotPoll()
            }
            val delay = if (PrefsManager.isAirportMode(this@AutoAcceptService)) {
                Random.nextLong(200L, 300L)
            } else {
                gaussianDelay(350L, 40L, 250L, 500L)
            }
            handler.postDelayed(this, delay)
        }
    }

    private val keepWarmRunnable = object : Runnable {
        override fun run() {
            if (!isRunning) return
            try {
                val dummyBm = Bitmap.createBitmap(32, 32, Bitmap.Config.ARGB_8888)
                val img = InputImage.fromBitmap(dummyBm, 0)
                getOcrRecognizer().process(img).addOnCompleteListener {
                    dummyBm.recycle()
                }
            } catch (_: Throwable) {
            }
            handler.postDelayed(this, 30000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isRunning = true
        loadXBtnTemplates()
        loadAcceptBtnTemplates()
        handler.post(pollRunnable)
        handler.post(screenshotPollRunnable)
        handler.post(keepWarmRunnable)
        LogBuffer.diag(this, "SERVICE", "접근성 서비스 연결됨 ✓")
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        try {
            ocrRecognizer?.close()
            ocrRecognizer = null
        } catch (_: Throwable) {
        }
        LogBuffer.diag(this, "SERVICE", "접근성 서비스 종료")
    }

    override fun onInterrupt() {
        Log.w(TAG, "접근성 서비스 인터럽트됨")
    }

    private fun getOcrRecognizer(): TextRecognizer {
        var rec = ocrRecognizer
        if (rec == null) {
            rec = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            ocrRecognizer = rec
        }
        return rec
    }

    private fun isSelfPackage(pkg: String?): Boolean {
        if (pkg == null) return false
        val myPkg = try { packageName } catch (_: Throwable) { "com.uber.autoaccept.test" }
        return pkg == myPkg ||
                pkg == "com.uber.autoaccept.test" ||
                pkg == "com.uber.autoaccept" ||
                (pkg.startsWith("com.uber.autoaccept.") && pkg != SIMULATOR_PACKAGE)
    }

    private fun isTargetPackage(pkg: String?): Boolean {
        if (pkg == null) return false
        if (isSelfPackage(pkg)) return false
        return pkg == UBER_DRIVER_PACKAGE || pkg == SIMULATOR_PACKAGE || pkg.contains("ubercab") || (pkg.contains("uber") && !pkg.contains("autoaccept"))
    }

    private fun updateForegroundApp(pkg: String?) {
        if (pkg != null && pkg != lastForegroundPkg) {
            lastForegroundPkg = pkg
        }
    }

    private var lastScanPkg: String? = null
    private var lastScanLogTime = 0L
    private var lastProcessScanLogTime = 0L
    private var lastNoCallPkg: String? = null
    private var lastNoCallReason: String? = null
    private var lastNoCallLogTime = 0L
    private var noCallRepeatCount = 0
    private var lastSelfSkipLogTime = 0L
    private var lastFalsePosLogTime = 0L
    private var cooldownLogged = false

    private fun logNoCall(pkg: String, reason: String) {
        val now = System.currentTimeMillis()
        if (pkg == lastNoCallPkg && reason == lastNoCallReason) {
            noCallRepeatCount++
            if (now - lastNoCallLogTime > 15000L) {
                lastNoCallLogTime = now
                LogBuffer.diag(this, "NO-CALL", "pkg=$pkg reason=$reason repeatSuppressed=$noCallRepeatCount")
                noCallRepeatCount = 0
            }
        } else {
            if (noCallRepeatCount > 0 && lastNoCallPkg != null) {
                LogBuffer.diag(this, "NO-CALL", "pkg=$lastNoCallPkg reason=$lastNoCallReason repeatSuppressed=$noCallRepeatCount")
            }
            lastNoCallPkg = pkg
            lastNoCallReason = reason
            lastNoCallLogTime = now
            noCallRepeatCount = 0
            LogBuffer.diag(this, "NO-CALL", "pkg=$pkg reason=$reason")
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !PrefsManager.isActive(this)) return

        val pkg = event.packageName?.toString()
        if (isSelfPackage(pkg)) {
            val now = System.currentTimeMillis()
            if (now - lastSelfSkipLogTime > 30000L) {
                lastSelfSkipLogTime = now
                LogBuffer.diag(this, "SCAN-SKIP", "pkg=$pkg reason=self_package")
            }
            return
        }

        updateForegroundApp(pkg)

        val now = System.currentTimeMillis()
        if (pkg != lastScanPkg || now - lastScanLogTime > 10000L) {
            lastScanPkg = pkg
            lastScanLogTime = now
            LogBuffer.diag(this, "SCAN", "Window/Event detected: pkg=$pkg, type=${event.eventType}")
        }

        if (!isTargetPackage(pkg)) {
            logNoCall(pkg ?: "unknown", "not_target_package")
            return
        }

        val root = try {
            rootInActiveWindow
        } catch (_: Throwable) {
            null
        } ?: return

        processWindow(root, event)
    }

    private fun findUberRoot(): AccessibilityNodeInfo? {
        try {
            val root = rootInActiveWindow
            if (root != null) {
                val pkg = root.packageName?.toString()
                if (isTargetPackage(pkg) && !isSelfPackage(pkg)) {
                    return root
                }
            }
            val winList = windows
            for (win in winList) {
                val winRoot = win.root
                if (winRoot != null) {
                    val pkg = winRoot.packageName?.toString()
                    if (isTargetPackage(pkg) && !isSelfPackage(pkg)) {
                        return winRoot
                    }
                }
            }
        } catch (_: Throwable) {
        }
        return null
    }

    fun processWindow(root: AccessibilityNodeInfo, event: AccessibilityEvent?) {
        val now = System.currentTimeMillis()
        val winPkg = root.packageName?.toString() ?: "unknown"

        if (isSelfPackage(winPkg) || isSelfPackage(lastForegroundPkg)) {
            if (now - lastSelfSkipLogTime > 30000L) {
                lastSelfSkipLogTime = now
                LogBuffer.diag(this, "SCAN-SKIP", "pkg=$winPkg reason=self_package")
            }
            return
        }
        if (!isTargetPackage(winPkg)) {
            return
        }

        val isUber = winPkg == UBER_DRIVER_PACKAGE || winPkg == SIMULATOR_PACKAGE
        val cardKey = "${winPkg}_$now"

        val inCooldown = now - lastAcceptTime < COOLDOWN_MS
        if (inCooldown || pendingAccept) {
            if (!cooldownLogged) {
                cooldownLogged = true
                LogBuffer.diag(this, "COOLDOWN", "START duration=${COOLDOWN_MS}ms")
            }
            return
        } else if (cooldownLogged) {
            cooldownLogged = false
            LogBuffer.diag(this, "COOLDOWN", "END")
        }

        if (now - lastProcessScanLogTime > 10000L) {
            lastProcessScanLogTime = now
            LogBuffer.diag(this, "SCAN", "Processing window: pkg=$winPkg, isUber=$isUber")
        }

        val fullText = collectAllText(root)
        val notifText = NotificationListener.lastCallText
        val combinedText = "$fullText $notifText"

        val acceptBtn = findAcceptButton(root)
        val isIndicator = findCardIndicator(root)
        val hasCard = isIndicator || acceptBtn != null || (notifText.isNotEmpty() && (notifText.contains("콜") || notifText.contains("배차") || notifText.contains("요청") || notifText.contains("Trip") || notifText.contains("Request")))

        if (hasCard) {
            val sampleText = combinedText.trim().replace("\n", " ").take(60)
            LogBuffer.diag(this, "CALL_CARD_CONTAINER_FOUND", "Call card container detected in pkg=$winPkg (rootPkg=${root.packageName})")
            LogBuffer.diag(this, "CARD", "Call card detected in pkg=$winPkg (indicator=$isIndicator, btn=${acceptBtn != null}, text='$sampleText')")
            if (callCardFirstSeenAt == 0L) {
                callCardFirstSeenAt = now
            }
            lastCallCardTime = now
            fastPollUntilMs = now + 4000L

            LogBuffer.diag(this, "STABILIZATION", "Card stabilized, proceeding with candidate evaluation (seen=${now - callCardFirstSeenAt}ms)")

            if (acceptBtn != null) {
                val btnRect = Rect()
                acceptBtn.getBoundsInScreen(btnRect)
                val labelText = acceptBtn.text?.toString() ?: acceptBtn.contentDescription?.toString() ?: "Button"
                LogBuffer.diag(this, "LABEL_MATCH", "Matched accept button label: '$labelText', bounds=$btnRect, viewId=${acceptBtn.viewIdResourceName}")
                val candDetails = "foregroundPkg=$lastForegroundPkg, rootPkg=${root.packageName}, windowPkg=$winPkg, className=${acceptBtn.className}, text='${acceptBtn.text}', desc='${acceptBtn.contentDescription}', viewId=${acceptBtn.viewIdResourceName}, bounds=$btnRect, cardKey=$cardKey, method=AccessibilityNode, isUber=$isUber"
                LogBuffer.diag(this, "ACCEPT-CANDIDATE", candDetails)
                if (!isUber) {
                    if (now - lastFalsePosLogTime > 5000L) {
                        lastFalsePosLogTime = now
                        LogBuffer.diag(this, "FALSE-POSITIVE-CANDIDATE", "Non-Uber screen detected as accept candidate: $candDetails")
                    }
                }
            } else {
                LogBuffer.diag(this, "ACCEPT-CANDIDATE", "Call card found without explicit node button; will rely on OCR/template (pkg=$winPkg, isUber=$isUber)")
            }

            val acceptAll = PrefsManager.isAcceptAll(this)
            val blacklistMode = PrefsManager.isBlacklistMode(this)
            val keywords = PrefsManager.getKeywords(this)
            val autoDismiss = PrefsManager.isAutoDismiss(this)

            var matchedKeyword: String? = null
            for (kw in keywords) {
                if (kw.isNotEmpty() && combinedText.contains(kw, ignoreCase = true)) {
                    matchedKeyword = kw
                    break
                }
            }

            val shouldAccept: Boolean = when {
                acceptAll -> true
                blacklistMode -> matchedKeyword == null
                else -> matchedKeyword != null
            }

            LogBuffer.diag(this, "ACCEPT-CONDITION", "Evaluation: acceptAll=$acceptAll, blacklist=$blacklistMode, matched='$matchedKeyword' -> shouldAccept=$shouldAccept, isUber=$isUber")

            if (shouldAccept) {
                if (acceptBtn != null) {
                    val rect = Rect()
                    acceptBtn.getBoundsInScreen(rect)
                    savedAcceptRect = rect
                    performAccept(acceptBtn, rect, matchedKeyword ?: if (acceptAll) "전체수락" else "조건일치", winPkg, cardKey)
                } else {
                    LogBuffer.diag(this, "ACCEPT-RETRY", "Accept candidate button missing in node tree, attempting OCR fallback")
                    if (PrefsManager.isOcrPoll(this)) {
                        doScreenshotPoll()
                    }
                }
            } else if (autoDismiss && (now - lastDismissTime > 1500L) && !pendingDismiss) {
                val dismissCandidateDetails = "foregroundPkg=$lastForegroundPkg, windowPkg=$winPkg, cardKey=$cardKey, method=AutoDismiss, isUber=$isUber"
                LogBuffer.diag(this, "DISMISS-CANDIDATE", dismissCandidateDetails)
                LogBuffer.diag(this, "DISMISS-CONDITION", "Auto-dismiss decided: autoDismiss=true, matched='$matchedKeyword', pkg=$winPkg")
                val coolSec = PrefsManager.getDismissCooldown(this)
                val delayMs = coolSec * 1000L
                LogBuffer.diag(this, "DISMISS-SCHEDULE", "Dismiss scheduled with delay=${delayMs}ms (${coolSec}s cooldown), cardKey=$cardKey")
                handler.postDelayed({
                    performDismissFresh(cardKey)
                }, delayMs)
            } else {
                LogBuffer.diag(this, "CANCEL-DECIDE", "Call ignored/cancelled by filter rules (shouldAccept=false, autoDismiss=$autoDismiss)")
            }
        } else {
            if (combinedText.isEmpty()) {
                logNoCall(winPkg, "no_call_card_detected")
            } else {
                logNoCall(winPkg, "no_card_indicator")
            }
            if (PrefsManager.isOcrPoll(this)) {
                doScreenshotPoll()
            }
        }
    }

    private fun performAccept(btn: AccessibilityNodeInfo, rect: Rect, reason: String, winPkg: String = "unknown", cardKey: String = "k_$lastAcceptTime") {
        val now = System.currentTimeMillis()
        if (now - lastAcceptTime < COOLDOWN_MS || pendingAccept) {
            LogBuffer.diag(this, "ACCEPT-FAIL", "performAccept skipped due to cooldown or pendingAccept (cooldown=${now - lastAcceptTime}ms, pending=$pendingAccept)")
            return
        }

        pendingAccept = true
        lastAcceptTime = now
        savedAcceptRect = rect

        val airport = PrefsManager.isAirportMode(this)
        val noDelay = PrefsManager.isAcceptNoDelay(this)
        val human = PrefsManager.isHumanMode(this)

        val delay = when {
            noDelay -> 0L
            airport -> Random.nextLong(200L, 300L)
            human -> gaussianDelay(PrefsManager.getMinDelay(this), 50L, PrefsManager.getMinDelay(this), PrefsManager.getMaxDelay(this))
            else -> PrefsManager.getMinDelay(this)
        }

        val modeStr = when {
            noDelay -> "NO_DELAY"
            airport -> "AIRPORT"
            human -> "HUMAN"
            else -> "DEFAULT"
        }

        lastHumanDelay = delay
        Log.d(TAG, "수락 예정: 이유=$reason, 딜레이=${delay}ms, 좌표=(${rect.centerX()}, ${rect.centerY()})")
        LogBuffer.diag(this, "ACCEPT-DELAY", "mode=$modeStr, delay=${delay}ms, minDelay=${PrefsManager.getMinDelay(this)}ms, maxDelay=${PrefsManager.getMaxDelay(this)}ms")
        LogBuffer.diag(this, "ACCEPT-SCHEDULE", "delay=${delay}ms, reason=$reason, coords=(${rect.centerX()}, ${rect.centerY()}), sourcePkg=$winPkg, cardKey=$cardKey")

        handler.postDelayed({
            executeAccept(btn, rect, winPkg, cardKey)
        }, delay)

        handler.postDelayed(acceptTimeoutRunnable, 5000L)
    }

    private fun executeAccept(btn: AccessibilityNodeInfo, rect: Rect, winPkg: String = "unknown", cardKey: String = "k_$lastAcceptTime") {
        var clicked = false
        var clickMethod = "NONE"
        val cx = rect.centerX()
        val cy = rect.centerY()

        showTapIndicator(cx, cy, true)
        LogBuffer.diag(this, "ACCEPT-TOUCH", "Touch starting: coords=($cx, $cy), bounds=$rect, targetText='${btn.text}', cardKey=$cardKey")

        val shizOk = shizukuTap(cx, cy)
        LogBuffer.diag(this, "ACCEPT-SHIZUKU", "Shizuku tap result=$shizOk, coords=($cx, $cy)")

        if (shizOk) {
            clicked = true
            clickMethod = "ShizukuTap"
            Log.d(TAG, "Shizuku 터치 수락 성공")
        } else {
            var actionOk = false
            try {
                if (btn.isClickable && btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    actionOk = true
                    clicked = true
                    clickMethod = "NodeClick"
                } else {
                    var parent = btn.parent
                    while (parent != null) {
                        if (parent.isClickable && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                            actionOk = true
                            clicked = true
                            clickMethod = "ParentNodeClick"
                            break
                        }
                        parent = parent.parent
                    }
                }
            } catch (e: Throwable) {
                LogBuffer.diag(this, "ACCEPT-FAIL", "Node action exception: ${e.message}")
            }
            LogBuffer.diag(this, "ACCEPT-ACTION", "Node click result=$actionOk, method=$clickMethod")

            if (!clicked) {
                val gestureBuilder = GestureDescription.Builder()
                val path = Path().apply {
                    moveTo(cx.toFloat(), cy.toFloat())
                }
                gestureBuilder.addStroke(GestureDescription.StrokeDescription(path, 0, 50))
                val dispatched = dispatchGesture(gestureBuilder.build(), null, null)
                clicked = dispatched
                clickMethod = if (dispatched) "dispatchGesture" else "GestureFailed"
                LogBuffer.diag(this, "ACCEPT-GESTURE", "dispatchGesture result=$dispatched, coords=($cx, $cy)")
            }
        }

        LogBuffer.diag(this, "ACCEPT-TOUCH", "Touch performed: method=$clickMethod, coords=($cx, $cy), success=$clicked, cardKey=$cardKey")

        val nextCount = PrefsManager.getAcceptScheduled(this) + 1
        LogBuffer.diag(this, "ACCEPT-COUNT", "source=executeAccept, reason=accept_dispatched, cardKey=$cardKey, winPkg=$winPkg, btn='${btn.text}', bounds=$rect, nextCount=$nextCount")
        PrefsManager.incrementAcceptScheduled(this, source = "executeAccept")

        PrefsManager.saveLastAcceptRect(this, rect)
        sendBroadcast(Intent("com.uber.autoaccept.ACCEPT_EVENT"))

        vibrate()
        triggerSleepAlarm()

        if (PrefsManager.isAcceptScreenshot(this)) {
            takeScreenshotAndSave()
        }

        pendingAccept = false
        handler.removeCallbacks(acceptTimeoutRunnable)

        // Verify accept after short delay (Separation of TOUCH and SUCCESS)
        handler.postDelayed({
            val verifyRoot = findUberRoot()
            val stillHasCard = verifyRoot != null && (findCardIndicator(verifyRoot) || findAcceptButton(verifyRoot) != null)
            if (!stillHasCard) {
                LogBuffer.diag(this, "ACCEPT-VERIFY", "Card disappeared successfully (Accept confirmed), cardKey=$cardKey")
                LogBuffer.diag(this, "ACCEPT-SUCCESS", "Accept operation verified SUCCESS on screen, cardKey=$cardKey")
            } else {
                LogBuffer.diag(this, "ACCEPT-VERIFY", "Card still visible -> Scheduling retry, cardKey=$cardKey")
                LogBuffer.diag(this, "ACCEPT-RETRY", "Retrying accept tap at ($cx, $cy), cardKey=$cardKey")
                scheduleAcceptRetap(rect, 300L, cardKey)
            }
        }, 500L)
    }

    fun performDismissFresh(cardKey: String = "k_$lastDismissTime") {
        val now = System.currentTimeMillis()
        if (now - lastDismissTime < 1500L || pendingDismiss) {
            LogBuffer.diag(this, "DISMISS-FAIL", "performDismissFresh skipped due to cooldown or pendingDismiss")
            return
        }

        pendingDismiss = true
        lastDismissTime = now
        dismissAttempts++

        val root = findUberRoot()
        val dismissBtn = if (root != null) findDismissButton(root, null) else null

        if (dismissBtn != null) {
            val r = Rect()
            dismissBtn.getBoundsInScreen(r)
            val cx = r.centerX()
            val cy = r.centerY()
            showTapIndicator(cx, cy, false)

            val isXBtn = dismissBtn.text?.toString()?.contains("X", ignoreCase = true) == true ||
                    dismissBtn.text?.toString()?.contains("✕", ignoreCase = true) == true ||
                    dismissBtn.text?.toString()?.contains("닫기", ignoreCase = true) == true ||
                    dismissBtn.contentDescription?.toString()?.contains("닫기", ignoreCase = true) == true ||
                    dismissBtn.contentDescription?.toString()?.contains("close", ignoreCase = true) == true

            val tagPrefix = if (isXBtn) "CLOSE" else "DISMISS"

            LogBuffer.diag(this, "${tagPrefix}-CANDIDATE", "Node found: text='${dismissBtn.text}', desc='${dismissBtn.contentDescription}', bounds=$r, cardKey=$cardKey")
            LogBuffer.diag(this, "${tagPrefix}-CONDITION", "Dismiss/Close condition verified for attempt $dismissAttempts")
            LogBuffer.diag(this, "${tagPrefix}-TOUCH", "Dismiss node touch at ($cx, $cy), text='${dismissBtn.text}', cardKey=$cardKey")

            var touchOk = shizukuTap(cx, cy)
            LogBuffer.diag(this, "${tagPrefix}-SHIZUKU", "Shizuku tap result=$touchOk at ($cx, $cy)")

            if (!touchOk) {
                val actionOk = dismissBtn.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                LogBuffer.diag(this, "${tagPrefix}-ACTION", "ACTION_CLICK result=$actionOk, node='${dismissBtn.text}'")
                if (!actionOk) {
                    val path = Path().apply { moveTo(cx.toFloat(), cy.toFloat()) }
                    touchOk = dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 50)).build(), null, null)
                    LogBuffer.diag(this, "${tagPrefix}-GESTURE", "dispatchGesture result=$touchOk at ($cx, $cy)")
                } else {
                    touchOk = true
                }
            }
            recordDismissSuccess(source = "performDismissFresh_Node", isClose = isXBtn, cardKey = cardKey)
        } else {
            val dm = resources.displayMetrics
            val tapX = (dm.widthPixels * 0.90f).toInt()
            val tapY = (dm.heightPixels * 0.15f).toInt()
            showTapIndicator(tapX, tapY, false)

            LogBuffer.diag(this, "CLOSE-CANDIDATE", "Fallback default close coordinate candidate at ($tapX, $tapY), cardKey=$cardKey")
            LogBuffer.diag(this, "CLOSE-CONDITION", "Fallback coordinate close condition triggered")
            LogBuffer.diag(this, "CLOSE-TOUCH", "Dismiss/Close default coordinate touch at ($tapX, $tapY)")

            val shizOk = shizukuTap(tapX, tapY)
            LogBuffer.diag(this, "CLOSE-SHIZUKU", "Shizuku fallback tap result=$shizOk at ($tapX, $tapY)")

            if (!shizOk) {
                val path = Path().apply { moveTo(tapX.toFloat(), tapY.toFloat()) }
                val gestOk = dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 50)).build(), null, null)
                LogBuffer.diag(this, "CLOSE-GESTURE", "dispatchGesture fallback tap result=$gestOk at ($tapX, $tapY)")
            }
            recordDismissSuccess(source = "performDismissFresh_Coord", isClose = true, cardKey = cardKey)
        }

        handler.postDelayed({
            pendingDismiss = false
            val verifyRoot = findUberRoot()
            val cardGone = verifyRoot == null || (!findCardIndicator(verifyRoot) && findDismissButton(verifyRoot, null) == null)
            if (cardGone) {
                LogBuffer.diag(this, "DISMISS-VERIFY", "Dismiss verified: call card closed, cardKey=$cardKey")
                LogBuffer.diag(this, "DISMISS-SUCCESS", "Dismiss operation confirmed SUCCESS on screen, cardKey=$cardKey")
                LogBuffer.diag(this, "CLOSE-VERIFY", "Close verified: call card closed, cardKey=$cardKey")
                LogBuffer.diag(this, "CLOSE-SUCCESS", "Close operation confirmed SUCCESS on screen, cardKey=$cardKey")
            } else {
                LogBuffer.diag(this, "DISMISS-VERIFY", "Card still visible after dismiss attempt $dismissAttempts, cardKey=$cardKey")
                LogBuffer.diag(this, "CLOSE-VERIFY", "Card still visible after close attempt $dismissAttempts, cardKey=$cardKey")
                if (dismissAttempts < 3) {
                    LogBuffer.diag(this, "DISMISS-RETRY", "Retrying dismiss attempt ${dismissAttempts + 1}, cardKey=$cardKey")
                    LogBuffer.diag(this, "CLOSE-RETRY", "Retrying close attempt ${dismissAttempts + 1}, cardKey=$cardKey")
                    performDismissFresh(cardKey)
                } else {
                    LogBuffer.diag(this, "DISMISS-FAIL", "Dismiss failed after max attempts, cardKey=$cardKey")
                    LogBuffer.diag(this, "CLOSE-FAIL", "Close failed after max attempts, cardKey=$cardKey")
                }
            }
        }, 1000L)
    }

    private fun recordDismissSuccess(source: String = "performDismissFresh", isClose: Boolean = false, cardKey: String = "") {
        val tagPrefix = if (isClose) "CLOSE" else "DISMISS"
        val nextCount = PrefsManager.getDismissExecuted(this) + 1
        LogBuffer.diag(this, "${tagPrefix}-COUNT", "source=$source, reason=dismiss_touch_completed, cardKey=$cardKey, totalCount=$nextCount")
        PrefsManager.incrementDismissExecuted(this, source = source)
        LogBuffer.diag(this, "${tagPrefix}-TOUCH", "콜 거절/닫기 터치 완료 (총 거절수: $nextCount)")
        sendBroadcast(Intent("com.uber.autoaccept.ACCEPT_EVENT"))
    }

    fun shizukuTap(x: Int, y: Int): Boolean {
        return try {
            if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != 0) {
                return false
            }
            val cmd = arrayOf("input", "touchscreen", "tap", x.toString(), y.toString())
            val method = Shizuku::class.java.methods.firstOrNull { it.name == "newProcess" }
            if (method != null) {
                method.isAccessible = true
                val process = method.invoke(null, cmd, null, null)
                val waitFor = process?.javaClass?.getMethod("waitFor")
                val exit = waitFor?.invoke(process) as? Int ?: -1
                exit == 0
            } else {
                false
            }
        } catch (e: Exception) {
            Log.w(TAG, "Shizuku tap 실패: ${e.message}")
            false
        }
    }

    private fun showTapIndicator(x: Int, y: Int, isAccept: Boolean) {
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val size = (40 * resources.displayMetrics.density).toInt()
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (isAccept) Color.parseColor("#8006C167") else Color.parseColor("#80E11900"))
                    setStroke((2 * resources.displayMetrics.density).toInt(), Color.WHITE)
                }
            }
            val lp = WindowManager.LayoutParams(
                size, size,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                this.x = x - size / 2
                this.y = y - size / 2
            }
            wm.addView(dot, lp)
            handler.postDelayed({
                try {
                    wm.removeView(dot)
                } catch (_: Throwable) {
                }
            }, 600L)
        } catch (_: Throwable) {
        }
    }

    fun doScreenshotPoll() {
        if (ocrCaptureInflight) return
        if (isSelfPackage(lastForegroundPkg)) return
        ocrCaptureInflight = true
        handler.postDelayed(ocrCaptureWatchdog, 3000L)

        takeScreenshot(0, ContextCompat.getMainExecutor(this), object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                ocrCaptureInflight = false
                handler.removeCallbacks(ocrCaptureWatchdog)
                val hwBm = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace) ?: return
                val softBm = hwBm.copy(Bitmap.Config.ARGB_8888, false)
                hwBm.recycle()

                val image = InputImage.fromBitmap(softBm, 0)
                getOcrRecognizer().process(image)
                    .addOnSuccessListener { text ->
                        processOcrText(text, softBm)
                    }
                    .addOnFailureListener {
                        softBm.recycle()
                    }
            }

            override fun onFailure(errorCode: Int) {
                ocrCaptureInflight = false
                handler.removeCallbacks(ocrCaptureWatchdog)
            }
        })
    }

    private fun processOcrText(text: Text, bitmap: Bitmap) {
        try {
            val winPkg = lastForegroundPkg ?: "unknown"
            if (isSelfPackage(winPkg) || !isTargetPackage(winPkg)) {
                return
            }

            val ocrStr = text.text
            val fullText = ocrStr.replace("\\s+".toRegex(), " ")
            val now = System.currentTimeMillis()
            val isUber = winPkg == UBER_DRIVER_PACKAGE || winPkg == SIMULATOR_PACKAGE
            val cardKey = "ocr_${winPkg}_$now"

            if (now - lastAcceptTime < COOLDOWN_MS || pendingAccept) {
                bitmap.recycle()
                return
            }

            val acceptAll = PrefsManager.isAcceptAll(this)
            val blacklistMode = PrefsManager.isBlacklistMode(this)
            val keywords = PrefsManager.getKeywords(this)

            var hasAcceptKeyword = false
            for (btnText in ACCEPT_BUTTON_TEXTS) {
                if (fullText.contains(btnText, ignoreCase = true)) {
                    hasAcceptKeyword = true
                    break
                }
            }

            if (!hasAcceptKeyword) {
                bitmap.recycle()
                return
            }

            var matchedKw: String? = null
            for (kw in keywords) {
                if (kw.isNotEmpty() && fullText.contains(kw, ignoreCase = true)) {
                    matchedKw = kw
                    break
                }
            }

            val shouldAccept = when {
                acceptAll -> true
                blacklistMode -> matchedKw == null
                else -> matchedKw != null
            }

            LogBuffer.diag(this, "ACCEPT-CONDITION", "OCR Evaluation: acceptAll=$acceptAll, blacklist=$blacklistMode, matched='$matchedKw' -> shouldAccept=$shouldAccept, isUber=$isUber")

            if (shouldAccept) {
                var acceptPos: Pair<Int, Int>? = null
                for (block in text.textBlocks) {
                    for (line in block.lines) {
                        for (element in line.elements) {
                            if (ACCEPT_BUTTON_TEXTS.any { element.text.contains(it, ignoreCase = true) }) {
                                val box = element.boundingBox
                                if (box != null) {
                                    acceptPos = Pair(box.centerX(), box.centerY())
                                    break
                                }
                            }
                        }
                        if (acceptPos != null) break
                    }
                    if (acceptPos != null) break
                }

                if (acceptPos == null) {
                    acceptPos = findAcceptButtonByTemplate(bitmap)
                }

                if (acceptPos != null) {
                    val rect = Rect(acceptPos.first - 50, acceptPos.second - 20, acceptPos.first + 50, acceptPos.second + 20)
                    savedAcceptRect = rect
                    val candDetails = "foregroundPkg=$lastForegroundPkg, windowPkg=$winPkg, target=(${acceptPos.first}, ${acceptPos.second}), bounds=$rect, cardKey=$cardKey, method=OCR/Template, isUber=$isUber"
                    LogBuffer.diag(this, "ACCEPT-CANDIDATE", candDetails)
                    if (!isUber) {
                        LogBuffer.diag(this, "FALSE-POSITIVE-CANDIDATE", "Non-Uber screen detected as OCR candidate: $candDetails")
                    }
                    executeAcceptAtPos(acceptPos.first, acceptPos.second, rect, "OCR/Template", cardKey)
                }
            }
        } finally {
            bitmap.recycle()
        }
    }

    private fun executeAcceptAtPos(x: Int, y: Int, rect: Rect, source: String = "Coordinate", cardKey: String = "pos_$lastAcceptTime") {
        val now = System.currentTimeMillis()
        if (now - lastAcceptTime < COOLDOWN_MS || pendingAccept) {
            LogBuffer.diag(this, "ACCEPT-FAIL", "executeAcceptAtPos skipped due to cooldown or pendingAccept")
            return
        }

        pendingAccept = true
        lastAcceptTime = now

        val airport = PrefsManager.isAirportMode(this)
        val human = PrefsManager.isHumanMode(this)
        val noDelay = PrefsManager.isAcceptNoDelay(this)

        val delay = when {
            noDelay -> 0L
            airport -> Random.nextLong(200L, 300L)
            human -> gaussianDelay(PrefsManager.getMinDelay(this), 50L, PrefsManager.getMinDelay(this), PrefsManager.getMaxDelay(this))
            else -> PrefsManager.getMinDelay(this)
        }

        val modeStr = when {
            noDelay -> "NO_DELAY"
            airport -> "AIRPORT"
            human -> "HUMAN"
            else -> "DEFAULT"
        }

        LogBuffer.diag(this, "ACCEPT-DELAY", "mode=$modeStr, delay=${delay}ms, minDelay=${PrefsManager.getMinDelay(this)}ms, maxDelay=${PrefsManager.getMaxDelay(this)}ms")
        LogBuffer.diag(this, "ACCEPT-SCHEDULE", "delay=${delay}ms, reason=$source, coords=($x, $y), cardKey=$cardKey")

        handler.postDelayed({
            showTapIndicator(x, y, true)
            LogBuffer.diag(this, "ACCEPT-TOUCH", "Touch starting ($source): coords=($x, $y), cardKey=$cardKey")

            var touchMethod = "ShizukuTap"
            val shizOk = shizukuTap(x, y)
            LogBuffer.diag(this, "ACCEPT-SHIZUKU", "Shizuku tap result=$shizOk at ($x, $y)")

            if (!shizOk) {
                val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
                val gestureOk = dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 50)).build(), null, null)
                touchMethod = if (gestureOk) "dispatchGesture" else "GestureFailed"
                LogBuffer.diag(this, "ACCEPT-GESTURE", "dispatchGesture result=$gestureOk at ($x, $y)")
            }
            LogBuffer.diag(this, "ACCEPT-TOUCH", "Touch performed ($source): method=$touchMethod, coords=($x, $y), cardKey=$cardKey")

            val newCount = PrefsManager.getAcceptScheduled(this) + 1
            LogBuffer.diag(this, "ACCEPT-COUNT", "source=executeAcceptAtPos, reason=pos_accept_dispatched, cardKey=$cardKey, coords=($x, $y), totalCount=$newCount")
            PrefsManager.incrementAcceptScheduled(this, source = "executeAcceptAtPos")

            PrefsManager.saveLastAcceptRect(this, rect)
            sendBroadcast(Intent("com.uber.autoaccept.ACCEPT_EVENT"))
            vibrate()
            triggerSleepAlarm()
            pendingAccept = false

            // Verification (Separation of TOUCH and SUCCESS)
            handler.postDelayed({
                val verifyRoot = findUberRoot()
                val stillHasCard = verifyRoot != null && (findCardIndicator(verifyRoot) || findAcceptButton(verifyRoot) != null)
                if (!stillHasCard) {
                    LogBuffer.diag(this, "ACCEPT-VERIFY", "Card disappeared after $source accept, cardKey=$cardKey")
                    LogBuffer.diag(this, "ACCEPT-SUCCESS", "Accept operation verified SUCCESS on screen ($source), cardKey=$cardKey")
                } else {
                    LogBuffer.diag(this, "ACCEPT-VERIFY", "Card still visible after $source accept, cardKey=$cardKey")
                    LogBuffer.diag(this, "ACCEPT-RETRY", "Retrying accept at ($x, $y), cardKey=$cardKey")
                }
            }, 500L)
        }, delay)
    }

    private fun scheduleAcceptRetap(rect: Rect?, delayMs: Long, cardKey: String = "") {
        if (rect == null) return
        LogBuffer.diag(this, "ACCEPT-RETRY", "Scheduling retap after ${delayMs}ms at (${rect.centerX()}, ${rect.centerY()}), cardKey=$cardKey")
        handler.postDelayed({
            executeAcceptAtPos(rect.centerX(), rect.centerY(), rect, "Retap", cardKey)
        }, delayMs)
    }

    private fun findAcceptButton(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (btnText in ACCEPT_BUTTON_TEXTS) {
            val list = root.findAccessibilityNodeInfosByText(btnText)
            if (!list.isNullOrEmpty()) {
                for (node in list) {
                    val pick = pickAcceptNode(node)
                    if (pick != null) return pick
                }
            }
        }

        // Deep node tree traversal fallback for complex / compound / custom views
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        val dm = resources.displayMetrics
        val screenH = dm.heightPixels
        val tempRect = Rect()

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()

            val txt = node.text?.toString()?.lowercase() ?: ""
            val desc = node.contentDescription?.toString()?.lowercase() ?: ""
            val viewId = node.viewIdResourceName?.lowercase() ?: ""

            val matchesAcceptText = txt.contains("수락") || txt.contains("accept") || txt.contains("tap to accept")
            val matchesAcceptDesc = desc.contains("수락") || desc.contains("accept") || desc.contains("tap to accept")
            val matchesAcceptId = viewId.contains("accept") || viewId.contains("trip_action") || viewId.contains("primary_button")

            if (matchesAcceptText || matchesAcceptDesc || matchesAcceptId) {
                node.getBoundsInScreen(tempRect)
                if (tempRect.width() > 50 && tempRect.height() > 30) {
                    val pick = pickAcceptNode(node)
                    if (pick != null) return pick
                }
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                if (child != null) {
                    queue.add(child)
                }
            }
        }

        return null
    }

    private fun pickAcceptNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var curr: AccessibilityNodeInfo? = node
        while (curr != null) {
            if (curr.isClickable && curr.isEnabled) return curr
            curr = curr.parent
        }
        return if (node.isClickable) node else null
    }

    private fun findDismissButton(root: AccessibilityNodeInfo, acceptRect: Rect?): AccessibilityNodeInfo? {
        for (text in DISMISS_BUTTON_TEXTS) {
            val nodes = root.findAccessibilityNodeInfosByText(text)
            if (!nodes.isNullOrEmpty()) {
                for (n in nodes) {
                    if (n.isClickable) return n
                    val p = n.parent
                    if (p != null && p.isClickable) return p
                }
            }
        }

        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            val txt = node.text?.toString()?.lowercase() ?: ""
            val desc = node.contentDescription?.toString()?.lowercase() ?: ""
            val viewId = node.viewIdResourceName?.lowercase() ?: ""

            val matchesClose = txt == "x" || txt == "✕" || txt == "×" || txt.contains("닫기") || txt.contains("거절") ||
                    desc.contains("닫기") || desc.contains("close") || desc.contains("거절") ||
                    viewId.contains("close") || viewId.contains("dismiss") || viewId.contains("cancel")

            if (matchesClose) {
                if (node.isClickable) return node
                val p = node.parent
                if (p != null && p.isClickable) return p
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                if (child != null) {
                    queue.add(child)
                }
            }
        }

        return null
    }

    private fun findCardIndicator(root: AccessibilityNodeInfo): Boolean {
        val fullText = collectAllText(root)
        if (fullText.isEmpty()) return false
        val keywords = listOf(
            "수락", "거절", "요금", "거리", "분", "km", "콜", "운행", "탑승", "배차",
            "원", "₩", "새 요청", "요청", "승객", "도착", "Trip", "Request", "Accept",
            "Fare", "Min", "Dropoff", "Pickup", "Tap to accept"
        )
        return keywords.any { fullText.contains(it, ignoreCase = true) }
    }

    private fun collectAllText(node: AccessibilityNodeInfo?): String {
        if (node == null) return ""
        val sb = StringBuilder()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(node)
        while (queue.isNotEmpty()) {
            val curr = queue.removeFirst()
            val txt = curr.text
            if (!txt.isNullOrEmpty()) {
                sb.append(txt).append(" ")
            }
            val desc = curr.contentDescription
            if (!desc.isNullOrEmpty()) {
                sb.append(desc).append(" ")
            }
            for (i in 0 until curr.childCount) {
                val child = curr.getChild(i)
                if (child != null) {
                    queue.add(child)
                }
            }
        }
        return sb.toString()
    }

    private fun loadXBtnTemplates() {
        val ids = listOf(
            R.raw.xbtn_template1, R.raw.xbtn_template2, R.raw.xbtn_template3,
            R.raw.xbtn_template4, R.raw.xbtn_template5
        )
        for (id in ids) {
            try {
                val bmp = BitmapFactory.decodeResource(resources, id) ?: continue
                val w = bmp.width
                val h = bmp.height
                val pixels = IntArray(w * h)
                bmp.getPixels(pixels, 0, w, 0, 0, w, h)
                xBtnTemplates.add(TemplateData(pixels, w, h))
                bmp.recycle()
            } catch (_: Throwable) {
            }
        }
    }

    private fun loadAcceptBtnTemplates() {
        val ids = listOf(
            R.raw.accept_template_light, R.raw.accept_template_dark,
            R.raw.accept_template_dark1, R.raw.accept_template_dark2,
            R.raw.accept_template_fold5_dark
        )
        for (id in ids) {
            try {
                val bmp = BitmapFactory.decodeResource(resources, id) ?: continue
                val w = bmp.width
                val h = bmp.height
                val pixels = IntArray(w * h)
                bmp.getPixels(pixels, 0, w, 0, 0, w, h)
                acceptBtnTemplates.add(TemplateData(pixels, w, h))
                bmp.recycle()
            } catch (_: Throwable) {
            }
        }
    }

    private fun computeSADArray(
        src: IntArray, srcW: Int, startX: Int, startY: Int,
        tmpl: IntArray, tw: Int, th: Int
    ): Long {
        var sad = 0L
        for (row in 0 until th) {
            val srcRowOff = (startY + row) * srcW + startX
            val tmplRowOff = row * tw
            for (col in 0 until tw) {
                val c1 = src[srcRowOff + col]
                val c2 = tmpl[tmplRowOff + col]
                val r = abs(((c1 shr 16) and 0xFF) - ((c2 shr 16) and 0xFF))
                val g = abs(((c1 shr 8) and 0xFF) - ((c2 shr 8) and 0xFF))
                val b = abs((c1 and 0xFF) - (c2 and 0xFF))
                sad += (r + g + b)
            }
        }
        return sad
    }

    fun findAcceptButtonByTemplate(bitmap: Bitmap): Pair<Int, Int>? {
        if (acceptBtnTemplates.isEmpty()) return null
        val bw = bitmap.width
        val bh = bitmap.height
        val pixels = IntArray(bw * bh)
        bitmap.getPixels(pixels, 0, bw, 0, 0, bw, bh)

        var bestScore = Long.MAX_VALUE
        var bestX = -1
        var bestY = -1

        for (tmpl in acceptBtnTemplates) {
            val tw = tmpl.width
            val th = tmpl.height
            if (tw >= bw || th >= bh) continue

            val startSearchY = (bh * 0.40f).toInt()
            val endSearchY = bh - th

            for (y in startSearchY until endSearchY step 8) {
                for (x in 0 until (bw - tw) step 8) {
                    val sad = computeSADArray(pixels, bw, x, y, tmpl.pixels, tw, th)
                    if (sad < bestScore) {
                        bestScore = sad
                        bestX = x + tw / 2
                        bestY = y + th / 2
                    }
                }
            }
        }

        return if (bestX != -1 && bestY != -1) Pair(bestX, bestY) else null
    }

    private fun takeScreenshotAndSave() {
        takeScreenshot(0, ContextCompat.getMainExecutor(this), object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                val hwBm = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace) ?: return
                val softBm = hwBm.copy(Bitmap.Config.ARGB_8888, false)
                hwBm.recycle()
                saveAcceptScreenshotToGallery(softBm)
            }
            override fun onFailure(errorCode: Int) {}
        })
    }

    fun saveAcceptScreenshotToGallery(bitmap: Bitmap) {
        val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
        val name = "UberAccept_${sdf.format(Date())}.png"
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/스마트알림")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    }
                }
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "스마트알림")
                if (!dir.exists()) dir.mkdirs()
                val file = File(dir, name)
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "스크린샷 저장 실패: ${e.message}")
        } finally {
            bitmap.recycle()
        }
    }

    fun gaussianDelay(mean: Long, stdDev: Long, minVal: Long, maxVal: Long): Long {
        val u1 = Random.nextDouble().coerceAtLeast(1e-7)
        val u2 = Random.nextDouble()
        val z0 = sqrt(-2.0 * kotlin.math.ln(u1)) * kotlin.math.cos(2.0 * Math.PI * u2)
        val result = (mean + z0 * stdDev).toLong()
        return result.coerceIn(minVal, maxVal)
    }

    fun vibrate() {
        if (!PrefsManager.isVibration(this)) return
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(150)
            }
        } catch (_: Throwable) {
        }
    }

    fun triggerSleepAlarm() {
        if (!PrefsManager.isSleepAlarm(this)) return
        try {
            val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val ringtone = RingtoneManager.getRingtone(this, alarmUri)
            ringtone?.play()
            sleepAlarmRingtone = ringtone
            handler.postDelayed({
                try {
                    ringtone?.stop()
                } catch (_: Throwable) {
                }
            }, 3000L)
        } catch (_: Throwable) {
        }
    }
}
