package com.uber.autoaccept

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import rikka.shizuku.Shizuku
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class AutoAcceptService : AccessibilityService() {

    companion object {
        private const val TAG = "AutoAcceptService"
        const val OCR_TOP_RATIO = 0.50f
        const val ACTION_COOLDOWN_MS = 2000L
        val ACCEPT_BUTTON_TEXTS = listOf("콜 수락", "수락", "Accept", "ACCEPT")
        val DISMISS_BUTTON_TEXTS = listOf("뒤로", "닫기", "Close", "close", "×", "✕", "X")
        val AIRPORT_KEYWORDS = listOf("공항", "인천공항", "김포공항", "Airport", "제1여객터미널", "제2여객터미널", "T1", "T2")

        var isRunning: Boolean = false
            private set
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val pollHandler = Handler(Looper.getMainLooper())
    private val screenshotHandler = Handler(Looper.getMainLooper())
    private val watchdogHandler = Handler(Looper.getMainLooper())
    private val ocrLoopHandler = Handler(Looper.getMainLooper())

    private val random = Random()
    private val shizukuExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    private val ocrRecognizer: TextRecognizer by lazy {
        TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
    }

    data class NamedTemplate(val name: String, val bitmap: Bitmap)
    private val acceptNamedTemplates = mutableListOf<NamedTemplate>()
    private val dismissNamedTemplates = mutableListOf<NamedTemplate>()

    private var lastForegroundPackage: String = ""
    private var lastActionTime: Long = 0L
    private var lastDismissTime: Long = 0L
    private var lastAcceptTime: Long = 0L
    private var isAcceptingInProgress: Boolean = false
    private var isDismissingInProgress: Boolean = false
    private var lastProcessedCardBounds: Rect? = null

    // OCR Continuous Loop State
    private var isOcrLoopRunning: Boolean = false
    private var isOcrScanInProgress: Boolean = false
    private var lastOcrResult: String? = null
    private var scanStartedCount: Long = 0L
    private var captureSuccessCount: Long = 0L
    private var ocrRequestedCount: Long = 0L
    private var ocrCompletedCount: Long = 0L
    private var textDetectedCount: Long = 0L
    private var emptyResultCount: Long = 0L
    private var errorCount: Long = 0L
    private var lastOcrHeartbeatTime: Long = 0L

    private val prefChangeListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "is_active") {
            mainHandler.post {
                checkAndSyncOcrLoop()
            }
        }
    }

    private val keepWarmRunnable = object : Runnable {
        override fun run() {
            try {
                if (PrefsManager.isActive(this@AutoAcceptService)) {
                    LogBuffer.log(this@AutoAcceptService, "KeepWarm", "Service heartbeat OK")
                    checkAndSyncOcrLoop()
                }
            } catch (_: Exception) {}
            pollHandler.postDelayed(this, 15000L)
        }
    }

    private val screenshotPollRunnable = object : Runnable {
        override fun run() {
            screenshotHandler.postDelayed(this, 5000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isRunning = true
        LogBuffer.log(this, "Service", "접근성 서비스 연결됨")
        loadAcceptBtnTemplates()
        loadXBtnTemplates()
        try {
            getSharedPreferences("auto_accept_prefs", Context.MODE_PRIVATE)
                .registerOnSharedPreferenceChangeListener(prefChangeListener)
        } catch (_: Exception) {}
        pollHandler.post(keepWarmRunnable)
        checkAndSyncOcrLoop()
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        LogBuffer.log(this, "Service", "접근성 서비스 종료됨")
        stopOcrLoop()
        try {
            getSharedPreferences("auto_accept_prefs", Context.MODE_PRIVATE)
                .unregisterOnSharedPreferenceChangeListener(prefChangeListener)
        } catch (_: Exception) {}
        SleepAlarmManager.stopAlarm()
        pollHandler.removeCallbacksAndMessages(null)
        screenshotHandler.removeCallbacksAndMessages(null)
        ocrLoopHandler.removeCallbacksAndMessages(null)
        mainHandler.removeCallbacksAndMessages(null)
        watchdogHandler.removeCallbacksAndMessages(null)
    }

    override fun onInterrupt() {
        LogBuffer.log(this, "Service", "접근성 서비스 중단됨")
        stopOcrLoop()
    }

    private fun checkAndSyncOcrLoop() {
        val active = PrefsManager.isActive(this)
        if (active) {
            if (!isOcrLoopRunning) {
                startOcrLoop()
            }
        } else {
            if (isOcrLoopRunning) {
                stopOcrLoop()
            }
        }
    }

    private fun startOcrLoop() {
        if (isOcrLoopRunning) return
        isOcrLoopRunning = true
        isOcrScanInProgress = false
        lastOcrResult = null
        scanStartedCount = 0L
        captureSuccessCount = 0L
        ocrRequestedCount = 0L
        ocrCompletedCount = 0L
        textDetectedCount = 0L
        emptyResultCount = 0L
        errorCount = 0L
        lastOcrHeartbeatTime = System.currentTimeMillis()
        LogBuffer.log(this, "OCR", "[OCR-LOOP] STARTED")
        triggerNextOcrScan()
    }

    private fun stopOcrLoop() {
        if (!isOcrLoopRunning) return
        isOcrLoopRunning = false
        isOcrScanInProgress = false
        lastOcrResult = null
        ocrLoopHandler.removeCallbacksAndMessages(null)
        LogBuffer.log(this, "OCR", "[OCR-LOOP] STOPPED")
    }

    private fun triggerNextOcrScan() {
        if (!isOcrLoopRunning || !PrefsManager.isActive(this)) {
            if (isOcrLoopRunning) {
                stopOcrLoop()
            }
            return
        }
        if (isOcrScanInProgress) {
            return // 중복 OCR 실행 방지
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            LogBuffer.log(this, "OCR", "[OCR-ERROR] API 30 이상에서만 화면 캡처 지원")
            stopOcrLoop()
            return
        }

        isOcrScanInProgress = true
        scanStartedCount++

        val now = System.currentTimeMillis()
        if (now - lastOcrHeartbeatTime >= 30000L) {
            lastOcrHeartbeatTime = now
            LogBuffer.log(
                this,
                "OCR",
                "[OCR-STATUS]\nloop=RUNNING\nscanStarted=$scanStartedCount\ncaptureSuccess=$captureSuccessCount\nocrRequested=$ocrRequestedCount\nocrCompleted=$ocrCompletedCount\ntextDetected=$textDetectedCount\nemptyResult=$emptyResultCount\nerror=$errorCount"
            )
        }

        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            applicationContext.mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    if (!isOcrLoopRunning || !PrefsManager.isActive(this@AutoAcceptService)) {
                        screenshot.hardwareBuffer.close()
                        isOcrScanInProgress = false
                        stopOcrLoop()
                        return
                    }

                    val hardwareBuffer = screenshot.hardwareBuffer
                    val colorSpace = screenshot.colorSpace
                    val rawBitmap = Bitmap.wrapHardwareBuffer(hardwareBuffer, colorSpace)
                        ?.copy(Bitmap.Config.ARGB_8888, false)
                    hardwareBuffer.close()

                    if (rawBitmap == null) {
                        errorCount++
                        isOcrScanInProgress = false
                        scheduleNextScanIfActive(100L)
                        return
                    }

                    captureSuccessCount++

                    val width = rawBitmap.width
                    val height = rawBitmap.height

                    // OCR 영역 계산: 화면 하단 50% (Y: 50% ~ 100%, X: 0% ~ 100%)
                    val cropTop = (height * OCR_TOP_RATIO).toInt().coerceIn(0, height - 1)
                    val cropHeight = height - cropTop
                    val croppedBitmap = try {
                        Bitmap.createBitmap(rawBitmap, 0, cropTop, width, cropHeight)
                    } catch (e: Exception) {
                        rawBitmap
                    }

                    val inputImage = InputImage.fromBitmap(croppedBitmap, 0)
                    ocrRequestedCount++

                    ocrRecognizer.process(inputImage)
                        .addOnSuccessListener { visionText ->
                            ocrCompletedCount++
                            val recognizedText = visionText.text.trim()

                            // 이전 OCR 결과와 비교하여 변경된 경우에만 출력 (로그 폭주 방지)
                            if (recognizedText != lastOcrResult) {
                                lastOcrResult = recognizedText
                                if (recognizedText.isNotEmpty()) {
                                    LogBuffer.log(this@AutoAcceptService, "OCR", "[OCR]\n$recognizedText")
                                } else {
                                    LogBuffer.log(this@AutoAcceptService, "OCR", "[OCR] EMPTY")
                                }
                            }

                            if (recognizedText.isNotEmpty()) {
                                textDetectedCount++
                                handleOcrDecisionAndImageSearch(recognizedText, rawBitmap)
                            } else {
                                emptyResultCount++
                            }

                            if (croppedBitmap != rawBitmap && !croppedBitmap.isRecycled) {
                                croppedBitmap.recycle()
                            }
                            if (!rawBitmap.isRecycled) {
                                rawBitmap.recycle()
                            }
                            isOcrScanInProgress = false

                            if (isOcrLoopRunning && PrefsManager.isActive(this@AutoAcceptService)) {
                                triggerNextOcrScan()
                            }
                        }
                        .addOnFailureListener { e ->
                            errorCount++
                            if (croppedBitmap != rawBitmap && !croppedBitmap.isRecycled) {
                                croppedBitmap.recycle()
                            }
                            if (!rawBitmap.isRecycled) {
                                rawBitmap.recycle()
                            }
                            isOcrScanInProgress = false

                            if (isOcrLoopRunning && PrefsManager.isActive(this@AutoAcceptService)) {
                                triggerNextOcrScan()
                            }
                        }
                }

                override fun onFailure(errorCode: Int) {
                    errorCount++
                    isOcrScanInProgress = false
                    scheduleNextScanIfActive(200L)
                }
            }
        )
    }

    private fun scheduleNextScanIfActive(delayMs: Long) {
        if (isOcrLoopRunning && PrefsManager.isActive(this)) {
            ocrLoopHandler.postDelayed({
                if (isOcrLoopRunning && PrefsManager.isActive(this)) {
                    triggerNextOcrScan()
                }
            }, delayMs)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (!PrefsManager.isActive(this)) return

        val pkgName = event.packageName?.toString() ?: ""
        if (pkgName.isNotEmpty()) {
            updateForegroundApp(pkgName)
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) {
            PrefsManager.incrementEventCount(this)
            val root = rootInActiveWindow ?: return
            val source = event.source ?: root
            processWindow(root, source)
        }
    }

    private fun updateForegroundApp(pkgName: String) {
        if (lastForegroundPackage != pkgName) {
            lastForegroundPackage = pkgName
        }
    }

    private fun isTargetPackage(pkgName: String): Boolean {
        return pkgName.contains("uber") ||
                pkgName.contains("ubercab") ||
                pkgName.contains("driver") ||
                pkgName.contains("launcher")
    }

    private fun loadAcceptBtnTemplates() {
        acceptNamedTemplates.clear()
        val templateDefs = listOf(
            Pair("btn_accept_v1_full", R.drawable.btn_accept_v1_full),
            Pair("btn_accept_v2_standard", R.drawable.btn_accept_v2_standard),
            Pair("btn_accept_v3_tight", R.drawable.btn_accept_v3_tight),
            Pair("btn_accept_v4_text", R.drawable.btn_accept_v4_text),
            Pair("btn_accept_v5_wide", R.drawable.btn_accept_v5_wide)
        )
        for ((name, id) in templateDefs) {
            try {
                val bmp = BitmapFactory.decodeResource(resources, id)
                if (bmp != null) acceptNamedTemplates.add(NamedTemplate(name, bmp))
            } catch (_: Exception) {}
        }
    }

    private fun loadXBtnTemplates() {
        dismissNamedTemplates.clear()
        val templateDefs = listOf(
            Pair("btn_dismiss_v1_full", R.drawable.btn_dismiss_v1_full),
            Pair("btn_dismiss_v2_standard", R.drawable.btn_dismiss_v2_standard),
            Pair("btn_dismiss_v3_tight", R.drawable.btn_dismiss_v3_tight),
            Pair("btn_dismiss_v4_icon", R.drawable.btn_dismiss_v4_icon),
            Pair("btn_dismiss_v5_wide", R.drawable.btn_dismiss_v5_wide)
        )
        for ((name, id) in templateDefs) {
            try {
                val bmp = BitmapFactory.decodeResource(resources, id)
                if (bmp != null) dismissNamedTemplates.add(NamedTemplate(name, bmp))
            } catch (_: Exception) {}
        }
    }

    data class TemplateMatchResult(
        val x: Int,
        val y: Int,
        val width: Int,
        val height: Int,
        val score: Float
    )

    private fun findAcceptButtonPoint(bitmap: Bitmap): Point? {
        LogBuffer.log(this, "Accept", "[IMAGE-SEARCH] type=ACCEPT")
        if (acceptNamedTemplates.isEmpty()) {
            loadAcceptBtnTemplates()
        }
        if (acceptNamedTemplates.isEmpty()) {
            LogBuffer.log(this, "Accept", "[IMAGE-NOT-FOUND] type=ACCEPT")
            return null
        }

        val screenW = bitmap.width
        val screenH = bitmap.height
        // 탐색 영역: 화면 하단 영역 (Y: 50% ~ 100%, X: 0% ~ 100%)
        val startY = (screenH * 0.50f).toInt().coerceIn(0, screenH - 1)
        val regionH = screenH - startY

        var bestMatch: TemplateMatchResult? = null

        acceptNamedTemplates.forEach { template ->
            LogBuffer.log(this, "Accept", "[IMAGE-TEMPLATE] ${template.name}")
            val match = matchSingleTemplateInRegion(
                bitmap,
                template.bitmap,
                startX = 0,
                startY = startY,
                regionW = screenW,
                regionH = regionH,
                minScore = 0.65f
            )
            if (match != null) {
                if (bestMatch == null || match.score > bestMatch!!.score) {
                    bestMatch = match
                }
            }
        }

        if (bestMatch != null) {
            val tapX = bestMatch!!.x + bestMatch!!.width / 2
            val tapY = bestMatch!!.y + bestMatch!!.height / 2
            val confStr = String.format(Locale.US, "%.2f", bestMatch!!.score)
            LogBuffer.log(
                this,
                "Accept",
                "[IMAGE-FOUND] type=ACCEPT x=${bestMatch!!.x} y=${bestMatch!!.y} width=${bestMatch!!.width} height=${bestMatch!!.height} confidence=$confStr"
            )
            return Point(tapX, tapY)
        } else {
            LogBuffer.log(this, "Accept", "[IMAGE-NOT-FOUND] type=ACCEPT")
            return null
        }
    }

    private fun findDismissButtonPoint(bitmap: Bitmap): Point? {
        LogBuffer.log(this, "Dismiss", "[IMAGE-SEARCH] type=DISMISS")
        if (dismissNamedTemplates.isEmpty()) {
            loadXBtnTemplates()
        }
        if (dismissNamedTemplates.isEmpty()) {
            LogBuffer.log(this, "Dismiss", "[IMAGE-NOT-FOUND] type=DISMISS")
            return null
        }

        val screenW = bitmap.width
        val screenH = bitmap.height
        // 탐색 영역: 화면 우측 상단/중간 영역 (X: 45% ~ 100%, Y: 10% ~ 70%)
        val startX = (screenW * 0.45f).toInt().coerceIn(0, screenW - 1)
        val regionW = screenW - startX
        val startY = (screenH * 0.10f).toInt().coerceIn(0, screenH - 1)
        val endY = (screenH * 0.70f).toInt().coerceIn(startY + 1, screenH)
        val regionH = endY - startY

        var bestMatch: TemplateMatchResult? = null

        dismissNamedTemplates.forEach { template ->
            LogBuffer.log(this, "Dismiss", "[IMAGE-TEMPLATE] ${template.name}")
            val match = matchSingleTemplateInRegion(
                bitmap,
                template.bitmap,
                startX = startX,
                startY = startY,
                regionW = regionW,
                regionH = regionH,
                minScore = 0.65f
            )
            if (match != null) {
                if (bestMatch == null || match.score > bestMatch!!.score) {
                    bestMatch = match
                }
            }
        }

        if (bestMatch != null) {
            val tapX = bestMatch!!.x + bestMatch!!.width / 2
            val tapY = bestMatch!!.y + bestMatch!!.height / 2
            val confStr = String.format(Locale.US, "%.2f", bestMatch!!.score)
            LogBuffer.log(
                this,
                "Dismiss",
                "[IMAGE-FOUND] type=DISMISS x=${bestMatch!!.x} y=${bestMatch!!.y} width=${bestMatch!!.width} height=${bestMatch!!.height} confidence=$confStr"
            )
            return Point(tapX, tapY)
        } else {
            LogBuffer.log(this, "Dismiss", "[IMAGE-NOT-FOUND] type=DISMISS")
            return null
        }
    }

    private fun matchSingleTemplateInRegion(
        screenBitmap: Bitmap,
        template: Bitmap,
        startX: Int,
        startY: Int,
        regionW: Int,
        regionH: Int,
        minScore: Float
    ): TemplateMatchResult? {
        if (template.isRecycled) return null
        var bestResult: TemplateMatchResult? = null
        var bestScore = minScore

        val scales = floatArrayOf(0.75f, 1.0f, 1.25f, 1.5f)

        for (scale in scales) {
            val tW = (template.width * scale).toInt()
            val tH = (template.height * scale).toInt()
            if (tW <= 0 || tH <= 0 || tW > regionW || tH > regionH) continue

            val scaledTemplate = try {
                if (abs(scale - 1.0f) < 0.01f) template
                else Bitmap.createScaledBitmap(template, tW, tH, true)
            } catch (_: Exception) {
                continue
            }

            val tPixels = IntArray(tW * tH)
            scaledTemplate.getPixels(tPixels, 0, tW, 0, 0, tW, tH)

            var validPixelCount = 0
            for (p in tPixels) {
                if ((p ushr 24) > 128) validPixelCount++
            }
            if (validPixelCount == 0) {
                if (scaledTemplate != template && !scaledTemplate.isRecycled) {
                    scaledTemplate.recycle()
                }
                continue
            }

            val step = if (tW > 100 || tH > 100) 4 else 2
            val maxScanX = startX + regionW - tW
            val maxScanY = startY + regionH - tH

            val sPixels = IntArray(tW * tH)

            for (sy in startY..maxScanY step step) {
                for (sx in startX..maxScanX step step) {
                    try {
                        screenBitmap.getPixels(sPixels, 0, tW, sx, sy, tW, tH)
                    } catch (_: Exception) {
                        continue
                    }

                    var matchedPixels = 0
                    for (i in 0 until validPixelCount) {
                        val tp = tPixels[i]
                        if ((tp ushr 24) <= 128) continue
                        val sp = sPixels[i]

                        val tr = (tp shr 16) and 0xFF
                        val tg = (tp shr 8) and 0xFF
                        val tb = tp and 0xFF

                        val sr = (sp shr 16) and 0xFF
                        val sg = (sp shr 8) and 0xFF
                        val sb = sp and 0xFF

                        val diff = abs(tr - sr) + abs(tg - sg) + abs(tb - sb)
                        if (diff < 90) {
                            matchedPixels++
                        }
                    }

                    val score = matchedPixels.toFloat() / validPixelCount.toFloat()
                    if (score > bestScore) {
                        bestScore = score
                        bestResult = TemplateMatchResult(
                            x = sx,
                            y = sy,
                            width = tW,
                            height = tH,
                            score = score
                        )
                    }
                }
            }

            if (scaledTemplate != template && !scaledTemplate.isRecycled) {
                scaledTemplate.recycle()
            }

            if (bestScore > 0.90f) {
                break
            }
        }

        return bestResult
    }

    private fun handleOcrDecisionAndImageSearch(recognizedText: String, fullBitmap: Bitmap) {
        if (isAcceptingInProgress || isDismissingInProgress) return

        val shouldAccept = evaluateDecision(recognizedText)
        val isAutoDismiss = PrefsManager.isAutoDismiss(this)

        if (shouldAccept) {
            val now = System.currentTimeMillis()
            if (now - lastActionTime < ACTION_COOLDOWN_MS) {
                return
            }

            val acceptPoint = findAcceptButtonPoint(fullBitmap)
            if (acceptPoint != null) {
                lastActionTime = System.currentTimeMillis()
                isAcceptingInProgress = true
                PrefsManager.incrementAcceptScheduled(this)

                val delay = if (PrefsManager.isAcceptNoDelay(this)) 0L else nextHumanDelay()
                mainHandler.postDelayed({
                    try {
                        LogBuffer.log(
                            this@AutoAcceptService,
                            "Accept",
                            "[IMAGE-TAP]\ntype=ACCEPT\nx=${acceptPoint.x}\ny=${acceptPoint.y}"
                        )
                        val fx = acceptPoint.x.toFloat()
                        val fy = acceptPoint.y.toFloat()
                        dispatchTapGesture(fx, fy)
                        shizukuTap(acceptPoint.x, acceptPoint.y)
                        showTapIndicator(acceptPoint.x, acceptPoint.y, true)
                        PrefsManager.incrementAcceptCount(this@AutoAcceptService)

                        if (PrefsManager.isVibration(this@AutoAcceptService)) vibrate()
                        if (PrefsManager.isSleepAlarm(this@AutoAcceptService)) triggerSleepAlarm()
                        if (PrefsManager.isAcceptScreenshot(this@AutoAcceptService)) takeScreenshotAndSave()

                        val intent = Intent("com.uber.autoaccept.ACCEPT_EVENT")
                        sendBroadcast(intent)
                    } finally {
                        mainHandler.postDelayed({ isAcceptingInProgress = false }, 1000L)
                    }
                }, delay)
            }
        } else if (isAutoDismiss) {
            val now = System.currentTimeMillis()
            val cooldown = PrefsManager.getDismissCooldownMs(this).coerceAtLeast(ACTION_COOLDOWN_MS)
            if (now - lastActionTime < cooldown) {
                return
            }

            val dismissPoint = findDismissButtonPoint(fullBitmap)
            if (dismissPoint != null) {
                lastActionTime = System.currentTimeMillis()
                isDismissingInProgress = true
                PrefsManager.incrementDismissScheduled(this)

                mainHandler.postDelayed({
                    try {
                        LogBuffer.log(
                            this@AutoAcceptService,
                            "Dismiss",
                            "[IMAGE-TAP]\ntype=DISMISS\nx=${dismissPoint.x}\ny=${dismissPoint.y}"
                        )
                        val fx = dismissPoint.x.toFloat()
                        val fy = dismissPoint.y.toFloat()
                        dispatchTapGesture(fx, fy)
                        shizukuTap(dismissPoint.x, dismissPoint.y)
                        showTapIndicator(dismissPoint.x, dismissPoint.y, false)
                        lastDismissTime = System.currentTimeMillis()
                        PrefsManager.incrementDismissExecuted(this@AutoAcceptService)
                        PrefsManager.incrementDismissCount(this@AutoAcceptService)
                    } finally {
                        mainHandler.postDelayed({ isDismissingInProgress = false }, 500L)
                    }
                }, 200L)
            }
        }
    }

    private fun processWindow(rootNode: AccessibilityNodeInfo, sourceNode: AccessibilityNodeInfo) {
        if (isAcceptingInProgress) return

        val acceptNode = pickAcceptNode(rootNode)
        if (acceptNode != null) {
            PrefsManager.incrementCallCount(this)
            val acceptRect = Rect()
            acceptNode.getBoundsInScreen(acceptRect)
            PrefsManager.saveLastAcceptRect(this, acceptRect.left, acceptRect.top, acceptRect.right, acceptRect.bottom)

            val textList = mutableListOf<String>()
            collectAllTexts(rootNode, textList)
            val combinedText = textList.joinToString(" ")

            LogBuffer.log(this, "CallDetect", "수락 노드 발견: bounds=$acceptRect, text=$combinedText")

            // [OCR 검증 단계] 실제 수락/취소 동작은 실행하지 않고 노드 감지만 기록
            /*
            val shouldAccept = evaluateDecision(combinedText)
            if (shouldAccept) {
                performAcceptFresh(acceptNode, acceptRect)
            } else if (PrefsManager.isAutoDismiss(this)) {
                performDismissFresh(rootNode, acceptRect)
            }
            */
        }
    }

    private fun evaluateDecision(text: String): Boolean {
        if (PrefsManager.isAcceptAll(this)) {
            return true
        }

        if (PrefsManager.isAirportMode(this)) {
            return AIRPORT_KEYWORDS.any { text.contains(it, ignoreCase = true) }
        }

        val keywords = PrefsManager.getKeywords(this)
        if (keywords.isEmpty()) {
            return false
        }

        val matched = keywords.any { text.contains(it, ignoreCase = true) }

        return if (PrefsManager.isBlacklistMode(this)) {
            !matched
        } else {
            matched
        }
    }

    private fun collectAllTexts(node: AccessibilityNodeInfo?, outList: MutableList<String>) {
        if (node == null) return
        val t = node.text?.toString()
        if (!t.isNullOrBlank()) outList.add(t)
        val cd = node.contentDescription?.toString()
        if (!cd.isNullOrBlank()) outList.add(cd)

        val count = node.childCount
        for (i in 0 until count) {
            collectAllTexts(node.getChild(i), outList)
        }
    }

    private fun pickAcceptNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (btnText in ACCEPT_BUTTON_TEXTS) {
            val list = root.findAccessibilityNodeInfosByText(btnText)
            if (!list.isNullOrEmpty()) {
                for (node in list) {
                    if (node.isVisibleToUser) {
                        return node
                    }
                }
            }
        }
        return findAcceptNodeRecursive(root)
    }

    private fun findAcceptNodeRecursive(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isVisibleToUser) {
            val text = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""
            if (ACCEPT_BUTTON_TEXTS.any { text.contains(it, ignoreCase = true) || desc.contains(it, ignoreCase = true) }) {
                return node
            }
        }
        val count = node.childCount
        for (i in 0 until count) {
            val child = node.getChild(i)
            val result = findAcceptNodeRecursive(child)
            if (result != null) return result
        }
        return null
    }

    private fun performAcceptFresh(node: AccessibilityNodeInfo, rect: Rect) {
        if (isAcceptingInProgress) return
        isAcceptingInProgress = true
        PrefsManager.incrementAcceptScheduled(this)

        val delay = if (PrefsManager.isAcceptNoDelay(this)) 0L else nextHumanDelay()
        LogBuffer.log(this, "Accept", "수락 실행 예약 (delay=${delay}ms)")

        mainHandler.postDelayed({
            try {
                var clicked = false
                if (node.isClickable) {
                    clicked = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                if (!clicked) {
                    var p = node.parent
                    while (p != null) {
                        if (p.isClickable) {
                            clicked = p.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                            if (clicked) break
                        }
                        p = p.parent
                    }
                }

                val centerX = rect.centerX()
                val centerY = rect.centerY()

                if (!clicked) {
                    dispatchTapGesture(centerX.toFloat(), centerY.toFloat())
                    clicked = true
                }

                shizukuTap(centerX, centerY)

                showTapIndicator(centerX, centerY, true)
                PrefsManager.incrementAcceptCount(this)
                LogBuffer.log(this, "Accept", "수락 완료: ($centerX, $centerY)")

                if (PrefsManager.isVibration(this)) vibrate()
                if (PrefsManager.isSleepAlarm(this)) triggerSleepAlarm()
                if (PrefsManager.isAcceptScreenshot(this)) takeScreenshotAndSave()

                val intent = Intent("com.uber.autoaccept.ACCEPT_EVENT")
                sendBroadcast(intent)
            } finally {
                mainHandler.postDelayed({ isAcceptingInProgress = false }, 1000L)
            }
        }, delay)
    }

    private fun performDismissFresh(root: AccessibilityNodeInfo, cardRect: Rect) {
        val now = System.currentTimeMillis()
        val cooldown = PrefsManager.getDismissCooldownMs(this)
        if (now - lastDismissTime < cooldown || isDismissingInProgress) {
            return
        }

        isDismissingInProgress = true
        PrefsManager.incrementDismissScheduled(this)
        LogBuffer.log(this, "Dismiss", "거절 대기 ($cooldown ms)")

        mainHandler.postDelayed({
            try {
                val closeNode = findCloseNode(root)
                var dismissed = false

                if (closeNode != null) {
                    val rect = Rect()
                    closeNode.getBoundsInScreen(rect)
                    if (closeNode.isClickable) {
                        dismissed = closeNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    }
                    if (!dismissed) {
                        dispatchTapGesture(rect.centerX().toFloat(), rect.centerY().toFloat())
                        shizukuTap(rect.centerX(), rect.centerY())
                        dismissed = true
                    }
                    showTapIndicator(rect.centerX(), rect.centerY(), false)
                    PrefsManager.saveDismissDiag(this, "노드 닫기 버튼 성공: $rect")
                } else {
                    // Tap top-right of the card as standard dismiss
                    val tapX = cardRect.right - dp(32)
                    val tapY = cardRect.top + dp(32)
                    dispatchTapGesture(tapX.toFloat(), tapY.toFloat())
                    shizukuTap(tapX, tapY)
                    showTapIndicator(tapX, tapY, false)
                    PrefsManager.saveDismissDiag(this, "상단 우측 좌표 탭 성공: ($tapX, $tapY)")
                    dismissed = true
                }

                if (dismissed) {
                    lastDismissTime = System.currentTimeMillis()
                    PrefsManager.incrementDismissExecuted(this)
                    PrefsManager.incrementDismissCount(this)
                    LogBuffer.log(this, "Dismiss", "거절 완료")
                }
            } finally {
                mainHandler.postDelayed({ isDismissingInProgress = false }, 500L)
            }
        }, cooldown)
    }

    private fun findCloseNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (txt in DISMISS_BUTTON_TEXTS) {
            val list = root.findAccessibilityNodeInfosByText(txt)
            if (!list.isNullOrEmpty()) {
                for (node in list) {
                    if (node.isVisibleToUser) return node
                }
            }
        }
        return findCloseNodeRecursive(root)
    }

    private fun findCloseNodeRecursive(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isVisibleToUser) {
            val desc = node.contentDescription?.toString() ?: ""
            val text = node.text?.toString() ?: ""
            if (DISMISS_BUTTON_TEXTS.any { desc.contains(it, ignoreCase = true) || text.contains(it, ignoreCase = true) }) {
                return node
            }
        }
        val count = node.childCount
        for (i in 0 until count) {
            val child = node.getChild(i)
            val result = findCloseNodeRecursive(child)
            if (result != null) return result
        }
        return null
    }

    private fun doScreenshotPoll() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        if (isAcceptingInProgress || isDismissingInProgress) return

        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            applicationContext.mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    val bitmap = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
                        ?.copy(Bitmap.Config.ARGB_8888, true)
                    screenshot.hardwareBuffer.close()
                    if (bitmap != null) {
                        processScreenshotOcr(bitmap)
                    }
                }

                override fun onFailure(errorCode: Int) {
                    Log.w(TAG, "스크린샷 캡처 실패: $errorCode")
                }
            }
        )
    }

    private fun processScreenshotOcr(bitmap: Bitmap) {
        val inputImage = InputImage.fromBitmap(bitmap, 0)
        ocrRecognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                val fullText = visionText.text
                if (fullText.isNotBlank()) {
                    val hasAccept = ACCEPT_BUTTON_TEXTS.any { fullText.contains(it, ignoreCase = true) }
                    if (hasAccept) {
                        LogBuffer.log(this, "OCR", "OCR로 콜 화면 감지됨: ${fullText.replace("\n", " ")}")
                        val shouldAccept = evaluateDecision(fullText)
                        if (shouldAccept) {
                            // Find accept text block for coordinates
                            var targetRect = Rect(bitmap.width / 4, bitmap.height * 3 / 4, bitmap.width * 3 / 4, bitmap.height * 9 / 10)
                            for (block in visionText.textBlocks) {
                                if (ACCEPT_BUTTON_TEXTS.any { block.text.contains(it, ignoreCase = true) }) {
                                    block.boundingBox?.let { targetRect = it }
                                    break
                                }
                            }
                            performAcceptFreshCoordinates(targetRect)
                        } else if (PrefsManager.isAutoDismiss(this)) {
                            performDismissFreshCoordinates(bitmap)
                        }
                    }
                }
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "OCR 분석 오류: ${e.message}")
            }
    }

    private fun performAcceptFreshCoordinates(rect: Rect) {
        if (isAcceptingInProgress) return
        isAcceptingInProgress = true
        PrefsManager.incrementAcceptScheduled(this)

        val delay = if (PrefsManager.isAcceptNoDelay(this)) 0L else nextHumanDelay()
        mainHandler.postDelayed({
            try {
                val cx = rect.centerX().toFloat()
                val cy = rect.centerY().toFloat()
                dispatchTapGesture(cx, cy)
                shizukuTap(rect.centerX(), rect.centerY())
                showTapIndicator(rect.centerX(), rect.centerY(), true)
                PrefsManager.incrementAcceptCount(this)
                if (PrefsManager.isVibration(this)) vibrate()
                if (PrefsManager.isSleepAlarm(this)) triggerSleepAlarm()

                val intent = Intent("com.uber.autoaccept.ACCEPT_EVENT")
                sendBroadcast(intent)
            } finally {
                mainHandler.postDelayed({ isAcceptingInProgress = false }, 1000L)
            }
        }, delay)
    }

    private fun performDismissFreshCoordinates(bitmap: Bitmap) {
        val now = System.currentTimeMillis()
        val cooldown = PrefsManager.getDismissCooldownMs(this)
        if (now - lastDismissTime < cooldown || isDismissingInProgress) return

        isDismissingInProgress = true
        PrefsManager.incrementDismissScheduled(this)

        mainHandler.postDelayed({
            try {
                val tapX = bitmap.width - dp(40)
                val tapY = dp(120)
                dispatchTapGesture(tapX.toFloat(), tapY.toFloat())
                shizukuTap(tapX, tapY)
                showTapIndicator(tapX, tapY, false)
                lastDismissTime = System.currentTimeMillis()
                PrefsManager.incrementDismissExecuted(this)
                PrefsManager.incrementDismissCount(this)
            } finally {
                mainHandler.postDelayed({ isDismissingInProgress = false }, 500L)
            }
        }, cooldown)
    }

    private fun dispatchTapGesture(x: Float, y: Float) {
        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    private fun shizukuTap(x: Int, y: Int): Boolean {
        return try {
            if (Shizuku.pingBinder()) {
                shizukuExecutor.execute {
                    try {
                        val method = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
                        method.isAccessible = true
                        val process = method.invoke(null, arrayOf("input", "tap", x.toString(), y.toString()), null, null) as? Process
                        process?.waitFor()
                    } catch (_: Exception) {}
                }
                true
            } else false
        } catch (_: Throwable) {
            false
        }
    }

    private fun showTapIndicator(x: Int, y: Int, isAccept: Boolean) {
        val colorName = if (isAccept) "GREEN" else "RED"
        val logType = if (isAccept) "ACCEPT" else "DISMISS"
        LogBuffer.log(
            this,
            if (isAccept) "Accept" else "Dismiss",
            "[TAP-INDICATOR]\ntype=$logType\ncolor=$colorName\nx=$x\ny=$y"
        )

        mainHandler.post {
            try {
                val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val size = dp(44)
                val primaryColor = if (isAccept) Color.parseColor("#00E676") else Color.parseColor("#FF1744")
                val fillColor = if (isAccept) Color.parseColor("#5500E676") else Color.parseColor("#55FF1744")

                val view = View(this).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(fillColor)
                        setStroke(dp(3), primaryColor)
                    }
                }

                val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    @Suppress("DEPRECATION")
                    WindowManager.LayoutParams.TYPE_PHONE
                }

                val params = WindowManager.LayoutParams(
                    size,
                    size,
                    layoutType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    this.x = x - size / 2
                    this.y = y - size / 2
                }

                wm.addView(view, params)
                mainHandler.postDelayed({
                    try {
                        wm.removeView(view)
                    } catch (_: Exception) {}
                }, 1000L)
            } catch (_: Exception) {}
        }
    }

    private fun nextHumanDelay(): Long {
        if (!PrefsManager.isHumanMode(this)) return 0L
        val min = PrefsManager.getMinDelayMs(this)
        val max = PrefsManager.getMaxDelayMs(this)
        return gaussianDelay(min, max, 100L, 5000L)
    }

    private fun gaussianDelay(minMs: Long, maxMs: Long, floorMs: Long, ceilMs: Long): Long {
        if (maxMs <= minMs) return minMs
        val mean = (minMs + maxMs) / 2.0
        val stdDev = (maxMs - minMs) / 4.0
        val sample = mean + random.nextGaussian() * stdDev
        return sample.toLong().coerceIn(floorMs, ceilMs)
    }

    private fun vibrate() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v?.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v?.vibrate(150)
                }
            }
        } catch (_: Exception) {}
    }

    private fun triggerSleepAlarm() {
        try {
            SleepAlarmManager.startAlarm(this)
        } catch (_: Exception) {}
    }

    private fun takeScreenshotAndSave() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            applicationContext.mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    val bitmap = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
                        ?.copy(Bitmap.Config.ARGB_8888, true)
                    screenshot.hardwareBuffer.close()
                    if (bitmap != null) {
                        saveAcceptScreenshotToGallery(bitmap)
                    }
                }
                override fun onFailure(errorCode: Int) {}
            }
        )
    }

    private fun saveAcceptScreenshotToGallery(bitmap: Bitmap) {
        try {
            val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.KOREA)
            val fileName = "ACCEPT_${sdf.format(Date())}.jpg"

            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_DCIM}/스마트알림")
                }
            }

            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
                }
                LogBuffer.log(this, "Screenshot", "스크린샷 저장됨: $fileName")
            }
        } catch (e: Exception) {
            Log.e(TAG, "스크린샷 저장 오류: ${e.message}")
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
