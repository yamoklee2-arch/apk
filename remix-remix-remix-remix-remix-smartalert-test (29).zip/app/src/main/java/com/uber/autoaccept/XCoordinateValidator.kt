package com.uber.autoaccept

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.os.SystemClock
import android.util.Log
import android.view.WindowManager
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * 하이브리드 X 좌표 검증 및 안전 타겟 산출 모듈
 *
 * 1. Accessibility X Node 직접 검출 (1순위)
 * 2. cardBounds 기반 Anchor 좌표 산출 (NORMAL vs OVERLAY_LARGE 동적 분기)
 * 3. Bitmap 우상단 ROI 기반 Sobel Edge + 대각선 피크 검출
 * 4. WindowMetrics / Root Window Bounds 기반 동적 화면 상한(realMaxX, realMaxY) 계산 (하드코딩 없음)
 * 5. Anchor <-> Edge 상호 교차 검증 및 [X-FINAL-TARGET] 확정
 */
object XCoordinateValidator {

    private const val TAG = "XCoordinateValidator"
    private val callCounter = AtomicInteger(0)

    enum class MapMode {
        DAY, NIGHT, UNKNOWN
    }

    enum class CardType {
        NORMAL, OVERLAY_LARGE, UNKNOWN
    }

    data class ValidationResult(
        val callNumber: Int,
        val cardType: CardType,
        val nodeCoord: Pair<Int, Int>?,
        val anchorCoord: Pair<Int, Int>?,
        val edgeCoord: Pair<Int, Int>?,
        val finalTarget: Pair<Int, Int>?,
        val finalSource: String,
        val edgeScore: Double,
        val mapMode: MapMode,
        val cardBounds: Rect?,
        val nodeBounds: Rect?,
        val roiRect: Rect?,
        val diffAnchorVsEdge: Double?,
        val diffNodeVsAnchor: Double?,
        val diffNodeVsEdge: Double?,
        val realMaxX: Int,
        val realMaxY: Int,
        val blockedReason: String? = null,
        val cardDetectedMs: Long = 0L,
        val totalUs: Long = 0L
    )

    /**
     * 콜카드 발생 시 3가지 좌표를 측정/검증하고 최종 안전 터치 좌표를 산출합니다.
     */
    fun validateXCoordinates(
        service: AutoAcceptService,
        root: AccessibilityNodeInfo?,
        cardBounds: Rect?,
        acceptRect: Rect?,
        bitmap: Bitmap?,
        cardDetectedTimestampMs: Long = System.currentTimeMillis()
    ): ValidationResult {
        val totalStartNano = SystemClock.elapsedRealtimeNanos()
        val currentCallNum = callCounter.incrementAndGet()

        // 1. [동적 화면 좌표계 산출 - 하드코딩 금지]
        val dm = service.resources.displayMetrics
        var dynamicMaxW = dm.widthPixels
        var dynamicMaxH = dm.heightPixels
        var windowW = dm.widthPixels
        var windowH = dm.heightPixels

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val wm = service.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
                val bounds = wm?.maximumWindowMetrics?.bounds
                if (bounds != null && !bounds.isEmpty) {
                    windowW = bounds.width()
                    windowH = bounds.height()
                    dynamicMaxW = max(dynamicMaxW, bounds.right)
                    dynamicMaxH = max(dynamicMaxH, bounds.bottom)
                }
            } catch (_: Throwable) {}
        }

        val rootBounds = Rect()
        if (root != null) {
            try {
                root.getBoundsInScreen(rootBounds)
                if (!rootBounds.isEmpty) {
                    dynamicMaxW = max(dynamicMaxW, rootBounds.right)
                    dynamicMaxH = max(dynamicMaxH, rootBounds.bottom)
                }
            } catch (_: Throwable) {}
        }

        if (cardBounds != null && !cardBounds.isEmpty) {
            dynamicMaxW = max(dynamicMaxW, cardBounds.right)
            dynamicMaxH = max(dynamicMaxH, cardBounds.bottom)
        }

        val realMaxX = dynamicMaxW
        val realMaxY = dynamicMaxH

        LogBuffer.diag(
            service,
            "COORD-SYSTEM",
            "displayW=${dm.widthPixels}\n" +
            "displayH=${dm.heightPixels}\n" +
            "windowW=$windowW\n" +
            "windowH=$windowH\n" +
            "rootBounds=Rect(${rootBounds.left}, ${rootBounds.top} - ${rootBounds.right}, ${rootBounds.bottom})\n" +
            "realMaxX=$realMaxX\n" +
            "realMaxY=$realMaxY"
        )

        // 2. [1순위: Accessibility X Node 검출]
        var nodeCoord: Pair<Int, Int>? = null
        var nodeBounds: Rect? = null
        if (root != null) {
            val aRect = acceptRect ?: Rect(0, (realMaxY * 0.75f).toInt(), realMaxX, realMaxY)
            val xNode = findValidatedXNode(root, aRect, cardBounds)
            if (xNode != null) {
                val nr = Rect()
                xNode.getBoundsInScreen(nr)
                nodeBounds = Rect(nr)
                val cx = nr.centerX()
                val cy = nr.centerY()
                nodeCoord = Pair(cx, cy)
                try { xNode.recycle() } catch (_: Throwable) {}

                LogBuffer.diag(service, "X-NODE-FOUND", "bounds=$nr")
                LogBuffer.diag(service, "X-NODE-BOUNDS", "left=${nr.left}\ntop=${nr.top}\nright=${nr.right}\nbottom=${nr.bottom}\nwidth=${nr.width()}\nheight=${nr.height()}")
                LogBuffer.diag(service, "X-NODE-CENTER", "x=$cx\ny=$cy")
            }
        }

        // 3. [cardBounds 유효성 및 CardType 분류]
        val validCardBounds = if (cardBounds != null && isValidBounds(cardBounds, realMaxX, realMaxY)) {
            cardBounds
        } else if (root != null) {
            val aRect = acceptRect ?: Rect(0, (realMaxY * 0.75f).toInt(), realMaxX, realMaxY)
            service.findOverlayCard(root, aRect)?.takeIf { isValidBounds(it, realMaxX, realMaxY) }
        } else {
            null
        }

        val cardType = when {
            validCardBounds == null -> CardType.UNKNOWN
            validCardBounds.height() >= 700 -> CardType.OVERLAY_LARGE
            else -> CardType.NORMAL
        }

        // 4. [2순위: Anchor 기반 X 좌표 산출]
        var anchorCoord: Pair<Int, Int>? = null
        if (validCardBounds != null) {
            val anchorX = (validCardBounds.right - (validCardBounds.width() * 0.035f + 24.0f)).roundToInt()
            val anchorY = when (cardType) {
                CardType.OVERLAY_LARGE -> (validCardBounds.top + 8.0f).roundToInt()
                CardType.NORMAL -> (validCardBounds.top + (validCardBounds.height() * 0.10f)).roundToInt()
                CardType.UNKNOWN -> (validCardBounds.top + 20.0f).roundToInt()
            }
            anchorCoord = Pair(anchorX, anchorY)

            LogBuffer.diag(
                service,
                "X-CARD-BOUNDS",
                "left=${validCardBounds.left}\n" +
                "top=${validCardBounds.top}\n" +
                "right=${validCardBounds.right}\n" +
                "bottom=${validCardBounds.bottom}\n" +
                "width=${validCardBounds.width()}\n" +
                "height=${validCardBounds.height()}\n" +
                "type=${cardType.name}"
            )

            LogBuffer.diag(
                service,
                "X-ANCHOR-COORD",
                "cardType=${cardType.name}\n" +
                "anchorX=$anchorX\n" +
                "anchorY=$anchorY"
            )
        }

        // 5. [3순위: Bitmap ROI Edge 검출]
        var edgeCoord: Pair<Int, Int>? = null
        var edgeScore = 0.0
        var mapMode = MapMode.UNKNOWN
        var roiRect: Rect? = null

        if (bitmap != null && !bitmap.isRecycled && validCardBounds != null) {
            val roiL = (validCardBounds.right - 280).coerceIn(0, bitmap.width - 20)
            val roiR = (validCardBounds.right + 20).coerceIn(roiL + 20, bitmap.width)
            val roiT = (validCardBounds.top - 40).coerceIn(0, bitmap.height - 20)
            val roiB = (validCardBounds.top + 180).coerceIn(roiT + 20, bitmap.height)
            val rRect = Rect(roiL, roiT, roiR, roiB)
            roiRect = rRect

            val detectResult = detectXFromRoiBitmap(bitmap, rRect)
            if (detectResult != null) {
                edgeCoord = detectResult.coord
                edgeScore = detectResult.score
                mapMode = detectResult.mode

                LogBuffer.diag(service, "X-MODE", "mode=${mapMode.name}")
                LogBuffer.diag(service, "X-EDGE-SCORE", "score=${String.format(Locale.US, "%.2f", edgeScore)}")
                LogBuffer.diag(
                    service,
                    "X-EDGE-DETECTED",
                    "x=${edgeCoord.first}\n" +
                    "y=${edgeCoord.second}\n" +
                    "score=${String.format(Locale.US, "%.2f", edgeScore)}\n" +
                    "roiLeft=${rRect.left}\n" +
                    "roiTop=${rRect.top}\n" +
                    "roiWidth=${rRect.width()}\n" +
                    "roiHeight=${rRect.height()}"
                )
            } else {
                LogBuffer.diag(service, "X-EDGE-FAILED", "reason=EDGE_PATTERN_CONFIDENCE_LOW")
            }
        }

        // 6. [4순위: 거리 오차 비교]
        var diffAnchorVsEdge: Double? = null
        var diffNodeVsAnchor: Double? = null
        var diffNodeVsEdge: Double? = null

        if (anchorCoord != null && edgeCoord != null) {
            diffAnchorVsEdge = calculateDistance(anchorCoord, edgeCoord)
        }
        if (nodeCoord != null && anchorCoord != null) {
            diffNodeVsAnchor = calculateDistance(nodeCoord, anchorCoord)
        }
        if (nodeCoord != null && edgeCoord != null) {
            diffNodeVsEdge = calculateDistance(nodeCoord, edgeCoord)
        }

        // 7. [5순위: 최종 터치 타겟 선정 및 안전 차단 판정]
        var finalTarget: Pair<Int, Int>? = null
        var finalSource = "NONE"
        var blockedReason: String? = null

        when {
            nodeCoord != null -> {
                finalTarget = nodeCoord
                finalSource = "NODE"
            }
            edgeCoord != null && edgeScore >= 200.0 && diffAnchorVsEdge != null && diffAnchorVsEdge <= 80.0 -> {
                finalTarget = edgeCoord
                finalSource = "EDGE"
            }
            edgeCoord != null && edgeScore >= 1000.0 && diffAnchorVsEdge != null && diffAnchorVsEdge <= 130.0 -> {
                finalTarget = edgeCoord
                finalSource = "EDGE_RESCUE"
            }
            anchorCoord != null -> {
                finalTarget = anchorCoord
                finalSource = "ANCHOR"
            }
            else -> {
                blockedReason = "NO_VALID_COORDINATE_CANDIDATE"
            }
        }

        // 안전 필터 검증
        if (finalTarget != null) {
            val fx = finalTarget.first
            val fy = finalTarget.second

            if (validCardBounds == null) {
                blockedReason = "NO_VALID_CARD_BOUNDS"
            } else if (!isValidBounds(validCardBounds, realMaxX, realMaxY)) {
                blockedReason = "ABNORMAL_CARD_SIZE"
            } else if (fx !in 0..realMaxX || fy !in 0..realMaxY) {
                blockedReason = "FINAL_COORD_OUT_OF_SCREEN (x=$fx, y=$fy, max=($realMaxX, $realMaxY))"
            } else if (fx < (validCardBounds.left + validCardBounds.width() * 0.45f)) {
                blockedReason = "FINAL_COORD_LEFT_OF_CARD_CENTER (x=$fx, cardLeft=${validCardBounds.left})"
            } else if (fy > (validCardBounds.top + validCardBounds.height() * 0.35f)) {
                blockedReason = "FINAL_COORD_BELOW_CARD_HEADER (y=$fy, cardTop=${validCardBounds.top})"
            } else if (diffAnchorVsEdge != null && diffAnchorVsEdge > 140.0 && edgeScore < 1000.0) {
                blockedReason = "LARGE_DIFF_BETWEEN_ANCHOR_AND_EDGE (${diffAnchorVsEdge.toInt()}px)"
            }
        }

        val totalEndNano = SystemClock.elapsedRealtimeNanos()
        val totalUs = (totalEndNano - totalStartNano) / 1000L
        val cardDetectedMs = System.currentTimeMillis() - cardDetectedTimestampMs

        // 8. [통합 진단 로그 출력: X-FINAL-TARGET]
        val anchorStr = if (anchorCoord != null) "(${anchorCoord.first},${anchorCoord.second})" else "null"
        val edgeStr = if (edgeCoord != null) "(${edgeCoord.first},${edgeCoord.second})" else "null"
        val targetStr = if (finalTarget != null) "(${finalTarget.first},${finalTarget.second})" else "null"
        val diffStr = diffAnchorVsEdge?.let { String.format(Locale.US, "%.1f px", it) } ?: "null"
        val blockedStr = blockedReason ?: "NONE (READY_TO_TOUCH)"

        LogBuffer.diag(
            service,
            "X-FINAL-TARGET",
            "cardType=${cardType.name}\n" +
            "cardBounds=${validCardBounds ?: "null"}\n" +
            "anchor=$anchorStr\n" +
            "edge=$edgeStr\n" +
            "edgeScore=${String.format(Locale.US, "%.2f", edgeScore)}\n" +
            "finalTarget=$targetStr\n" +
            "source=$finalSource\n" +
            "diff=$diffStr\n" +
            "blockedReason=$blockedStr"
        )

        val summaryLog = """
            |━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            |CALL #$currentCallNum
            |Type = ${cardType.name}
            |Node X = ${if (nodeCoord != null) "(${nodeCoord.first},${nodeCoord.second})" else "null"}
            |Anchor X = $anchorStr
            |Edge X = $edgeStr (Score: ${String.format(Locale.US, "%.2f", edgeScore)}, Mode: ${mapMode.name})
            |Final Target = $targetStr (Source: $finalSource)
            |Anchor↔Edge diff = $diffStr
            |Detection time = ${String.format(Locale.US, "%.2f", totalUs / 1000.0)} ms
            |Blocked Reason = $blockedStr
            |━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        """.trimMargin()
        LogBuffer.log(service, TAG, summaryLog)
        Log.i(TAG, summaryLog)

        return ValidationResult(
            callNumber = currentCallNum,
            cardType = cardType,
            nodeCoord = nodeCoord,
            anchorCoord = anchorCoord,
            edgeCoord = edgeCoord,
            finalTarget = finalTarget,
            finalSource = finalSource,
            edgeScore = edgeScore,
            mapMode = mapMode,
            cardBounds = validCardBounds,
            nodeBounds = nodeBounds,
            roiRect = roiRect,
            diffAnchorVsEdge = diffAnchorVsEdge,
            diffNodeVsAnchor = diffNodeVsAnchor,
            diffNodeVsEdge = diffNodeVsEdge,
            realMaxX = realMaxX,
            realMaxY = realMaxY,
            blockedReason = blockedReason,
            cardDetectedMs = cardDetectedMs,
            totalUs = totalUs
        )
    }

    private fun calculateDistance(p1: Pair<Int, Int>, p2: Pair<Int, Int>): Double {
        val dx = (p1.first - p2.first).toDouble()
        val dy = (p1.second - p2.second).toDouble()
        return sqrt(dx * dx + dy * dy)
    }

    private fun isValidBounds(bounds: Rect, screenW: Int, screenH: Int): Boolean {
        if (bounds.isEmpty) return false
        val w = bounds.width()
        val h = bounds.height()
        if (w < 250 || h < 150) return false
        if (bounds.left <= 0 && bounds.right >= screenW && bounds.top <= 0 && bounds.bottom >= screenH) return false
        return true
    }

    private fun findValidatedXNode(root: AccessibilityNodeInfo, acceptRect: Rect, cardBounds: Rect?): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var bestNode: AccessibilityNodeInfo? = null
        var bestScore = -1

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            val nr = Rect()
            node.getBoundsInScreen(nr)
            val w = nr.width()
            val h = nr.height()
            val cls = node.className?.toString() ?: ""
            val vid = node.viewIdResourceName ?: ""
            val txt = "${node.text ?: ""} ${node.contentDescription ?: ""}".trim()

            val isAccept = txt.contains("수락") || txt.contains("콜")
            val isMapMarker = vid.contains("marker", ignoreCase = true) || cls.contains("Map", ignoreCase = true)

            if (!isAccept && !isMapMarker && w in 20..220 && h in 20..220) {
                var valid = true
                if (cardBounds != null) {
                    val isInside = nr.left >= cardBounds.left && nr.right <= cardBounds.right &&
                            nr.top >= cardBounds.top && nr.bottom <= cardBounds.bottom
                    val maxTop = cardBounds.top + (cardBounds.height() * 0.35f)
                    val minLeft = cardBounds.left + (cardBounds.width() * 0.50f)
                    if (!isInside || nr.top > maxTop || nr.left < minLeft) {
                        valid = false
                    }
                } else if (nr.top > acceptRect.top - 100) {
                    valid = false
                }

                if (valid) {
                    val score = (acceptRect.top - nr.centerY()) + (nr.right * 5)
                    if (score > bestScore) {
                        bestScore = score
                        if (bestNode != null && bestNode != root) {
                            try { bestNode.recycle() } catch (_: Throwable) {}
                        }
                        bestNode = node
                    }
                }
            }

            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.add(it) }
            }
            if (node != root && node != bestNode) {
                try { node.recycle() } catch (_: Throwable) {}
            }
        }
        return bestNode
    }

    private data class EdgeDetectionResult(
        val coord: Pair<Int, Int>,
        val score: Double,
        val mode: MapMode
    )

    private fun detectXFromRoiBitmap(bitmap: Bitmap, roi: Rect): EdgeDetectionResult? {
        val rw = roi.width()
        val rh = roi.height()
        if (rw < 30 || rh < 30) return null

        val pixels = IntArray(rw * rh)
        try {
            bitmap.getPixels(pixels, 0, rw, roi.left, roi.top, rw, rh)
        } catch (e: Throwable) {
            Log.w(TAG, "getPixels failed: ${e.message}")
            return null
        }

        val gray = IntArray(rw * rh)
        var sumLum = 0L
        var minLum = 255
        var maxLum = 0

        for (i in pixels.indices) {
            val p = pixels[i]
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            val lum = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
            gray[i] = lum
            sumLum += lum
            if (lum < minLum) minLum = lum
            if (lum > maxLum) maxLum = lum
        }

        val avgLum = sumLum / (rw * rh)
        val mapMode = when {
            avgLum >= 120 -> MapMode.DAY
            avgLum < 120 -> MapMode.NIGHT
            else -> MapMode.UNKNOWN
        }

        val range = (maxLum - minLum).coerceAtLeast(1)
        val norm = FloatArray(rw * rh)
        for (i in gray.indices) {
            norm[i] = ((gray[i] - minLum) * 255.0f / range)
        }

        val edge = FloatArray(rw * rh)
        for (y in 1 until rh - 1) {
            val yOffset = y * rw
            for (x in 1 until rw - 1) {
                val p00 = norm[(y - 1) * rw + (x - 1)]
                val p01 = norm[(y - 1) * rw + x]
                val p02 = norm[(y - 1) * rw + (x + 1)]
                val p10 = norm[yOffset + (x - 1)]
                val p12 = norm[yOffset + (x + 1)]
                val p20 = norm[(y + 1) * rw + (x - 1)]
                val p21 = norm[(y + 1) * rw + x]
                val p22 = norm[(y + 1) * rw + (x + 1)]

                val gx = (p02 + 2 * p12 + p22) - (p00 + 2 * p10 + p20)
                val gy = (p20 + 2 * p21 + p22) - (p00 + 2 * p01 + p02)
                edge[yOffset + x] = abs(gx) + abs(gy)
            }
        }

        val rRadius = 9
        var maxPeakScore = 0.0
        var bestPx = -1
        var bestPy = -1

        for (y in rRadius until rh - rRadius step 2) {
            val yOffset = y * rw
            for (x in rRadius until rw - rRadius step 2) {
                var diag1Sum = 0.0
                var diag2Sum = 0.0

                for (d in -rRadius..rRadius) {
                    diag1Sum += edge[(y + d) * rw + (x + d)]
                    diag2Sum += edge[(y + d) * rw + (x - d)]
                }

                val crossScore = sqrt(diag1Sum * diag2Sum)
                if (crossScore > maxPeakScore) {
                    maxPeakScore = crossScore
                    bestPx = x
                    bestPy = y
                }
            }
        }

        if (bestPx >= 0 && bestPy >= 0 && maxPeakScore >= 120.0) {
            val absX = roi.left + bestPx
            val absY = roi.top + bestPy
            return EdgeDetectionResult(
                coord = Pair(absX, absY),
                score = maxPeakScore,
                mode = mapMode
            )
        }

        return null
    }
}

