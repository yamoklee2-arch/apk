package com.uber.autoaccept

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import rikka.shizuku.Shizuku
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class AutoAcceptService : AccessibilityService() {

    companion object {
        private const val TAG = "AutoAcceptService"
        const val OCR_TOP_RATIO = 0.50f
        const val ACTION_COOLDOWN_MS = 2000L
        val ACCEPT_BUTTON_TEXTS = listOf("콜 수락", "수락", "Accept", "ACCEPT")
        val DISMISS_BUTTON_TEXTS = listOf("뒤로", "닫기", "Close", "close", "×", "✕", "X")
        val AIRPORT_KEYWORDS = listOf("공항", "인천공항", "김포공항", "Airport", "제1여객터미널", "제2여객터미널", "T1", "T2")

        var isRunning: Boolean = false
            private set
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val pollHandler = Handler(Looper.getMainLooper())
    private val screenshotHandler = Handler(Looper.getMainLooper())
    private val watchdogHandler = Handler(Looper.getMainLooper())
    private val ocrLoopHandler = Handler(Looper.getMainLooper())

    private val random = Random()
    private val shizukuExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val ocrExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    private val ocrRecognizer: TextRecognizer by lazy {
        TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
    }

    private val acceptNamedTemplates = mutableListOf<NamedTemplate>()
    private val dismissNamedTemplates = mutableListOf<NamedTemplate>()

    private var lastForegroundPackage: String = ""
    private var lastActionTime: Long = 0L
    private var lastDismissTime: Long = 0L
    private var lastAcceptTime: Long = 0L
    private var isAcceptingInProgress: Boolean = false
    private var isDismissingInProgress: Boolean = false
    private var lastProcessedCardBounds: Rect? = null

    // Event-driven OCR State
    private var isOcrProcessing: Boolean = false
    private var scanSessionCounter: Long = 0L
    private var lastOcrTriggerTime: Long = 0L
    private var lastOcrResult: String? = null
    private val ocrDebounceHandler = Handler(Looper.getMainLooper())

    private val prefChangeListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "is_active") {
            mainHandler.post {
                val active = PrefsManager.isActive(this)
                if (!active) {
                    ocrDebounceHandler.removeCallbacksAndMessages(null)
                    isOcrProcessing = false
                }
            }
        }
    }

    private val keepWarmRunnable = object : Runnable {
        override fun run() {
            try {
                if (PrefsManager.isActive(this@AutoAcceptService)) {
                    LogBuffer.log(this@AutoAcceptService, "KeepWarm", "Service heartbeat OK")
                }
            } catch (_: Exception) {}
            pollHandler.postDelayed(this, 15000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isRunning = true
        LogBuffer.log(this, "Service", "접근성 서비스 연결됨")
        loadAcceptBtnTemplates()
        loadXBtnTemplates()
        try {
            getSharedPreferences("auto_accept_prefs", Context.MODE_PRIVATE)
                .registerOnSharedPreferenceChangeListener(prefChangeListener)
        } catch (_: Exception) {}
        pollHandler.post(keepWarmRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        LogBuffer.log(this, "Service", "접근성 서비스 종료됨")
        try {
            getSharedPreferences("auto_accept_prefs", Context.MODE_PRIVATE)
                .unregisterOnSharedPreferenceChangeListener(prefChangeListener)
        } catch (_: Exception) {}
        SleepAlarmManager.stopAlarm()
        pollHandler.removeCallbacksAndMessages(null)
        screenshotHandler.removeCallbacksAndMessages(null)
        ocrLoopHandler.removeCallbacksAndMessages(null)
        ocrDebounceHandler.removeCallbacksAndMessages(null)
        mainHandler.removeCallbacksAndMessages(null)
        watchdogHandler.removeCallbacksAndMessages(null)
    }

    override fun onInterrupt() {
        LogBuffer.log(this, "Service", "접근성 서비스 중단됨")
        ocrDebounceHandler.removeCallbacksAndMessages(null)
        isOcrProcessing = false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (!PrefsManager.isActive(this)) return

        val pkgName = event.packageName?.toString() ?: ""
        if (pkgName.isNotEmpty()) {
            updateForegroundApp(pkgName)
        }

        // 대상 Uber 패키지 검증 (비 Uber 패키지인 경우 대기 중인 OCR 작업을 즉시 취소하고 안전하게 종료)
        if (!isTargetPackage(pkgName)) {
            ocrDebounceHandler.removeCallbacksAndMessages(null)
            return
        }

        val eventType = event.eventType
        val isTargetEvent = eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
                eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED

        if (!isTargetEvent) {
            return
        }

        PrefsManager.incrementEventCount(this)
        LogBuffer.log(this, "EVENT", "[EVENT-ALLOW] uber pkg=$pkgName type=$eventType")

        requestEventOcrScan(eventType)
    }

    private fun requestEventOcrScan(eventType: Int) {
        if (!PrefsManager.isActive(this)) return

        if (isOcrProcessing) {
            LogBuffer.log(this, "OCR", "[OCR-SKIP] isOcrProcessing=true")
            return
        }

        val now = System.currentTimeMillis()
        if (now - lastOcrTriggerTime < 100L) {
            LogBuffer.log(this, "OCR", "[OCR-SKIP] debounce (<100ms)")
            return
        }

        lastOcrTriggerTime = now

        // [Fast-Path] 고정 100ms 지연 없이 즉시 1차 캡처 및 OCR 시도
        ocrDebounceHandler.removeCallbacksAndMessages(null)
        executeSingleOcrScan(eventType, attempt = 1, eventStartTime = now)
    }

    private fun executeSingleOcrScan(eventType: Int, attempt: Int = 1, eventStartTime: Long = System.currentTimeMillis()) {
        if (!PrefsManager.isActive(this)) return
        if (isOcrProcessing) return

        // 실제 실행 시점에 현재 포그라운드 대상이 여전히 Uber Driver인지 재확인
        if (!isTargetPackage(lastForegroundPackage)) {
            return
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            LogBuffer.log(this, "OCR", "[OCR-ERROR] API 30 이상에서만 화면 캡처 지원")
            return
        }

        val sessionId = ++scanSessionCounter
        isOcrProcessing = true
        val captureStartTime = System.currentTimeMillis()
        LogBuffer.log(this, "OCR", "[OCR-TRIGGER] attempt=$attempt source=uber_event type=$eventType")

        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                applicationContext.mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        val captureElapsed = System.currentTimeMillis() - captureStartTime
                        try {
                            if (!PrefsManager.isActive(this@AutoAcceptService)) {
                                screenshot.hardwareBuffer.close()
                                isOcrProcessing = false
                                return
                            }

                            val hardwareBuffer = screenshot.hardwareBuffer
                            val colorSpace = screenshot.colorSpace
                            val rawBitmap = Bitmap.wrapHardwareBuffer(hardwareBuffer, colorSpace)
                                ?.copy(Bitmap.Config.ARGB_8888, false)
                            hardwareBuffer.close()

                            if (rawBitmap == null || rawBitmap.isRecycled) {
                                LogBuffer.log(this@AutoAcceptService, "OCR", "[OCR-ERROR] 비트맵 변환 실패 (capture=${captureElapsed}ms)")
                                isOcrProcessing = false
                                return
                            }

                            val width = rawBitmap.width
                            val height = rawBitmap.height

                            // OCR 영역 계산: 화면 하단 50% (Y: 50% ~ 100%, X: 0% ~ 100%)
                            val cropTop = (height * OCR_TOP_RATIO).toInt().coerceIn(0, height - 1)
                            val cropHeight = height - cropTop
                            val croppedBitmap = try {
                                Bitmap.createBitmap(rawBitmap, 0, cropTop, width, cropHeight)
                            } catch (e: Exception) {
                                rawBitmap
                            }

                            if (croppedBitmap.isRecycled) {
                                if (!rawBitmap.isRecycled) {
                                    rawBitmap.recycle()
                                }
                                isOcrProcessing = false
                                return
                            }

                            val inputImage = InputImage.fromBitmap(croppedBitmap, 0)
                            val ocrStartTime = System.currentTimeMillis()

                            ocrRecognizer.process(inputImage)
                                .addOnSuccessListener { visionText ->
                                    val ocrElapsed = System.currentTimeMillis() - ocrStartTime
                                    val totalFromEvent = System.currentTimeMillis() - eventStartTime
                                    val recognizedText = visionText.text.trim()

                                    if (recognizedText != lastOcrResult) {
                                        lastOcrResult = recognizedText
                                        if (recognizedText.isNotEmpty()) {
                                            LogBuffer.log(this@AutoAcceptService, "OCR", "[OCR] (capture=${captureElapsed}ms, ocr=${ocrElapsed}ms, total=${totalFromEvent}ms)\n$recognizedText")
                                        } else {
                                            LogBuffer.log(this@AutoAcceptService, "OCR", "[OCR] EMPTY (capture=${captureElapsed}ms, ocr=${ocrElapsed}ms)")
                                        }
                                    }

                                    // 렌더링 중(텍스트 비어있음 또는 불완전) 검사
                                    val isTextIncomplete = recognizedText.isEmpty() ||
                                            (!recognizedText.contains("분") && !recognizedText.contains("km", ignoreCase = true))

                                    // [Retry-Path] 1차 시도에서 텍스트가 아직 준비되지 않은 경우 50ms 후 1회 재시도
                                    if (attempt == 1 && isTextIncomplete) {
                                        LogBuffer.log(
                                            this@AutoAcceptService,
                                            "OCR",
                                            "[RETRY-TRIGGER] attempt=1 incomplete text -> scheduling retry in 50ms (reason=rendering_wait)"
                                        )
                                        if (croppedBitmap != rawBitmap && !croppedBitmap.isRecycled) {
                                            croppedBitmap.recycle()
                                        }
                                        if (!rawBitmap.isRecycled) {
                                            rawBitmap.recycle()
                                        }
                                        isOcrProcessing = false

                                        ocrDebounceHandler.postDelayed({
                                            executeSingleOcrScan(eventType, attempt = 2, eventStartTime = eventStartTime)
                                        }, 50L)
                                        return@addOnSuccessListener
                                    }

                                    // 무거운 템플릿 매칭 연산 및 비트맵 정리를 백그라운드 스레드에서 수행하여 메인 스레드 블로킹 방지
                                    ocrExecutor.execute {
                                        try {
                                            if (recognizedText.isNotEmpty() && !rawBitmap.isRecycled) {
                                                handleOcrDecisionAndImageSearch(recognizedText, rawBitmap, sessionId, eventStartTime)
                                            }
                                        } finally {
                                            if (croppedBitmap != rawBitmap && !croppedBitmap.isRecycled) {
                                                croppedBitmap.recycle()
                                            }
                                            if (!rawBitmap.isRecycled) {
                                                rawBitmap.recycle()
                                            }
                                            isOcrProcessing = false
                                        }
                                    }
                                }
                                .addOnFailureListener { e ->
                                    try {
                                        LogBuffer.log(this@AutoAcceptService, "OCR", "[OCR-ERROR] ${e.message}")
                                    } finally {
                                        if (croppedBitmap != rawBitmap && !croppedBitmap.isRecycled) {
                                            croppedBitmap.recycle()
                                        }
                                        if (!rawBitmap.isRecycled) {
                                            rawBitmap.recycle()
                                        }
                                        isOcrProcessing = false
                                    }
                                }
                        } catch (t: Throwable) {
                            LogBuffer.log(this@AutoAcceptService, "OCR", "[OCR-ERROR] 처리 중 예외: ${t.message}")
                            isOcrProcessing = false
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        LogBuffer.log(this@AutoAcceptService, "OCR", "[OCR-ERROR] 스크린샷 캡처 실패: $errorCode")
                        isOcrProcessing = false
                    }
                }
            )
        } catch (t: Throwable) {
            LogBuffer.log(this, "OCR", "[OCR-ERROR] takeScreenshot 호출 실패: ${t.message}")
            isOcrProcessing = false
        }
    }

    private fun updateForegroundApp(pkgName: String) {
        if (lastForegroundPackage != pkgName) {
            lastForegroundPackage = pkgName
        }
    }

    private fun isTargetPackage(pkgName: String): Boolean {
        if (pkgName.isBlank()) return false
        val myPkg = packageName
        if (pkgName == myPkg || pkgName.startsWith("com.uber.autoaccept")) {
            return false
        }
        val lower = pkgName.lowercase(Locale.ROOT)
        return lower == "com.ubercab.driver" || lower.startsWith("com.ubercab.driver.")
    }

    private fun loadAcceptBtnTemplates() {
        acceptNamedTemplates.clear()
        LogBuffer.log(this, "Service", "[TEMPLATE-CACHE] init start: accept templates")
        val templateDefs = listOf(
            Pair("btn_accept_dark", R.drawable.btn_accept_dark),
            Pair("btn_accept_light", R.drawable.btn_accept_light)
        )
        val scales = floatArrayOf(1.0f, 1.25f, 0.75f, 1.5f)
        for ((name, id) in templateDefs) {
            try {
                val bmp = BitmapFactory.decodeResource(resources, id) ?: continue
                val cachedScales = mutableListOf<CachedScaleTemplate>()
                for (scale in scales) {
                    val tW = (bmp.width * scale).toInt()
                    val tH = (bmp.height * scale).toInt()
                    if (tW <= 0 || tH <= 0) continue
                    val isBaseScale = abs(scale - 1.0f) < 0.01f
                    val scaledBmp = try {
                        if (isBaseScale) bmp
                        else Bitmap.createScaledBitmap(bmp, tW, tH, true)
                    } catch (_: Exception) {
                        null
                    } ?: continue

                    val prep = prepareTemplate(scaledBmp)
                    if (!isBaseScale && !scaledBmp.isRecycled) {
                        scaledBmp.recycle()
                    }
                    if (prep != null) {
                        cachedScales.add(CachedScaleTemplate(scale, prep.width, prep.height, isBaseScale, prep))
                    }
                }
                acceptNamedTemplates.add(NamedTemplate(name, bmp, cachedScales))
                LogBuffer.log(this, "Service", "[TEMPLATE-CACHE] accept prepared: $name (${cachedScales.size} scales)")
            } catch (_: Exception) {}
        }
    }

    private fun loadXBtnTemplates() {
        dismissNamedTemplates.clear()
        LogBuffer.log(this, "Service", "[TEMPLATE-CACHE] init start: dismiss templates")
        val templateDefs = listOf(
            Pair("btn_dismiss_dark", R.drawable.btn_dismiss_dark),
            Pair("btn_dismiss_light", R.drawable.btn_dismiss_light)
        )
        val scales = floatArrayOf(1.0f, 1.25f, 0.75f, 1.5f)
        for ((name, id) in templateDefs) {
            try {
                val bmp = BitmapFactory.decodeResource(resources, id) ?: continue
                val cachedScales = mutableListOf<CachedScaleTemplate>()
                for (scale in scales) {
                    val tW = (bmp.width * scale).toInt()
                    val tH = (bmp.height * scale).toInt()
                    if (tW <= 0 || tH <= 0) continue
                    val isBaseScale = abs(scale - 1.0f) < 0.01f
                    val scaledBmp = try {
                        if (isBaseScale) bmp
                        else Bitmap.createScaledBitmap(bmp, tW, tH, true)
                    } catch (_: Exception) {
                        null
                    } ?: continue

                    val prep = prepareTemplate(scaledBmp)
                    if (!isBaseScale && !scaledBmp.isRecycled) {
                        scaledBmp.recycle()
                    }
                    if (prep != null) {
                        cachedScales.add(CachedScaleTemplate(scale, prep.width, prep.height, isBaseScale, prep))
                    }
                }
                dismissNamedTemplates.add(NamedTemplate(name, bmp, cachedScales))
                LogBuffer.log(this, "Service", "[TEMPLATE-CACHE] dismiss prepared: $name (${cachedScales.size} scales)")
            } catch (_: Exception) {}
        }
        LogBuffer.log(this, "Service", "[TEMPLATE-CACHE] READY")
    }

    data class TemplateMatchResult(
        val x: Int,
        val y: Int,
        val width: Int,
        val height: Int,
        val score: Float
    )

    class CachedScaleTemplate(
        val scale: Float,
        val width: Int,
        val height: Int,
        val isBaseScale: Boolean,
        val prepared: PreparedTemplate
    )

    data class NamedTemplate(
        val name: String,
        val bitmap: Bitmap,
        val cachedScales: List<CachedScaleTemplate> = emptyList()
    )

    class PreparedTemplate(
        val width: Int,
        val height: Int,
        val validXs: IntArray,
        val validYs: IntArray,
        val validRs: IntArray,
        val validGs: IntArray,
        val validBs: IntArray,
        val validCount: Int,
        val sampleIndices: IntArray
    )

    private fun prepareTemplate(bitmap: Bitmap): PreparedTemplate? {
        val w = bitmap.width
        val h = bitmap.height
        if (w <= 0 || h <= 0) return null
        val pixels = IntArray(w * h)
        try {
            bitmap.getPixels(pixels, 0, w, 0, 0, w, h)
        } catch (_: Exception) {
            return null
        }

        var count = 0
        for (p in pixels) {
            if ((p ushr 24) > 128) count++
        }
        if (count == 0) return null

        val xs = IntArray(count)
        val ys = IntArray(count)
        val rs = IntArray(count)
        val gs = IntArray(count)
        val bs = IntArray(count)

        var idx = 0
        for (y in 0 until h) {
            val rowOffset = y * w
            for (x in 0 until w) {
                val p = pixels[rowOffset + x]
                if ((p ushr 24) > 128) {
                    xs[idx] = x
                    ys[idx] = y
                    rs[idx] = (p ushr 16) and 0xFF
                    gs[idx] = (p ushr 8) and 0xFF
                    bs[idx] = p and 0xFF
                    idx++
                }
            }
        }

        val sampleCount = min(32, count)
        val step = max(1, count / sampleCount)
        val samples = IntArray(sampleCount) { i -> (i * step).coerceIn(0, count - 1) }

        return PreparedTemplate(w, h, xs, ys, rs, gs, bs, count, samples)
    }

    private fun findAcceptButtonPoint(bitmap: Bitmap): Point? {
        LogBuffer.log(this, "Accept", "[IMAGE-SEARCH] type=ACCEPT")
        if (acceptNamedTemplates.isEmpty()) {
            loadAcceptBtnTemplates()
        }
        if (acceptNamedTemplates.isEmpty()) {
            LogBuffer.log(this, "Accept", "[IMAGE-NOT-FOUND] type=ACCEPT")
            return null
        }

        val screenW = bitmap.width
        val screenH = bitmap.height

        // 1차 고속 ROI 탐색: 화면 하단 40% 영역 (Y: 60% ~ 100%, X: 0% ~ 100%)
        val roiStartY = (screenH * 0.60f).toInt().coerceIn(0, screenH - 1)
        val roiRegionH = screenH - roiStartY
        LogBuffer.log(this, "Accept", "[ROI-SEARCH] using accept ROI (1st pass: Y 60%~100%)")

        var bestMatch: TemplateMatchResult? = null

        acceptNamedTemplates.forEach { template ->
            LogBuffer.log(this, "Accept", "[IMAGE-TEMPLATE] ${template.name}")
            val match = matchSingleTemplateInRegion(
                bitmap,
                template,
                startX = 0,
                startY = roiStartY,
                regionW = screenW,
                regionH = roiRegionH,
                minScore = 0.65f
            )
            if (match != null) {
                if (bestMatch == null || match.score > bestMatch!!.score) {
                    bestMatch = match
                }
            }
        }

        // 1차 ROI에서 미발견 시 2차 전체/기존 하단 50% 영역 Fallback 탐색
        if (bestMatch == null) {
            LogBuffer.log(this, "Accept", "[ROI-SEARCH] accept fallback to full region (Y 50%~100%)")
            val fallbackStartY = (screenH * 0.50f).toInt().coerceIn(0, screenH - 1)
            val fallbackRegionH = screenH - fallbackStartY

            acceptNamedTemplates.forEach { template ->
                val match = matchSingleTemplateInRegion(
                    bitmap,
                    template,
                    startX = 0,
                    startY = fallbackStartY,
                    regionW = screenW,
                    regionH = fallbackRegionH,
                    minScore = 0.65f
                )
                if (match != null) {
                    if (bestMatch == null || match.score > bestMatch!!.score) {
                        bestMatch = match
                    }
                }
            }
        }

        if (bestMatch != null) {
            val tapX = bestMatch!!.x + bestMatch!!.width / 2
            val tapY = bestMatch!!.y + bestMatch!!.height / 2
            val confStr = String.format(Locale.US, "%.2f", bestMatch!!.score)
            LogBuffer.log(
                this,
                "Accept",
                "[IMAGE-FOUND] type=ACCEPT x=${bestMatch!!.x} y=${bestMatch!!.y} width=${bestMatch!!.width} height=${bestMatch!!.height} confidence=$confStr"
            )
            return Point(tapX, tapY)
        } else {
            LogBuffer.log(this, "Accept", "[IMAGE-NOT-FOUND] type=ACCEPT")
            return null
        }
    }

    private fun findDismissButtonPoint(bitmap: Bitmap): Point? {
        LogBuffer.log(this, "Dismiss", "[IMAGE-SEARCH] type=DISMISS")
        if (dismissNamedTemplates.isEmpty()) {
            loadXBtnTemplates()
        }
        if (dismissNamedTemplates.isEmpty()) {
            LogBuffer.log(this, "Dismiss", "[IMAGE-NOT-FOUND] type=DISMISS")
            return null
        }

        val screenW = bitmap.width
        val screenH = bitmap.height

        // 1차 고속 ROI 탐색: 화면 우측 상단/중상단 영역 (X: 50% ~ 95%, Y: 5% ~ 35%)
        val roiStartX = (screenW * 0.50f).toInt().coerceIn(0, screenW - 1)
        val roiEndX = (screenW * 0.95f).toInt().coerceIn(roiStartX + 1, screenW)
        val roiRegionW = roiEndX - roiStartX
        val roiStartY = (screenH * 0.05f).toInt().coerceIn(0, screenH - 1)
        val roiEndY = (screenH * 0.35f).toInt().coerceIn(roiStartY + 1, screenH)
        val roiRegionH = roiEndY - roiStartY
        LogBuffer.log(this, "Dismiss", "[ROI-SEARCH] using dismiss ROI (1st pass: X 50%~95%, Y 5%~35%)")

        var bestMatch: TemplateMatchResult? = null

        dismissNamedTemplates.forEach { template ->
            LogBuffer.log(this, "Dismiss", "[IMAGE-TEMPLATE] ${template.name}")
            val match = matchSingleTemplateInRegion(
                bitmap,
                template,
                startX = roiStartX,
                startY = roiStartY,
                regionW = roiRegionW,
                regionH = roiRegionH,
                minScore = 0.60f
            )
            if (match != null) {
                if (bestMatch == null || match.score > bestMatch!!.score) {
                    bestMatch = match
                }
            }
        }

        // 1차 ROI에서 미발견 시 2차 상단 카드 영역(X: 40%~100%, Y: 0%~50%) Fallback 탐색
        if (bestMatch == null) {
            LogBuffer.log(this, "Dismiss", "[ROI-SEARCH] dismiss fallback to upper region (X 40%~100%, Y 0%~50%)")
            val fallbackStartX = (screenW * 0.40f).toInt().coerceIn(0, screenW - 1)
            val fallbackRegionW = screenW - fallbackStartX
            val fallbackStartY = 0
            val fallbackEndY = (screenH * 0.50f).toInt().coerceIn(fallbackStartY + 1, screenH)
            val fallbackRegionH = fallbackEndY - fallbackStartY

            dismissNamedTemplates.forEach { template ->
                val match = matchSingleTemplateInRegion(
                    bitmap,
                    template,
                    startX = fallbackStartX,
                    startY = fallbackStartY,
                    regionW = fallbackRegionW,
                    regionH = fallbackRegionH,
                    minScore = 0.60f
                )
                if (match != null) {
                    if (bestMatch == null || match.score > bestMatch!!.score) {
                        bestMatch = match
                    }
                }
            }
        }

        if (bestMatch != null) {
            val tapX = bestMatch!!.x + bestMatch!!.width / 2
            val tapY = bestMatch!!.y + bestMatch!!.height / 2
            val confStr = String.format(Locale.US, "%.2f", bestMatch!!.score)
            LogBuffer.log(
                this,
                "Dismiss",
                "[IMAGE-FOUND] type=DISMISS x=${bestMatch!!.x} y=${bestMatch!!.y} width=${bestMatch!!.width} height=${bestMatch!!.height} confidence=$confStr"
            )
            return Point(tapX, tapY)
        } else {
            LogBuffer.log(this, "Dismiss", "[IMAGE-NOT-FOUND] type=DISMISS")
            return null
        }
    }

    private data class GridCandidate(val relX: Int, val relY: Int, val score: Float)

    private fun matchSingleTemplateInRegion(
        screenBitmap: Bitmap,
        template: NamedTemplate,
        startX: Int,
        startY: Int,
        regionW: Int,
        regionH: Int,
        minScore: Float
    ): TemplateMatchResult? {
        if (screenBitmap.isRecycled || template.cachedScales.isEmpty()) return null
        var bestResult: TemplateMatchResult? = null
        var bestScore = minScore

        val screenW = screenBitmap.width
        val screenH = screenBitmap.height
        val sStartX = startX.coerceIn(0, screenW - 1)
        val sStartY = startY.coerceIn(0, screenH - 1)
        val sRegionW = regionW.coerceIn(1, screenW - sStartX)
        val sRegionH = regionH.coerceIn(1, screenH - sStartY)

        val fullScreenRegionPixels = try {
            val arr = IntArray(sRegionW * sRegionH)
            screenBitmap.getPixels(arr, 0, sRegionW, sStartX, sStartY, sRegionW, sRegionH)
            arr
        } catch (_: Exception) {
            return null
        }

        // 스케일 우선순위: 캐시된 스케일 순서 (1.0x -> 1.25x -> 0.75x -> 1.5x) 유지
        for (scaleEntry in template.cachedScales) {
            val prep = scaleEntry.prepared
            val isBaseScale = scaleEntry.isBaseScale
            if (prep.width > sRegionW || prep.height > sRegionH) continue

            val maxRelX = sRegionW - prep.width
            val maxRelY = sRegionH - prep.height
            if (maxRelX < 0 || maxRelY < 0) continue

            // ----------------------------------------------------
            // Stage 1: Fast Grid Search (Step=4, Sample Filter)
            // ----------------------------------------------------
            val gridStep = 4
            val sampleCount = prep.sampleIndices.size
            val sampleMinScore = min(0.60f, minScore)
            val minSampleMatches = (sampleCount * sampleMinScore).toInt()
            val maxSampleMismatches = sampleCount - minSampleMatches
            val candidates = mutableListOf<GridCandidate>()

            for (relY in 0..maxRelY step gridStep) {
                for (relX in 0..maxRelX step gridStep) {
                    var sampleMatched = 0
                    var sampleMismatched = 0
                    var samplePassed = true

                    for (sIdx in prep.sampleIndices) {
                        val tx = prep.validXs[sIdx]
                        val ty = prep.validYs[sIdx]
                        val tr = prep.validRs[sIdx]
                        val tg = prep.validGs[sIdx]
                        val tb = prep.validBs[sIdx]

                        val sp = fullScreenRegionPixels[(relY + ty) * sRegionW + (relX + tx)]
                        val sr = (sp ushr 16) and 0xFF
                        val sg = (sp ushr 8) and 0xFF
                        val sb = sp and 0xFF

                        // Fast L1 distance with tolerance 38 * 3 = 114
                        val diff = abs(tr - sr) + abs(tg - sg) + abs(tb - sb)
                        if (diff <= 114) {
                            sampleMatched++
                        } else {
                            sampleMismatched++
                            if (sampleMismatched > maxSampleMismatches) {
                                samplePassed = false
                                break
                            }
                        }
                    }

                    if (samplePassed) {
                        val sScore = sampleMatched.toFloat() / sampleCount.toFloat()
                        if (sScore >= sampleMinScore) {
                            candidates.add(GridCandidate(relX, relY, sScore))
                        }
                    }
                }
            }

            if (candidates.isEmpty()) continue

            // ----------------------------------------------------
            // Stage 2: Candidate Narrowing (Top 3 Candidates)
            // ----------------------------------------------------
            val topCandidates = candidates.sortedByDescending { it.score }.take(3)

            // ----------------------------------------------------
            // Stage 3: Fine Verification with Early Exit
            // ----------------------------------------------------
            for (cand in topCandidates) {
                val fineMinY = max(0, cand.relY - gridStep)
                val fineMaxY = min(maxRelY, cand.relY + gridStep)
                val fineMinX = max(0, cand.relX - gridStep)
                val fineMaxX = min(maxRelX, cand.relX + gridStep)

                for (fy in fineMinY..fineMaxY) {
                    for (fx in fineMinX..fineMaxX) {
                        val minRequiredMatches = (prep.validCount * bestScore).toInt()
                        val maxAllowedMismatches = prep.validCount - minRequiredMatches
                        var matched = 0
                        var mismatched = 0
                        var passed = true

                        for (i in 0 until prep.validCount) {
                            val tx = prep.validXs[i]
                            val ty = prep.validYs[i]
                            val tr = prep.validRs[i]
                            val tg = prep.validGs[i]
                            val tb = prep.validBs[i]

                            val sp = fullScreenRegionPixels[(fy + ty) * sRegionW + (fx + tx)]
                            val sr = (sp ushr 16) and 0xFF
                            val sg = (sp ushr 8) and 0xFF
                            val sb = sp and 0xFF

                            if (abs(tr - sr) <= 38 && abs(tg - sg) <= 38 && abs(tb - sb) <= 38) {
                                matched++
                            } else {
                                mismatched++
                                if (mismatched > maxAllowedMismatches) {
                                    passed = false
                                    break
                                }
                            }
                        }

                        if (passed) {
                            val score = matched.toFloat() / prep.validCount.toFloat()
                            if (score > bestScore) {
                                bestScore = score
                                bestResult = TemplateMatchResult(
                                    x = sStartX + fx,
                                    y = sStartY + fy,
                                    width = prep.width,
                                    height = prep.height,
                                    score = score
                                )
                            }
                        }
                    }
                }
            }

            // 1.0x 스케일에서 확정 기준(>= 0.78) 만족 시 나머지 스케일 탐색 즉시 조기 종료
            if (isBaseScale && bestResult != null && bestResult.score >= 0.78f) {
                break
            }
            if (bestResult != null && bestResult.score >= 0.88f) {
                break
            }
        }

        return bestResult
    }

    private fun handleOcrDecisionAndImageSearch(
        recognizedText: String,
        fullBitmap: Bitmap,
        sessionId: Long,
        eventStartTime: Long = System.currentTimeMillis()
    ) {
        if (isAcceptingInProgress || isDismissingInProgress) return

        val decisionStartTime = System.currentTimeMillis()

        // 1단계: 콜카드 여부 확인을 위한 분/km 보조 정보 검사 (수락 및 취소 양방향 공통 전제조건)
        val hasMinutes = recognizedText.contains("분")
        val hasDistance = recognizedText.contains("km", ignoreCase = true)
        val hasTimeOrDistance = hasMinutes || hasDistance
        LogBuffer.log(
            this,
            "OCR",
            "[MIN-KM-CHECK] hasMinutes=$hasMinutes, hasDistance=$hasDistance, validCard=$hasTimeOrDistance"
        )

        if (!hasTimeOrDistance) {
            LogBuffer.log(this, "OCR", "[CALL-CARD-SKIP] reason=missing_time_or_distance (eval=${System.currentTimeMillis() - decisionStartTime}ms)")
            return
        }

        // 2단계: 실제 사용자 등록 키워드 목록 로드 및 비교
        LogBuffer.log(this, "OCR", "[KEYWORD-CHECK] LOAD_START")
        val userKeywords = PrefsManager.getKeywords(this)
        val isAcceptAll = PrefsManager.isAcceptAll(this)
        val isAirport = PrefsManager.isAirportMode(this)

        LogBuffer.log(this, "OCR", "[KEYWORD-CHECK] registeredCount=${userKeywords.size}")
        LogBuffer.log(this, "OCR", "[KEYWORD-CHECK] loadedKeywords=$userKeywords")
        LogBuffer.log(this, "OCR", "[KEYWORD-CHECK] OCR_TEXT=\"$recognizedText\"")

        LogBuffer.log(this, "OCR", "[KEYWORD-CHECK] COMPARE_START")

        var matchedKeywordName: String? = null
        val isKeywordMatched = when {
            isAcceptAll -> {
                matchedKeywordName = "ACCEPT_ALL"
                true
            }
            isAirport -> {
                var airportMatch: String? = null
                for (kw in AIRPORT_KEYWORDS) {
                    val res = recognizedText.contains(kw, ignoreCase = true)
                    LogBuffer.log(this, "OCR", "[KEYWORD-CHECK] COMPARE keyword=\"$kw\" result=$res")
                    if (res && airportMatch == null) {
                        airportMatch = kw
                    }
                }
                matchedKeywordName = airportMatch
                airportMatch != null
            }
            userKeywords.isNotEmpty() -> {
                var userMatch: String? = null
                for (kw in userKeywords) {
                    val res = recognizedText.contains(kw, ignoreCase = true)
                    LogBuffer.log(this, "OCR", "[KEYWORD-CHECK] COMPARE keyword=\"$kw\" result=$res")
                    if (res && userMatch == null) {
                        userMatch = kw
                    }
                }
                matchedKeywordName = userMatch
                userMatch != null
            }
            else -> {
                LogBuffer.log(this, "OCR", "[KEYWORD-CHECK] KEYWORD_LIST_EMPTY")
                false
            }
        }

        if (isKeywordMatched) {
            LogBuffer.log(this, "OCR", "[KEYWORD-MATCH] matchedKeyword=\"$matchedKeywordName\"")
        } else {
            LogBuffer.log(this, "OCR", "[KEYWORD-CHECK] result=NO_MATCH")
            LogBuffer.log(this, "OCR", "[KEYWORD-CHECK] OCR_TEXT=\"$recognizedText\"")
            LogBuffer.log(this, "OCR", "[KEYWORD-CHECK] LOADED_KEYWORDS=$userKeywords")
        }

        // 3단계: 키워드 결과 + 분/km 보조 결과를 종합한 최종 evaluateDecision 판단
        val shouldAccept = evaluateDecision(recognizedText)
        val decisionElapsed = System.currentTimeMillis() - decisionStartTime
        val isAutoDismiss = PrefsManager.isAutoDismiss(this)

        if (shouldAccept) {
            LogBuffer.log(this, "Accept", "[CALL-CARD-DECISION] action=ACCEPT")
            val now = System.currentTimeMillis()
            if (now - lastActionTime < ACTION_COOLDOWN_MS) {
                return
            }

            val matchStartTime = System.currentTimeMillis()
            val acceptPoint = findAcceptButtonPoint(fullBitmap)
            val matchElapsed = System.currentTimeMillis() - matchStartTime

            if (acceptPoint != null) {
                lastActionTime = System.currentTimeMillis()
                isAcceptingInProgress = true
                PrefsManager.incrementAcceptScheduled(this)

                val totalPipelineElapsed = System.currentTimeMillis() - eventStartTime
                LogBuffer.log(
                    this,
                    "Accept",
                    "[TIMING-METRIC] event->ready: total=${totalPipelineElapsed}ms (eval=${decisionElapsed}ms, match=${matchElapsed}ms)"
                )

                val delay = if (PrefsManager.isAcceptNoDelay(this)) 0L else nextHumanDelay()
                mainHandler.postDelayed({
                    if (sessionId != scanSessionCounter) {
                        LogBuffer.log(this@AutoAcceptService, "Accept", "[SESSION-DISCARD] stale session: $sessionId vs $scanSessionCounter")
                        return@postDelayed
                    }
                    try {
                        val tapExecuteTime = System.currentTimeMillis() - eventStartTime
                        LogBuffer.log(
                            this@AutoAcceptService,
                            "Accept",
                            "[IMAGE-TAP]\ntype=ACCEPT\nx=${acceptPoint.x}\ny=${acceptPoint.y}\n(total_to_tap=${tapExecuteTime}ms)"
                        )
                        val fx = acceptPoint.x.toFloat()
                        val fy = acceptPoint.y.toFloat()
                        dispatchTapGesture(fx, fy)
                        shizukuTap(acceptPoint.x, acceptPoint.y)
                        showTapIndicator(acceptPoint.x, acceptPoint.y, true)
                        PrefsManager.incrementAcceptCount(this@AutoAcceptService)

                        if (PrefsManager.isVibration(this@AutoAcceptService)) vibrate()
                        if (PrefsManager.isSleepAlarm(this@AutoAcceptService)) triggerSleepAlarm()
                        takeScreenshotAndSave(true)

                        val intent = Intent("com.uber.autoaccept.ACCEPT_EVENT")
                        sendBroadcast(intent)
                    } finally {
                        mainHandler.postDelayed({ isAcceptingInProgress = false }, 1000L)
                    }
                }, delay)
            }
        } else if (isAutoDismiss) {
            LogBuffer.log(this, "Dismiss", "[CALL-CARD-DECISION] action=CANCEL")
            val now = System.currentTimeMillis()
            val cooldown = PrefsManager.getDismissCooldownMs(this).coerceAtLeast(ACTION_COOLDOWN_MS)
            if (now - lastActionTime < cooldown) {
                return
            }

            LogBuffer.log(this, "Dismiss", "[CANCEL] existing_cancel_flow_start")
            val matchStartTime = System.currentTimeMillis()
            val dismissPoint = findDismissButtonPoint(fullBitmap)
            val matchElapsed = System.currentTimeMillis() - matchStartTime

            if (dismissPoint != null) {
                lastActionTime = System.currentTimeMillis()
                isDismissingInProgress = true
                PrefsManager.incrementDismissScheduled(this)

                val totalPipelineElapsed = System.currentTimeMillis() - eventStartTime
                LogBuffer.log(
                    this,
                    "Dismiss",
                    "[TIMING-METRIC] event->ready: total=${totalPipelineElapsed}ms (eval=${decisionElapsed}ms, match=${matchElapsed}ms)"
                )

                mainHandler.postDelayed({
                    if (sessionId != scanSessionCounter) {
                        LogBuffer.log(this@AutoAcceptService, "Dismiss", "[SESSION-DISCARD] stale session: $sessionId vs $scanSessionCounter")
                        return@postDelayed
                    }
                    try {
                        val tapExecuteTime = System.currentTimeMillis() - eventStartTime
                        LogBuffer.log(
                            this@AutoAcceptService,
                            "Dismiss",
                            "[IMAGE-TAP]\ntype=DISMISS\nx=${dismissPoint.x}\ny=${dismissPoint.y}\n(total_to_tap=${tapExecuteTime}ms)"
                        )
                        val fx = dismissPoint.x.toFloat()
                        val fy = dismissPoint.y.toFloat()
                        dispatchTapGesture(fx, fy)
                        shizukuTap(dismissPoint.x, dismissPoint.y)
                        showTapIndicator(dismissPoint.x, dismissPoint.y, false)
                        LogBuffer.log(this@AutoAcceptService, "Dismiss", "[CANCEL] existing_cancel_action_executed")
                        lastDismissTime = System.currentTimeMillis()
                        PrefsManager.incrementDismissExecuted(this@AutoAcceptService)
                        PrefsManager.incrementDismissCount(this@AutoAcceptService)
                        takeScreenshotAndSave(false)
                    } finally {
                        mainHandler.postDelayed({ isDismissingInProgress = false }, 500L)
                    }
                }, 200L)
            }
        }
    }

    private fun evaluateDecision(text: String): Boolean {
        if (PrefsManager.isAcceptAll(this)) {
            return true
        }

        if (PrefsManager.isAirportMode(this)) {
            return AIRPORT_KEYWORDS.any { text.contains(it, ignoreCase = true) }
        }

        val keywords = PrefsManager.getKeywords(this)
        if (keywords.isEmpty()) {
            return false
        }

        val matched = keywords.any { text.contains(it, ignoreCase = true) }

        return if (PrefsManager.isBlacklistMode(this)) {
            !matched
        } else {
            matched
        }
    }

    private fun dispatchTapGesture(x: Float, y: Float) {
        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    private fun shizukuTap(x: Int, y: Int): Boolean {
        return try {
            if (Shizuku.pingBinder()) {
                shizukuExecutor.execute {
                    try {
                        val method = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
                        method.isAccessible = true
                        val process = method.invoke(null, arrayOf("input", "tap", x.toString(), y.toString()), null, null) as? Process
                        process?.waitFor()
                    } catch (_: Exception) {}
                }
                true
            } else false
        } catch (_: Throwable) {
            false
        }
    }

    private fun showTapIndicator(x: Int, y: Int, isAccept: Boolean) {
        val colorName = if (isAccept) "GREEN" else "RED"
        val logType = if (isAccept) "ACCEPT" else "DISMISS"
        LogBuffer.log(
            this,
            if (isAccept) "Accept" else "Dismiss",
            "[TAP-INDICATOR]\ntype=$logType\ncolor=$colorName\nx=$x\ny=$y"
        )

        mainHandler.post {
            try {
                val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val size = dp(44)
                val primaryColor = if (isAccept) Color.parseColor("#00E676") else Color.parseColor("#FF1744")
                val fillColor = if (isAccept) Color.parseColor("#5500E676") else Color.parseColor("#55FF1744")

                val view = View(this).apply {
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(fillColor)
                        setStroke(dp(3), primaryColor)
                    }
                }

                val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    @Suppress("DEPRECATION")
                    WindowManager.LayoutParams.TYPE_PHONE
                }

                val params = WindowManager.LayoutParams(
                    size,
                    size,
                    layoutType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    this.x = x - size / 2
                    this.y = y - size / 2
                }

                wm.addView(view, params)
                mainHandler.postDelayed({
                    try {
                        wm.removeView(view)
                    } catch (_: Exception) {}
                }, 1000L)
            } catch (_: Exception) {}
        }
    }

    private fun nextHumanDelay(): Long {
        if (!PrefsManager.isHumanMode(this)) return 0L
        val min = PrefsManager.getMinDelayMs(this)
        val max = PrefsManager.getMaxDelayMs(this)
        return gaussianDelay(min, max, 100L, 5000L)
    }

    private fun gaussianDelay(minMs: Long, maxMs: Long, floorMs: Long, ceilMs: Long): Long {
        if (maxMs <= minMs) return minMs
        val mean = (minMs + maxMs) / 2.0
        val stdDev = (maxMs - minMs) / 4.0
        val sample = mean + random.nextGaussian() * stdDev
        return sample.toLong().coerceIn(floorMs, ceilMs)
    }

    private fun vibrate() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v?.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v?.vibrate(150)
                }
            }
        } catch (_: Exception) {}
    }

    private fun triggerSleepAlarm() {
        try {
            SleepAlarmManager.startAlarm(this)
        } catch (_: Exception) {}
    }

    private fun takeScreenshotAndSave(isAccept: Boolean) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                applicationContext.mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        try {
                            val bitmap = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
                                ?.copy(Bitmap.Config.ARGB_8888, true)
                            screenshot.hardwareBuffer.close()
                            if (bitmap != null) {
                                saveScreenshotToGallery(bitmap, isAccept)
                            }
                        } catch (_: Throwable) {}
                    }
                    override fun onFailure(errorCode: Int) {}
                }
            )
        } catch (_: Throwable) {}
    }

    private fun saveScreenshotToGallery(bitmap: Bitmap, isAccept: Boolean) {
        try {
            val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.KOREA)
            val prefix = if (isAccept) "ACCEPT" else "DISMISS"
            val fileName = "${prefix}_${sdf.format(Date())}.jpg"

            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_DCIM}/스마트알림")
                }
            }

            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
                }
                LogBuffer.log(this, "Screenshot", "스크린샷 저장됨: $fileName")
            }
        } catch (e: Exception) {
            Log.e(TAG, "스크린샷 저장 오류: ${e.message}")
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
