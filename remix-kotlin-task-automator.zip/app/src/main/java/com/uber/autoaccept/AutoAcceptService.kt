package com.uber.autoaccept

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import rikka.shizuku.Shizuku
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class AutoAcceptService : AccessibilityService() {

    companion object {
        private const val TAG = "AutoAcceptService"
        const val OCR_TOP_RATIO = 0.50f
        const val ACTION_COOLDOWN_MS = 2000L
        val ACCEPT_BUTTON_TEXTS = listOf("콜 수락", "수락", "Accept", "ACCEPT")
        val DISMISS_BUTTON_TEXTS = listOf("뒤로", "닫기", "Close", "close", "×", "✕", "X")
        val AIRPORT_KEYWORDS = listOf("공항", "인천공항", "김포공항", "Airport", "제1여객터미널", "제2여객터미널", "T1", "T2")

        var isRunning: Boolean = false
            private set
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val pollHandler = Handler(Looper.getMainLooper())
    private val screenshotHandler = Handler(Looper.getMainLooper())
    private val watchdogHandler = Handler(Looper.getMainLooper())
    private val ocrLoopHandler = Handler(Looper.getMainLooper())

    private val random = Random()
    private val shizukuExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    private val ocrRecognizer: TextRecognizer by lazy {
        TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
    }

    data class NamedTemplate(val name: String, val bitmap: Bitmap)
    private val acceptNamedTemplates = mutableListOf<NamedTemplate>()
    private val dismissNamedTemplates = mutableListOf<NamedTemplate>()

    private var lastForegroundPackage: String = ""
    private var lastActionTime: Long = 0L
    private var lastDismissTime: Long = 0L
    private var lastAcceptTime: Long = 0L
    private var isAcceptingInProgress: Boolean = false
    private var isDismissingInProgress: Boolean = false
    private var lastProcessedCardBounds: Rect? = null

    // Event-driven OCR State
    private var isOcrProcessing: Boolean = false
    private var lastOcrTriggerTime: Long = 0L
    private var lastOcrResult: String? = null
    private val ocrDebounceHandler = Handler(Looper.getMainLooper())

    private val prefChangeListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "is_active") {
            mainHandler.post {
                val active = PrefsManager.isActive(this)
                if (!active) {
                    ocrDebounceHandler.removeCallbacksAndMessages(null)
                    isOcrProcessing = false
                }
            }
        }
    }

    private val keepWarmRunnable = object : Runnable {
        override fun run() {
            try {
                if (PrefsManager.isActive(this@AutoAcceptService)) {
                    LogBuffer.log(this@AutoAcceptService, "KeepWarm", "Service heartbeat OK")
                }
            } catch (_: Exception) {}
            pollHandler.postDelayed(this, 15000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isRunning = true
        LogBuffer.log(this, "Service", "접근성 서비스 연결됨")
        loadAcceptBtnTemplates()
        loadXBtnTemplates()
        try {
            getSharedPreferences("auto_accept_prefs", Context.MODE_PRIVATE)
                .registerOnSharedPreferenceChangeListener(prefChangeListener)
        } catch (_: Exception) {}
        pollHandler.post(keepWarmRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        LogBuffer.log(this, "Service", "접근성 서비스 종료됨")
        try {
            getSharedPreferences("auto_accept_prefs", Context.MODE_PRIVATE)
                .unregisterOnSharedPreferenceChangeListener(prefChangeListener)
        } catch (_: Exception) {}
        SleepAlarmManager.stopAlarm()
        pollHandler.removeCallbacksAndMessages(null)
        screenshotHandler.removeCallbacksAndMessages(null)
        ocrLoopHandler.removeCallbacksAndMessages(null)
        ocrDebounceHandler.removeCallbacksAndMessages(null)
        mainHandler.removeCallbacksAndMessages(null)
        watchdogHandler.removeCallbacksAndMessages(null)
    }

    override fun onInterrupt() {
        LogBuffer.log(this, "Service", "접근성 서비스 중단됨")
        ocrDebounceHandler.removeCallbacksAndMessages(null)
        isOcrProcessing = false
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (!PrefsManager.isActive(this)) return

        val pkgName = event.packageName?.toString() ?: ""
        if (pkgName.isNotEmpty()) {
            updateForegroundApp(pkgName)
        }

        // 대상 Uber 패키지 검증 (비 Uber 패키지는 즉시 차단 후 조용히 종료)
        if (!isTargetPackage(pkgName)) {
            return
        }

        val eventType = event.eventType
        val isTargetEvent = eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
                eventType == AccessibilityEvent.TYPE_WINDOWS_CHANGED

        if (!isTargetEvent) {
            return
        }

        PrefsManager.incrementEventCount(this)
        LogBuffer.log(this, "EVENT", "[EVENT-ALLOW] uber pkg=$pkgName type=$eventType")

        requestEventOcrScan(eventType)
    }

    private fun requestEventOcrScan(eventType: Int) {
        if (!PrefsManager.isActive(this)) return

        if (isOcrProcessing) {
            LogBuffer.log(this, "OCR", "[OCR-SKIP] isOcrProcessing=true")
            return
        }

        val now = System.currentTimeMillis()
        if (now - lastOcrTriggerTime < 150L) {
            LogBuffer.log(this, "OCR", "[OCR-SKIP] debounce (<150ms)")
            return
        }

        lastOcrTriggerTime = now

        // UI 렌더링 안정화 딜레이 (100ms) 후 1회 OCR 실행
        ocrDebounceHandler.removeCallbacksAndMessages(null)
        ocrDebounceHandler.postDelayed({
            executeSingleOcrScan(eventType)
        }, 100L)
    }

    private fun executeSingleOcrScan(eventType: Int) {
        if (!PrefsManager.isActive(this)) return
        if (isOcrProcessing) return

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            LogBuffer.log(this, "OCR", "[OCR-ERROR] API 30 이상에서만 화면 캡처 지원")
            return
        }

        isOcrProcessing = true
        LogBuffer.log(this, "OCR", "[OCR-TRIGGER] source=uber_event type=$eventType")

        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                applicationContext.mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        try {
                            if (!PrefsManager.isActive(this@AutoAcceptService)) {
                                screenshot.hardwareBuffer.close()
                                isOcrProcessing = false
                                return
                            }

                            val hardwareBuffer = screenshot.hardwareBuffer
                            val colorSpace = screenshot.colorSpace
                            val rawBitmap = Bitmap.wrapHardwareBuffer(hardwareBuffer, colorSpace)
                                ?.copy(Bitmap.Config.ARGB_8888, false)
                            hardwareBuffer.close()

                            if (rawBitmap == null || rawBitmap.isRecycled) {
                                LogBuffer.log(this@AutoAcceptService, "OCR", "[OCR-ERROR] 비트맵 변환 실패")
                                isOcrProcessing = false
                                return
                            }

                            val width = rawBitmap.width
                            val height = rawBitmap.height

                            // OCR 영역 계산: 화면 하단 50% (Y: 50% ~ 100%, X: 0% ~ 100%)
                            val cropTop = (height * OCR_TOP_RATIO).toInt().coerceIn(0, height - 1)
                            val cropHeight = height - cropTop
                            val croppedBitmap = try {
                                Bitmap.createBitmap(rawBitmap, 0, cropTop, width, cropHeight)
                            } catch (e: Exception) {
                                rawBitmap
                            }

                            if (croppedBitmap.isRecycled) {
                                if (!rawBitmap.isRecycled) {
                                    rawBitmap.recycle()
                                }
                                isOcrProcessing = false
                                return
                            }

                            val inputImage = InputImage.fromBitmap(croppedBitmap, 0)

                            ocrRecognizer.process(inputImage)
                                .addOnSuccessListener { visionText ->
                                    try {
                                        val recognizedText = visionText.text.trim()

                                        if (recognizedText != lastOcrResult) {
                                            lastOcrResult = recognizedText
                                            if (recognizedText.isNotEmpty()) {
                                                LogBuffer.log(this@AutoAcceptService, "OCR", "[OCR]\n$recognizedText")
                                            } else {
                                                LogBuffer.log(this@AutoAcceptService, "OCR", "[OCR] EMPTY")
                                            }
                                        }

                                        if (recognizedText.isNotEmpty() && !rawBitmap.isRecycled) {
                                            handleOcrDecisionAndImageSearch(recognizedText, rawBitmap)
                                        }
                                    } finally {
                                        if (croppedBitmap != rawBitmap && !croppedBitmap.isRecycled) {
                                            croppedBitmap.recycle()
                                        }
                                        if (!rawBitmap.isRecycled) {
                                            rawBitmap.recycle()
                                        }
                                        isOcrProcessing = false
                                    }
                                }
                                .addOnFailureListener { e ->
                                    try {
                                        LogBuffer.log(this@AutoAcceptService, "OCR", "[OCR-ERROR] ${e.message}")
                                    } finally {
                                        if (croppedBitmap != rawBitmap && !croppedBitmap.isRecycled) {
                                            croppedBitmap.recycle()
                                        }
                                        if (!rawBitmap.isRecycled) {
                                            rawBitmap.recycle()
                                        }
                                        isOcrProcessing = false
                                    }
                                }
                        } catch (t: Throwable) {
                            LogBuffer.log(this@AutoAcceptService, "OCR", "[OCR-ERROR] 처리 중 예외: ${t.message}")
                            isOcrProcessing = false
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        LogBuffer.log(this@AutoAcceptService, "OCR", "[OCR-ERROR] 스크린샷 캡처 실패: $errorCode")
                        isOcrProcessing = false
                    }
                }
            )
        } catch (t: Throwable) {
            LogBuffer.log(this, "OCR", "[OCR-ERROR] takeScreenshot 호출 실패: ${t.message}")
            isOcrProcessing = false
        }
    }

    private fun updateForegroundApp(pkgName: String) {
        if (lastForegroundPackage != pkgName) {
            lastForegroundPackage = pkgName
        }
    }

    private fun isTargetPackage(pkgName: String): Boolean {
        if (pkgName.isBlank()) return false
        val myPkg = packageName
        if (pkgName == myPkg || pkgName.startsWith("com.uber.autoaccept")) {
            return false
        }
        val lower = pkgName.lowercase(Locale.ROOT)
        return lower == "com.ubercab.driver" || lower.startsWith("com.ubercab.driver.")
    }

    private fun loadAcceptBtnTemplates() {
        acceptNamedTemplates.clear()
        val templateDefs = listOf(
            Pair("btn_accept_v1_full", R.drawable.btn_accept_v1_full),
            Pair("btn_accept_v2_standard", R.drawable.btn_accept_v2_standard),
            Pair("btn_accept_v3_tight", R.drawable.btn_accept_v3_tight),
            Pair("btn_accept_v4_text", R.drawable.btn_accept_v4_text),
            Pair("btn_accept_v5_wide", R.drawable.btn_accept_v5_wide)
        )
        for ((name, id) in templateDefs) {
            try {
                val bmp = BitmapFactory.decodeResource(resources, id)
                if (bmp != null) acceptNamedTemplates.add(NamedTemplate(name, bmp))
            } catch (_: Exception) {}
        }
    }

    private fun loadXBtnTemplates() {
        dismissNamedTemplates.clear()
        val templateDefs = listOf(
            Pair("btn_dismiss_v1_full", R.drawable.btn_dismiss_v1_full),
            Pair("btn_dismiss_v2_standard", R.drawable.btn_dismiss_v2_standard),
            Pair("btn_dismiss_v3_tight", R.drawable.btn_dismiss_v3_tight),
            Pair("btn_dismiss_v4_icon", R.drawable.btn_dismiss_v4_icon),
            Pair("btn_dismiss_v5_wide", R.drawable.btn_dismiss_v5_wide)
        )
        for ((name, id) in templateDefs) {
            try {
                val bmp = BitmapFactory.decodeResource(resources, id)
                if (bmp != null) dismissNamedTemplates.add(NamedTemplate(name, bmp))
            } catch (_: Exception) {}
        }
    }

    data class TemplateMatchResult(
        val x: Int,
        val y: Int,
        val width: Int,
        val height: Int,
        val score: Float
    )

    private fun findAcceptButtonPoint(bitmap: Bitmap): Point? {
        LogBuffer.log(this, "Accept", "[IMAGE-SEARCH] type=ACCEPT")
        if (acceptNamedTemplates.isEmpty()) {
            loadAcceptBtnTemplates()
        }
        if (acceptNamedTemplates.isEmpty()) {
            LogBuffer.log(this, "Accept", "[IMAGE-NOT-FOUND] type=ACCEPT")
            return null
        }

        val screenW = bitmap.width
        val screenH = bitmap.height
        // 탐색 영역: 화면 하단 영역 (Y: 50% ~ 100%, X: 0% ~ 100%)
        val startY = (screenH * 0.50f).toInt().coerceIn(0, screenH - 1)
        val regionH = screenH - startY

        var bestMatch: TemplateMatchResult? = null

        acceptNamedTemplates.forEach { template ->
            LogBuffer.log(this, "Accept", "[IMAGE-TEMPLATE] ${template.name}")
            val match = matchSingleTemplateInRegion(
                bitmap,
                template.bitmap,
                startX = 0,
                startY = startY,
                regionW = screenW,
                regionH = regionH,
                minScore = 0.65f
            )
            if (match != null) {
                if (bestMatch == null || match.score > bestMatch!!.score) {
                    bestMatch = match
                }
            }
        }

        if (bestMatch != null) {
            val tapX = bestMatch!!.x + bestMatch!!.width / 2
            val tapY = bestMatch!!.y + bestMatch!!.height / 2
            val confStr = String.format(Locale.US, "%.2f", bestMatch!!.score)
            LogBuffer.log(
                this,
                "Accept",
                "[IMAGE-FOUND] type=ACCEPT x=${bestMatch!!.x} y=${bestMatch!!.y} width=${bestMatch!!.width} height=${bestMatch!!.height} confidence=$confStr"
            )
            return Point(tapX, tapY)
        } else {
            LogBuffer.log(this, "Accept", "[IMAGE-NOT-FOUND] type=ACCEPT")
            return null
        }
    }

    private fun findDismissButtonPoint(bitmap: Bitmap): Point? {
        LogBuffer.log(this, "Dismiss", "[IMAGE-SEARCH] type=DISMISS")
        if (dismissNamedTemplates.isEmpty()) {
            loadXBtnTemplates()
        }
        if (dismissNamedTemplates.isEmpty()) {
            LogBuffer.log(this, "Dismiss", "[IMAGE-NOT-FOUND] type=DISMISS")
            return null
        }

        val screenW = bitmap.width
        val screenH = bitmap.height
        // 탐색 영역: 화면 우측 상단/중간 영역 (X: 45% ~ 100%, Y: 10% ~ 70%)
        val startX = (screenW * 0.45f).toInt().coerceIn(0, screenW - 1)
        val regionW = screenW - startX
        val startY = (screenH * 0.10f).toInt().coerceIn(0, screenH - 1)
        val endY = (screenH * 0.70f).toInt().coerceIn(startY + 1, screenH)
        val regionH = endY - startY

        var bestMatch: TemplateMatchResult? = null

        dismissNamedTemplates.forEach { template ->
            LogBuffer.log(this, "Dismiss", "[IMAGE-TEMPLATE] ${template.name}")
            val match = matchSingleTemplateInRegion(
                bitmap,
                template.bitmap,
                startX = startX,
                startY = startY,
                regionW = regionW,
                regionH = regionH,
                minScore = 0.65f
            )
            if (match != null) {
                if (bestMatch == null || match.score > bestMatch!!.score) {
                    bestMatch = match
                }
            }
        }

        if (bestMatch != null) {
            val tapX = bestMatch!!.x + bestMatch!!.width / 2
            val tapY = bestMatch!!.y + bestMatch!!.height / 2
            val confStr = String.format(Locale.US, "%.2f", bestMatch!!.score)
            LogBuffer.log(
                this,
                "Dismiss",
                "[IMAGE-FOUND] type=DISMISS x=${bestMatch!!.x} y=${bestMatch!!.y} width=${bestMatch!!.width} height=${bestMatch!!.height} confidence=$confStr"
            )
            return Point(tapX, tapY)
        } else {
            LogBuffer.log(this, "Dismiss", "[IMAGE-NOT-FOUND] type=DISMISS")
            return null
        }
    }

    private fun matchSingleTemplateInRegion(
        screenBitmap: Bitmap,
        template: Bitmap,
        startX: Int,
        startY: Int,
        regionW: Int,
        regionH: Int,
        minScore: Float
    ): TemplateMatchResult? {
        if (template.isRecycled) return null
        var bestResult: TemplateMatchResult? = null
        var bestScore = minScore

        val scales = floatArrayOf(0.75f, 1.0f, 1.25f, 1.5f)

        for (scale in scales) {
            val tW = (template.width * scale).toInt()
            val tH = (template.height * scale).toInt()
            if (tW <= 0 || tH <= 0 || tW > regionW || tH > regionH) continue

            val scaledTemplate = try {
                if (abs(scale - 1.0f) < 0.01f) template
                else Bitmap.createScaledBitmap(template, tW, tH, true)
            } catch (_: Exception) {
                continue
            }

            val tPixels = IntArray(tW * tH)
            scaledTemplate.getPixels(tPixels, 0, tW, 0, 0, tW, tH)

            var validPixelCount = 0
            for (p in tPixels) {
                if ((p ushr 24) > 128) validPixelCount++
            }
            if (validPixelCount == 0) {
                if (scaledTemplate != template && !scaledTemplate.isRecycled) {
                    scaledTemplate.recycle()
                }
                continue
            }

            val step = if (tW > 100 || tH > 100) 4 else 2
            val maxScanX = startX + regionW - tW
            val maxScanY = startY + regionH - tH

            val sPixels = IntArray(tW * tH)

            for (sy in startY..maxScanY step step) {
                for (sx in startX..maxScanX step step) {
                    try {
                        screenBitmap.getPixels(sPixels, 0, tW, sx, sy, tW, tH)
                    } catch (_: Exception) {
                        continue
                    }

                    var matchedPixels = 0
                    for (i in 0 until validPixelCount) {
                        val tp = tPixels[i]
                        if ((tp ushr 24) <= 128) continue
                        val sp = sPixels[i]

                        val tr = (tp shr 16) and 0xFF
                        val tg = (tp shr 8) and 0xFF
                        val tb = tp and 0xFF

                        val sr = (sp shr 16) and 0xFF
                        val sg = (sp shr 8) and 0xFF
                        val sb = sp and 0xFF

                        val diff = abs(tr - sr) + abs(tg - sg) + abs(tb - sb)
                        if (diff < 90) {
                            matchedPixels++
                        }
                    }

                    val score = matchedPixels.toFloat() / validPixelCount.toFloat()
                    if (score > bestScore) {
                        bestScore = score
                        bestResult = TemplateMatchResult(
                            x = sx,
                            y = sy,
                            width = tW,
                            height = tH,
                            score = score
                        )
                    }
                }
            }

            if (scaledTemplate != template && !scaledTemplate.isRecycled) {
                scaledTemplate.recycle()
            }

            if (bestScore > 0.90f) {
                break
            }
        }

        return bestResult
    }

    private fun handleOcrDecisionAndImageSearch(recognizedText: String, fullBitmap: Bitmap) {
        if (isAcceptingInProgress || isDismissingInProgress) return

        val shouldAccept = evaluateDecision(recognizedText)
        val isAutoDismiss = PrefsManager.isAutoDismiss(this)

        if (shouldAccept) {
            val now = System.currentTimeMillis()
            if (now - lastActionTime < ACTION_COOLDOWN_MS) {
                return
            }

            val acceptPoint = findAcceptButtonPoint(fullBitmap)
            if (acceptPoint != null) {
                lastActionTime = System.currentTimeMillis()
                isAcceptingInProgress = true
                PrefsManager.incrementAcceptScheduled(this)

                val delay = if (PrefsManager.isAcceptNoDelay(this)) 0L else nextHumanDelay()
                mainHandler.postDelayed({
                    try {
                        LogBuffer.log(
                            this@AutoAcceptService,
                            "Accept",
                            "[IMAGE-TAP]\ntype=ACCEPT\nx=${acceptPoint.x}\ny=${acceptPoint.y}"
                        )
                        val fx = acceptPoint.x.toFloat()
                        val fy = acceptPoint.y.toFloat()
                        dispatchTapGesture(fx, fy)
                        shizukuTap(acceptPoint.x, acceptPoint.y)
                        showTapIndicator(acceptPoint.x, acceptPoint.y, true)
                        PrefsManager.incrementAcceptCount(this@AutoAcceptService)

                        if (PrefsManager.isVibration(this@AutoAcceptService)) vibrate()
                        if (PrefsManager.isSleepAlarm(this@AutoAcceptService)) triggerSleepAlarm()
                        takeScreenshotAndSave(true)

                        val intent = Intent("com.uber.autoaccept.ACCEPT_EVENT")
                        sendBroadcast(intent)
                    } finally {
                        mainHandler.postDelayed({ isAcceptingInProgress = false }, 1000L)
                    }
                }, delay)
            }
        } else if (isAutoDismiss) {
            val now = System.currentTimeMillis()
            val cooldown = PrefsManager.getDismissCooldownMs(this).coerceAtLeast(ACTION_COOLDOWN_MS)
            if (now - lastActionTime < cooldown) {
                return
            }

            val dismissPoint = findDismissButtonPoint(fullBitmap)
            if (dismissPoint != null) {
                lastActionTime = System.currentTimeMillis()
                isDismissingInProgress = true
                PrefsManager.incrementDismissScheduled(this)

                mainHandler.postDelayed({
                    try {
                        LogBuffer.log(
                            this@AutoAcceptService,
                            "Dismiss",
                            "[IMAGE-TAP]\ntype=DISMISS\nx=${dismissPoint.x}\ny=${dismissPoint.y}"
                        )
                        val fx = dismissPoint.x.toFloat()
                        val fy = dismissPoint.y.toFloat()
                        dispatchTapGesture(fx, fy)
                        shizukuTap(dismissPoint.x, dismissPoint.y)
                        showTapIndicator(dismissPoint.x, dismissPoint.y, false)
                        lastDismissTime = System.currentTimeMillis()
                        PrefsManager.incrementDismissExecuted(this@AutoAcceptService)
                        PrefsManager.incrementDismissCount(this@AutoAcceptService)
                        takeScreenshotAndSave(false)
                    } finally {
                        mainHandler.postDelayed({ isDismissingInProgress = false }, 500L)
                    }
                }, 200L)
            }
        }
    }

    private fun evaluateDecision(text: String): Boolean {
        if (PrefsManager.isAcceptAll(this)) {
            return true
        }

        if (PrefsManager.isAirportMode(this)) {
            return AIRPORT_KEYWORDS.any { text.contains(it, ignoreCase = true) }
        }

        val keywords = PrefsManager.getKeywords(this)
        if (keywords.isEmpty()) {
            return false
        }

        val matched = keywords.any { text.contains(it, ignoreCase = true) }

        return if (PrefsManager.isBlacklistMode(this)) {
            !matched
        } else {
            matched
        }
    }

    private fun dispatchTapGesture(x: Float, y: Float) {
        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    private fun shizukuTap(x: Int, y: Int): Boolean {
        return try {
            if (Shizuku.pingBinder()) {
                shizukuExecutor.execute {
                    try {
                        val method = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
                        method.isAccessible = true
                        val process = method.invoke(null, arrayOf("input", "tap", x.toString(), y.toString()), null, null) as? Process
                        process?.waitFor()
                    } catch (_: Exception) {}
                }
                true
            } else false
        } catch (_: Throwable) {
            false
        }
    }

    private fun showTapIndicator(x: Int, y: Int, isAccept: Boolean) {
        val colorName = if (isAccept) "GREEN" else "RED"
        val logType = if (isAccept) "ACCEPT" else "DISMISS"
        LogBuffer.log(
            this,
            if (isAccept) "Accept" else "Dismiss",
            "[TAP-INDICATOR]\ntype=$logType\ncolor=$colorName\nx=$x\ny=$y"
        )

        mainHandler.post {
            try {
                val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val size = dp(44)
                val primaryColor = if (isAccept) Color.parseColor("#00E676") else Color.parseColor("#FF1744")
                val fillColor = if (isAccept) Color.parseColor("#5500E676") else Color.parseColor("#55FF1744")

                val view = View(this).apply {
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(fillColor)
                        setStroke(dp(3), primaryColor)
                    }
                }

                val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    @Suppress("DEPRECATION")
                    WindowManager.LayoutParams.TYPE_PHONE
                }

                val params = WindowManager.LayoutParams(
                    size,
                    size,
                    layoutType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    this.x = x - size / 2
                    this.y = y - size / 2
                }

                wm.addView(view, params)
                mainHandler.postDelayed({
                    try {
                        wm.removeView(view)
                    } catch (_: Exception) {}
                }, 1000L)
            } catch (_: Exception) {}
        }
    }

    private fun nextHumanDelay(): Long {
        if (!PrefsManager.isHumanMode(this)) return 0L
        val min = PrefsManager.getMinDelayMs(this)
        val max = PrefsManager.getMaxDelayMs(this)
        return gaussianDelay(min, max, 100L, 5000L)
    }

    private fun gaussianDelay(minMs: Long, maxMs: Long, floorMs: Long, ceilMs: Long): Long {
        if (maxMs <= minMs) return minMs
        val mean = (minMs + maxMs) / 2.0
        val stdDev = (maxMs - minMs) / 4.0
        val sample = mean + random.nextGaussian() * stdDev
        return sample.toLong().coerceIn(floorMs, ceilMs)
    }

    private fun vibrate() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v?.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v?.vibrate(150)
                }
            }
        } catch (_: Exception) {}
    }

    private fun triggerSleepAlarm() {
        try {
            SleepAlarmManager.startAlarm(this)
        } catch (_: Exception) {}
    }

    private fun takeScreenshotAndSave(isAccept: Boolean) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        try {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                applicationContext.mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        try {
                            val bitmap = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
                                ?.copy(Bitmap.Config.ARGB_8888, true)
                            screenshot.hardwareBuffer.close()
                            if (bitmap != null) {
                                saveScreenshotToGallery(bitmap, isAccept)
                            }
                        } catch (_: Throwable) {}
                    }
                    override fun onFailure(errorCode: Int) {}
                }
            )
        } catch (_: Throwable) {}
    }

    private fun saveScreenshotToGallery(bitmap: Bitmap, isAccept: Boolean) {
        try {
            val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.KOREA)
            val prefix = if (isAccept) "ACCEPT" else "DISMISS"
            val fileName = "${prefix}_${sdf.format(Date())}.jpg"

            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_DCIM}/스마트알림")
                }
            }

            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
                }
                LogBuffer.log(this, "Screenshot", "스크린샷 저장됨: $fileName")
            }
        } catch (e: Exception) {
            Log.e(TAG, "스크린샷 저장 오류: ${e.message}")
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
