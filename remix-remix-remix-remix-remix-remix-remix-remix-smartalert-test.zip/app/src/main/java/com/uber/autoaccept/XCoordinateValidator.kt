package com.uber.autoaccept

import android.content.Context
import android.graphics.Rect
import android.os.Build
import android.os.SystemClock
import android.util.Log
import android.view.WindowManager
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max

/**
 * X 좌표 Dynamic WindowMetrics 및 검증 모듈
 *
 * 1. WindowMetrics / Root Window Bounds 기반 동적 화면 상한(realMaxX, realMaxY) 계산 (하드코딩 없음)
 * 2. Fold7/Android 16 동적 화면 좌표계 보정 지원
 */
object XCoordinateValidator {

    private const val TAG = "XCoordinateValidator"
    private val callCounter = AtomicInteger(0)

    enum class CardType {
        NORMAL, OVERLAY_LARGE, UNKNOWN
    }

    data class ValidationResult(
        val callNumber: Int,
        val cardType: CardType,
        val finalTarget: Pair<Int, Int>?,
        val finalSource: String,
        val cardBounds: Rect?,
        val nodeBounds: Rect?,
        val realMaxX: Int,
        val realMaxY: Int,
        val blockedReason: String? = null,
        val cardDetectedMs: Long = 0L,
        val totalUs: Long = 0L
    )

    fun getDynamicScreenBounds(
        service: AutoAcceptService,
        root: AccessibilityNodeInfo?,
        cardBounds: Rect?
    ): Pair<Int, Int> {
        val dm = service.resources.displayMetrics
        var dynamicMaxW = dm.widthPixels
        var dynamicMaxH = dm.heightPixels

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val wm = service.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
                val bounds = wm?.maximumWindowMetrics?.bounds
                if (bounds != null && !bounds.isEmpty) {
                    dynamicMaxW = max(dynamicMaxW, bounds.right)
                    dynamicMaxH = max(dynamicMaxH, bounds.bottom)
                }
            } catch (_: Throwable) {}
        }

        val rootBounds = Rect()
        if (root != null) {
            try {
                root.getBoundsInScreen(rootBounds)
                if (!rootBounds.isEmpty) {
                    dynamicMaxW = max(dynamicMaxW, rootBounds.right)
                    dynamicMaxH = max(dynamicMaxH, rootBounds.bottom)
                }
            } catch (_: Throwable) {}
        }

        if (cardBounds != null && !cardBounds.isEmpty) {
            dynamicMaxW = max(dynamicMaxW, cardBounds.right)
            dynamicMaxH = max(dynamicMaxH, cardBounds.bottom)
        }

        return Pair(dynamicMaxW, dynamicMaxH)
    }
}
