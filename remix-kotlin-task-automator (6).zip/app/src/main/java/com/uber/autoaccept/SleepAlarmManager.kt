package com.uber.autoaccept

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.util.Log

object SleepAlarmManager {
    private const val TAG = "SleepAlarmManager"
    private var mediaPlayer: MediaPlayer? = null
    private val lock = Any()

    @Synchronized
    fun startAlarm(context: Context) {
        synchronized(lock) {
            try {
                if (mediaPlayer != null) {
                    if (mediaPlayer?.isPlaying == true) {
                        Log.d(TAG, "Sleep alarm is already playing")
                        return
                    } else {
                        stopAlarmInternal()
                    }
                }

                val appContext = context.applicationContext
                val player = MediaPlayer()

                val audioAttributes = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setLegacyStreamType(AudioManager.STREAM_ALARM)
                    .build()
                player.setAudioAttributes(audioAttributes)

                var sourceSet = false
                try {
                    val afd = appContext.resources.openRawResourceFd(R.raw.sleep_alarm_bugle)
                    player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                    afd.close()
                    sourceSet = true
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to load sleep_alarm_bugle raw resource: ${e.message}")
                }

                if (!sourceSet) {
                    val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    if (uri != null) {
                        player.setDataSource(appContext, uri)
                        sourceSet = true
                    }
                }

                if (!sourceSet) {
                    Log.e(TAG, "No valid audio source found for sleep alarm")
                    player.release()
                    return
                }

                player.isLooping = true
                player.setOnErrorListener { _, what, extra ->
                    Log.e(TAG, "MediaPlayer error: what=$what, extra=$extra")
                    stopAlarmInternal()
                    true
                }

                player.prepare()
                player.start()
                mediaPlayer = player
                LogBuffer.log(appContext, "SleepAlarm", "수면모드 기상나팔 알람 시작 (무한 반복)")
            } catch (e: Exception) {
                Log.e(TAG, "Error starting sleep alarm: ${e.message}", e)
                stopAlarmInternal()
            }
        }
    }

    @Synchronized
    fun stopAlarm() {
        synchronized(lock) {
            stopAlarmInternal()
        }
    }

    private fun stopAlarmInternal() {
        try {
            mediaPlayer?.let { player ->
                if (player.isPlaying) {
                    player.stop()
                }
                player.reset()
                player.release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping sleep alarm: ${e.message}")
        } finally {
            mediaPlayer = null
        }
    }

    fun isPlaying(): Boolean {
        synchronized(lock) {
            return try {
                mediaPlayer?.isPlaying == true
            } catch (_: Exception) {
                false
            }
        }
    }
}
