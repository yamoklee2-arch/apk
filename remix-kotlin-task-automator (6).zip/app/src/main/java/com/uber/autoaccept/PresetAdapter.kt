package com.uber.autoaccept

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PresetAdapter(
    private val items: List<KeywordPreset>,
    private val onApply: (Int) -> Unit,
    private val onEdit: (Int) -> Unit,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<PresetAdapter.VH>() {

    inner class VH(val row: LinearLayout) : RecyclerView.ViewHolder(row) {
        val tvName: TextView = row.findViewWithTag("name")
        val tvKeywords: TextView = row.findViewWithTag("keywords")
        val btnApply: Button = row.findViewWithTag("apply")
        val btnEdit: Button = row.findViewWithTag("edit")
        val btnDel: Button = row.findViewWithTag("delete")
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val context = parent.context
        fun dp(v: Int): Int = (v * context.resources.displayMetrics.density).toInt()

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(8)
            }
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#070D18"))
                setStroke(dp(1), Color.parseColor("#152238"))
                cornerRadius = dp(10).toFloat()
            }
            setPadding(dp(14), dp(10), dp(10), dp(10))
        }

        val textCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                rightMargin = dp(8)
            }
        }

        val tvName = TextView(context).apply {
            tag = "name"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 14.5f
            setTypeface(typeface, Typeface.BOLD)
        }
        textCol.addView(tvName)

        val tvKeywords = TextView(context).apply {
            tag = "keywords"
            setTextColor(Color.parseColor("#8E9CAE"))
            textSize = 12f
        }
        textCol.addView(tvKeywords)
        row.addView(textCol)

        val btnApply = Button(context).apply {
            tag = "apply"
            text = "적용"
            setTextColor(Color.parseColor("#06C167"))
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#072A1C"))
                setStroke(dp(1), Color.parseColor("#06C167"))
                cornerRadius = dp(8).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(32)).apply {
                rightMargin = dp(4)
            }
            setPadding(0, 0, 0, 0)
        }
        row.addView(btnApply)

        val btnEdit = Button(context).apply {
            tag = "edit"
            text = "수정"
            setTextColor(Color.parseColor("#38BDF8"))
            textSize = 12f
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#0A2540"))
                setStroke(dp(1), Color.parseColor("#0284C7"))
                cornerRadius = dp(8).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(32)).apply {
                rightMargin = dp(4)
            }
            setPadding(0, 0, 0, 0)
        }
        row.addView(btnEdit)

        val btnDel = Button(context).apply {
            tag = "delete"
            text = "✕"
            setTextColor(Color.parseColor("#F87171"))
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#251118"))
                setStroke(dp(1), Color.parseColor("#DC2626"))
                cornerRadius = dp(8).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(dp(32), dp(32))
            setPadding(0, 0, 0, 0)
        }
        row.addView(btnDel)

        return VH(row)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.tvName.text = item.name
        holder.tvKeywords.text = if (item.keywords.isEmpty()) "키워드 없음" else item.keywords.joinToString(", ")

        holder.btnApply.setOnClickListener {
            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_POSITION) onApply(pos)
        }
        holder.btnEdit.setOnClickListener {
            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_POSITION) onEdit(pos)
        }
        holder.btnDel.setOnClickListener {
            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_POSITION) onDelete(pos)
        }
    }

    override fun getItemCount(): Int = items.size
}
