package com.uber.autoaccept

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Rect
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object PrefsManager {
    private const val PREFS_NAME = "auto_accept_prefs"
    private const val KEY_IS_ACTIVE = "is_active"
    private const val KEY_KEYWORDS = "keywords"
    private const val KEY_MIN_DELAY_MS = "min_delay_ms"
    private const val KEY_MAX_DELAY_MS = "max_delay_ms"
    private const val KEY_HUMAN_MODE = "human_mode"
    private const val KEY_MICRO_VARIANCE = "micro_variance"
    private const val KEY_VIBRATION = "vibration"
    private const val KEY_ACCEPT_ALL = "accept_all"
    private const val KEY_AUTO_DISMISS = "auto_dismiss"
    private const val KEY_DISMISS_COOLDOWN_MS = "dismiss_cooldown_ms"
    private const val KEY_AIRPORT_MODE = "airport_mode"
    private const val KEY_BLACKLIST_MODE = "blacklist_mode"
    private const val KEY_FLOATING_BUBBLE = "floating_bubble"
    private const val KEY_SLEEP_ALARM = "sleep_alarm"
    private const val KEY_OCR_POLL = "ocr_poll"
    private const val KEY_ACCEPT_SCREENSHOT = "accept_screenshot"
    private const val KEY_ACCEPT_NO_DELAY = "accept_no_delay"
    private const val KEY_KEYWORD_PRESETS = "keyword_presets"
    private const val KEY_ACCEPT_COUNT = "accept_count"
    private const val KEY_EVENT_COUNT = "event_count"
    private const val KEY_CALL_COUNT = "call_count"
    private const val KEY_DISMISS_COUNT = "dismiss_count"
    private const val KEY_ACCEPT_SCHEDULED = "accept_scheduled"
    private const val KEY_DISMISS_SCHEDULED = "dismiss_scheduled"
    private const val KEY_DISMISS_EXECUTED = "dismiss_executed"
    private const val KEY_LAST_ACCEPT_RECT = "last_accept_rect"
    private const val KEY_DISMISS_DIAG = "dismiss_diag"

    private val gson = Gson()

    private fun prefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun isActive(context: Context): Boolean = prefs(context).getBoolean(KEY_IS_ACTIVE, false)
    fun setActive(context: Context, active: Boolean) = prefs(context).edit().putBoolean(KEY_IS_ACTIVE, active).apply()

    fun getKeywords(context: Context): List<String> {
        val json = prefs(context).getString(KEY_KEYWORDS, null) ?: return emptyList()
        val type = object : TypeToken<List<String>>() {}.type
        return gson.fromJson(json, type) ?: emptyList()
    }

    fun saveKeywords(context: Context, keywords: List<String>) {
        val json = gson.toJson(keywords)
        prefs(context).edit().putString(KEY_KEYWORDS, json).apply()
    }

    fun getPresets(context: Context): List<KeywordPreset> {
        val json = prefs(context).getString(KEY_KEYWORD_PRESETS, null) ?: return emptyList()
        val type = object : TypeToken<List<KeywordPreset>>() {}.type
        return gson.fromJson(json, type) ?: emptyList()
    }

    fun savePresets(context: Context, presets: List<KeywordPreset>) {
        val json = gson.toJson(presets)
        prefs(context).edit().putString(KEY_KEYWORD_PRESETS, json).apply()
    }

    fun getMinDelayMs(context: Context): Long = prefs(context).getLong(KEY_MIN_DELAY_MS, 1000L)
    fun getMaxDelayMs(context: Context): Long = prefs(context).getLong(KEY_MAX_DELAY_MS, 3000L)
    fun setDelays(context: Context, min: Long, max: Long) {
        prefs(context).edit().putLong(KEY_MIN_DELAY_MS, min).putLong(KEY_MAX_DELAY_MS, max).apply()
    }

    fun getDismissCooldownMs(context: Context): Long = prefs(context).getLong(KEY_DISMISS_COOLDOWN_MS, 1500L)
    fun setDismissCooldownMs(context: Context, cooldown: Long) {
        prefs(context).edit().putLong(KEY_DISMISS_COOLDOWN_MS, cooldown).apply()
    }

    fun isHumanMode(context: Context): Boolean = prefs(context).getBoolean(KEY_HUMAN_MODE, true)
    fun setHumanMode(context: Context, value: Boolean) = prefs(context).edit().putBoolean(KEY_HUMAN_MODE, value).apply()

    fun isMicroVariance(context: Context): Boolean = prefs(context).getBoolean(KEY_MICRO_VARIANCE, true)
    fun setMicroVariance(context: Context, value: Boolean) = prefs(context).edit().putBoolean(KEY_MICRO_VARIANCE, value).apply()

    fun isVibration(context: Context): Boolean = prefs(context).getBoolean(KEY_VIBRATION, true)
    fun setVibration(context: Context, value: Boolean) = prefs(context).edit().putBoolean(KEY_VIBRATION, value).apply()

    fun isAcceptAll(context: Context): Boolean = prefs(context).getBoolean(KEY_ACCEPT_ALL, false)
    fun setAcceptAll(context: Context, value: Boolean) = prefs(context).edit().putBoolean(KEY_ACCEPT_ALL, value).apply()

    fun isAutoDismiss(context: Context): Boolean = prefs(context).getBoolean(KEY_AUTO_DISMISS, false)
    fun setAutoDismiss(context: Context, value: Boolean) = prefs(context).edit().putBoolean(KEY_AUTO_DISMISS, value).apply()

    fun isAirportMode(context: Context): Boolean = prefs(context).getBoolean(KEY_AIRPORT_MODE, false)
    fun saveAirportMode(context: Context, value: Boolean) = prefs(context).edit().putBoolean(KEY_AIRPORT_MODE, value).apply()

    fun isBlacklistMode(context: Context): Boolean = prefs(context).getBoolean(KEY_BLACKLIST_MODE, false)
    fun saveBlacklistMode(context: Context, value: Boolean) = prefs(context).edit().putBoolean(KEY_BLACKLIST_MODE, value).apply()

    fun isFloatingBubble(context: Context): Boolean = prefs(context).getBoolean(KEY_FLOATING_BUBBLE, false)
    fun saveFloatingBubble(context: Context, value: Boolean) = prefs(context).edit().putBoolean(KEY_FLOATING_BUBBLE, value).apply()

    fun isSleepAlarm(context: Context): Boolean = prefs(context).getBoolean(KEY_SLEEP_ALARM, false)
    fun saveSleepAlarm(context: Context, value: Boolean) = prefs(context).edit().putBoolean(KEY_SLEEP_ALARM, value).apply()

    fun isOcrPoll(context: Context): Boolean = prefs(context).getBoolean(KEY_OCR_POLL, false)
    fun saveOcrPoll(context: Context, value: Boolean) = prefs(context).edit().putBoolean(KEY_OCR_POLL, value).apply()

    fun isAcceptScreenshot(context: Context): Boolean = prefs(context).getBoolean(KEY_ACCEPT_SCREENSHOT, false)
    fun saveAcceptScreenshot(context: Context, value: Boolean) = prefs(context).edit().putBoolean(KEY_ACCEPT_SCREENSHOT, value).apply()

    fun isAcceptNoDelay(context: Context): Boolean = prefs(context).getBoolean(KEY_ACCEPT_NO_DELAY, false)
    fun saveAcceptNoDelay(context: Context, value: Boolean) = prefs(context).edit().putBoolean(KEY_ACCEPT_NO_DELAY, value).apply()

    fun getAcceptCount(context: Context): Int = prefs(context).getInt(KEY_ACCEPT_COUNT, 0)
    fun incrementAcceptCount(context: Context): Int {
        val count = getAcceptCount(context) + 1
        prefs(context).edit().putInt(KEY_ACCEPT_COUNT, count).apply()
        return count
    }

    fun getEventCount(context: Context): Int = prefs(context).getInt(KEY_EVENT_COUNT, 0)
    fun incrementEventCount(context: Context, delta: Int = 1) {
        val count = getEventCount(context) + delta
        prefs(context).edit().putInt(KEY_EVENT_COUNT, count).apply()
    }

    fun getCallCount(context: Context): Int = prefs(context).getInt(KEY_CALL_COUNT, 0)
    fun incrementCallCount(context: Context) {
        val count = getCallCount(context) + 1
        prefs(context).edit().putInt(KEY_CALL_COUNT, count).apply()
    }

    fun getDismissCount(context: Context): Int = prefs(context).getInt(KEY_DISMISS_COUNT, 0)
    fun incrementDismissCount(context: Context) {
        val count = getDismissCount(context) + 1
        prefs(context).edit().putInt(KEY_DISMISS_COUNT, count).apply()
    }

    fun getAcceptScheduled(context: Context): Int = prefs(context).getInt(KEY_ACCEPT_SCHEDULED, 0)
    fun incrementAcceptScheduled(context: Context) {
        val count = getAcceptScheduled(context) + 1
        prefs(context).edit().putInt(KEY_ACCEPT_SCHEDULED, count).apply()
    }

    fun getDismissScheduled(context: Context): Int = prefs(context).getInt(KEY_DISMISS_SCHEDULED, 0)
    fun incrementDismissScheduled(context: Context) {
        val count = getDismissScheduled(context) + 1
        prefs(context).edit().putInt(KEY_DISMISS_SCHEDULED, count).apply()
    }

    fun getDismissExecuted(context: Context): Int = prefs(context).getInt(KEY_DISMISS_EXECUTED, 0)
    fun incrementDismissExecuted(context: Context) {
        val count = getDismissExecuted(context) + 1
        prefs(context).edit().putInt(KEY_DISMISS_EXECUTED, count).apply()
    }

    fun getLastAcceptRectString(context: Context): String = prefs(context).getString(KEY_LAST_ACCEPT_RECT, "미감지") ?: "미감지"
    fun saveLastAcceptRect(context: Context, l: Int, t: Int, r: Int, b: Int) {
        prefs(context).edit().putString(KEY_LAST_ACCEPT_RECT, "$l,$t,$r,$b").apply()
    }

    fun loadLastAcceptRect(context: Context): Rect? {
        val str = prefs(context).getString(KEY_LAST_ACCEPT_RECT, null) ?: return null
        return try {
            val parts = str.split(",")
            if (parts.size == 4) {
                Rect(parts[0].toInt(), parts[1].toInt(), parts[2].toInt(), parts[3].toInt())
            } else null
        } catch (_: Exception) {
            null
        }
    }

    fun getDismissDiag(context: Context): String = prefs(context).getString(KEY_DISMISS_DIAG, "아직 닫기 시도 없음") ?: "아직 닫기 시도 없음"
    fun saveDismissDiag(context: Context, diag: String) {
        prefs(context).edit().putString(KEY_DISMISS_DIAG, diag).apply()
    }

    fun resetCounts(context: Context) {
        prefs(context).edit()
            .putInt(KEY_ACCEPT_COUNT, 0)
            .putInt(KEY_EVENT_COUNT, 0)
            .putInt(KEY_CALL_COUNT, 0)
            .putInt(KEY_DISMISS_COUNT, 0)
            .putInt(KEY_ACCEPT_SCHEDULED, 0)
            .putInt(KEY_DISMISS_SCHEDULED, 0)
            .putInt(KEY_DISMISS_EXECUTED, 0)
            .remove(KEY_LAST_ACCEPT_RECT)
            .apply()
    }
}
