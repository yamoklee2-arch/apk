package com.uber.autoaccept

data class KeywordPreset(
    val name: String,
    val keywords: List<String>
)
