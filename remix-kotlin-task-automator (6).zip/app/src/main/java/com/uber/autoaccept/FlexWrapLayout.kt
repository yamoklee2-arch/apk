package com.uber.autoaccept

import android.content.Context
import android.view.ViewGroup
import kotlin.math.max

class FlexWrapLayout(context: Context) : ViewGroup(context) {
    private val gap: Int = (8 * resources.displayMetrics.density).toInt()

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val maxWidth = MeasureSpec.getSize(widthSpec)
        var x = 0
        var y = 0
        var rowH = 0
        val count = childCount
        for (i in 0 until count) {
            val child = getChildAt(i)
            child.measure(0, 0)
            if (x + child.measuredWidth > maxWidth && x > 0) {
                x = 0
                y += gap + rowH
                rowH = 0
            }
            x += child.measuredWidth + gap
            rowH = max(rowH, child.measuredHeight)
        }
        setMeasuredDimension(maxWidth, y + rowH + gap)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val maxWidth = r - l
        var x = 0
        var y = 0
        var rowH = 0
        val count = childCount
        for (i in 0 until count) {
            val child = getChildAt(i)
            if (x + child.measuredWidth > maxWidth && x > 0) {
                x = 0
                y += gap + rowH
                rowH = 0
            }
            child.layout(x, y, x + child.measuredWidth, y + child.measuredHeight)
            x += child.measuredWidth + gap
            rowH = max(rowH, child.measuredHeight)
        }
    }
}
