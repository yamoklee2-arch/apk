package com.uber.autoaccept

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class NotificationListener : NotificationListenerService() {

    companion object {
        var lastCallText: String = ""
            private set
        var lastCallTextTime: Long = 0L
            private set
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != "com.ubercab.driver") return
        val extras = sbn.notification?.extras ?: return

        val title = extras.getCharSequence("android.title")?.toString() ?: ""
        val text = extras.getCharSequence("android.text")?.toString() ?: ""
        val bigText = extras.getCharSequence("android.bigText")?.toString() ?: ""

        val combined = listOf(title, text, bigText)
            .filter { it.isNotBlank() }
            .joinToString(" ")

        if (combined.isNotBlank()) {
            lastCallText = combined
            lastCallTextTime = System.currentTimeMillis()
            Log.d("UberAutoAccept", "Uber 알림 수신: $combined")
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.packageName == "com.ubercab.driver") {
            Log.d("UberAutoAccept", "Uber 알림 제거됨")
        }
    }
}
