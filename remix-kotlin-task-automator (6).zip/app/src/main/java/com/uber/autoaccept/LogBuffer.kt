package com.uber.autoaccept

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

object LogBuffer {
    private const val MAX_LOG_SIZE = 3000000L // ~3MB
    private val lock = Any()
    private val logExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    fun log(context: Context, tag: String, message: String) {
        if (message.isEmpty()) return
        logExecutor.execute {
            synchronized(lock) {
                try {
                    val sdf = SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.KOREA)
                    val time = sdf.format(Date())
                    val line = "[$time][$tag] $message\n"
                    val file = File(context.filesDir, "app_log.txt")
                    if (file.parentFile?.exists() == false) {
                        file.parentFile?.mkdirs()
                    }
                    if (!file.exists()) {
                        file.createNewFile()
                    }
                    if (file.length() > MAX_LOG_SIZE) {
                        val text = file.readText()
                        file.writeText(text.substring(text.length / 2))
                    }
                    file.appendText(line)
                } catch (e: Exception) {
                    Log.e("UberAutoAccept", "LogBuffer 쓰기 오류: ${e.javaClass.simpleName} — ${e.message}")
                }
            }
        }
    }

    fun read(context: Context): String {
        return try {
            File(context.filesDir, "app_log.txt").readText()
        } catch (_: Exception) {
            ""
        }
    }

    fun clear(context: Context) {
        synchronized(lock) {
            try {
                File(context.filesDir, "app_log.txt").delete()
            } catch (_: Exception) {
            }
        }
    }
}
