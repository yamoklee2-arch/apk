package com.uber.autoaccept

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class KeywordAdapter(
    private val items: List<String>,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<KeywordAdapter.VH>() {

    inner class VH(val row: LinearLayout) : RecyclerView.ViewHolder(row) {
        val tvText: TextView = row.findViewWithTag("text")
        val btnDel: Button = row.findViewWithTag("delete")
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val context = parent.context
        fun dp(v: Int): Int = (v * context.resources.displayMetrics.density).toInt()

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(6)
            }
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#070D18"))
                setStroke(dp(1), Color.parseColor("#152238"))
                cornerRadius = dp(10).toFloat()
            }
            setPadding(dp(14), dp(8), dp(10), dp(8))
        }

        val tv = TextView(context).apply {
            tag = "text"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        row.addView(tv)

        val btn = Button(context).apply {
            tag = "delete"
            text = "✕"
            setTextColor(Color.parseColor("#F87171"))
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#251118"))
                setStroke(dp(1), Color.parseColor("#DC2626"))
                cornerRadius = dp(8).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(dp(32), dp(32))
            setPadding(0, 0, 0, 0)
        }
        row.addView(btn)

        return VH(row)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.tvText.text = items[position]
        holder.btnDel.setOnClickListener {
            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                onDelete(pos)
            }
        }
    }

    override fun getItemCount(): Int = items.size
}
