package com.uber.autoaccept

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED || action == "android.intent.action.QUICKBOOT_POWERON") {
            val active = PrefsManager.isActive(context)
            Log.d("BootReceiver", "기기 부팅 완료 - 자동 수락 상태: $active")
        }
    }
}
