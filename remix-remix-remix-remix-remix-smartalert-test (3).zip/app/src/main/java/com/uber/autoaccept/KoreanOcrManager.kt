package com.uber.autoaccept

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.Log
import com.google.android.gms.common.moduleinstall.InstallStatusListener
import com.google.android.gms.common.moduleinstall.ModuleInstall
import com.google.android.gms.common.moduleinstall.ModuleInstallRequest
import com.google.android.gms.common.moduleinstall.ModuleInstallStatusUpdate
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions

object KoreanOcrManager {
    private const val TAG = "KoreanOcrManager"

    enum class OcrState {
        INITIALIZING,
        MODULE_INSTALL_REQUESTED,
        MODULE_DOWNLOADING,
        MODULE_INSTALLING,
        MODULE_READY,
        DETECTOR_INITIALIZING,
        OCR_READY,
        DETECTOR_INIT_FAILED,
        MODULE_INSTALL_FAILED,
        RETRY_WAIT
    }

    @Volatile
    var currentState: OcrState = OcrState.INITIALIZING
        private set

    @Volatile
    var recognizer: TextRecognizer? = null
        private set

    @Volatile
    private var isInstalling: Boolean = false

    private var lastFailTime: Long = 0L
    private const val RETRY_COOLDOWN_MS = 15000L

    private val listeners = mutableListOf<(OcrState, String) -> Unit>()

    fun addStateListener(listener: (OcrState, String) -> Unit) {
        synchronized(listeners) {
            listeners.add(listener)
            listener(currentState, "")
        }
    }

    private fun setState(state: OcrState, msg: String, context: Context? = null) {
        currentState = state
        LogBuffer.log(context, "KoreanOcrManager", "[ML-KIT-STATE] $state - $msg")
        synchronized(listeners) {
            listeners.forEach { it(state, msg) }
        }
    }

    @Synchronized
    fun ensureInitialized(context: Context, onComplete: ((Boolean) -> Unit)? = null) {
        val now = System.currentTimeMillis()
        if (currentState == OcrState.OCR_READY && recognizer != null) {
            onComplete?.invoke(true)
            return
        }

        if (isInstalling) {
            Log.d(TAG, "GMS 모듈 설치 진행 중 - 중복 요청 방지")
            onComplete?.invoke(false)
            return
        }

        if (currentState == OcrState.MODULE_INSTALL_FAILED || currentState == OcrState.DETECTOR_INIT_FAILED) {
            if (now - lastFailTime < RETRY_COOLDOWN_MS) {
                setState(OcrState.RETRY_WAIT, "재시도 쿨다운 중 (${(RETRY_COOLDOWN_MS - (now - lastFailTime)) / 1000}초 남음)", context)
                onComplete?.invoke(false)
                return
            }
        }

        setState(OcrState.INITIALIZING, "GMS 한국어 OCR 모듈 가용성 확인 시작", context)

        try {
            val moduleInstallClient = ModuleInstall.getClient(context.applicationContext)
            val optionalApi = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())

            val statusListener = object : InstallStatusListener {
                override fun onInstallStatusUpdated(update: ModuleInstallStatusUpdate) {
                    when (update.installState) {
                        ModuleInstallStatusUpdate.InstallState.STATE_DOWNLOADING -> {
                            val progress = update.progressInfo?.let {
                                val total = it.totalBytesToDownload
                                if (total > 0) "${(it.bytesDownloaded * 100 / total)}%" else "${it.bytesDownloaded} bytes"
                            } ?: ""
                            setState(OcrState.MODULE_DOWNLOADING, "GMS 모듈 다운로드 중 $progress", context)
                        }
                        ModuleInstallStatusUpdate.InstallState.STATE_INSTALLING -> {
                            setState(OcrState.MODULE_INSTALLING, "GMS 모듈 설치 중...", context)
                        }
                        ModuleInstallStatusUpdate.InstallState.STATE_COMPLETED -> {
                            isInstalling = false
                            setState(OcrState.MODULE_READY, "GMS 모듈 설치 완료 (STATE_COMPLETED) ✓", context)
                            initDetectorAndWarmup(context, optionalApi, onComplete)
                        }
                        ModuleInstallStatusUpdate.InstallState.STATE_FAILED -> {
                            isInstalling = false
                            lastFailTime = System.currentTimeMillis()
                            setState(OcrState.MODULE_INSTALL_FAILED, "GMS 모듈 설치 실패 (STATE_FAILED: ${update.errorCode})", context)
                            onComplete?.invoke(false)
                        }
                        ModuleInstallStatusUpdate.InstallState.STATE_CANCELED -> {
                            isInstalling = false
                            lastFailTime = System.currentTimeMillis()
                            setState(OcrState.MODULE_INSTALL_FAILED, "GMS 모듈 설치 취소됨", context)
                            onComplete?.invoke(false)
                        }
                    }
                }
            }

            val request = ModuleInstallRequest.newBuilder()
                .addApi(optionalApi)
                .setListener(statusListener)
                .build()

            moduleInstallClient.areModulesAvailable(optionalApi)
                .addOnSuccessListener { response ->
                    if (response.areModulesAvailable()) {
                        setState(OcrState.MODULE_READY, "GMS 모듈 이미 설치되어 있음 ✓", context)
                        initDetectorAndWarmup(context, optionalApi, onComplete)
                    } else {
                        isInstalling = true
                        setState(OcrState.MODULE_INSTALL_REQUESTED, "GMS 모듈 다운로드 및 설치 요청 전송", context)
                        moduleInstallClient.installModules(request)
                            .addOnSuccessListener { installResponse ->
                                if (installResponse.areModulesAlreadyInstalled()) {
                                    isInstalling = false
                                    setState(OcrState.MODULE_READY, "GMS 모듈 설치 확인 완료 ✓", context)
                                    initDetectorAndWarmup(context, optionalApi, onComplete)
                                } else {
                                    setState(OcrState.MODULE_DOWNLOADING, "GMS 모듈 다운로드 세션 시작 (session: ${installResponse.sessionId})", context)
                                }
                            }
                            .addOnFailureListener { e ->
                                isInstalling = false
                                lastFailTime = System.currentTimeMillis()
                                setState(OcrState.MODULE_INSTALL_FAILED, "GMS 모듈 요청 실패: ${e.message}", context)
                                onComplete?.invoke(false)
                            }
                    }
                }
                .addOnFailureListener { e ->
                    isInstalling = false
                    lastFailTime = System.currentTimeMillis()
                    setState(OcrState.MODULE_INSTALL_FAILED, "GMS 가용성 확인 실패: ${e.message}", context)
                    onComplete?.invoke(false)
                }
        } catch (t: Throwable) {
            isInstalling = false
            lastFailTime = System.currentTimeMillis()
            setState(OcrState.MODULE_INSTALL_FAILED, "모듈 확인 예외: ${t.message}", context)
            onComplete?.invoke(false)
        }
    }

    private fun initDetectorAndWarmup(
        context: Context,
        rec: TextRecognizer,
        onComplete: ((Boolean) -> Unit)?
    ) {
        setState(OcrState.DETECTOR_INITIALIZING, "Korean TextRecognizer 웜업 시작...", context)
        try {
            val dummy = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888).apply {
                eraseColor(Color.WHITE)
                val canvas = Canvas(this)
                val paint = Paint().apply {
                    color = Color.BLACK
                    textSize = 28f
                    isAntiAlias = true
                }
                canvas.drawText("TEST", 30f, 70f, paint)
            }

            rec.process(InputImage.fromBitmap(dummy, 0))
                .addOnSuccessListener {
                    try { dummy.recycle() } catch (_: Throwable) {}
                    recognizer = rec
                    setState(OcrState.OCR_READY, "사전 웜업 성공 (Korean OCR 준비 완료 ✓)", context)
                    onComplete?.invoke(true)
                }
                .addOnFailureListener { e ->
                    try { dummy.recycle() } catch (_: Throwable) {}
                    lastFailTime = System.currentTimeMillis()
                    val causeStr = e.cause?.let { " [cause: ${it.javaClass.simpleName}: ${it.message}]" } ?: ""
                    setState(OcrState.DETECTOR_INIT_FAILED, "Detector 웜업 실패: ${e.message}$causeStr", context)
                    onComplete?.invoke(false)
                }
        } catch (t: Throwable) {
            lastFailTime = System.currentTimeMillis()
            setState(OcrState.DETECTOR_INIT_FAILED, "Detector 생성 예외: ${t.message}", context)
            onComplete?.invoke(false)
        }
    }

    @Synchronized
    fun getOcrRecognizer(): TextRecognizer? {
        return recognizer
    }

    @Synchronized
    fun close() {
        try {
            recognizer?.close()
        } catch (_: Throwable) {}
        recognizer = null
        currentState = OcrState.INITIALIZING
        isInstalling = false
    }
}
