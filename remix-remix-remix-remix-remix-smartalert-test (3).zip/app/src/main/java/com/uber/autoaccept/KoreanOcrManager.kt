package com.uber.autoaccept

import android.content.Context
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions

object KoreanOcrManager {
    private const val TAG = "KoreanOcrManager"

    enum class OcrState {
        UNINITIALIZED,
        INITIALIZING,
        MODULE_INSTALL_REQUESTED,
        MODULE_DOWNLOADING,
        MODULE_INSTALLING,
        MODULE_READY,
        DETECTOR_INITIALIZING,
        OCR_READY,
        DETECTOR_INIT_FAILED,
        MODULE_INSTALL_FAILED,
        FAILED,
        RETRY_WAIT
    }

    private val recognizerInstance: TextRecognizer by lazy {
        TextRecognition.getClient(
            KoreanTextRecognizerOptions.Builder().build()
        )
    }

    var currentState: OcrState = OcrState.OCR_READY
        private set

    fun addStateListener(listener: (OcrState, String) -> Unit) {
        listener(currentState, "OCR Ready (Lazy)")
    }

    fun ensureInitialized(context: Context, onComplete: ((Boolean) -> Unit)? = null) {
        // 원본 APK와 동일하게 사전 강제 초기화/웜업 없이 Lazy 인스턴스 준비 완료 상태로 처리
        onComplete?.invoke(true)
    }

    fun getOcrRecognizer(): TextRecognizer {
        return recognizerInstance
    }

    fun close() {
        // 원본 APK와 동일하게 단일 Lazy 인스턴스를 유지하며 임의 해제/재생성하지 않음
    }
}
