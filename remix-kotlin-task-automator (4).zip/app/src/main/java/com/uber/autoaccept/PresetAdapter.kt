package com.uber.autoaccept

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PresetAdapter(
    private val items: List<KeywordPreset>,
    private val onApply: (Int) -> Unit,
    private val onEdit: (Int) -> Unit,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<PresetAdapter.VH>() {

    inner class VH(val row: LinearLayout) : RecyclerView.ViewHolder(row) {
        val tvName: TextView = row.findViewWithTag("name")
        val tvKeywords: TextView = row.findViewWithTag("keywords")
        val btnApply: Button = row.findViewWithTag("apply")
        val btnEdit: Button = row.findViewWithTag("edit")
        val btnDel: Button = row.findViewWithTag("delete")
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val context = parent.context
        fun dp(v: Int): Int = (v * context.resources.displayMetrics.density).toInt()

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(8)
            }
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#0B1322"))
                setStroke(dp(1), Color.parseColor("#1E293B"))
                cornerRadius = dp(10).toFloat()
            }
            setPadding(dp(14), dp(10), dp(10), dp(10))
        }

        val textCol = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val tvName = TextView(context).apply {
            tag = "name"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 15f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        textCol.addView(tvName)

        val tvKeywords = TextView(context).apply {
            tag = "keywords"
            setTextColor(Color.parseColor("#888888"))
            textSize = 12f
        }
        textCol.addView(tvKeywords)
        row.addView(textCol)

        val btnApply = Button(context).apply {
            tag = "apply"
            text = "적용"
            setTextColor(Color.parseColor("#06C167"))
            textSize = 12f
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#142E1F"))
                cornerRadius = dp(8).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(34)).apply {
                rightMargin = dp(4)
            }
            setPadding(0, 0, 0, 0)
        }
        row.addView(btnApply)

        val btnEdit = Button(context).apply {
            tag = "edit"
            text = "수정"
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 12f
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2A2A2A"))
                cornerRadius = dp(8).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(dp(44), dp(34)).apply {
                rightMargin = dp(4)
            }
            setPadding(0, 0, 0, 0)
        }
        row.addView(btnEdit)

        val btnDel = Button(context).apply {
            tag = "delete"
            text = "✕"
            setTextColor(Color.parseColor("#FF5252"))
            textSize = 13f
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2A1A1A"))
                cornerRadius = dp(8).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(dp(34), dp(34))
            setPadding(0, 0, 0, 0)
        }
        row.addView(btnDel)

        return VH(row)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.tvName.text = item.name
        holder.tvKeywords.text = if (item.keywords.isEmpty()) "키워드 없음" else item.keywords.joinToString(", ")

        holder.btnApply.setOnClickListener {
            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_POSITION) onApply(pos)
        }
        holder.btnEdit.setOnClickListener {
            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_POSITION) onEdit(pos)
        }
        holder.btnDel.setOnClickListener {
            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_POSITION) onDelete(pos)
        }
    }

    override fun getItemCount(): Int = items.size
}
