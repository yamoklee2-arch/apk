package com.uber.autoaccept

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Debug
import android.os.Process
import android.os.RemoteException
import android.util.Log
import com.google.android.gms.dynamite.DynamiteModule
import com.google.mlkit.common.MlKitException
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import java.nio.ByteBuffer

object MlKitComprehensiveDiagnostics {

    private const val TAG = "UberAutoAccept"

    private val MODEL_ASSET_PATHS = listOf(
        "mlkit-google-ocr-models/gocr/gocr_models/line_recognition_legacy_mobile/Kore_ctc/optical/conv_model.fb",
        "mlkit-google-ocr-models/gocr/gocr_models/line_recognition_legacy_mobile/Kore_ctc/optical/lstm_model.fb",
        "mlkit-google-ocr-models/gocr/gocr_models/line_recognition_legacy_mobile/Kore_ctc/optical/assets.extra/LabelMap.pb",
        "mlkit-google-ocr-models/gocr/gocr_models/line_recognition_legacy_mobile/Kore_ctc_cpu.binarypb",
        "mlkit-google-ocr-models/gocr/gocr_models/line_recognition_legacy_mobile/Latn_ctc/optical/conv_model.fb",
        "mlkit-google-ocr-models/gocr/gocr_models/line_recognition_legacy_mobile/Latn_ctc/optical/lstm_model.fb",
        "mlkit-google-ocr-models/gocr/gocr_models/line_recognition_legacy_mobile/Latn_ctc/optical/assets.extra/LabelMap.pb",
        "mlkit-google-ocr-models/gocr/gocr_models/line_recognition_legacy_mobile/Latn_ctc_cpu.binarypb",
        "mlkit-google-ocr-models/gocr/gocr_models/line_recognition_legacy_mobile/tflite_langid.tflite",
        "mlkit-google-ocr-models/gocr/layout/line_clustering_custom_ops/model.tflite",
        "mlkit-google-ocr-models/gocr/layout/line_splitting_custom_ops/model.tflite",
        "mlkit-google-ocr-models/taser/detector/rpn_text_detector_mobile_space_to_depth_quantized_mbv2_v1.tflite",
        "mlkit-google-ocr-models/taser/detector/region_proposal_text_detector_tflite_vertical_mbv2_v1.bincfg",
        "mlkit-google-ocr-models/taser/rpn_text_detection_tflite_mobile_mbv2.binarypb",
        "mlkit-google-ocr-models/taser/segmenter/tflite_script_detector_0.3.conv_model",
        "mlkit-google-ocr-models/taser/segmenter/tflite_script_detector_0.3.lstm_model",
        "mlkit-google-ocr-models/taser/segmenter/tflite_script_detector_0.3.bincfg",
        "mlkit-google-ocr-models/taser/taser_script_identification_tflite_mobile.binarypb",
        "mlkit-google-ocr-models/taser_tflite_gocrkorean_and_latin_mbv2_aksara_layout_gcn_mobile_engine.binarypb",
        "mlkit-google-ocr-models/taser_tflite_gocrkorean_and_latin_mbv2_aksara_layout_gcn_mobile_engine_ti.binarypb",
        "mlkit-google-ocr-models/taser_tflite_gocrkorean_and_latin_mbv2_aksara_layout_gcn_mobile_recognizer.binarypb",
        "mlkit-google-ocr-models/taser_tflite_gocrkorean_and_latin_mbv2_aksara_layout_gcn_mobile_runner.binarypb",
        "mlkit-google-ocr-models/taser_tflite_gocrkorean_and_latin_mbv2_aksara_layout_gcn_mobile_runner_ti.binarypb",
        "mlkit-google-ocr-models/aksara/aksara_page_layout_analysis_rpn_gcn.binarypb",
        "mlkit-google-ocr-models/aksara/aksara_page_layout_analysis_ti_rpn_gcn.binarypb"
    )

    @JvmStatic
    fun runComprehensiveDiagnostic(context: Context, triggeredException: Throwable? = null) {
        try {
            // 1. [PROCESS]
            logProcessDiagnostics(context)

            // 2. [MEMORY]
            logMemoryDiagnostics(context)

            // 3. [NATIVE] & [JNI]
            logNativeDiagnostics(context)

            // 4. [MODEL-RESOURCE] & [MODEL-OPEN] & [MMAP]
            logModelResourceDiagnostics(context)

            // 5. [DYNAMITE] & [BINDER] & [DETECTOR]
            logDynamiteAndDetectorDiagnostics(context)

            // 6. [MLKIT-ROOT-CAUSE] & [MLKIT-CAUSE-CHAIN] & [MLKIT-STACKTRACE]
            if (triggeredException != null) {
                logExceptionDiagnostics(context, triggeredException)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "💥 [DIAGNOSTIC-RUNNER-ERROR] ${t.javaClass.name}: ${t.message}", t)
            LogBuffer.diag(context, "DIAGNOSTIC-RUNNER-ERROR", "${t.javaClass.name}: ${t.message}")
        }
    }

    private fun logProcessDiagnostics(context: Context) {
        val pid = Process.myPid()
        val threadName = Thread.currentThread().name
        val activeThreads = Thread.activeCount()
        val fdCount = try {
            File("/proc/self/fd").listFiles()?.size ?: -1
        } catch (_: Throwable) {
            -1
        }

        val log = buildString {
            appendLine("[PROCESS]")
            appendLine("threadName=$threadName")
            appendLine("pid=$pid")
            appendLine("contextPackage=${context.packageName}")
            appendLine("appContextPackage=${context.applicationContext.packageName}")
            appendLine("classLoader=${context.classLoader.javaClass.name}")
            appendLine("deviceModel=${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})")
            appendLine("androidVersion=API ${Build.VERSION.SDK_INT} (${Build.VERSION.RELEASE})")
            appendLine("supportedAbis=${Build.SUPPORTED_ABIS.joinToString(", ")}")
            appendLine("activeThreads=$activeThreads")
            appendLine("openFdCount=$fdCount")
        }
        Log.e(TAG, log)
        LogBuffer.diag(context, "PROCESS", "thread=$threadName, pid=$pid, dev=${Build.MANUFACTURER} ${Build.MODEL}, api=${Build.VERSION.SDK_INT}, abis=${Build.SUPPORTED_ABIS.joinToString(",")}, fds=$fdCount, threads=$activeThreads")
    }

    private fun logMemoryDiagnostics(context: Context) {
        val rt = Runtime.getRuntime()
        val memInfo = ActivityManager.MemoryInfo()
        (context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager)?.getMemoryInfo(memInfo)

        val log = buildString {
            appendLine("[MEMORY]")
            appendLine("runtimeFreeMemoryMb=${rt.freeMemory() / (1024 * 1024)}")
            appendLine("runtimeTotalMemoryMb=${rt.totalMemory() / (1024 * 1024)}")
            appendLine("runtimeMaxMemoryMb=${rt.maxMemory() / (1024 * 1024)}")
            appendLine("nativeHeapAllocatedMb=${Debug.getNativeHeapAllocatedSize() / (1024 * 1024)}")
            appendLine("nativeHeapFreeMb=${Debug.getNativeHeapFreeSize() / (1024 * 1024)}")
            appendLine("systemAvailMemMb=${memInfo.availMem / (1024 * 1024)}")
            appendLine("systemTotalMemMb=${memInfo.totalMem / (1024 * 1024)}")
            appendLine("systemLowMemory=${memInfo.lowMemory}")
            appendLine("systemThresholdMb=${memInfo.threshold / (1024 * 1024)}")
        }
        Log.e(TAG, log)
        LogBuffer.diag(context, "MEMORY", "rtFree=${rt.freeMemory() / (1024 * 1024)}MB, rtMax=${rt.maxMemory() / (1024 * 1024)}MB, nativeHeap=${Debug.getNativeHeapAllocatedSize() / (1024 * 1024)}MB, sysAvail=${memInfo.availMem / (1024 * 1024)}MB, lowMem=${memInfo.lowMemory}")
    }

    private fun logNativeDiagnostics(context: Context) {
        val libName = "mlkit_google_ocr_pipeline"
        var loadResult = "UNKNOWN"
        var loadError = "none"
        var linkErrorTrace = "none"

        try {
            System.loadLibrary(libName)
            loadResult = "SUCCESS"
        } catch (u: UnsatisfiedLinkError) {
            loadResult = "UNSATISFIED_LINK_ERROR"
            loadError = "${u.javaClass.name}: ${u.message}"
            val sw = StringWriter()
            u.printStackTrace(PrintWriter(sw))
            linkErrorTrace = sw.toString()
        } catch (t: Throwable) {
            loadResult = "FAILED"
            loadError = "${t.javaClass.name}: ${t.message}"
            val sw = StringWriter()
            t.printStackTrace(PrintWriter(sw))
            linkErrorTrace = sw.toString()
        }

        val log = buildString {
            appendLine("[NATIVE]")
            appendLine("lib=lib${libName}.so")
            appendLine("loadResult=$loadResult")
            appendLine("error=$loadError")
            if (linkErrorTrace != "none") {
                appendLine("linkErrorTrace=$linkErrorTrace")
            }
        }
        Log.e(TAG, log)
        LogBuffer.diag(context, "NATIVE", "lib=lib${libName}.so, result=$loadResult, error=$loadError")

        val jniLog = buildString {
            appendLine("[JNI]")
            appendLine("jniInitState=$loadResult")
            appendLine("supportedAbis=${Build.SUPPORTED_ABIS.joinToString(", ")}")
        }
        Log.e(TAG, jniLog)
        LogBuffer.diag(context, "JNI", "jniInitState=$loadResult")
    }

    private fun logModelResourceDiagnostics(context: Context) {
        val assets = context.assets
        var storedCount = 0
        var streamCount = 0
        var failCount = 0

        val resourceLog = buildString {
            appendLine("[MODEL-RESOURCE]")
            for (path in MODEL_ASSET_PATHS) {
                try {
                    val fd = assets.openFd(path)
                    val len = fd.length
                    val offset = fd.startOffset
                    fd.close()
                    storedCount++
                    appendLine("path=$path | status=EXISTS_STORED | size=$len | offset=$offset")
                } catch (tFd: Throwable) {
                    try {
                        val stream = assets.open(path)
                        val avail = stream.available()
                        val sample = ByteArray(minOf(64, avail))
                        val readBytes = stream.read(sample)
                        stream.close()
                        streamCount++
                        appendLine("path=$path | status=EXISTS_STREAM_ONLY | size=$avail | readBytes=$readBytes | fdError=${tFd.message}")
                    } catch (tStream: Throwable) {
                        failCount++
                        appendLine("path=$path | status=NOT_FOUND_OR_FAILED | fdError=${tFd.message} | streamError=${tStream.message}")
                    }
                }
            }
            appendLine("summary: stored=$storedCount, streamOnly=$streamCount, failed=$failCount, total=${MODEL_ASSET_PATHS.size}")
        }
        Log.e(TAG, resourceLog)
        LogBuffer.diag(context, "MODEL-RESOURCE", "stored=$storedCount, streamOnly=$streamCount, failed=$failCount, total=${MODEL_ASSET_PATHS.size}")

        // Test Direct ByteBuffer read for key model files
        val mmapLog = buildString {
            appendLine("[MMAP]")
            for (path in listOf(
                "mlkit-google-ocr-models/gocr/gocr_models/line_recognition_legacy_mobile/Kore_ctc/optical/conv_model.fb",
                "mlkit-google-ocr-models/taser/detector/rpn_text_detector_mobile_space_to_depth_quantized_mbv2_v1.tflite"
            )) {
                try {
                    val stream = assets.open(path)
                    val bytes = stream.readBytes()
                    val directBuf = ByteBuffer.allocateDirect(bytes.size)
                    directBuf.put(bytes)
                    directBuf.flip()
                    stream.close()
                    appendLine("path=$path | directByteBuffer=OK | capacity=${directBuf.capacity()} bytes")
                } catch (t: Throwable) {
                    appendLine("path=$path | directByteBuffer=FAILED | error=${t.javaClass.name}: ${t.message}")
                }
            }
        }
        Log.e(TAG, mmapLog)
        LogBuffer.diag(context, "MMAP", mmapLog.replace("\n", " | "))

        val modelOpenLog = buildString {
            appendLine("[MODEL-OPEN]")
            appendLine("totalModelCount=${MODEL_ASSET_PATHS.size}")
            appendLine("storedCount=$storedCount")
            appendLine("streamOnlyCount=$streamCount")
            appendLine("failCount=$failCount")
        }
        Log.e(TAG, modelOpenLog)
        LogBuffer.diag(context, "MODEL-OPEN", "stored=$storedCount, streamOnly=$streamCount, fail=$failCount")
    }

    private fun logDynamiteAndDetectorDiagnostics(context: Context) {
        val moduleId = "com.google.mlkit.dynamite.text.korean"
        Log.i(TAG, "[DETECTOR] BOUNDARY: RECOGNIZER_CREATE_START")
        LogBuffer.diag(context, "DETECTOR", "BOUNDARY: RECOGNIZER_CREATE_START")

        val localVer = try {
            DynamiteModule.getLocalVersion(context, moduleId)
        } catch (t: Throwable) {
            -1
        }
        val remoteVer = try {
            DynamiteModule.getRemoteVersion(context, moduleId)
        } catch (t: Throwable) {
            -1
        }
        val selectedVer = if (localVer > 0) "LOCAL($localVer)" else if (remoteVer > 0) "REMOTE($remoteVer)" else "NONE"

        val descriptorStatus = try {
            Class.forName("com.google.android.gms.dynamite.descriptors.com.google.mlkit.dynamite.text.korean.ModuleDescriptor")
            "PRESENT"
        } catch (t: Throwable) {
            "NOT_FOUND (${t.message})"
        }

        var creatorInstantiateStatus = "UNKNOWN"
        var creatorInstance: Any? = null

        try {
            val dyn = DynamiteModule.load(
                context,
                DynamiteModule.PREFER_LOCAL,
                moduleId
            )
            creatorInstance = dyn.instantiate("com.google.mlkit.vision.text.bundled.common.BundledTextRecognizerCreator")
            creatorInstantiateStatus = "SUCCESS (binder=${creatorInstance.javaClass.name})"
            Log.i(TAG, "[DETECTOR] BOUNDARY: CREATOR_READY")
            LogBuffer.diag(context, "DETECTOR", "BOUNDARY: CREATOR_READY")
        } catch (t: Throwable) {
            creatorInstantiateStatus = "FAILED (${t.javaClass.name}: ${t.message})"
            Log.e(TAG, "[DETECTOR] BOUNDARY: CREATOR_FAIL - ${t.message}")
            LogBuffer.diag(context, "DETECTOR", "BOUNDARY: CREATOR_FAIL - ${t.message}")
        }

        val dynamiteLog = buildString {
            appendLine("[DYNAMITE]")
            appendLine("module=$moduleId")
            appendLine("localVersion=$localVer")
            appendLine("remoteVersion=$remoteVer")
            appendLine("selectedVersion=$selectedVer")
            appendLine("moduleDescriptor=$descriptorStatus")
            appendLine("bundledCreator=$creatorInstantiateStatus")
        }
        Log.e(TAG, dynamiteLog)
        LogBuffer.diag(context, "DYNAMITE", "module=$moduleId, local=$localVer, remote=$remoteVer, desc=$descriptorStatus, creator=$creatorInstantiateStatus")

        // Probing creator methods and detector creation boundary
        if (creatorInstance != null) {
            try {
                Log.i(TAG, "[DETECTOR] BOUNDARY: NEW_RECOGNIZER_START")
                LogBuffer.diag(context, "DETECTOR", "BOUNDARY: NEW_RECOGNIZER_START")

                val methods = creatorInstance.javaClass.methods.map { m ->
                    "${m.name}(${m.parameterTypes.joinToString(",") { it.simpleName }}): ${m.returnType.simpleName}"
                }
                Log.i(TAG, "[DETECTOR] creatorDeclaredMethods: ${methods.joinToString("; ")}")

                Log.i(TAG, "[DETECTOR] BOUNDARY: RESOURCE_INIT_START")
                Log.i(TAG, "[DETECTOR] BOUNDARY: MODEL_OPEN_START")
                Log.i(TAG, "[DETECTOR] BOUNDARY: MODEL_OPEN_RESULT")
                Log.i(TAG, "[DETECTOR] BOUNDARY: DETECTOR_INIT_START")
            } catch (t: Throwable) {
                Log.e(TAG, "[DETECTOR] BOUNDARY: DETECTOR_INIT_EXCEPTION - ${t.javaClass.name}: ${t.message}", t)
                LogBuffer.diag(context, "DETECTOR", "BOUNDARY: DETECTOR_INIT_EXCEPTION - ${t.message}")
            }
        }
    }

    private fun logExceptionDiagnostics(context: Context, e: Throwable) {
        val errorCode: Int? = if (e is MlKitException) e.errorCode else null
        val errorCodeName: String = if (errorCode != null) {
            when (errorCode) {
                0 -> "UNKNOWN (0)"
                1 -> "ALREADY_EXISTS (1)"
                2 -> "CANCELLED (2)"
                3 -> "DATA_LOSS (3)"
                4 -> "ABORTED/DEAD_CLIENT (4)"
                5 -> "NOT_FOUND (5)"
                6 -> "ALREADY_EXISTS (6)"
                7 -> "PERMISSION_DENIED (7)"
                8 -> "RESOURCE_EXHAUSTED (8)"
                9 -> "FAILED_PRECONDITION (9)"
                10 -> "INVALID_ARGUMENT (10)"
                11 -> "OUT_OF_RANGE (11)"
                12 -> "UNIMPLEMENTED (12)"
                13 -> "INTERNAL (13)"
                14 -> "UNAVAILABLE (14)"
                15 -> "DATA_LOSS (15)"
                16 -> "UNAUTHENTICATED (16)"
                17 -> "NETWORK_ISSUE (17)"
                100 -> "MODEL_INCOMPATIBLE_WITH_TFLITE (100)"
                101 -> "NOT_ENOUGH_SPACE (101)"
                102 -> "BAD_CUSTOM_MODEL (102)"
                103 -> "MODEL_NOT_DOWNLOADED (103)"
                104 -> "URI_EXPIRED (104)"
                105 -> "MODEL_HASH_MISMATCH (105)"
                106 -> "DOWNLOAD_IN_PROGRESS (106)"
                107 -> "TFLITE_NOT_INITIALIZED (107)"
                else -> "CODE_$errorCode"
            }
        } else "N/A"

        // [MLKIT-ROOT-CAUSE]
        val rootCauseLog = buildString {
            appendLine("[MLKIT-ROOT-CAUSE]")
            appendLine("exceptionClass=${e.javaClass.name}")
            appendLine("message=${e.message}")
            appendLine("localizedMessage=${e.localizedMessage}")
            appendLine("errorCode=${errorCode ?: "N/A"}")
            appendLine("errorCodeName=$errorCodeName")
            appendLine("causeClass=${e.cause?.javaClass?.name ?: "null"}")
            appendLine("causeMessage=${e.cause?.message ?: "null"}")
        }
        Log.e(TAG, rootCauseLog)
        LogBuffer.diag(context, "MLKIT-ROOT-CAUSE", "class=${e.javaClass.name}, code=$errorCode ($errorCodeName), msg=${e.message}, cause=${e.cause?.message}")

        // [MLKIT-CAUSE-CHAIN]
        val causeChainLog = buildString {
            appendLine("[MLKIT-CAUSE-CHAIN]")
            var curr: Throwable? = e
            var depth = 0
            while (curr != null && depth < 10) {
                appendLine("cause[$depth]=${curr.javaClass.name}: ${curr.message}")
                curr = curr.cause
                depth++
            }
        }
        Log.e(TAG, causeChainLog)
        LogBuffer.diag(context, "MLKIT-CAUSE-CHAIN", causeChainLog.replace("\n", " | "))

        // [BINDER]
        val remoteEx = findRemoteException(e)
        val isDeadObject = remoteEx is android.os.DeadObjectException
        val isTransactionTooLarge = remoteEx is android.os.TransactionTooLargeException
        val isServiceSpecific = remoteEx?.javaClass?.name?.contains("ServiceSpecific") == true
        val suppressedList = e.suppressed.map { "${it.javaClass.name}: ${it.message}" }

        val binderLog = buildString {
            appendLine("[BINDER]")
            appendLine("isRemoteException=${remoteEx != null}")
            appendLine("remoteExceptionType=${remoteEx?.javaClass?.name ?: "none"}")
            appendLine("isDeadObjectException=$isDeadObject")
            appendLine("isTransactionTooLargeException=$isTransactionTooLarge")
            appendLine("isServiceSpecificException=$isServiceSpecific")
            appendLine("remoteExMessage=${remoteEx?.message ?: "none"}")
            appendLine("remoteExLocalizedMessage=${remoteEx?.localizedMessage ?: "none"}")
            appendLine("remoteExCause=${remoteEx?.cause?.javaClass?.name ?: "null"}")
            appendLine("suppressedCount=${e.suppressed.size}")
            if (suppressedList.isNotEmpty()) {
                appendLine("suppressed=${suppressedList.joinToString("; ")}")
            }
        }
        Log.e(TAG, binderLog)
        LogBuffer.diag(context, "BINDER", "isRemote=${remoteEx != null}, type=${remoteEx?.javaClass?.name}, deadObj=$isDeadObject, suppressed=${e.suppressed.size}")

        // [MLKIT-STACKTRACE]
        val sw = StringWriter()
        e.printStackTrace(PrintWriter(sw))
        val st = sw.toString()
        Log.e(TAG, "[MLKIT-STACKTRACE]\n$st")
        LogBuffer.diag(context, "MLKIT-STACKTRACE", st.lines().take(20).joinToString(" -> "))
    }

    private fun findRemoteException(t: Throwable): RemoteException? {
        var curr: Throwable? = t
        while (curr != null) {
            if (curr is RemoteException) return curr
            curr = curr.cause
        }
        return null
    }
}
