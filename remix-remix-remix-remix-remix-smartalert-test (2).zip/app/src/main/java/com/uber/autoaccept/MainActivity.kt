package com.uber.autoaccept

import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.PointerIconCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.common.moduleinstall.ModuleInstall
import com.google.android.gms.common.moduleinstall.ModuleInstallRequest
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import rikka.shizuku.Shizuku
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvCallCount: TextView
    private lateinit var tvAcceptScheduled: TextView
    private lateinit var tvDismissScheduled: TextView
    private lateinit var tvDismissDebug: TextView

    private lateinit var tvDiagLog: TextView
    private lateinit var svDiagLog: ScrollView
    private lateinit var btnClearDiagLog: Button
    private lateinit var btnShareDiagLog: Button

    private lateinit var switchActive: Switch
    private lateinit var switchAcceptAll: Switch
    private lateinit var switchBlacklistMode: Switch
    private lateinit var switchOcrPoll: Switch
    private lateinit var switchAutoDismiss: Switch
    private lateinit var switchSleepAlarm: Switch
    private lateinit var switchAirportMode: Switch
    private lateinit var switchAcceptNoDelay: Switch
    private lateinit var switchFloatingBubble: Switch
    private lateinit var switchHumanMode: Switch
    private lateinit var switchVibration: Switch
    private lateinit var switchAcceptScreenshot: Switch

    private lateinit var tvDismissCooldown: TextView
    private lateinit var seekDismissCooldown: SeekBar

    private lateinit var btnAccessibility: Button
    private lateinit var btnNotification: Button

    private lateinit var etKeyword: EditText
    private lateinit var btnAdd: Button

    private lateinit var rvKeywords: RecyclerView
    private lateinit var adapter: KeywordAdapter

    private lateinit var rvPresets: RecyclerView
    private lateinit var presetAdapter: PresetAdapter

    private lateinit var tvMinDelay: TextView
    private lateinit var seekMinDelay: SeekBar
    private lateinit var tvMaxDelay: TextView
    private lateinit var seekMaxDelay: SeekBar

    private val keywords = mutableListOf<String>()
    private val presets = mutableListOf<KeywordPreset>()

    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private val handler = Handler(Looper.getMainLooper())
    private val statsRefresher = object : Runnable {
        override fun run() {
            updateStats()
            handler.postDelayed(this, 1500L)
        }
    }

    private val acceptReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            updateStats()
        }
    }

    private val shizukuPermissionCode = PointerIconCompat.TYPE_CONTEXT_MENU
    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (grantResult == 0) {
            Toast.makeText(this@MainActivity, "Shizuku 권한 허용됨 ✓", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this@MainActivity, "Shizuku 권한 거부됨 — 자동 클릭 불가", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUI()

        keywords.addAll(PrefsManager.getKeywords(this))
        adapter.notifyDataSetChanged()

        presets.addAll(PrefsManager.getPresets(this))
        presetAdapter.notifyDataSetChanged()

        loadSettings()
        setupListeners()
        updateStats()
        updateAccessibilityStatus()

        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
        requestShizukuPermission()
        initKoreanOcrModule()
    }

    private fun initKoreanOcrModule() {
        Thread {
            try {
                val recognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
                val moduleInstallClient = ModuleInstall.getClient(this)
                val moduleInstallRequest = ModuleInstallRequest.newBuilder().addApi(recognizer).build()

                fun doWarmup() {
                    val dummy = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888).apply {
                        eraseColor(Color.WHITE)
                        val canvas = Canvas(this)
                        val paint = Paint().apply {
                            color = Color.BLACK
                            textSize = 28f
                            isAntiAlias = true
                        }
                        canvas.drawText("TEST", 30f, 70f, paint)
                    }
                    recognizer.process(InputImage.fromBitmap(dummy, 0))
                        .addOnSuccessListener {
                            dummy.recycle()
                            LogBuffer.log(this@MainActivity, "MainActivity", "[ML-KIT-STATE] READY - 사전 웜업 성공 ✓")
                        }
                        .addOnFailureListener { e ->
                            dummy.recycle()
                            val causeStr = e.cause?.let { " [cause: ${it.javaClass.simpleName}: ${it.message}]" } ?: ""
                            LogBuffer.log(this@MainActivity, "MainActivity", "[ML-KIT-STATE] DETECTOR_INIT_FAILED - 웜업 실패: ${e.message}$causeStr")
                            try {
                                moduleInstallClient.installModules(moduleInstallRequest)
                                    .addOnSuccessListener {
                                        LogBuffer.log(this@MainActivity, "MainActivity", "[ML-KIT-STATE] INITIALIZING - GMS 모듈 설치 요청됨")
                                    }
                            } catch (_: Throwable) {}
                        }
                }

                moduleInstallClient.areModulesAvailable(recognizer)
                    .addOnSuccessListener { response ->
                        if (response.areModulesAvailable()) {
                            doWarmup()
                        } else {
                            LogBuffer.log(this@MainActivity, "MainActivity", "[ML-KIT-STATE] MODEL_UNAVAILABLE - GMS 모듈 다운로드 요청 중...")
                            moduleInstallClient.installModules(moduleInstallRequest)
                                .addOnSuccessListener { installResponse ->
                                    if (installResponse.areModulesAlreadyInstalled()) {
                                        doWarmup()
                                    } else {
                                        LogBuffer.log(this@MainActivity, "MainActivity", "[ML-KIT-STATE] INITIALIZING - 모듈 다운로드 진행 중 (session: ${installResponse.sessionId})")
                                    }
                                }
                                .addOnFailureListener { e ->
                                    LogBuffer.log(this@MainActivity, "MainActivity", "[ML-KIT-STATE] MODEL_UNAVAILABLE - 다운로드 실패: ${e.message}")
                                    doWarmup()
                                }
                        }
                    }
                    .addOnFailureListener {
                        doWarmup()
                    }
            } catch (t: Throwable) {
                val stackStr = t.stackTraceToString()
                LogBuffer.log(this@MainActivity, "MainActivity", "[ML-KIT-STATE] DETECTOR_INIT_FAILED - 예외: ${t.message}\n$stackStr")
            }
        }.start()
    }

    private fun requestShizukuPermission() {
        try {
            if (!Shizuku.pingBinder()) {
                Toast.makeText(this, "Shizuku가 실행 중이 아님 — 앱을 먼저 시작하세요", Toast.LENGTH_LONG).show()
            } else {
                if (Shizuku.checkSelfPermission() == 0) {
                    return
                }
                if (Shizuku.shouldShowRequestPermissionRationale()) {
                    Toast.makeText(this, "Shizuku 권한이 필요합니다", Toast.LENGTH_SHORT).show()
                }
                Shizuku.requestPermission(shizukuPermissionCode)
            }
        } catch (_: Exception) {
        }
    }

    private fun isLogScrolledToBottom(): Boolean {
        if (!::svDiagLog.isInitialized) return true
        val child = svDiagLog.getChildAt(0) ?: return true
        val diff = child.bottom - (svDiagLog.height + svDiagLog.scrollY)
        return diff <= dp(32)
    }

    private fun scrollLogToBottom() {
        if (!::svDiagLog.isInitialized) return
        svDiagLog.post {
            val child = svDiagLog.getChildAt(0) ?: return@post
            val scrollAmount = child.bottom - svDiagLog.height
            if (scrollAmount > 0) {
                svDiagLog.scrollTo(0, scrollAmount)
            }
        }
    }

    private val logListener: (String) -> Unit = { line ->
        handler.post {
            if (::tvDiagLog.isInitialized) {
                val wasAtBottom = isLogScrolledToBottom()
                tvDiagLog.append(line + "\n")
                if (wasAtBottom) {
                    scrollLogToBottom()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        LogBuffer.removeListener(logListener)
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
    }

    override fun onResume() {
        super.onResume()
        updateAccessibilityStatus()
        updateDiagLogUI()
        LogBuffer.addListener(logListener)
        handler.post(statsRefresher)

        etKeyword.clearFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        currentFocus?.let {
            imm?.hideSoftInputFromWindow(it.windowToken, 0)
        }

        val filter = IntentFilter("com.uber.autoaccept.CALL_ACCEPTED")
        registerReceiver(acceptReceiver, filter, 4)

        if (PrefsManager.isFloatingBubble(this) && Settings.canDrawOverlays(this)) {
            startService(Intent(this, FloatingBubbleService::class.java))
        }
    }

    override fun onPause() {
        super.onPause()
        LogBuffer.removeListener(logListener)
        handler.removeCallbacks(statsRefresher)
        try {
            unregisterReceiver(acceptReceiver)
        } catch (_: Exception) {
        }
    }

    private fun buildUI() {
        val BG = Color.parseColor("#141414")
        val CARD = Color.parseColor("#1E1E1E")
        val ACCENT = Color.parseColor("#06C167")
        val TEXT_SEC = Color.parseColor("#9A9A9A")
        val BORDER = Color.parseColor("#2E2E2E")

        val rootScroll = ScrollView(this).apply {
            setBackgroundColor(BG)
            isScrollbarFadingEnabled = true
            overScrollMode = View.OVER_SCROLL_NEVER
            isSmoothScrollingEnabled = true
            isFillViewport = true
            descendantFocusability = ViewGroup.FOCUS_BEFORE_DESCENDANTS
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(48), dp(16), dp(100))
        }

        // Header Row
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val tvTitle = TextView(this).apply {
            text = "스마트 알림"
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        headerRow.addView(tvTitle)

        tvStatus = TextView(this).apply {
            text = "● 비활성"
            textSize = 12f
            setTextColor(TEXT_SEC)
            setPadding(dp(10), dp(5), dp(10), dp(5))
            background = roundRect(CARD, dp(20))
        }
        headerRow.addView(tvStatus)
        root.addView(headerRow)
        root.addView(space(12))

        // Stats Card
        val statsCard = card(CARD, BORDER)
        val statsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val (callView, col1) = buildStatView(Color.WHITE, TEXT_SEC, "콜 감지")
        tvCallCount = callView
        val (acceptSchView, col2) = buildStatView(Color.WHITE, TEXT_SEC, "수락예약")
        tvAcceptScheduled = acceptSchView
        val (dismissSchView, col3) = buildStatView(Color.WHITE, TEXT_SEC, "닫기실행")
        tvDismissScheduled = dismissSchView

        statsRow.addView(col1)
        statsRow.addView(dividerV(BORDER))
        statsRow.addView(col2)
        statsRow.addView(dividerV(BORDER))
        statsRow.addView(col3)
        statsCard.addView(statsRow)

        val btnResetStats = TextView(this).apply {
            text = "카운터 초기화"
            textSize = 11f
            setTextColor(Color.parseColor("#555555"))
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
            setOnClickListener {
                PrefsManager.resetCounts(this@MainActivity)
                updateStats()
            }
        }
        statsCard.addView(btnResetStats)

        tvDismissDebug = TextView(this).apply {
            textSize = 10f
            setTextColor(Color.parseColor("#666666"))
            gravity = android.view.Gravity.CENTER
            setPadding(0, dp(4), 0, 0)
            text = "수락버튼: 미감지"
            setOnClickListener {
                showDiagDialog()
            }
        }
        statsCard.addView(tvDismissDebug)
        root.addView(statsCard)
        root.addView(space(12))

        // 1. Toggle Card: 자동 수락
        val toggleCard = card(CARD, BORDER)
        val toggleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val toggleTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvToggleTitle = TextView(this).apply {
            text = "자동 수락"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvToggleSub = TextView(this).apply {
            text = "키워드가 일치하는 콜 자동 수락"
            textSize = 12f
            setTextColor(TEXT_SEC)
        }
        toggleTextCol.addView(tvToggleTitle)
        toggleTextCol.addView(tvToggleSub)
        toggleRow.addView(toggleTextCol)

        switchActive = Switch(this).apply {
            isChecked = PrefsManager.isActive(this@MainActivity)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(ACCENT, Color.parseColor("#444444"))
            )
        }
        toggleRow.addView(switchActive)
        toggleCard.addView(toggleRow)
        root.addView(toggleCard)
        root.addView(space(8))

        // 2. Accept All Card: 전체 수락 모드
        val acceptAllCard = card(CARD, BORDER)
        val acceptAllRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        val acceptAllTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvAcceptAllTitle = TextView(this).apply {
            text = "⚡ 전체 수락 모드"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvAcceptAllSub = TextView(this).apply {
            text = "키워드 무시 — 모든 콜 자동 수락"
            textSize = 12f
            setTextColor(TEXT_SEC)
        }
        acceptAllTextCol.addView(tvAcceptAllTitle)
        acceptAllTextCol.addView(tvAcceptAllSub)
        acceptAllRow.addView(acceptAllTextCol)

        switchAcceptAll = Switch(this).apply {
            isChecked = PrefsManager.isAcceptAll(this@MainActivity)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.parseColor("#FFB800"), Color.parseColor("#444444"))
            )
        }
        acceptAllRow.addView(switchAcceptAll)
        acceptAllCard.addView(acceptAllRow)
        root.addView(acceptAllCard)
        root.addView(space(8))

        // 3. Blacklist Card: 블랙리스트 모드
        val blacklistCard = card(CARD, BORDER)
        val blacklistRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        val blacklistTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvBlacklistTitle = TextView(this).apply {
            text = "🚫 블랙리스트 모드"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvBlacklistSub = TextView(this).apply {
            text = "키워드 포함 콜 거절 — 나머지 전부 수락"
            textSize = 12f
            setTextColor(TEXT_SEC)
        }
        blacklistTextCol.addView(tvBlacklistTitle)
        blacklistTextCol.addView(tvBlacklistSub)
        blacklistRow.addView(blacklistTextCol)

        switchBlacklistMode = Switch(this).apply {
            isChecked = PrefsManager.isBlacklistMode(this@MainActivity)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.parseColor("#FF5555"), Color.parseColor("#444444"))
            )
        }
        blacklistRow.addView(switchBlacklistMode)
        blacklistCard.addView(blacklistRow)
        root.addView(blacklistCard)
        root.addView(space(8))

        // 4. OCR Poll Card: OCR 자동수락
        val ocrPollCard = card(CARD, BORDER)
        val ocrPollRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        val ocrPollTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvOcrTitle = TextView(this).apply {
            text = "📸 OCR 자동수락 (0.8초 폴링)"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvOcrSub = TextView(this).apply {
            text = "스크린샷으로 키워드 감지 → 수락버튼 탭"
            textSize = 12f
            setTextColor(TEXT_SEC)
        }
        ocrPollTextCol.addView(tvOcrTitle)
        ocrPollTextCol.addView(tvOcrSub)
        ocrPollRow.addView(ocrPollTextCol)

        switchOcrPoll = Switch(this).apply {
            isChecked = PrefsManager.isOcrPoll(this@MainActivity)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.parseColor("#CC44FF"), Color.parseColor("#444444"))
            )
        }
        ocrPollRow.addView(switchOcrPoll)
        ocrPollCard.addView(ocrPollRow)
        root.addView(ocrPollCard)
        root.addView(space(8))

        // 5. Dismiss Card: 불일치 콜 자동 닫기 + 쿨타임 SeekBar
        val dismissCard = card(CARD, BORDER)
        val dismissRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        val dismissTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvDismissTitle = TextView(this).apply {
            text = "✕ 불일치 콜 자동 닫기"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvDismissSub = TextView(this).apply {
            text = "키워드 불일치 콜 — X 버튼 자동 클릭"
            textSize = 12f
            setTextColor(TEXT_SEC)
        }
        dismissTextCol.addView(tvDismissTitle)
        dismissTextCol.addView(tvDismissSub)
        dismissRow.addView(dismissTextCol)

        switchAutoDismiss = Switch(this).apply {
            isChecked = PrefsManager.isAutoDismiss(this@MainActivity)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.parseColor("#FF6B35"), Color.parseColor("#444444"))
            )
        }
        dismissRow.addView(switchAutoDismiss)
        dismissCard.addView(dismissRow)
        dismissCard.addView(space(8))

        val cooldownRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val tvCooldownLabel = TextView(this).apply {
            text = "닫기 쿨타임"
            textSize = 13f
            setTextColor(TEXT_SEC)
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        tvDismissCooldown = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#FF6B35"))
            typeface = Typeface.DEFAULT_BOLD
        }
        cooldownRow.addView(tvCooldownLabel)
        cooldownRow.addView(tvDismissCooldown)
        dismissCard.addView(cooldownRow)

        seekDismissCooldown = SeekBar(this).apply {
            max = 10
            progressTintList = ColorStateList.valueOf(Color.parseColor("#FF6B35"))
        }
        dismissCard.addView(seekDismissCooldown)
        root.addView(dismissCard)
        root.addView(space(8))

        // 6. Sleep Alarm Card: 수면 알람
        val sleepCard = card(CARD, BORDER)
        val sleepRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        val sleepTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvSleepTitle = TextView(this).apply {
            text = "수면 알람"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvSleepSub = TextView(this).apply {
            text = "콜 수락 시 알람 소리 + 진동 (10초)"
            textSize = 12f
            setTextColor(TEXT_SEC)
        }
        sleepTextCol.addView(tvSleepTitle)
        sleepTextCol.addView(tvSleepSub)
        sleepRow.addView(sleepTextCol)

        switchSleepAlarm = Switch(this).apply {
            isChecked = PrefsManager.isSleepAlarm(this@MainActivity)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.parseColor("#00BFFF"), Color.parseColor("#444444"))
            )
        }
        sleepRow.addView(switchSleepAlarm)
        sleepCard.addView(sleepRow)
        root.addView(sleepCard)
        root.addView(space(8))

        // 7. Airport Mode Card: 공항 모드
        val airportCard = card(CARD, BORDER)
        val airportRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        val airportTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvAirportTitle = TextView(this).apply {
            text = "공항 모드"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvAirportSub = TextView(this).apply {
            text = "최속 수락 (딜레이 50ms · 폴링 250ms · 쿨다운 없음)"
            textSize = 12f
            setTextColor(TEXT_SEC)
        }
        airportTextCol.addView(tvAirportTitle)
        airportTextCol.addView(tvAirportSub)
        airportRow.addView(airportTextCol)

        switchAirportMode = Switch(this).apply {
            isChecked = PrefsManager.isAirportMode(this@MainActivity)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.parseColor("#F0A500"), Color.parseColor("#444444"))
            )
        }
        airportRow.addView(switchAirportMode)
        airportCard.addView(airportRow)
        root.addView(airportCard)
        root.addView(space(8))

        // 8. Accept No Delay Card: 수락 무딜레이
        val noDelayCard = card(CARD, BORDER)
        val noDelayRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        val noDelayTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvNoDelayTitle = TextView(this).apply {
            text = "수락 무딜레이"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvNoDelaySub = TextView(this).apply {
            text = "수락만 0ms 즉시 탭 · 거절 딜레이는 그대로 유지"
            textSize = 12f
            setTextColor(TEXT_SEC)
        }
        noDelayTextCol.addView(tvNoDelayTitle)
        noDelayTextCol.addView(tvNoDelaySub)
        noDelayRow.addView(noDelayTextCol)

        switchAcceptNoDelay = Switch(this).apply {
            isChecked = PrefsManager.isAcceptNoDelay(this@MainActivity)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.parseColor("#E53935"), Color.parseColor("#444444"))
            )
        }
        noDelayRow.addView(switchAcceptNoDelay)
        noDelayCard.addView(noDelayRow)
        root.addView(noDelayCard)
        root.addView(space(8))

        // 9. Bubble Card: 위젯
        val bubbleCard = card(CARD, BORDER)
        val bubbleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        val bubbleTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvBubbleTitle = TextView(this).apply {
            text = "위젯"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvBubbleSub = TextView(this).apply {
            text = "화면 위에 뜨는 콜대기중 버튼"
            textSize = 12f
            setTextColor(TEXT_SEC)
        }
        bubbleTextCol.addView(tvBubbleTitle)
        bubbleTextCol.addView(tvBubbleSub)
        bubbleRow.addView(bubbleTextCol)

        switchFloatingBubble = Switch(this).apply {
            isChecked = PrefsManager.isFloatingBubble(this@MainActivity)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(ACCENT, Color.parseColor("#444444"))
            )
        }
        bubbleRow.addView(switchFloatingBubble)
        bubbleCard.addView(bubbleRow)
        root.addView(bubbleCard)
        root.addView(space(12))

        // 10. Buttons for Settings
        btnAccessibility = Button(this).apply {
            text = "접근성 서비스 설정 열기"
            textSize = 14f
            setTextColor(Color.WHITE)
            background = roundRect(Color.parseColor("#276EF1"), dp(12))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(50))
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        root.addView(btnAccessibility)
        root.addView(space(8))

        btnNotification = Button(this).apply {
            text = "알림 접근 권한 설정 열기"
            textSize = 14f
            setTextColor(Color.WHITE)
            background = roundRect(Color.parseColor("#E65C00"), dp(12))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(50))
            setOnClickListener {
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            }
        }
        root.addView(btnNotification)
        root.addView(space(16))

        // 11. Add Card (Destination keywords + fast chips)
        val addCard = card(CARD, BORDER)
        val addRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        etKeyword = EditText(this).apply {
            hint = "목적지 키워드"
            setHintTextColor(Color.parseColor("#555555"))
            setTextColor(Color.WHITE)
            textSize = 14f
            val gd = GradientDrawable().apply {
                setColor(Color.parseColor("#272727"))
                cornerRadius = dp(10).toFloat()
            }
            background = gd
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setSingleLine(true)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply {
                weight = 1f
                marginEnd = dp(8)
            }
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                    addKeywordFromInput()
                    true
                } else false
            }
        }
        addRow.addView(etKeyword)

        btnAdd = Button(this).apply {
            text = "추가"
            textSize = 13f
            setTextColor(Color.WHITE)
            background = roundRect(ACCENT, dp(10))
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(44))
            setPadding(0, 0, 0, 0)
            setOnClickListener {
                addKeywordFromInput()
            }
        }
        addRow.addView(btnAdd)
        addCard.addView(addRow)
        addCard.addView(space(10))

        val tvPresetHeader = TextView(this).apply {
            text = "자주 쓰는 목적지"
            textSize = 11f
            setTextColor(TEXT_SEC)
        }
        addCard.addView(tvPresetHeader)
        addCard.addView(space(6))

        val presetFlow = FlexWrapLayout(this)
        val popularKws = listOf("인천공항", "강남", "잠실", "홍대", "서울역", "여의도", "공항")
        for (kw in popularKws) {
            val chip = TextView(this).apply {
                text = "+ $kw"
                textSize = 12f
                setTextColor(ACCENT)
                background = roundRect(Color.parseColor("#0D1F17"), dp(8))
                setPadding(dp(10), dp(6), dp(10), dp(6))
                setOnClickListener {
                    addKeyword(kw)
                }
            }
            presetFlow.addView(chip)
        }
        addCard.addView(presetFlow)
        root.addView(addCard)
        root.addView(space(12))

        // 12. Keywords Header & RecyclerView
        val kwHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                bottomMargin = dp(6)
            }
        }
        val tvKwHeader = TextView(this).apply {
            text = "키워드 목록"
            textSize = 13f
            setTextColor(TEXT_SEC)
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        kwHeaderRow.addView(tvKwHeader)

        val btnClearAll = Button(this).apply {
            text = "전체 삭제"
            textSize = 12f
            setTextColor(Color.parseColor("#FF5555"))
            background = roundRect(Color.parseColor("#2A1515"), dp(8))
            setPadding(dp(12), dp(4), dp(12), dp(4))
            layoutParams = LinearLayout.LayoutParams(WRAP, dp(34))
            setOnClickListener {
                if (keywords.isEmpty()) {
                    Toast.makeText(this@MainActivity, "삭제할 키워드가 없습니다", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("전체 삭제")
                    .setMessage("등록된 모든 키워드를 삭제할까요?")
                    .setPositiveButton("삭제") { _, _ ->
                        val count = keywords.size
                        keywords.clear()
                        adapter.notifyItemRangeRemoved(0, count)
                        PrefsManager.saveKeywords(this@MainActivity, keywords)
                        updateStats()
                        Toast.makeText(this@MainActivity, "${count}개 삭제됨", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("취소", null)
                    .show()
            }
        }
        kwHeaderRow.addView(btnClearAll)
        root.addView(kwHeaderRow)

        rvKeywords = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
        }
        adapter = KeywordAdapter(keywords) { pos ->
            keywords.removeAt(pos)
            adapter.notifyItemRemoved(pos)
            PrefsManager.saveKeywords(this, keywords)
            updateStats()
        }
        rvKeywords.adapter = adapter
        root.addView(rvKeywords)
        root.addView(space(12))

        // 13. Preset Card (키워드 프리셋)
        val presetCard = card(CARD, BORDER)
        val presetHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val presetTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvPresetTitle = TextView(this).apply {
            text = "키워드 프리셋"
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvPresetSub = TextView(this).apply {
            text = "탭하면 해당 키워드 목록으로 전환"
            textSize = 12f
            setTextColor(TEXT_SEC)
        }
        presetTextCol.addView(tvPresetTitle)
        presetTextCol.addView(tvPresetSub)
        presetHeaderRow.addView(presetTextCol)

        val btnSavePreset = Button(this).apply {
            text = "+ 현재 저장"
            textSize = 12f
            setTextColor(Color.WHITE)
            background = roundRect(Color.parseColor("#276EF1"), dp(10))
            layoutParams = LinearLayout.LayoutParams(WRAP, dp(36))
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener {
                showSavePresetDialog()
            }
        }
        presetHeaderRow.addView(btnSavePreset)
        presetCard.addView(presetHeaderRow)
        presetCard.addView(space(10))

        rvPresets = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            isNestedScrollingEnabled = false
        }
        presetAdapter = PresetAdapter(
            presets,
            onApply = { pos ->
                val p = presets[pos]
                keywords.clear()
                keywords.addAll(p.keywords)
                adapter.notifyDataSetChanged()
                PrefsManager.saveKeywords(this@MainActivity, keywords)
                updateStats()
                Toast.makeText(this@MainActivity, "「${p.name}」 적용됨", Toast.LENGTH_SHORT).show()
            },
            onEdit = { pos ->
                showEditPresetDialog(pos)
            },
            onDelete = { pos ->
                showDeletePresetDialog(pos)
            }
        )
        rvPresets.adapter = presetAdapter
        presetCard.addView(rvPresets)
        root.addView(presetCard)
        root.addView(space(12))

        // 14. Human Simulation Card (딜레이 & 진동)
        val humanCard = card(CARD, BORDER)
        val humanHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val humanTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvHumanTitle = TextView(this).apply {
            text = "인간 반응 시뮬레이션"
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvHumanSub = TextView(this).apply {
            text = "랜덤 딜레이로 패턴 감지 방어"
            textSize = 12f
            setTextColor(TEXT_SEC)
        }
        humanTextCol.addView(tvHumanTitle)
        humanTextCol.addView(tvHumanSub)
        humanHeader.addView(humanTextCol)

        switchHumanMode = Switch(this).apply {
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(ACCENT, Color.parseColor("#444444"))
            )
        }
        humanHeader.addView(switchHumanMode)
        humanCard.addView(humanHeader)
        humanCard.addView(space(12))

        val minDelayRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val tvMinLabel = TextView(this).apply {
            text = "최소 딜레이"
            textSize = 13f
            setTextColor(TEXT_SEC)
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        tvMinDelay = TextView(this).apply {
            textSize = 13f
            setTextColor(ACCENT)
            typeface = Typeface.DEFAULT_BOLD
        }
        minDelayRow.addView(tvMinLabel)
        minDelayRow.addView(tvMinDelay)
        humanCard.addView(minDelayRow)

        seekMinDelay = SeekBar(this).apply {
            max = 14
            progressTintList = ColorStateList.valueOf(ACCENT)
        }
        humanCard.addView(seekMinDelay)
        humanCard.addView(space(8))

        val maxDelayRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val tvMaxLabel = TextView(this).apply {
            text = "최대 딜레이"
            textSize = 13f
            setTextColor(TEXT_SEC)
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        tvMaxDelay = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.parseColor("#FFB800"))
            typeface = Typeface.DEFAULT_BOLD
        }
        maxDelayRow.addView(tvMaxLabel)
        maxDelayRow.addView(tvMaxDelay)
        humanCard.addView(maxDelayRow)

        seekMaxDelay = SeekBar(this).apply {
            max = 14
            progressTintList = ColorStateList.valueOf(Color.parseColor("#FFB800"))
        }
        humanCard.addView(seekMaxDelay)
        humanCard.addView(space(8))

        val vibRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        val tvVibLabel = TextView(this).apply {
            text = "수락 시 진동"
            textSize = 13f
            setTextColor(TEXT_SEC)
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        switchVibration = Switch(this).apply {
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(ACCENT, Color.parseColor("#444444"))
            )
        }
        vibRow.addView(tvVibLabel)
        vibRow.addView(switchVibration)
        humanCard.addView(vibRow)
        root.addView(humanCard)
        root.addView(space(12))

        // 15. Screenshot Card (수락 시 스크린샷)
        val screenshotCard = card(CARD, BORDER)
        val screenshotRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        val screenshotTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        val tvScreenshotTitle = TextView(this).apply {
            text = "수락 시 스크린샷"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvScreenshotSub = TextView(this).apply {
            text = "콜 수락 시 화면을 DCIM/스마트알림/ 에 저장"
            textSize = 12f
            setTextColor(TEXT_SEC)
        }
        screenshotTextCol.addView(tvScreenshotTitle)
        screenshotTextCol.addView(tvScreenshotSub)
        screenshotRow.addView(screenshotTextCol)

        switchAcceptScreenshot = Switch(this).apply {
            isChecked = PrefsManager.isAcceptScreenshot(this@MainActivity)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            trackTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(Color.parseColor("#06C167"), Color.parseColor("#444444"))
            )
        }
        screenshotRow.addView(switchAcceptScreenshot)
        screenshotCard.addView(screenshotRow)
        root.addView(screenshotCard)
        root.addView(space(12))

        // 16. Real-time Diagnostic Log Card (실시간 진단 로그)
        val diagLogCard = card(CARD, BORDER)

        val diagHeaderRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }

        val diagTextCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }

        val tvDiagTitle = TextView(this).apply {
            text = "실시간 진단 로그"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvDiagSub = TextView(this).apply {
            text = "이벤트 및 동작 상태 실시간 스트림"
            textSize = 11f
            setTextColor(TEXT_SEC)
        }
        diagTextCol.addView(tvDiagTitle)
        diagTextCol.addView(tvDiagSub)
        diagHeaderRow.addView(diagTextCol)

        diagLogCard.addView(diagHeaderRow)
        diagLogCard.addView(space(10))

        // Action buttons row: [로그 초기화] [진단 로그 공유]
        val diagBtnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        btnClearDiagLog = Button(this).apply {
            text = "로그 초기화"
            textSize = 12f
            setTextColor(Color.WHITE)
            background = roundRect(Color.parseColor("#444444"), dp(8))
            layoutParams = LinearLayout.LayoutParams(0, dp(40)).apply {
                weight = 1f
                rightMargin = dp(6)
            }
            setOnClickListener {
                LogBuffer.clear(this@MainActivity)
                updateDiagLogUI()
                Toast.makeText(this@MainActivity, "진단 로그가 초기화되었습니다", Toast.LENGTH_SHORT).show()
            }
        }

        btnShareDiagLog = Button(this).apply {
            text = "진단 로그 공유"
            textSize = 12f
            setTextColor(Color.WHITE)
            background = roundRect(Color.parseColor("#276EF1"), dp(8))
            layoutParams = LinearLayout.LayoutParams(0, dp(40)).apply {
                weight = 1f
                leftMargin = dp(6)
            }
            setOnClickListener {
                shareDiagnosticLog()
            }
        }

        diagBtnRow.addView(btnClearDiagLog)
        diagBtnRow.addView(btnShareDiagLog)
        diagLogCard.addView(diagBtnRow)
        diagLogCard.addView(space(10))

        // Monospace Log View inside ScrollView (Fixed height, independent scroll)
        svDiagLog = ScrollView(this).apply {
            background = roundRect(Color.parseColor("#0D0D0D"), dp(8))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(240))
            isScrollbarFadingEnabled = false
            isFocusable = false
            isFocusableInTouchMode = false
            descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
            setOnTouchListener { v, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                        v.parent?.requestDisallowInterceptTouchEvent(true)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        v.parent?.requestDisallowInterceptTouchEvent(false)
                    }
                }
                false
            }
        }

        tvDiagLog = TextView(this).apply {
            textSize = 10.5f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.parseColor("#00E676"))
            isFocusable = false
            isFocusableInTouchMode = false
            setTextIsSelectable(false)
            text = "[진단 로그 대기 중...]\n"
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        }
        svDiagLog.addView(tvDiagLog)
        diagLogCard.addView(svDiagLog)

        root.addView(diagLogCard)
        root.addView(space(12))

        // 17. Export Log Button
        val btnExportLog = Button(this).apply {
            text = "로그 파일 내보내기"
            textSize = 14f
            setTextColor(Color.WHITE)
            background = roundRect(Color.parseColor("#555555"), dp(12))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(50))
            setOnClickListener {
                exportLog()
            }
        }
        root.addView(btnExportLog)
        root.addView(space(20))

        rootScroll.addView(root)
        setContentView(rootScroll)
    }

    private fun buildStatView(TEXT: Int, TEXT_SEC: Int, label: String): Pair<TextView, LinearLayout> {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
            setPadding(dp(8), dp(12), dp(8), dp(12))
        }
        val tvValue = TextView(this).apply {
            text = "0"
            textSize = 22f
            gravity = android.view.Gravity.CENTER
            setTextColor(TEXT)
            typeface = Typeface.DEFAULT_BOLD
        }
        val tvLabel = TextView(this).apply {
            text = label
            textSize = 11f
            gravity = android.view.Gravity.CENTER
            setTextColor(TEXT_SEC)
        }
        col.addView(tvValue)
        col.addView(tvLabel)
        return Pair(tvValue, col)
    }

    private fun setupListeners() {
        switchActive.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setActive(this, isChecked)
            updateAccessibilityStatus()
        }
        switchAcceptAll.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setAcceptAll(this, isChecked)
        }
        switchBlacklistMode.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setBlacklistMode(this, isChecked)
        }
        switchOcrPoll.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setOcrPoll(this, isChecked)
        }
        switchAutoDismiss.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setAutoDismiss(this, isChecked)
        }
        switchSleepAlarm.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.saveSleepAlarm(this, isChecked)
        }
        switchAirportMode.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.saveAirportMode(this, isChecked)
        }
        switchAcceptNoDelay.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.saveAcceptNoDelay(this, isChecked)
        }
        switchAcceptScreenshot.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.saveAcceptScreenshot(this, isChecked)
        }
        switchFloatingBubble.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.saveFloatingBubble(this, isChecked)
            if (isChecked) {
                if (Settings.canDrawOverlays(this)) {
                    startService(Intent(this, FloatingBubbleService::class.java))
                } else {
                    switchFloatingBubble.isChecked = false
                    PrefsManager.saveFloatingBubble(this, false)
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    startActivity(intent)
                    Toast.makeText(this, "다른 앱 위에 표시 권한을 허용한 뒤 다시 켜주세요", Toast.LENGTH_LONG).show()
                }
            } else {
                stopService(Intent(this, FloatingBubbleService::class.java))
            }
        }
        switchHumanMode.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setHumanMode(this, isChecked)
        }
        switchVibration.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setVibration(this, isChecked)
        }

        seekMinDelay.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val delayMs = ((progress * 0.5 + 0.5) * 1000).toLong()
                tvMinDelay.text = "${delayMs / 1000.0}초"
                if (fromUser) {
                    PrefsManager.saveMinDelayMs(this@MainActivity, delayMs)
                    if (delayMs > PrefsManager.getMaxDelayMs(this@MainActivity)) {
                        seekMaxDelay.progress = progress
                        PrefsManager.saveMaxDelayMs(this@MainActivity, delayMs)
                        tvMaxDelay.text = "${delayMs / 1000.0}초"
                    }
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        seekMaxDelay.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val delayMs = ((progress * 0.5 + 0.5) * 1000).toLong()
                tvMaxDelay.text = "${delayMs / 1000.0}초"
                if (fromUser) {
                    PrefsManager.saveMaxDelayMs(this@MainActivity, delayMs)
                    if (delayMs < PrefsManager.getMinDelayMs(this@MainActivity)) {
                        seekMinDelay.progress = progress
                        PrefsManager.saveMinDelayMs(this@MainActivity, delayMs)
                        tvMinDelay.text = "${delayMs / 1000.0}초"
                    }
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        seekDismissCooldown.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val cooldownMs = (progress * 500).toLong()
                tvDismissCooldown.text = "${cooldownMs / 1000.0}초"
                if (fromUser) {
                    PrefsManager.saveDismissCooldownMs(this@MainActivity, cooldownMs)
                }
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun loadSettings() {
        val minMs = PrefsManager.getMinDelayMs(this)
        val maxMs = PrefsManager.getMaxDelayMs(this)

        seekMinDelay.progress = (((minMs / 1000.0 - 0.5) / 0.5)).toInt().coerceIn(0, 14)
        seekMaxDelay.progress = (((maxMs / 1000.0 - 0.5) / 0.5)).toInt().coerceIn(0, 14)
        tvMinDelay.text = "${minMs / 1000.0}초"
        tvMaxDelay.text = "${maxMs / 1000.0}초"

        switchHumanMode.isChecked = PrefsManager.isHumanMode(this)
        switchVibration.isChecked = PrefsManager.isVibration(this)

        val cooldownMs = PrefsManager.getDismissCooldownMs(this)
        val cooldownStep = ((cooldownMs / 1000.0) / 0.5).toInt().coerceIn(0, 10)
        seekDismissCooldown.progress = cooldownStep
        tvDismissCooldown.text = "${cooldownMs / 1000.0}초"
    }

    private fun addKeywordFromInput() {
        addKeyword(etKeyword.text.toString())
        etKeyword.text.clear()
    }

    private fun addKeyword(text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        if (keywords.any { it.equals(trimmed, ignoreCase = true) }) {
            Toast.makeText(this, "이미 등록된 키워드입니다", Toast.LENGTH_SHORT).show()
            return
        }
        keywords.add(0, trimmed)
        adapter.notifyItemInserted(0)
        PrefsManager.saveKeywords(this, keywords)
        updateStats()
    }

    private fun updateStats() {
        tvCallCount.text = PrefsManager.getCallCount(this).toString()
        tvAcceptScheduled.text = PrefsManager.getAcceptScheduled(this).toString()
        tvDismissScheduled.text = PrefsManager.getDismissExecuted(this).toString()

        val rectStr = PrefsManager.getLastAcceptRectString(this)
        val diagStr = PrefsManager.getDismissDiag(this)
        val hasTree = diagStr.contains("노드수:")
        val nodeCount = if (hasTree) {
            val match = Regex("노드수: (\\d+)").find(diagStr)
            match?.groupValues?.getOrNull(1) ?: "?"
        } else {
            "-"
        }
        tvDismissDebug.text = "수락버튼: $rectStr  |  노드수: $nodeCount"
    }

    private fun showDiagDialog() {
        val diag = PrefsManager.getDismissDiag(this)
        val tv = TextView(this).apply {
            text = diag
            textSize = 9f
            setTextColor(Color.parseColor("#CCCCCC"))
            setPadding(dp(16), dp(8), dp(16), dp(8))
            
        }
        val sv = ScrollView(this).apply {
            addView(tv)
        }
        AlertDialog.Builder(this)
            .setTitle("닫기 진단 — 접근성 트리 덤프")
            .setView(sv)
            .setPositiveButton("닫기", null)
            .show()
    }

    private fun showSavePresetDialog() {
        val nameInput = EditText(this).apply {
            hint = "프리셋 이름 (예: 강남권)"
            setHintTextColor(Color.parseColor("#555555"))
            setTextColor(Color.WHITE)
            textSize = 14f
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#272727"))
                cornerRadius = dp(10).toFloat()
            }
            setPadding(dp(14), dp(10), dp(14), dp(10))
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }

        if (keywords.isEmpty()) {
            Toast.makeText(this, "저장할 키워드가 없습니다", Toast.LENGTH_SHORT).show()
            return
        }

        AlertDialog.Builder(this)
            .setTitle("프리셋으로 저장")
            .setMessage("현재 키워드: ${keywords.joinToString(", ")}")
            .setView(nameInput)
            .setPositiveButton("저장") { _, _ ->
                val name = nameInput.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(this, "이름을 입력해주세요", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val existing = presets.indexOfFirst { it.name == name }
                val preset = KeywordPreset(name, keywords.toList())
                if (existing >= 0) {
                    presets[existing] = preset
                    presetAdapter.notifyItemChanged(existing)
                } else {
                    presets.add(preset)
                    presetAdapter.notifyItemInserted(presets.size - 1)
                }
                PrefsManager.savePresets(this, presets)
                Toast.makeText(this, "「${name}」 저장됨", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun showEditPresetDialog(pos: Int) {
        val p = presets[pos]
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
        }
        val nameInput = EditText(this).apply {
            setText(p.name)
            setTextColor(Color.WHITE)
            textSize = 14f
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#272727"))
                cornerRadius = dp(10).toFloat()
            }
            setPadding(dp(14), dp(10), dp(14), dp(10))
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            hint = "프리셋 이름"
            setHintTextColor(Color.parseColor("#555555"))
        }
        val kwInput = EditText(this).apply {
            setText(p.keywords.joinToString(", "))
            setTextColor(Color.WHITE)
            textSize = 14f
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#272727"))
                cornerRadius = dp(10).toFloat()
            }
            setPadding(dp(14), dp(10), dp(14), dp(10))
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            hint = "키워드 (쉼표로 구분)"
            setHintTextColor(Color.parseColor("#555555"))
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                topMargin = dp(10)
            }
        }

        val tvNameLabel = TextView(this).apply {
            text = "프리셋 이름"
            setTextColor(Color.parseColor("#9A9A9A"))
            textSize = 12f
        }
        val tvKwLabel = TextView(this).apply {
            text = "키워드 (쉼표로 구분)"
            setTextColor(Color.parseColor("#9A9A9A"))
            textSize = 12f
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                topMargin = dp(12)
            }
        }

        container.addView(tvNameLabel)
        container.addView(nameInput)
        container.addView(tvKwLabel)
        container.addView(kwInput)

        AlertDialog.Builder(this)
            .setTitle("프리셋 수정")
            .setView(container)
            .setPositiveButton("저장") { _, _ ->
                val name = nameInput.text.toString().trim()
                if (name.isEmpty()) {
                    Toast.makeText(this, "이름을 입력해주세요", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val kws = kwInput.text.toString().split(",").map { it.trim() }.filter { it.isNotEmpty() }
                presets[pos] = KeywordPreset(name, kws)
                presetAdapter.notifyItemChanged(pos)
                PrefsManager.savePresets(this, presets)
                Toast.makeText(this, "「${name}」 수정됨", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun showDeletePresetDialog(pos: Int) {
        val name = presets[pos].name
        AlertDialog.Builder(this)
            .setTitle("프리셋 삭제")
            .setMessage("「${name}」을 삭제할까요?\n이 작업은 되돌릴 수 없습니다.")
            .setPositiveButton("삭제") { _, _ ->
                presets.removeAt(pos)
                presetAdapter.notifyItemRemoved(pos)
                PrefsManager.savePresets(this, presets)
                Toast.makeText(this, "「${name}」 삭제됨", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun updateStatus(active: Boolean) {
        val ACCENT = Color.parseColor("#06C167")
        if (active) {
            tvStatus.text = "● 활성"
            tvStatus.setTextColor(ACCENT)
        } else {
            tvStatus.text = "● 비활성"
            tvStatus.setTextColor(Color.parseColor("#9A9A9A"))
        }
    }

    private fun updateAccessibilityStatus() {
        val enabled = AutoAcceptService.isRunning
        val active = PrefsManager.isActive(this)
        updateStatus(active && enabled)
        switchActive.isChecked = active

        val notifOk = NotificationListener.isEnabled(this)
        btnNotification.text = if (notifOk) {
            "알림 접근 권한 허용됨 ✓"
        } else {
            "알림 접근 권한 설정 열기 (목적지 인식 필요)"
        }
        btnNotification.background = roundRect(
            Color.parseColor(if (notifOk) "#1E7E34" else "#E65C00"),
            dp(12)
        )
    }

    private fun updateDiagLogUI() {
        if (::tvDiagLog.isInitialized) {
            val allLogs = LogBuffer.getAll(this)
            val text = if (allLogs.isEmpty()) {
                "[진단 로그 대기 중... 새로운 이벤트가 감지되면 여기에 실시간 표시됩니다]\n"
            } else {
                allLogs.joinToString("\n") + "\n"
            }
            tvDiagLog.text = text
            scrollLogToBottom()
        }
    }

    private fun shareDiagnosticLog() {
        val logText = LogBuffer.read(this)
        if (logText.isBlank()) {
            Toast.makeText(this, "공유할 진단 로그가 없습니다", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            val shareFile = File(cacheDir, "diagnostic_log_$timestamp.txt")
            shareFile.writeText(logText)

            val fileUri = androidx.core.content.FileProvider.getUriForFile(
                this,
                "com.uber.autoaccept.test.fileprovider",
                shareFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "스마트알림 실시간 진단 로그 ($timestamp)")
                putExtra(Intent.EXTRA_TEXT, logText)
                putExtra(Intent.EXTRA_STREAM, fileUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            startActivity(Intent.createChooser(shareIntent, "진단 로그 공유"))
        } catch (e: Exception) {
            Toast.makeText(this, "로그 공유 실패: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun exportLog() {
        Toast.makeText(this, "로그 저장 중...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                val output = LogBuffer.read(this)
                if (output.isBlank()) {
                    runOnUiThread {
                        Toast.makeText(this, "로그가 없습니다.\n앱이 실행된 후 콜을 받으면 자동으로 기록됩니다.", Toast.LENGTH_LONG).show()
                    }
                    return@Thread
                }
                val content = "=== 스마트알림 로그 $timestamp ===\n\n$output"
                val fileName = "smart_alarm_$timestamp.txt"
                val saved = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val cv = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                        put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                    if (uri != null) {
                        contentResolver.openOutputStream(uri)?.use { os ->
                            os.write(content.toByteArray(Charsets.UTF_8))
                        }
                        cv.clear()
                        cv.put(MediaStore.Downloads.IS_PENDING, 0)
                        contentResolver.update(uri, cv, null, null)
                        true
                    } else false
                } else {
                    val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    dir.mkdirs()
                    File(dir, fileName).writeText(content)
                    true
                }
                runOnUiThread {
                    if (saved) {
                        Toast.makeText(this, "다운로드 폴더에 저장됨:\n$fileName", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, "저장 실패 — 다시 시도하세요.", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "로그 저장 실패: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    private fun space(dp: Int): View {
        return View(this).apply {
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(dp))
        }
    }

    private fun card(bgColor: Int, borderColor: Int): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            val gd = GradientDrawable().apply {
                setColor(bgColor)
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), borderColor)
            }
            background = gd
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                bottomMargin = 0
            }
        }
    }

    private fun roundRect(color: Int, radius: Int): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }
    }

    private fun dividerV(color: Int): View {
        return View(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(1), MATCH)
            setBackgroundColor(color)
        }
    }
}
