package com.uber.autoaccept

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.media.Ringtone
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.MediaStore
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.content.ContextCompat
import com.google.android.gms.dynamite.DynamiteModule
import com.google.mlkit.common.MlKitException
import com.google.android.gms.common.moduleinstall.ModuleInstall
import com.google.android.gms.common.moduleinstall.ModuleInstallRequest
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import rikka.shizuku.Shizuku
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.sqrt
import kotlin.random.Random

class AutoAcceptService : AccessibilityService() {

    companion object {
        private const val TAG = "UberAutoAccept"
        private const val UBER_DRIVER_PACKAGE = "com.ubercab.driver"
        private const val SIMULATOR_PACKAGE = "com.uber.autoaccept.simulator"
        private const val COOLDOWN_MS = 10000L

        private val ACCEPT_BUTTON_TEXTS = listOf("콜 수락", "콜수락", "수락")
        private val DISMISS_BUTTON_TEXTS = listOf("뒤로", "닫기", "Close", "close", "×", "✕", "X")
        private val NORMAL_SCREEN_KEYWORDS = listOf(
            "운행 요청을 찾고 있습니다",
            "운행요청을 찾고 있습니다",
            "운행 명세서",
            "운행명세서",
            "안전 도구 키트",
            "안전 도구키트",
            "안전도구 키트",
            "안전도구키트",
            "맞춤 추천",
            "맞춤추천",
            "오프라인으로 전환할 수 없습니다",
            "오프라인으로 전환"
        )

        @Volatile
        var isRunning: Boolean = false
    }

    private val handler = Handler(Looper.getMainLooper())
    private val ocrExecutor = Executors.newSingleThreadExecutor()
    private val shizukuExecutor = Executors.newSingleThreadExecutor { r ->
        Thread(r, "ShizukuWorker")
    }

    @Volatile
    private var ocrRecognizerInstance: TextRecognizer? = null

    @Synchronized
    private fun getOcrRecognizer(): TextRecognizer {
        return ocrRecognizerInstance ?: run {
            val appContext = applicationContext ?: this
            try {
                com.google.mlkit.common.sdkinternal.MlKitContext.initializeIfNeeded(appContext)
            } catch (_: Throwable) {}
            TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()).also {
                ocrRecognizerInstance = it
            }
        }
    }

    private var lastAcceptTime = 0L
    private var lastDismissTime = 0L
    private var lastCallCardTime = 0L
    private var callCardFirstSeenAt = 0L
    private var lastHumanDelay = 0L
    private var dismissAttempts = 0
    private var fastPollUntilMs = 0L

    private var pendingAccept = false
    private var pendingDismiss = false
    private var pendingAcceptVerify = false
    private var ocrCaptureInflight = false

    private var activeTargetPackage: String = UBER_DRIVER_PACKAGE
    private var bufferedEventCount: Int = 0
    private var callKeywordSeenAtMs: Long = 0L
    private var screenshotPollActive: Boolean = false
    private var savedAcceptRect: Rect? = null
    private var lastForegroundPkg: String? = null
    private var backgroundPollEnabled = false
    private var lastNotForegroundLogTime = 0L
    private var dismissTapFiredAtMs: Long = 0L
    private var dismissEventLogCount: Int = 0
    private var sleepAlarmRingtone: Ringtone? = null

    private var lastGateResult: String? = null
    private var lastKeepWarmFailed: Boolean = false
    private var hasLoggedKeepWarmSuccess: Boolean = false

    enum class OcrState {
        INITIALIZING,
        READY,
        MODEL_UNAVAILABLE,
        DETECTOR_INIT_FAILED,
        RETRY_WAIT
    }

    @Volatile
    private var currentOcrState: OcrState = OcrState.INITIALIZING
    private var lastOcrStateLogged: OcrState? = null
    private var lastStateLogMsg: String = ""
    private var lastOcrFailTime: Long = 0L
    private val ocrRecreateCooldownMs: Long = 15000L

    private fun setOcrState(newState: OcrState, detail: String = "") {
        currentOcrState = newState
        val logMsg = if (detail.isNotEmpty()) "[ML-KIT-STATE] ${newState.name} - $detail" else "[ML-KIT-STATE] ${newState.name}"
        if (lastOcrStateLogged != newState || lastStateLogMsg != detail) {
            lastOcrStateLogged = newState
            lastStateLogMsg = detail
            Log.i(TAG, logMsg)
            LogBuffer.log(this, TAG, logMsg)
            LogBuffer.diag(this, "ML-KIT-STATE", "state=${newState.name}, detail=$detail")
        }
    }

    private val xBtnTemplates = mutableListOf<TemplateData>()
    private val acceptBtnTemplates = mutableListOf<TemplateData>()

    private val acceptTimeoutRunnable = Runnable {
        if (pendingAccept) {
            Log.w(TAG, "수락 안전 타임아웃 → 상태 리셋")
            LogBuffer.diag(this, "ACCEPT-FAIL", "수락 타임아웃(5초) 리셋")
            pendingAccept = false
        }
    }

    private val dismissTimeoutRunnable = Runnable {
        if (pendingDismiss) {
            Log.w(TAG, "거절 안전 타임아웃 → 상태 리셋")
            LogBuffer.diag(this, "DISMISS-FAIL", "거절 타임아웃(3초) 리셋")
            pendingDismiss = false
            dismissAttempts = 0
        }
    }

    private val ocrCaptureWatchdog = Runnable {
        if (ocrCaptureInflight) {
            Log.w(TAG, "워치독: OCR 캡처 대기 3초 경과 → 리셋")
            ocrCaptureInflight = false
        }
    }

    private val pollRunnable = object : Runnable {
        override fun run() {
            if (!isRunning) return
            val active = PrefsManager.isActive(this@AutoAcceptService)
            if (active && !pendingAccept && !pendingDismiss) {
                if (!isForegroundUber()) {
                    val now = System.currentTimeMillis()
                    if (now - lastNotForegroundLogTime > 30000L) {
                        lastNotForegroundLogTime = now
                        LogBuffer.diag(this@AutoAcceptService, "SCAN-SKIP", "pkg=${lastForegroundPkg ?: UBER_DRIVER_PACKAGE} reason=not_foreground")
                    }
                } else {
                    val card = findCallCard(source = "POLL")
                    if (card != null) {
                        val (root, btn) = card
                        try {
                            processWindow(root, btn)
                        } finally {
                            try {
                                root.recycle()
                            } catch (_: Throwable) {}
                        }
                    }
                }
            }
            val delay = if (System.currentTimeMillis() < fastPollUntilMs) 200L else 500L
            handler.postDelayed(this, delay)
        }
    }

    private val screenshotPollRunnable = object : Runnable {
        override fun run() {
            if (!isRunning) return
            if (PrefsManager.isActive(this@AutoAcceptService) && PrefsManager.isOcrPoll(this@AutoAcceptService)) {
                doScreenshotPoll()
            }
            val delay = if (PrefsManager.isAirportMode(this@AutoAcceptService)) {
                Random.nextLong(200L, 300L)
            } else {
                gaussianDelay(350L, 40L, 250L, 500L)
            }
            handler.postDelayed(this, delay)
        }
    }

    private val keepWarmRunnable = object : Runnable {
        override fun run() {
            if (!isRunning) return
            try {
                val dummyBitmap = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
                val inputImage = InputImage.fromBitmap(dummyBitmap, 0)
                val recognizer = try { getOcrRecognizer() } catch (_: Throwable) { null }
                if (recognizer != null) {
                    recognizer.process(inputImage)
                        .addOnSuccessListener {
                            Log.i(TAG, "MLKit 워밍업 더미OCR 완료")
                            LogBuffer.diag(this@AutoAcceptService, "MLKIT-WARM", "MLKit 워밍업 더미OCR 완료")
                        }
                        .addOnFailureListener { e ->
                            Log.w(TAG, "MLKit 워밍업 실패: ${e.message}")
                            LogBuffer.diag(this@AutoAcceptService, "MLKIT-WARM", "MLKit 워밍업 실패: ${e.message}")
                            logMlKitDetailedDiagnostic(e)
                        }
                        .addOnCompleteListener {
                            try {
                                dummyBitmap.recycle()
                            } catch (_: Throwable) {}
                        }
                } else {
                    try {
                        dummyBitmap.recycle()
                    } catch (_: Throwable) {}
                }
            } catch (e: Exception) {
                Log.w(TAG, "MLKit 워밍업 실패: ${e.message}")
                LogBuffer.diag(this@AutoAcceptService, "MLKIT-WARM", "MLKit 워밍업 실패: ${e.message}")
                logMlKitDetailedDiagnostic(e)
            } finally {
                if (isRunning) {
                    handler.postDelayed(this, 540000L)
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isRunning = true
        savedAcceptRect = PrefsManager.loadLastAcceptRect(this)
        loadXBtnTemplates()
        loadAcceptBtnTemplates()
        setOcrState(OcrState.READY, "접근성 서비스 연결됨 ✓")
        handler.post(pollRunnable)
        handler.post(screenshotPollRunnable)
        handler.postDelayed(keepWarmRunnable, 15000L)
        LogBuffer.diag(this, "SERVICE", "접근성 서비스 연결됨 ✓")
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        closeOcrRecognizer("SERVICE_DESTROY")
        LogBuffer.diag(this, "SERVICE", "접근성 서비스 종료")
    }

    override fun onInterrupt() {
        Log.w(TAG, "접근성 서비스 인터럽트됨")
    }

    @Synchronized
    private fun closeOcrRecognizer(reason: String) {
        try {
            ocrRecognizerInstance?.close()
        } catch (_: Throwable) {}
        ocrRecognizerInstance = null
        Log.d(TAG, "TextRecognizer 인스턴스 닫힘 (사유: $reason)")
    }

    fun ensureOcrModuleInstalled(onComplete: ((Boolean) -> Unit)? = null) {
        try {
            val recognizer = getOcrRecognizer()
            setOcrState(OcrState.READY, "OCR 준비 완료 ✓")
            onComplete?.invoke(true)
        } catch (e: Throwable) {
            Log.e(TAG, "OCR Recognizer 로드 실패: ${e.message}", e)
            logMlKitDetailedDiagnostic(e)
            onComplete?.invoke(false)
        }
    }

    private fun logMlKitDetailedDiagnostic(e: Throwable, context: Context = this) {
        MlKitComprehensiveDiagnostics.runComprehensiveDiagnostic(context, e)
    }

    private fun isSelfPackage(pkg: String?): Boolean {
        if (pkg == null) return false
        val myPkg = try { packageName } catch (_: Throwable) { "com.uber.autoaccept.test" }
        return pkg == myPkg ||
                pkg == "com.uber.autoaccept.test" ||
                pkg == "com.uber.autoaccept" ||
                (pkg.startsWith("com.uber.autoaccept.") && pkg != SIMULATOR_PACKAGE)
    }

    private fun isTargetPackage(pkg: String?): Boolean {
        if (pkg == null) return false
        if (isSelfPackage(pkg)) return false
        return pkg == UBER_DRIVER_PACKAGE || pkg == SIMULATOR_PACKAGE || pkg.contains("ubercab") || (pkg.contains("uber") && !pkg.contains("autoaccept"))
    }

    private var pendingExitPkg: String? = null
    private var lastTransientLogTime = 0L
    private val uberExitDebounceRunnable = Runnable {
        val winList = try { windows ?: emptyList() } catch (_: Throwable) { emptyList() }
        val hasUberWin = winList.any { win ->
            val p = try { win.root?.packageName?.toString() } catch (_: Throwable) { null }
            isTargetPackage(p)
        }
        val activePkg = try { rootInActiveWindow?.packageName?.toString() } catch (_: Throwable) { null }
        val activeIsUber = isTargetPackage(activePkg)

        if (hasUberWin || activeIsUber) {
            // 우버 윈도우가 화면에 여전히 존재함 -> 이탈 취소 및 포그라운드 우버 상태 유지
            pendingExitPkg = null
            if (backgroundPollEnabled) {
                backgroundPollEnabled = false
                lastForegroundPkg = UBER_DRIVER_PACKAGE
                LogBuffer.log(this@AutoAcceptService, TAG, "📱 우버 복귀(pkg=com.ubercab.driver) → 백그라운드 폴링 OFF")
                LogBuffer.diag(this@AutoAcceptService, "FOREGROUND", "Uber confirmed")
            }
            return@Runnable
        }

        val reallyNonUber = activePkg != null && !isTargetPackage(activePkg) && !isSelfPackage(activePkg) && !activePkg.startsWith("com.android.systemui") && !activePkg.contains("inputmethod")
        val fallbackExit = pendingExitPkg != null && !isTargetPackage(pendingExitPkg)
        if (reallyNonUber || fallbackExit) {
            val targetExitPkg = (if (reallyNonUber) activePkg else pendingExitPkg) ?: "unknown"
            lastForegroundPkg = targetExitPkg
            if (!backgroundPollEnabled) {
                backgroundPollEnabled = true
                LogBuffer.log(this@AutoAcceptService, TAG, "📱 다른 앱 진입(pkg=$targetExitPkg) → 백그라운드 폴링 ON")
                LogBuffer.diag(this@AutoAcceptService, "FOREGROUND", "Uber lost confirmed")
            }
        }
        pendingExitPkg = null
    }

    private fun updateForegroundApp(pkg: String?) {
        if (pkg.isNullOrEmpty()) return
        if (isSelfPackage(pkg)) return
        if (pkg.startsWith("com.android.systemui")) return
        if (pkg.contains("inputmethod")) return

        val isUber = isTargetPackage(pkg)
        if (isUber) {
            handler.removeCallbacks(uberExitDebounceRunnable)
            pendingExitPkg = null
            val wasBackground = backgroundPollEnabled || !isTargetPackage(lastForegroundPkg)
            lastForegroundPkg = pkg
            if (wasBackground) {
                backgroundPollEnabled = false
                LogBuffer.log(this, TAG, "📱 우버 복귀(pkg=$pkg) → 백그라운드 폴링 OFF")
                LogBuffer.diag(this, "FOREGROUND", "Uber confirmed")
            }
        } else {
            // 비-우버 패키지 (예: com.sec.android.app.launcher)
            if (isTargetPackage(lastForegroundPkg) && !backgroundPollEnabled) {
                // 현재 우버 포그라운드 상태인 경우 즉시 이탈 처리하지 않고 디바운스(1000ms) 적용
                pendingExitPkg = pkg
                handler.removeCallbacks(uberExitDebounceRunnable)
                handler.postDelayed(uberExitDebounceRunnable, 1000L)
                val now = System.currentTimeMillis()
                if (now - lastTransientLogTime > 5000L) {
                    lastTransientLogTime = now
                    LogBuffer.diag(this, "FOREGROUND", "Ignore transient package=$pkg")
                }
            } else {
                lastForegroundPkg = pkg
                if (!backgroundPollEnabled) {
                    backgroundPollEnabled = true
                    LogBuffer.log(this, TAG, "📱 다른 앱 진입(pkg=$pkg) → 백그라운드 폴링 ON")
                    LogBuffer.diag(this, "FOREGROUND", "Uber lost confirmed")
                }
            }
        }
    }

    private fun isForegroundUber(): Boolean {
        // 1. rootInActiveWindow 패키지 확인
        val activeRootPkg = try { rootInActiveWindow?.packageName?.toString() } catch (_: Throwable) { null }
        if (activeRootPkg != null) {
            if (isSelfPackage(activeRootPkg)) {
                return false
            }
            if (isTargetPackage(activeRootPkg)) {
                updateForegroundApp(activeRootPkg)
                return true
            }
        }

        // 2. windows 목록에서 Uber 윈도우 존재 확인
        val winList = try { windows ?: emptyList() } catch (_: Throwable) { emptyList() }
        val hasUberWin = winList.any { win ->
            val p = try { win.root?.packageName?.toString() } catch (_: Throwable) { null }
            isTargetPackage(p)
        }
        if (hasUberWin) {
            if (backgroundPollEnabled || !isTargetPackage(lastForegroundPkg)) {
                updateForegroundApp(UBER_DRIVER_PACKAGE)
            }
            return true
        }

        // 3. lastForegroundPkg가 Uber이고 백그라운드 미확정(디바운스 중)인 경우
        val currentFg = lastForegroundPkg
        if (currentFg != null && isSelfPackage(currentFg)) {
            return false
        }
        if (isTargetPackage(currentFg) && !backgroundPollEnabled) {
            return true
        }

        return false
    }

    private var lastScanPkg: String? = null
    private var lastScanLogTime = 0L
    private var lastScanDiagLogTime = 0L
    private var lastProcessScanLogTime = 0L
    private var lastNoCallPkg: String? = null
    private var lastNoCallReason: String? = null
    private var lastNoCallLogTime = 0L
    private var noCallRepeatCount = 0
    private var lastSelfSkipLogTime = 0L
    private var lastFalsePosLogTime = 0L
    private var cooldownLogged = false

    private fun logNoCall(pkg: String, reason: String) {
        val now = System.currentTimeMillis()
        if (pkg == lastNoCallPkg && reason == lastNoCallReason) {
            noCallRepeatCount++
            if (now - lastNoCallLogTime > 15000L) {
                lastNoCallLogTime = now
                LogBuffer.diag(this, "NO-CALL", "pkg=$pkg reason=$reason repeatSuppressed=$noCallRepeatCount")
                noCallRepeatCount = 0
            }
        } else {
            if (noCallRepeatCount > 0 && lastNoCallPkg != null) {
                LogBuffer.diag(this, "NO-CALL", "pkg=$lastNoCallPkg reason=$lastNoCallReason repeatSuppressed=$noCallRepeatCount")
            }
            lastNoCallPkg = pkg
            lastNoCallReason = reason
            lastNoCallLogTime = now
            noCallRepeatCount = 0
            LogBuffer.diag(this, "NO-CALL", "pkg=$pkg reason=$reason")
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !PrefsManager.isActive(this)) return

        if (pendingDismiss && dismissTapFiredAtMs > 0L && dismissEventLogCount < 8) {
            val elapsed = System.currentTimeMillis() - dismissTapFiredAtMs
            val typeStr = AccessibilityEvent.eventTypeToString(event.eventType)
            LogBuffer.log(this, TAG, "📡 닫기대기중 이벤트 +${elapsed}ms type=$typeStr pkg=${event.packageName}")
            dismissEventLogCount++
        }

        val pkg = event.packageName?.toString()
        if (isSelfPackage(pkg)) {
            val now = System.currentTimeMillis()
            if (now - lastSelfSkipLogTime > 30000L) {
                lastSelfSkipLogTime = now
                LogBuffer.diag(this, "SCAN-SKIP", "pkg=$pkg reason=self_package")
            }
            return
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || isTargetPackage(pkg)) {
            updateForegroundApp(pkg)
        }

        if (!isTargetPackage(pkg)) {
            return
        }

        if (!isForegroundUber()) {
            val now = System.currentTimeMillis()
            if (now - lastNotForegroundLogTime > 30000L) {
                lastNotForegroundLogTime = now
                LogBuffer.diag(this, "SCAN-SKIP", "pkg=${pkg ?: UBER_DRIVER_PACKAGE} reason=not_foreground")
            }
            return
        }

        bufferedEventCount++
        if (bufferedEventCount >= 20) {
            PrefsManager.incrementEventCount(this, bufferedEventCount)
            bufferedEventCount = 0
        }

        if (pendingAccept || pendingDismiss) {
            return
        }

        val card = findCallCard(source = "ON_EVENT")
        if (card == null) {
            return
        }

        val (root, button) = card
        try {
            processWindow(root, button)
        } finally {
            try {
                root.recycle()
            } catch (_: Throwable) {}
        }
    }

    private fun isNormalScreen(root: AccessibilityNodeInfo): Boolean {
        for (kw in NORMAL_SCREEN_KEYWORDS) {
            val nodes = root.findAccessibilityNodeInfosByText(kw)
            if (!nodes.isNullOrEmpty()) {
                for (n in nodes) {
                    try { n.recycle() } catch (_: Throwable) {}
                }
                return true
            }
        }
        return false
    }

    private fun findCallCard(source: String = "UNKNOWN"): Pair<AccessibilityNodeInfo, AccessibilityNodeInfo?>? {
        if (!isForegroundUber()) {
            val now = System.currentTimeMillis()
            if (now - lastNotForegroundLogTime > 60000L) {
                lastNotForegroundLogTime = now
                LogBuffer.diag(this, "SCAN-SKIP", "pkg=${lastForegroundPkg ?: UBER_DRIVER_PACKAGE} reason=not_foreground")
            }
            return null
        }

        var hadIndicatorOnly = false

        val allWindows = windows ?: emptyList()
        for ((index, window) in allWindows.withIndex()) {
            val root = try { window.root } catch (e: Exception) { null } ?: continue
            val rootPkg = root.packageName?.toString()
            if (isSelfPackage(rootPkg) || !isTargetPackage(rootPkg)) {
                try { root.recycle() } catch (_: Throwable) {}
                continue
            }

            if (isNormalScreen(root)) {
                try { root.recycle() } catch (_: Throwable) {}
                continue
            }

            val btn = findAcceptButton(root)
            if (btn != null) {
                lastGateResult = "FOUND"
                val bRect = Rect()
                btn.getBoundsInScreen(bRect)
                val candidateText = btn.text?.toString()?.trim() ?: btn.contentDescription?.toString()?.trim() ?: "수락"
                LogBuffer.diag(this, "CALL-CARD-GATE", "keyword=$candidateText result=FOUND acceptCandidate=$candidateText source=$source windowIndex=$index rootPkg=$rootPkg text='${btn.text}' bounds=$bRect")
                activeTargetPackage = rootPkg ?: UBER_DRIVER_PACKAGE
                Log.d(TAG, "콜카드 수락 노드 발견 — 창 패키지: ${root.packageName}, 텍스트: '${btn.text}'")
                return Pair(root, btn)
            }

            if (findCardIndicator(root)) {
                hadIndicatorOnly = true
            }

            try { root.recycle() } catch (_: Throwable) {}
        }

        val root = try { rootInActiveWindow } catch (e: Exception) { null }
        if (root != null) {
            val fallbackPkg = root.packageName?.toString()
            if (!isSelfPackage(fallbackPkg) && isTargetPackage(fallbackPkg)) {
                if (!isNormalScreen(root)) {
                    val btn = findAcceptButton(root)
                    if (btn != null) {
                        lastGateResult = "FOUND"
                        val bRect = Rect()
                        btn.getBoundsInScreen(bRect)
                        val candidateText = btn.text?.toString()?.trim() ?: btn.contentDescription?.toString()?.trim() ?: "수락"
                        LogBuffer.diag(this, "CALL-CARD-GATE", "keyword=$candidateText result=FOUND acceptCandidate=$candidateText source=$source rootPkg=$fallbackPkg text='${btn.text}' bounds=$bRect")
                        activeTargetPackage = fallbackPkg ?: UBER_DRIVER_PACKAGE
                        Log.d(TAG, "콜카드 수락 노드 발견 — rootInActiveWindow ($fallbackPkg), 텍스트: '${btn.text}'")
                        return Pair(root, btn)
                    }

                    if (findCardIndicator(root)) {
                        hadIndicatorOnly = true
                    }
                }
            }
            try { root.recycle() } catch (_: Throwable) {}
        }

        if (hadIndicatorOnly) {
            if (lastGateResult != "REJECT_INDICATOR_ONLY") {
                lastGateResult = "REJECT_INDICATOR_ONLY"
                LogBuffer.diag(this, "CALL-CARD-GATE", "result=REJECT reason=indicator_only source=$source")
            }
        } else {
            if (lastGateResult != "NOT_FOUND") {
                lastGateResult = "NOT_FOUND"
                LogBuffer.diag(this, "CALL-CARD-GATE", "result=NOT_FOUND source=$source")
            }
        }
        return null
    }

    private fun findUberRoot(): AccessibilityNodeInfo? {
        try {
            val root = rootInActiveWindow
            if (root != null) {
                val pkg = root.packageName?.toString()
                if (isTargetPackage(pkg) && !isSelfPackage(pkg)) {
                    return root
                }
            }
            val winList = windows
            for (win in winList) {
                val winRoot = win.root
                if (winRoot != null) {
                    val pkg = winRoot.packageName?.toString()
                    if (isTargetPackage(pkg) && !isSelfPackage(pkg)) {
                        return winRoot
                    }
                }
            }
        } catch (_: Throwable) {
        }
        return null
    }

    fun findOverlayCard(root: AccessibilityNodeInfo, acceptRect: Rect): Rect {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var bestRect: Rect? = null

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            val rect = Rect()
            node.getBoundsInScreen(rect)
            val w = rect.width()
            val h = rect.height()

            if (w in 400..1200 && h in 150..1200 && rect.top < acceptRect.top) {
                val combined = "${node.text ?: ""} ${node.contentDescription ?: ""}"
                val isAccept = ACCEPT_BUTTON_TEXTS.any { combined.contains(it, ignoreCase = true) }
                if (!isAccept) {
                    if (bestRect == null || rect.top < bestRect.top) {
                        bestRect = rect
                    }
                }
            }

            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.add(it) }
            }
            if (node != root) {
                try { node.recycle() } catch (_: Throwable) {}
            }
        }

        val fallback = bestRect ?: Rect(45, (acceptRect.top - 800).coerceAtLeast(0), 1035, (acceptRect.top - 50).coerceAtLeast(0))
        Log.d(TAG, "findOverlayCard → $fallback (${if (bestRect != null) "실측" else "추정"})")
        return fallback
    }

    private fun processWindow(root: AccessibilityNodeInfo, acceptBtn: AccessibilityNodeInfo?) {
        val now = System.currentTimeMillis()
        val winPkg = root.packageName?.toString() ?: activeTargetPackage

        if (isSelfPackage(winPkg)) {
            if (now - lastSelfSkipLogTime > 30000L) {
                lastSelfSkipLogTime = now
                LogBuffer.diag(this, "SCAN-SKIP", "pkg=$winPkg reason=self_package")
            }
            return
        }

        val isUber = winPkg == UBER_DRIVER_PACKAGE || winPkg == SIMULATOR_PACKAGE
        val cardKey = "${winPkg}_$now"

        val inCooldown = now - lastAcceptTime < COOLDOWN_MS
        if (inCooldown || pendingAccept) {
            if (!cooldownLogged) {
                cooldownLogged = true
                LogBuffer.diag(this, "COOLDOWN", "START duration=${COOLDOWN_MS}ms")
            }
            return
        } else if (cooldownLogged) {
            cooldownLogged = false
            LogBuffer.diag(this, "COOLDOWN", "END")
        }

        val isFirstSeen = callCardFirstSeenAt == 0L
        if (isFirstSeen) {
            callCardFirstSeenAt = now
        }
        lastCallCardTime = now
        fastPollUntilMs = now + 4000L

        val dumpAcceptR = if (acceptBtn != null) Rect().also { acceptBtn.getBoundsInScreen(it) } else savedAcceptRect ?: Rect()
        if (isFirstSeen) {
            val dump = dumpCallTree(root, dumpAcceptR)
            LogBuffer.log(this, TAG, "=== 콜카드 트리 덤프 ===\n$dump")
        }

        val acceptR: Rect = if (acceptBtn != null) {
            Rect().also { acceptBtn.getBoundsInScreen(it) }
        } else {
            savedAcceptRect?.let { Rect(it) }
                ?: PrefsManager.loadLastAcceptRect(this)
                ?: Rect(
                    45,
                    (resources.displayMetrics.heightPixels * 0.75f).toInt(),
                    resources.displayMetrics.widthPixels - 45,
                    (resources.displayMetrics.heightPixels * 0.92f).toInt()
                )
        }

        if (acceptBtn != null) {
            savedAcceptRect = Rect(acceptR)
            PrefsManager.saveLastAcceptRect(this, acceptR.left, acceptR.top, acceptR.right, acceptR.bottom)
        }

        if (isFirstSeen) {
            PrefsManager.incrementCallCount(this)
        }

        Log.d(TAG, "콜 화면 감지됨" + if (acceptBtn == null) " [수락버튼 미발견 — savedAcceptRect 사용]" else "")
        LogBuffer.diag(this, "CALL_CARD_CONTAINER_FOUND", "Call card container detected in pkg=$winPkg (rootPkg=${root.packageName})")

        if (acceptBtn != null) {
            val labelText = acceptBtn.text?.toString() ?: acceptBtn.contentDescription?.toString() ?: "Button"
            LogBuffer.diag(this, "LABEL_MATCH", "Matched accept button label: '$labelText', bounds=$acceptR, viewId=${acceptBtn.viewIdResourceName}")
            val candDetails = "foregroundPkg=$lastForegroundPkg, rootPkg=${root.packageName}, windowPkg=$winPkg, className=${acceptBtn.className}, text='${acceptBtn.text}', desc='${acceptBtn.contentDescription}', viewId=${acceptBtn.viewIdResourceName}, bounds=$acceptR, cardKey=$cardKey, method=AccessibilityNode, isUber=$isUber"
            LogBuffer.diag(this, "ACCEPT-CANDIDATE", candDetails)
            if (!isUber) {
                if (now - lastFalsePosLogTime > 5000L) {
                    lastFalsePosLogTime = now
                    LogBuffer.diag(this, "FALSE-POSITIVE-CANDIDATE", "Non-Uber screen detected as accept candidate: $candDetails")
                }
            }
        } else {
            LogBuffer.diag(this, "ACCEPT-CANDIDATE", "Call card found without explicit node button; will rely on OCR/template (pkg=$winPkg, isUber=$isUber)")
        }

        val acceptAll = PrefsManager.isAcceptAll(this)
        val blacklistMode = PrefsManager.isBlacklistMode(this)
        val keywords = PrefsManager.getKeywords(this)

        if (!acceptAll && keywords.isNotEmpty() && Build.VERSION.SDK_INT >= 30) {
            val rootRect = Rect().also { root.getBoundsInScreen(it) }
            val isFloatingOverlay = rootRect.top > 500
            val (ocrRect, dismissCardRect) = if (isFloatingOverlay) {
                val found = findOverlayCard(root, acceptR)
                Pair(found, found)
            } else {
                val fullCard = Rect(rootRect.left, rootRect.top, rootRect.right, acceptR.top)
                val overlayCard = findOverlayCard(root, acceptR)
                Pair(fullCard, overlayCard)
            }

            val cardTop = dismissCardRect.top
            val cardRight = dismissCardRect.right
            val dismissTapX = cardRight - 106
            val dismissTapY = cardTop + 78

            savedAcceptRect = Rect(acceptR)
            dismissAttempts = 0
            PrefsManager.saveLastAcceptRect(this, acceptR.left, acceptR.top, acceptR.right, acceptR.bottom)
            pendingAccept = true

            Log.d(TAG, "OCR 경로 시작 — ocrRect=$ocrRect  dismissCard=$dismissCardRect  dismissTap=($dismissTapX,$dismissTapY)  acceptRect=$acceptR  overlay=$isFloatingOverlay")

            startOcrAndDecide(ocrRect, dismissCardRect, dismissTapX, dismissTapY, isFloatingOverlay, acceptR, acceptBtn, keywords, blacklistMode)
            return
        }

        // Fallback for acceptAll or empty keywords or SDK < 30
        if (acceptAll) {
            LogBuffer.diag(this, "ACCEPT-CONDITION", "Evaluation: acceptAll=true, blacklist=$blacklistMode, matched='전체수락' -> shouldAccept=true, isUber=$isUber")
            if (acceptBtn != null) {
                performAccept(acceptBtn, acceptR, "전체수락", winPkg, cardKey)
            } else {
                executeAcceptAtPos(acceptR.centerX(), acceptR.centerY(), acceptR, "전체수락", cardKey)
            }
            return
        }

        val fullText = collectAllText(root)
        val notifText = NotificationListener.lastCallText
        val combinedText = "$fullText $notifText"
        var matchedKeyword: String? = null
        for (kw in keywords) {
            if (kw.isNotEmpty() && combinedText.contains(kw, ignoreCase = true)) {
                matchedKeyword = kw
                break
            }
        }
        val shouldAccept: Boolean = if (blacklistMode) matchedKeyword == null else matchedKeyword != null
        LogBuffer.diag(this, "ACCEPT-CONDITION", "Evaluation (Fallback): acceptAll=$acceptAll, blacklist=$blacklistMode, matched='$matchedKeyword' -> shouldAccept=$shouldAccept, isUber=$isUber")

        if (shouldAccept) {
            if (acceptBtn != null) {
                performAccept(acceptBtn, acceptR, matchedKeyword ?: "조건일치", winPkg, cardKey)
            } else {
                executeAcceptAtPos(acceptR.centerX(), acceptR.centerY(), acceptR, "조건일치", cardKey)
            }
        } else if (PrefsManager.isAutoDismiss(this)) {
            performDismissFresh()
        }
    }

    private fun performAccept(btn: AccessibilityNodeInfo, rect: Rect, reason: String, winPkg: String = "unknown", cardKey: String = "k_$lastAcceptTime") {
        val now = System.currentTimeMillis()
        if (now - lastAcceptTime < COOLDOWN_MS || pendingAccept) {
            LogBuffer.diag(this, "ACCEPT-FAIL", "performAccept skipped due to cooldown or pendingAccept (cooldown=${now - lastAcceptTime}ms, pending=$pendingAccept)")
            return
        }

        pendingAccept = true
        lastAcceptTime = now
        savedAcceptRect = rect

        val airport = PrefsManager.isAirportMode(this)
        val noDelay = PrefsManager.isAcceptNoDelay(this)
        val human = PrefsManager.isHumanMode(this)

        val delay = when {
            noDelay -> 0L
            airport -> Random.nextLong(200L, 300L)
            human -> gaussianDelay(PrefsManager.getMinDelay(this), 50L, PrefsManager.getMinDelay(this), PrefsManager.getMaxDelay(this))
            else -> PrefsManager.getMinDelay(this)
        }

        val modeStr = when {
            noDelay -> "NO_DELAY"
            airport -> "AIRPORT"
            human -> "HUMAN"
            else -> "DEFAULT"
        }

        lastHumanDelay = delay
        Log.d(TAG, "수락 예정: 이유=$reason, 딜레이=${delay}ms, 좌표=(${rect.centerX()}, ${rect.centerY()})")
        LogBuffer.diag(this, "ACCEPT-DELAY", "mode=$modeStr, delay=${delay}ms, minDelay=${PrefsManager.getMinDelay(this)}ms, maxDelay=${PrefsManager.getMaxDelay(this)}ms")
        LogBuffer.diag(this, "ACCEPT-SCHEDULE", "delay=${delay}ms, reason=$reason, coords=(${rect.centerX()}, ${rect.centerY()}), sourcePkg=$winPkg, cardKey=$cardKey")

        handler.postDelayed({
            executeAccept(btn, rect, winPkg, cardKey)
        }, delay)

        handler.postDelayed(acceptTimeoutRunnable, 5000L)
    }

    private fun executeAccept(btn: AccessibilityNodeInfo, rect: Rect, winPkg: String = "unknown", cardKey: String = "k_$lastAcceptTime") {
        var clicked = false
        var clickMethod = "NONE"
        val cx = rect.centerX()
        val cy = rect.centerY()

        showTapIndicator(cx, cy, true)
        LogBuffer.diag(this, "ACCEPT-TOUCH", "Touch starting: coords=($cx, $cy), bounds=$rect, targetText='${btn.text}', cardKey=$cardKey")

        val shizOk = shizukuTap(cx, cy)
        LogBuffer.diag(this, "ACCEPT-SHIZUKU", "Shizuku tap result=$shizOk, coords=($cx, $cy)")

        if (shizOk) {
            clicked = true
            clickMethod = "ShizukuTap"
            Log.d(TAG, "Shizuku 터치 수락 성공")
        } else {
            var actionOk = false
            try {
                if (btn.isClickable && btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    actionOk = true
                    clicked = true
                    clickMethod = "NodeClick"
                } else {
                    var parent = btn.parent
                    while (parent != null) {
                        if (parent.isClickable && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                            actionOk = true
                            clicked = true
                            clickMethod = "ParentNodeClick"
                            break
                        }
                        parent = parent.parent
                    }
                }
            } catch (e: Throwable) {
                LogBuffer.diag(this, "ACCEPT-FAIL", "Node action exception: ${e.message}")
            }
            LogBuffer.diag(this, "ACCEPT-ACTION", "Node click result=$actionOk, method=$clickMethod")

            if (!clicked) {
                val gestureBuilder = GestureDescription.Builder()
                val path = Path().apply {
                    moveTo(cx.toFloat(), cy.toFloat())
                }
                gestureBuilder.addStroke(GestureDescription.StrokeDescription(path, 0, 50))
                val dispatched = dispatchGesture(gestureBuilder.build(), null, null)
                clicked = dispatched
                clickMethod = if (dispatched) "dispatchGesture" else "GestureFailed"
                LogBuffer.diag(this, "ACCEPT-GESTURE", "dispatchGesture result=$dispatched, coords=($cx, $cy)")
            }
        }

        LogBuffer.diag(this, "ACCEPT-TOUCH", "Touch performed: method=$clickMethod, coords=($cx, $cy), success=$clicked, cardKey=$cardKey")

        val nextCount = PrefsManager.getAcceptScheduled(this) + 1
        LogBuffer.diag(this, "ACCEPT-COUNT", "source=executeAccept, reason=accept_dispatched, cardKey=$cardKey, winPkg=$winPkg, btn='${btn.text}', bounds=$rect, nextCount=$nextCount")
        PrefsManager.incrementAcceptScheduled(this, source = "executeAccept")

        PrefsManager.saveLastAcceptRect(this, rect)
        sendBroadcast(Intent("com.uber.autoaccept.ACCEPT_EVENT"))

        vibrate()
        triggerSleepAlarm()

        if (PrefsManager.isAcceptScreenshot(this)) {
            takeScreenshotAndSave()
        }

        pendingAccept = false
        handler.removeCallbacks(acceptTimeoutRunnable)

        // Verify accept after short delay (Separation of TOUCH and SUCCESS)
        handler.postDelayed({
            val verifyRoot = findUberRoot()
            val stillHasCard = verifyRoot != null && (findCardIndicator(verifyRoot) || findAcceptButton(verifyRoot) != null)
            if (!stillHasCard) {
                LogBuffer.diag(this, "ACCEPT-VERIFY", "Card disappeared successfully (Accept confirmed), cardKey=$cardKey")
                LogBuffer.diag(this, "ACCEPT-SUCCESS", "Accept operation verified SUCCESS on screen, cardKey=$cardKey")
            } else {
                LogBuffer.diag(this, "ACCEPT-VERIFY", "Card still visible -> Scheduling retry, cardKey=$cardKey")
                LogBuffer.diag(this, "ACCEPT-RETRY", "Retrying accept tap at ($cx, $cy), cardKey=$cardKey")
                scheduleAcceptRetap(rect, 300L, cardKey)
            }
        }, 500L)
    }

    fun performDismissFresh() {
        dismissAttempts++
        PrefsManager.incrementDismissExecuted(this)
        Log.d(TAG, "performDismissFresh 호출 (시도 $dismissAttempts 번째)")
        LogBuffer.diag(this, "DISMISS-START", "source=ORIGINAL_FLOW_RESTORED, performDismissFresh started")
        LogBuffer.diag(this, "DISMISS-ATTEMPT", "source=ORIGINAL_FLOW_RESTORED, attempt=$dismissAttempts, totalExecuted=${PrefsManager.getDismissExecuted(this)}")
        LogBuffer.diag(this, "DISMISS-EXECUTED", "source=ORIGINAL_FLOW_RESTORED, dismiss execution attempt counter incremented, count=${PrefsManager.getDismissExecuted(this)}")
        val acceptRect = savedAcceptRect
        LogBuffer.diag(this, "DISMISS-RECT", "source=ORIGINAL_FLOW_RESTORED, savedAcceptRect=${acceptRect ?: "null"}")
        if (acceptRect == null) {
            Log.w(TAG, "닫기: savedAcceptRect 없음 — 건너뜀")
            LogBuffer.diag(this, "DISMISS-FAIL", "source=ORIGINAL_FLOW_RESTORED, savedAcceptRect is null, skipping dismiss")
            pendingDismiss = false
            return
        }

        val activeRootBefore = try { rootInActiveWindow } catch (_: Throwable) { null }
        val activeRootBeforePkg = activeRootBefore?.packageName?.toString()
        val activeRootBeforeChild = activeRootBefore?.childCount ?: -1
        val winListBefore = windows ?: emptyList()
        LogBuffer.diag(
            this,
            "DISMISS-BEFORE-FINDCALLCARD",
            "foregroundPkg=${lastForegroundPkg ?: "none"}, lastForegroundPkg=${lastForegroundPkg ?: "none"}, windowCount=${winListBefore.size}, activeRootPkg=${activeRootBeforePkg ?: "none"}, activeRootChildCount=$activeRootBeforeChild, savedAcceptRect=${acceptRect ?: "null"}"
        )

        val beforeDumpRoot = try { rootInActiveWindow } catch (_: Throwable) { null }
        val beforeDumpCard = beforeDumpRoot != null && (findAcceptButton(beforeDumpRoot) != null || findCardIndicator(beforeDumpRoot))
        try { beforeDumpRoot?.recycle() } catch (_: Throwable) {}
        LogBuffer.diag(this, "BEFORE-DUMP-CARD-CHECK", "result=${if (beforeDumpCard) "FOUND" else "NOT_FOUND"}")

        try {
            val windows = windows ?: emptyList()
            val sb = StringBuilder()
            sb.append("▶ acceptRect: $acceptRect\n")
            sb.append("▶ 전체 창 수: ${windows.size}\n")
            for ((idx, win) in windows.withIndex()) {
                val wr = try { win.root } catch (_: Throwable) { null }
                if (wr == null) {
                    sb.append("── 창[$idx] root=null ──\n")
                } else {
                    sb.append("── 창[$idx] pkg=${wr.packageName} ──\n")
                    sb.append(dumpCallTree(wr, acceptRect))
                    try { wr.recycle() } catch (_: Throwable) {}
                }
            }
            PrefsManager.saveDismissDiag(this, sb.toString().take(4000))
            Log.d(TAG, "전창덤프 저장 완료")
        } catch (e2: Throwable) {
            Log.e(TAG, "덤프 오류: ${e2.message}")
        }
        LogBuffer.diag(this, "DUMP-COMPLETE", "savedDumpLength=${PrefsManager.getDismissDiag(this).length}")

        val afterDumpRoot = try { rootInActiveWindow } catch (_: Throwable) { null }
        val afterDumpCard = afterDumpRoot != null && (findAcceptButton(afterDumpRoot) != null || findCardIndicator(afterDumpRoot))
        val afterDumpPkg = afterDumpRoot?.packageName?.toString()
        val afterDumpChild = afterDumpRoot?.childCount ?: -1
        val winListAfter = windows ?: emptyList()
        try { afterDumpRoot?.recycle() } catch (_: Throwable) {}

        LogBuffer.diag(this, "AFTER-DUMP-CARD-CHECK", "result=${if (afterDumpCard) "FOUND" else "NOT_FOUND"}")
        LogBuffer.diag(
            this,
            "DISMISS-AFTER-DUMP",
            "foregroundPkg=${lastForegroundPkg ?: "none"}, lastForegroundPkg=${lastForegroundPkg ?: "none"}, windowCount=${winListAfter.size}, activeRootPkg=${afterDumpPkg ?: "none"}, activeRootChildCount=$afterDumpChild"
        )

        try {
            val pair = findCallCard(source = "DISMISS_FRESH")
            LogBuffer.diag(
                this,
                "DISMISS-FINDCALLCARD-RESULT",
                "result=${if (pair != null) "FOUND" else "NOT_FOUND"}, failReason=${if (pair != null) "none" else "card_not_detected_in_windows_and_fallback"}"
            )
            LogBuffer.diag(this, "DISMISS-CARD", "source=ORIGINAL_FLOW_RESTORED, cardPresent=${pair != null}, root=${pair?.first != null}, acceptBtn=${pair?.second != null}, pkg=${pair?.first?.packageName ?: "none"}")
            if (pair != null) {
                val (root, acceptBtn) = pair
                val actionDismissOk = root.performAction(1048576) // ACTION_DISMISS
                LogBuffer.diag(this, "DISMISS-ACTION", "source=ORIGINAL_FLOW_RESTORED, root ACTION_DISMISS result=$actionDismissOk")
                if (actionDismissOk) {
                    Log.d(TAG, "루트 ACTION_DISMISS 성공")
                    try { acceptBtn?.recycle() } catch (_: Throwable) {}
                    try { root.recycle() } catch (_: Throwable) {}
                    LogBuffer.diag(this, "DISMISS-SUCCESS-CONDITION", "source=ORIGINAL_FLOW_RESTORED, cardPresent=false, verificationPassed=true, via=root_action_dismiss")
                    recordDismissSuccess()
                    return
                }

                var selectMethod = "none"
                var xNode = findDismissButton(root, acceptRect)
                if (xNode != null) {
                    selectMethod = "findDismissButton"
                } else if (acceptBtn != null) {
                    xNode = findDismissViaParent(acceptBtn, acceptRect)
                    if (xNode != null) {
                        selectMethod = "findDismissViaParent"
                    }
                }

                if (xNode != null) {
                    val xr = Rect()
                    xNode.getBoundsInScreen(xr)
                    Log.d(TAG, "X버튼 발견: $xr ($selectMethod)")
                    LogBuffer.diag(this, "DISMISS-NODE", "source=ORIGINAL_FLOW_RESTORED, nodeSelected=true, method=$selectMethod, text='${xNode.text}', desc='${xNode.contentDescription}', bounds=$xr")
                    try { acceptBtn?.recycle() } catch (_: Throwable) {}
                    try { root.recycle() } catch (_: Throwable) {}
                    dismissWithVerify(xNode, xr)
                    return
                }

                try { acceptBtn?.recycle() } catch (_: Throwable) {}
                try { root.recycle() } catch (_: Throwable) {}
                Log.w(TAG, "X버튼 없음 → tapDismissCoordinates")
                LogBuffer.diag(this, "DISMISS-FALLBACK", "source=ORIGINAL_FLOW_RESTORED, no X button found -> tapDismissCoordinates")
                if (Build.VERSION.SDK_INT >= 24) {
                    tapDismissCoordinates(acceptRect)
                    return
                } else {
                    fallbackBack()
                    return
                }
            }

            Log.d(TAG, "콜카드 없음 → 이미 닫힘")
            LogBuffer.diag(this, "DISMISS-ALREADY-CLOSED", "source=ORIGINAL_FLOW_RESTORED, call card not found at start -> already closed")
            LogBuffer.diag(this, "DISMISS-SUCCESS-CONDITION", "source=ORIGINAL_FLOW_RESTORED, cardPresent=false, verificationPassed=true, via=already_closed")
            recordDismissSuccess()
        } catch (e3: Throwable) {
            Log.e(TAG, "노드 액션 예외: ${e3.message}")
        }
    }

    private fun dismissWithVerify(xNode: AccessibilityNodeInfo, dismissRect: Rect) {
        val clicked = try {
            xNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        } catch (_: Throwable) {
            false
        }
        Log.d(TAG, "ACTION_CLICK → $clicked  nodeRect=$dismissRect")
        LogBuffer.diag(this, "CLOSE-ACTION", "source=ORIGINAL_FLOW_RESTORED, ACTION_CLICK result=$clicked, nodeBounds=$dismissRect")
        try { xNode.recycle() } catch (_: Throwable) {}

        if (!clicked && Build.VERSION.SDK_INT >= 24) {
            tapXButtonTopRight(dismissRect, 0L, "1차")
        }

        handler.postDelayed({
            LogBuffer.diag(this, "DISMISS-VERIFY-1", "source=ORIGINAL_FLOW_RESTORED, 1st verification started (400ms post-touch)")
            val pair = findCallCard(source = "DISMISS_VERIFY_1")
            LogBuffer.diag(this, "DISMISS-VERIFY-1-RESULT", "source=ORIGINAL_FLOW_RESTORED, cardPresent=${pair != null}")
            if (pair == null) {
                Log.d(TAG, "검증: 콜카드 사라짐 → 성공")
                LogBuffer.diag(this, "DISMISS-SUCCESS-CONDITION", "source=ORIGINAL_FLOW_RESTORED, cardPresent=false, verificationPassed=true, step=verify_1")
                recordDismissSuccess()
                return@postDelayed
            }
            try { pair.first.recycle() } catch (_: Throwable) {}
            try { pair.second?.recycle() } catch (_: Throwable) {}
            Log.w(TAG, "검증: 카드 잔존 → 2차 gesture 재시도")
            LogBuffer.diag(this, "DISMISS-RETRY-1", "source=ORIGINAL_FLOW_RESTORED, card still present -> starting 2nd gesture retry")
            if (Build.VERSION.SDK_INT >= 24) {
                tapXButtonTopRight(dismissRect, 0L, "2차")
            }
            handler.postDelayed({
                LogBuffer.diag(this, "DISMISS-VERIFY-2", "source=ORIGINAL_FLOW_RESTORED, 2nd verification started (600ms post-retry)")
                val pair2 = findCallCard(source = "DISMISS_VERIFY_2")
                LogBuffer.diag(this, "DISMISS-VERIFY-2-RESULT", "source=ORIGINAL_FLOW_RESTORED, cardPresent=${pair2 != null}")
                LogBuffer.diag(this, "DISMISS-VERIFY-FINAL", "source=ORIGINAL_FLOW_RESTORED, final verification check")
                LogBuffer.diag(this, "DISMISS-VERIFY-FINAL-RESULT", "source=ORIGINAL_FLOW_RESTORED, cardPresent=${pair2 != null}")
                if (pair2 == null) {
                    Log.d(TAG, "2차 후 콜카드 사라짐 → 성공")
                    LogBuffer.diag(this, "DISMISS-SUCCESS-CONDITION", "source=ORIGINAL_FLOW_RESTORED, cardPresent=false, verificationPassed=true, step=verify_2")
                } else {
                    try { pair2.first.recycle() } catch (_: Throwable) {}
                    try { pair2.second?.recycle() } catch (_: Throwable) {}
                    Log.w(TAG, "2차 후도 카드 잔존 → 포기 (뒤로가기 사용 안 함)")
                    LogBuffer.diag(this, "DISMISS-FAIL", "source=ORIGINAL_FLOW_RESTORED, card still visible after 2nd attempt -> give up")
                }
                recordDismissSuccess()
            }, 600L)
        }, 400L)
    }

    private fun tapXButtonTopRight(headerRect: Rect, startDelay: Long, tag: String) {
        val cx = headerRect.centerX().toFloat()
        val cy = headerRect.centerY().toFloat()
        val taps = listOf(
            Pair(cx, cy),
            Pair(cx + 15f, cy),
            Pair(cx - 15f, cy),
            Pair(cx, cy - 15f),
            Pair(cx, cy + 15f),
            Pair(cx + 25f, cy - 10f),
            Pair(cx - 25f, cy - 10f),
            Pair(cx + 25f, cy + 10f)
        ).filter { it.first > 0f && it.second > 0f }

        Log.d(TAG, "$tag 탭 시작 — 노드중심=(${cx.toInt()},${cy.toInt()}) bounds=$headerRect ${taps.size}개")
        LogBuffer.diag(this, "DISMISS-TOUCH", "source=ORIGINAL_FLOW_RESTORED, tag=$tag, coord=(${cx.toInt()},${cy.toInt()}), targetBounds=$headerRect")
        handler.postDelayed({
            showTapIndicator(cx.toInt(), cy.toInt(), false)
            shizukuExecutor.execute {
                val shizOk = shizukuTap(cx.toInt(), cy.toInt())
                Log.d(TAG, "$tag Shizuku중심탭 (${cx.toInt()},${cy.toInt()}) → $shizOk")
                LogBuffer.diag(this, "CLOSE-SHIZUKU", "source=ORIGINAL_FLOW_RESTORED, tag=$tag, coord=(${cx.toInt()},${cy.toInt()}), result=$shizOk")
                if (!shizOk) {
                    handler.post {
                        taps.forEachIndexed { i, pair ->
                            handler.postDelayed({
                                if (Build.VERSION.SDK_INT >= 24) {
                                    val path = Path().apply { moveTo(pair.first, pair.second) }
                                    val stroke = GestureDescription.StrokeDescription(path, 0L, 80L)
                                    val gesture = GestureDescription.Builder().addStroke(stroke).build()
                                    val gestOk = dispatchGesture(gesture, null, null)
                                    LogBuffer.diag(this, "CLOSE-GESTURE", "source=ORIGINAL_FLOW_RESTORED, tag=$tag, idx=$i, coord=(${pair.first.toInt()},${pair.second.toInt()}), result=$gestOk (request dispatched, NOT verified success)")
                                }
                            }, i * 70L)
                        }
                    }
                }
            }
        }, startDelay)
    }

    private fun tapDismissCoordinates(acceptRect: Rect) {
        val screenW = resources.displayMetrics.widthPixels.toFloat()
        val xPositions = listOf(
            screenW - 55f,
            acceptRect.right - 30f,
            acceptRect.right - 68f,
            acceptRect.right - 110f
        ).distinct()

        val yOffsets = (100..1600 step 150).map { it.toFloat() }
        val priorityY = yOffsets.filter { it in 300f..900f }
        val remainderY = yOffsets.filter { it !in 300f..900f }

        val tapPositions = mutableListOf<Pair<Float, Float>>()
        for (dy in priorityY) {
            for (x in xPositions) {
                tapPositions.add(Pair(x, acceptRect.top - dy))
            }
        }
        for (dy in remainderY) {
            tapPositions.add(Pair(xPositions.first(), acceptRect.top - dy))
        }

        val validTaps = tapPositions.filter { (x, y) -> x > 0f && y in 50f..3000f }
        Log.d(TAG, "좌표탭 시작 — screenW=$screenW acceptRight=${acceptRect.right} top=${acceptRect.top} → ${validTaps.size}개")
        LogBuffer.diag(this, "CLOSE-FALLBACK", "source=ORIGINAL_FLOW_RESTORED, starting coordinate tap fallback, totalCandidates=${validTaps.size}")

        var delay = 0L
        for (pair in validTaps) {
            val x = pair.first
            val y = pair.second
            LogBuffer.diag(this, "CLOSE-FALLBACK-CANDIDATE", "source=ORIGINAL_FLOW_RESTORED, candidate=(${x.toInt()},${y.toInt()})")
            handler.postDelayed({
                if (Build.VERSION.SDK_INT >= 24) {
                    val path = Path().apply { moveTo(x, y) }
                    val stroke = GestureDescription.StrokeDescription(path, 0L, 80L)
                    val gesture = GestureDescription.Builder().addStroke(stroke).build()
                    val ok = dispatchGesture(gesture, null, null)
                    LogBuffer.diag(this, "CLOSE-FALLBACK-GESTURE", "source=ORIGINAL_FLOW_RESTORED, candidate=(${x.toInt()},${y.toInt()}), result=$ok (request dispatched, NOT verified success)")
                    if (!ok) {
                        Log.w(TAG, "dispatchGesture false @ (${String.format(Locale.US, "%.0f", x)}, ${String.format(Locale.US, "%.0f", y)})")
                    }
                }
            }, delay)
            delay += 80L
        }

        handler.postDelayed({
            Log.d(TAG, "탭 완료 → BACK 폴백")
            fallbackBack()
        }, 200L + delay)
    }

    private fun fallbackBack() {
        val pair = findCallCard(source = "FALLBACK_BACK")
        if (pair == null) {
            Log.d(TAG, "폴백: 카드 이미 없음 → 성공 처리")
            LogBuffer.diag(this, "DISMISS-VERIFY-FINAL", "source=ORIGINAL_FLOW_RESTORED, fallbackBack check: card already gone")
            LogBuffer.diag(this, "DISMISS-SUCCESS-CONDITION", "source=ORIGINAL_FLOW_RESTORED, cardPresent=false, verificationPassed=true, via=fallback_already_gone")
            recordDismissSuccess()
            return
        }
        try { pair.first.recycle() } catch (_: Throwable) {}
        try { pair.second?.recycle() } catch (_: Throwable) {}
        if (dismissAttempts >= 3) {
            Log.w(TAG, "폴백: 3회 실패 → 포기 (뒤로가기 사용 안 함)")
            LogBuffer.diag(this, "DISMISS-FAIL", "source=ORIGINAL_FLOW_RESTORED, fallbackBack: 3 attempts failed -> give up")
            recordDismissSuccess()
            return
        }
        Log.w(TAG, "폴백: 카드 아직 있음, 재시도 예정 ($dismissAttempts/3)")
        LogBuffer.diag(this, "DISMISS-RETRY", "source=ORIGINAL_FLOW_RESTORED, fallbackBack: card still exists, retry scheduled ($dismissAttempts/3)")
        val rect = savedAcceptRect
        if (rect == null) {
            Log.w(TAG, "savedAcceptRect 없어 재시도 불가 → 포기")
            recordDismissSuccess()
        } else {
            handler.postDelayed({
                performDismissFresh()
            }, 2500L)
        }
    }

    private fun recordDismissSuccess() {
        lastDismissTime = System.currentTimeMillis()
        PrefsManager.incrementDismissCount(this)
        savedAcceptRect = null
        pendingDismiss = false
        dismissAttempts = 0
        Log.d(TAG, "닫기 완료 — 총 ${PrefsManager.getDismissCount(this)}회")
        LogBuffer.diag(this, "DISMISS-SUCCESS", "source=ORIGINAL_FLOW_RESTORED, dismiss verified success on screen")
        LogBuffer.diag(this, "DISMISS-SUCCESS-COUNT", "source=ORIGINAL_FLOW_RESTORED, totalSuccessCount=${PrefsManager.getDismissCount(this)}")
        sendBroadcast(Intent("com.uber.autoaccept.ACCEPT_EVENT"))
        handler.removeCallbacks(pollRunnable)
        handler.postDelayed(pollRunnable, 200L)
    }

    fun shizukuTap(x: Int, y: Int): Boolean {
        return try {
            if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != 0) {
                return false
            }
            val cmd = arrayOf("input", "touchscreen", "tap", x.toString(), y.toString())
            val method = Shizuku::class.java.methods.firstOrNull { it.name == "newProcess" }
            if (method != null) {
                method.isAccessible = true
                val process = method.invoke(null, cmd, null, null)
                val waitFor = process?.javaClass?.getMethod("waitFor")
                val exit = waitFor?.invoke(process) as? Int ?: -1
                exit == 0
            } else {
                false
            }
        } catch (e: Exception) {
            Log.w(TAG, "Shizuku tap 실패: ${e.message}")
            false
        }
    }

    private fun showTapIndicator(x: Int, y: Int, isAccept: Boolean) {
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val size = (40 * resources.displayMetrics.density).toInt()
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (isAccept) Color.parseColor("#8006C167") else Color.parseColor("#80E11900"))
                    setStroke((2 * resources.displayMetrics.density).toInt(), Color.WHITE)
                }
            }
            val lp = WindowManager.LayoutParams(
                size, size,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                this.x = x - size / 2
                this.y = y - size / 2
            }
            wm.addView(dot, lp)
            handler.postDelayed({
                try {
                    wm.removeView(dot)
                } catch (_: Throwable) {
                }
            }, 600L)
        } catch (_: Throwable) {
        }
    }

    fun normalizeOcrForFingerprint(text: String): String {
        return text.filter { c ->
            c.isLetterOrDigit() || "가맹전용일반호출콜분뒤픽업가능거리km남음구로종로용산구중구장거리경유지".contains(c)
        }
    }

    private fun startOcrAndDecide(
        ocrRect: Rect,
        dismissCardRect: Rect,
        dismissTapX: Int,
        dismissTapY: Int,
        isOverlay: Boolean,
        acceptRect: Rect,
        acceptNode: AccessibilityNodeInfo?,
        keywords: List<String>,
        blacklistMode: Boolean,
        retryCount: Int = 0
    ) {
        ocrCaptureInflight = true
        handler.removeCallbacks(ocrCaptureWatchdog)
        handler.postDelayed(ocrCaptureWatchdog, 5000L)

        try {
            takeScreenshot(0, ContextCompat.getMainExecutor(this), OcrScreenshotCallback(
                ocrRect, dismissCardRect, dismissTapX, dismissTapY, isOverlay, acceptRect, acceptNode, keywords, blacklistMode, retryCount
            ))
        } catch (e: Exception) {
            Log.w(TAG, "OCR takeScreenshot 호출 실패: ${e.message}")
            handler.removeCallbacks(ocrCaptureWatchdog)
            ocrCaptureInflight = false
            pendingAccept = false
        }
    }

    private inner class OcrScreenshotCallback(
        private val cardRect: Rect,
        private val dismissCardRect: Rect,
        private val dismissTapX: Int,
        private val dismissTapY: Int,
        private val isOverlay: Boolean,
        private val acceptRect: Rect,
        private val acceptNode: AccessibilityNodeInfo?,
        private val keywords: List<String>,
        private val blacklistMode: Boolean,
        private val retryCount: Int
    ) : TakeScreenshotCallback {
        override fun onSuccess(screenshot: ScreenshotResult) {
            ocrCaptureInflight = false
            handler.removeCallbacks(ocrCaptureWatchdog)
            val hwBm = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
            if (hwBm == null) {
                pendingAccept = false
                return
            }
            val t0 = System.currentTimeMillis()
            val softBm = hwBm.copy(Bitmap.Config.ARGB_8888, false)
            hwBm.recycle()

            val cropX = cardRect.left.coerceAtLeast(0)
            val cropY = cardRect.top.coerceAtLeast(0)
            val cw = cardRect.width().coerceAtMost(softBm.width - cropX).coerceAtLeast(1)
            val ch = cardRect.height().coerceAtMost(softBm.height - cropY).coerceAtLeast(1)
            val cropped = Bitmap.createBitmap(softBm, cropX, cropY, cw, ch)

            val t1 = System.currentTimeMillis()
            Log.d(TAG, "크롭 소요: ${t1 - t0}ms")
            LogBuffer.log(this@AutoAcceptService, TAG, "크롭 소요: ${t1 - t0}ms")

            val image = InputImage.fromBitmap(cropped, 0)
            val recognizer = try { getOcrRecognizer() } catch (_: Throwable) { null }
            if (recognizer == null) {
                LogBuffer.log(this@AutoAcceptService, TAG, "OCR Recognizer 미준비 상태 — 초기화 요청")
                ensureOcrModuleInstalled()
                cropped.recycle()
                try { softBm.recycle() } catch (_: Throwable) {}
                ocrCaptureInflight = false
                return
            }
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    val t2 = System.currentTimeMillis()
                    val ocrElapsed = t2 - t1
                    val fullElapsed = t2 - t0
                    cropped.recycle()

                    val rawOcr = visionText.text
                    val ocrText = rawOcr.replace("\\s+".toRegex(), " ").trim()
                    setOcrState(OcrState.READY, "OCR 텍스트 인식 성공 (${ocrElapsed}ms)")
                    Log.d(TAG, "⏱️ ML Kit OCR: ${ocrElapsed}ms (전체 ${fullElapsed}ms) — 텍스트='$ocrText'")
                    LogBuffer.log(this@AutoAcceptService, TAG, "⏱️ ML Kit OCR: ${ocrElapsed}ms (전체 ${fullElapsed}ms) — 텍스트='$ocrText'")

                    if (PrefsManager.isAcceptScreenshot(this@AutoAcceptService)) {
                        val bmCopy = softBm.copy(Bitmap.Config.ARGB_8888, false)
                        Thread {
                            try {
                                saveAcceptScreenshotToGallery(bmCopy)
                            } catch (_: Throwable) {
                            }
                        }.start()
                    }

                    try { softBm.recycle() } catch (_: Throwable) {}

                    handler.post {
                        processOcrDecision(
                            ocrText = ocrText,
                            acceptRect = acceptRect,
                            acceptNode = acceptNode,
                            dismissCardRect = dismissCardRect,
                            dismissTapX = dismissTapX,
                            dismissTapY = dismissTapY,
                            isOverlay = isOverlay,
                            keywords = keywords,
                            blacklistMode = blacklistMode,
                            xFromPixels = null,
                            startTime = t0
                        )
                    }
                }
                .addOnFailureListener { e ->
                    val causeMsg = e.cause?.message ?: e.message ?: "unknown"
                    lastOcrFailTime = System.currentTimeMillis()
                    setOcrState(OcrState.DETECTOR_INIT_FAILED, "OCR 실패: ${e.javaClass.simpleName} - $causeMsg")
                    Log.e(TAG, "💥 [OCR-FAILURE] Exception=${e.javaClass.name}, Message=${e.message}, Cause=$causeMsg")
                    LogBuffer.log(this@AutoAcceptService, TAG, "💥 [OCR-FAILURE] ${e.javaClass.simpleName}: $causeMsg")
                    logMlKitDetailedDiagnostic(e)

                    try { cropped.recycle() } catch (_: Throwable) {}
                    try { softBm.recycle() } catch (_: Throwable) {}
                    pendingAccept = false
                }
        }

        override fun onFailure(errorCode: Int) {
            ocrCaptureInflight = false
            handler.removeCallbacks(ocrCaptureWatchdog)
            Log.w(TAG, "OCR takeScreenshot onFailure: errorCode=$errorCode")
            LogBuffer.log(this@AutoAcceptService, TAG, "OCR takeScreenshot onFailure: errorCode=$errorCode")
            pendingAccept = false
        }
    }

    private fun processOcrDecision(
        ocrText: String,
        acceptRect: Rect,
        acceptNode: AccessibilityNodeInfo?,
        dismissCardRect: Rect,
        dismissTapX: Int,
        dismissTapY: Int,
        isOverlay: Boolean,
        keywords: List<String>,
        blacklistMode: Boolean,
        xFromPixels: Pair<Int, Int>?,
        startTime: Long
    ) {
        val now = System.currentTimeMillis()
        val winPkg = lastForegroundPkg ?: UBER_DRIVER_PACKAGE
        val cardKey = "ocr_${winPkg}_$now"

        var matchedKeyword: String? = null
        for (kw in keywords) {
            if (kw.isNotEmpty() && ocrText.contains(kw, ignoreCase = true)) {
                matchedKeyword = kw
                break
            }
        }

        val keywordFound = matchedKeyword != null
        val isAirport = keywordFound
        val shouldAccept = if (blacklistMode) !keywordFound else keywordFound

        Log.d(TAG, "블랙리스트모드=$blacklistMode keywordFound=$keywordFound → shouldAccept=$shouldAccept")
        LogBuffer.log(this, TAG, if (shouldAccept) "🟢 OCR 키워드 일치 → 수락 (블랙리스트=$blacklistMode)" else "🔴 OCR 키워드 불일치 → 닫기 (블랙리스트=$blacklistMode)")

        LogBuffer.diag(
            this,
            "CALLCARD-KEYWORD",
            "candidateTexts='$ocrText', matched=${matchedKeyword ?: "null"}, matchSource=ocr, matchReason=${if (matchedKeyword != null) "KEYWORD_FOUND" else "NO_KEYWORDS_MATCHED"}"
        )

        LogBuffer.diag(
            this,
            "ACCEPT-CONDITION",
            "OCR Evaluation: acceptAll=false, blacklist=$blacklistMode, matched='$matchedKeyword' -> shouldAccept=$shouldAccept [공항=$isAirport]"
        )

        if (shouldAccept) {
            val isUberPkg = winPkg == UBER_DRIVER_PACKAGE
            val cardMarkerList = listOf("분 거리", "분거리", "km 남음", "km남음", "★", "⭐", "콜 수락", "수락하기")
            val hasCardMarker = cardMarkerList.any { ocrText.contains(it) }
            if (!isUberPkg && !hasCardMarker) {
                LogBuffer.log(this, TAG, "🛡️ 가짜 매칭 차단 → 수락 취소 (pkg=$winPkg uber=$isUberPkg 카드마커=$hasCardMarker)")
                Log.w(TAG, "가짜 매칭 차단: pkg=$winPkg uber=$isUberPkg 카드마커=$hasCardMarker ocr=${ocrText.take(120)}")
                pendingAccept = false
                try { acceptNode?.recycle() } catch (_: Throwable) {}
                return
            }
            val sinceCardSeen = if (callCardFirstSeenAt > 0L) now - callCardFirstSeenAt else 999L
            val noDelay = PrefsManager.isAcceptNoDelay(this)
            val airport = PrefsManager.isAirportMode(this)
            val human = PrefsManager.isHumanMode(this)

            val baseDelay = when {
                noDelay -> 0L
                airport -> Random.nextLong(200L, 300L)
                human -> gaussianDelay(PrefsManager.getMinDelay(this), 50L, PrefsManager.getMinDelay(this), PrefsManager.getMaxDelay(this))
                else -> PrefsManager.getMinDelay(this)
            }

            val correction = if (noDelay) 0L else (250L - sinceCardSeen).coerceAtLeast(0L)
            val humanDelay = baseDelay + correction

            val cx = acceptRect.centerX()
            val cy = acceptRect.centerY()
            val tmplLog = "tmpl=생략(옵션A)→노드($cx,$cy)"

            Log.d(TAG, "OCR 키워드 일치 → base=${baseDelay}ms+보정=${correction}ms=${humanDelay}ms 후 수락 ($tmplLog) 카드후=${sinceCardSeen}ms [공항=$isAirport]")
            LogBuffer.log(this, TAG, "OCR 키워드 일치 → base=${baseDelay}ms+보정=${correction}ms=${humanDelay}ms 후 수락 ($cx,$cy) 카드후=${sinceCardSeen}ms [공항=$isAirport]")

            val newCount = PrefsManager.getAcceptScheduled(this) + 1
            LogBuffer.diag(this, "ACCEPT-COUNT", "source=processOcrDecision, reason=ocr_match, cardKey=$cardKey, coords=($cx, $cy), totalCount=$newCount")
            PrefsManager.incrementAcceptScheduled(this, source = "ocr")

            handler.postDelayed({
                lastAcceptTime = System.currentTimeMillis()
                if (acceptNode != null) {
                    executeAccept(acceptNode, acceptRect, winPkg, cardKey)
                } else {
                    executeAcceptAtPos(cx, cy, acceptRect, "OCR", cardKey)
                }
            }, humanDelay)
        } else {
            Log.d(TAG, "OCR 키워드 불일치 → 거절 (overlay=$isOverlay tap=$dismissTapX,$dismissTapY)")
            try { acceptNode?.recycle() } catch (_: Throwable) {}
            pendingAccept = false

            if (now - lastAcceptTime < 5000L) {
                Log.d(TAG, "수락 쿨다운 중 → 거절 건너뜀 (${(now - lastAcceptTime) / 1000}s)")
                return
            }

            val autoDismiss = PrefsManager.isAutoDismiss(this)
            if (!autoDismiss && !blacklistMode) {
                return
            }

            // Sparse OCR safety check
            val cardMarkerList = listOf("분 거리", "분거리", "km 남음", "km남음", "★", "⭐", "*", "분 뒤", "이내 도착", "픽업 가능")
            val markerHits = cardMarkerList.count { ocrText.contains(it) }
            val hasCallAcceptText = ocrText.contains("콜 수락") || ocrText.contains("수락하기")
            if (markerHits < 2 && !hasCallAcceptText) {
                LogBuffer.log(this, TAG, "⏸️ OCR 빈약 → 닫기 보류, 다음 사이클 대기 (마커=$markerHits/2 길이=${ocrText.length})")
                return
            }

            PrefsManager.incrementDismissScheduled(this)

            LogBuffer.log(this, TAG, "🔴 OCR 키워드 불일치 → 닫기 (블랙리스트=$blacklistMode)")

            val cardTop = dismissCardRect.top
            val cardRight = dismissCardRect.right
            val dx = cardRight - 106
            val dy = cardTop + 78
            LogBuffer.log(this, TAG, "🎯 콜카드 우측 상단 X좌표로 닫기: ($dx, $dy) [card=(${dismissCardRect.left},$cardTop ~ $cardRight,${dismissCardRect.bottom})]")

            executeDismissAtPos(dx, dy)
        }
    }

    fun doScreenshotPoll() {
        if (ocrCaptureInflight) return
        if (!isForegroundUber()) return
        val card = findCallCard(source = "OCR_POLL") ?: return
        val (root, btn) = card
        try {
            processWindow(root, btn)
        } finally {
            try { root.recycle() } catch (_: Throwable) {}
        }
    }

    private fun processOcrText(text: Text, bitmap: Bitmap) {
        try {
            if (!isForegroundUber()) {
                return
            }
            val winPkg = lastForegroundPkg ?: UBER_DRIVER_PACKAGE

            val ocrStr = text.text
            val fullText = ocrStr.replace("\\s+".toRegex(), " ")
            val now = System.currentTimeMillis()
            val isUber = winPkg == UBER_DRIVER_PACKAGE || winPkg == SIMULATOR_PACKAGE
            val cardKey = "ocr_${winPkg}_$now"

            if (now - lastAcceptTime < COOLDOWN_MS || pendingAccept) {
                bitmap.recycle()
                return
            }

            val acceptAll = PrefsManager.isAcceptAll(this)
            val blacklistMode = PrefsManager.isBlacklistMode(this)
            val keywords = PrefsManager.getKeywords(this)

            var hasAcceptKeyword = false
            for (btnText in ACCEPT_BUTTON_TEXTS) {
                if (fullText.contains(btnText, ignoreCase = true)) {
                    hasAcceptKeyword = true
                    break
                }
            }

            if (!hasAcceptKeyword) {
                bitmap.recycle()
                return
            }

            var matchedKw: String? = null
            for (kw in keywords) {
                if (kw.isNotEmpty() && fullText.contains(kw, ignoreCase = true)) {
                    matchedKw = kw
                    break
                }
            }

            val shouldAccept = when {
                acceptAll -> true
                blacklistMode -> matchedKw == null
                else -> matchedKw != null
            }

            LogBuffer.diag(this, "ACCEPT-CONDITION", "OCR Evaluation: acceptAll=$acceptAll, blacklist=$blacklistMode, matched='$matchedKw' -> shouldAccept=$shouldAccept, isUber=$isUber")

            if (shouldAccept) {
                var acceptPos: Pair<Int, Int>? = null
                for (block in text.textBlocks) {
                    for (line in block.lines) {
                        for (element in line.elements) {
                            if (ACCEPT_BUTTON_TEXTS.any { element.text.contains(it, ignoreCase = true) }) {
                                val box = element.boundingBox
                                if (box != null) {
                                    acceptPos = Pair(box.centerX(), box.centerY())
                                    break
                                }
                            }
                        }
                        if (acceptPos != null) break
                    }
                    if (acceptPos != null) break
                }

                if (acceptPos == null) {
                    acceptPos = findAcceptButtonByTemplate(bitmap)
                }

                if (acceptPos != null) {
                    val rect = Rect(acceptPos.first - 50, acceptPos.second - 20, acceptPos.first + 50, acceptPos.second + 20)
                    savedAcceptRect = rect
                    val candDetails = "foregroundPkg=$lastForegroundPkg, windowPkg=$winPkg, target=(${acceptPos.first}, ${acceptPos.second}), bounds=$rect, cardKey=$cardKey, method=OCR/Template, isUber=$isUber"
                    LogBuffer.diag(this, "ACCEPT-CANDIDATE", candDetails)
                    if (!isUber) {
                        LogBuffer.diag(this, "FALSE-POSITIVE-CANDIDATE", "Non-Uber screen detected as OCR candidate: $candDetails")
                    }
                    executeAcceptAtPos(acceptPos.first, acceptPos.second, rect, "OCR/Template", cardKey)
                }
            } else {
                val autoDismiss = PrefsManager.isAutoDismiss(this)
                if (autoDismiss && !pendingDismiss && !pendingAccept) {
                    LogBuffer.log(this, TAG, "🔴 OCR 키워드 불일치 → 닫기 (블랙리스트=$blacklistMode)")
                    val isSparseOcr = fullText.length < 10
                    val acceptRect = savedAcceptRect ?: Rect(0, bitmap.height - 200, bitmap.width, bitmap.height)
                    val cardRect = savedAcceptRect?.let { Rect(0, (it.top - 800).coerceAtLeast(0), bitmap.width, it.top) }
                        ?: Rect(0, (bitmap.height * 0.6).toInt(), bitmap.width, bitmap.height)

                    val x = cardRect.right - 106
                    val y = cardRect.top + 78
                    LogBuffer.log(this, TAG, "📸 스크린샷폴링 닫기 X=($x,$y)")
                    executeDismissAtPos(x, y)
                }
            }
        } finally {
            bitmap.recycle()
        }
    }

    private fun executeAcceptAtPos(x: Int, y: Int, rect: Rect, source: String = "Coordinate", cardKey: String = "pos_$lastAcceptTime") {
        val now = System.currentTimeMillis()
        if (now - lastAcceptTime < COOLDOWN_MS || pendingAccept) {
            LogBuffer.diag(this, "ACCEPT-FAIL", "executeAcceptAtPos skipped due to cooldown or pendingAccept")
            return
        }

        pendingAccept = true
        lastAcceptTime = now

        val airport = PrefsManager.isAirportMode(this)
        val human = PrefsManager.isHumanMode(this)
        val noDelay = PrefsManager.isAcceptNoDelay(this)

        val delay = when {
            noDelay -> 0L
            airport -> Random.nextLong(200L, 300L)
            human -> gaussianDelay(PrefsManager.getMinDelay(this), 50L, PrefsManager.getMinDelay(this), PrefsManager.getMaxDelay(this))
            else -> PrefsManager.getMinDelay(this)
        }

        val modeStr = when {
            noDelay -> "NO_DELAY"
            airport -> "AIRPORT"
            human -> "HUMAN"
            else -> "DEFAULT"
        }

        LogBuffer.diag(this, "ACCEPT-DELAY", "mode=$modeStr, delay=${delay}ms, minDelay=${PrefsManager.getMinDelay(this)}ms, maxDelay=${PrefsManager.getMaxDelay(this)}ms")
        LogBuffer.diag(this, "ACCEPT-SCHEDULE", "delay=${delay}ms, reason=$source, coords=($x, $y), cardKey=$cardKey")

        handler.postDelayed({
            showTapIndicator(x, y, true)
            LogBuffer.diag(this, "ACCEPT-TOUCH", "Touch starting ($source): coords=($x, $y), cardKey=$cardKey")

            var touchMethod = "ShizukuTap"
            val shizOk = shizukuTap(x, y)
            LogBuffer.diag(this, "ACCEPT-SHIZUKU", "Shizuku tap result=$shizOk at ($x, $y)")

            if (!shizOk) {
                val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
                val gestureOk = dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 50)).build(), null, null)
                touchMethod = if (gestureOk) "dispatchGesture" else "GestureFailed"
                LogBuffer.diag(this, "ACCEPT-GESTURE", "dispatchGesture result=$gestureOk at ($x, $y)")
            }
            LogBuffer.diag(this, "ACCEPT-TOUCH", "Touch performed ($source): method=$touchMethod, coords=($x, $y), cardKey=$cardKey")

            val newCount = PrefsManager.getAcceptScheduled(this) + 1
            LogBuffer.diag(this, "ACCEPT-COUNT", "source=executeAcceptAtPos, reason=pos_accept_dispatched, cardKey=$cardKey, coords=($x, $y), totalCount=$newCount")
            PrefsManager.incrementAcceptScheduled(this, source = "executeAcceptAtPos")

            PrefsManager.saveLastAcceptRect(this, rect)
            sendBroadcast(Intent("com.uber.autoaccept.ACCEPT_EVENT"))
            vibrate()
            triggerSleepAlarm()
            pendingAccept = false

            // Verification (Separation of TOUCH and SUCCESS)
            handler.postDelayed({
                val verifyRoot = findUberRoot()
                val stillHasCard = verifyRoot != null && (findCardIndicator(verifyRoot) || findAcceptButton(verifyRoot) != null)
                if (!stillHasCard) {
                    LogBuffer.diag(this, "ACCEPT-VERIFY", "Card disappeared after $source accept, cardKey=$cardKey")
                    LogBuffer.diag(this, "ACCEPT-SUCCESS", "Accept operation verified SUCCESS on screen ($source), cardKey=$cardKey")
                } else {
                    LogBuffer.diag(this, "ACCEPT-VERIFY", "Card still visible after $source accept, cardKey=$cardKey")
                    LogBuffer.diag(this, "ACCEPT-RETRY", "Retrying accept at ($x, $y), cardKey=$cardKey")
                }
            }, 500L)
        }, delay)
    }

    private fun executeDismissAtPos(x: Int, y: Int) {
        val now = System.currentTimeMillis()
        if (now - lastDismissTime < 1500L || pendingDismiss || pendingAccept) {
            return
        }
        pendingDismiss = true
        dismissAttempts = 1
        dismissTapFiredAtMs = now
        dismissEventLogCount = 0
        handler.removeCallbacks(dismissTimeoutRunnable)
        handler.postDelayed(dismissTimeoutRunnable, 20000L)

        showTapIndicator(x, y, false)
        LogBuffer.log(this, TAG, "🔨 스크린샷폴링 닫기탭 ($x, $y) shizuku=true")

        shizukuExecutor.execute {
            val shizOk = shizukuTap(x, y)
            if (!shizOk) {
                val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
                dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 50)).build(), null, null)
            }
        }

        // 1차 검증 (400ms 후 실제 카드 소멸 여부 확인)
        handler.postDelayed({
            if (!pendingDismiss) return@postDelayed
            val card = findCallCard(source = "DISMISS_VERIFY_1")
            if (card == null) {
                LogBuffer.log(this, TAG, "✅ 스크린샷폴링 닫기 성공 (1회차 검증 통과 - 카드 소멸)")
                recordDismissSuccess()
            } else {
                // 카드가 남아있거나(닫기 실패) 뒤쪽 2번째 카드가 전면에 노출된 경우 -> 새 전면 카드 bounds 재측정
                val (root, acceptBtn) = card
                val acceptR = Rect().also {
                    if (acceptBtn != null) acceptBtn.getBoundsInScreen(it) else root.getBoundsInScreen(it)
                }
                val freshCard = findOverlayCard(root, acceptR)
                val retryX = freshCard.right - 106
                val retryY = freshCard.top + 78
                try { acceptBtn?.recycle() } catch (_: Throwable) {}
                try { root.recycle() } catch (_: Throwable) {}

                LogBuffer.log(this, TAG, "⚠️ 1차 검증: 카드 잔존 → 새 bounds ($retryX, $retryY) 2차 탭 재시도")
                dismissAttempts = 2
                showTapIndicator(retryX, retryY, false)

                shizukuExecutor.execute {
                    val shizOk = shizukuTap(retryX, retryY)
                    if (!shizOk) {
                        val path = Path().apply { moveTo(retryX.toFloat(), retryY.toFloat()) }
                        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 50)).build(), null, null)
                    }
                }

                // 2차 검증 (600ms 후)
                handler.postDelayed({
                    if (!pendingDismiss) return@postDelayed
                    val card2 = findCallCard(source = "DISMISS_VERIFY_2")
                    if (card2 == null) {
                        LogBuffer.log(this, TAG, "✅ 스크린샷폴링 닫기 성공 (2회차 검증 통과)")
                    } else {
                        try { card2.first.recycle() } catch (_: Throwable) {}
                        try { card2.second?.recycle() } catch (_: Throwable) {}
                        LogBuffer.log(this, TAG, "⚠️ 2차 검증 후에도 카드 잔존 → 닫기 완료 처리 후 다음 사이클 대기")
                    }
                    recordDismissSuccess()
                }, 600L)
            }
        }, 400L)
    }

    private fun scheduleAcceptRetap(rect: Rect?, delayMs: Long, cardKey: String = "") {
        if (rect == null) return
        LogBuffer.diag(this, "ACCEPT-RETRY", "Scheduling retap after ${delayMs}ms at (${rect.centerX()}, ${rect.centerY()}), cardKey=$cardKey")
        handler.postDelayed({
            executeAcceptAtPos(rect.centerX(), rect.centerY(), rect, "Retap", cardKey)
        }, delayMs)
    }

    private fun findAcceptButton(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val screenHeight = resources.displayMetrics.heightPixels
        for (btnText in ACCEPT_BUTTON_TEXTS) {
            val list = root.findAccessibilityNodeInfosByText(btnText)
            if (!list.isNullOrEmpty()) {
                for (node in list) {
                    val nodeText = node.text?.toString()?.trim() ?: node.contentDescription?.toString()?.trim() ?: ""
                    val isStatus = (nodeText.contains("가능") || nodeText.contains("불가") || nodeText.contains("수락률") || nodeText.contains("기록") || nodeText.contains("설정")) && !nodeText.contains("콜")
                    if (isStatus) {
                        try { node.recycle() } catch (_: Throwable) {}
                        continue
                    }
                    val r = Rect()
                    node.getBoundsInScreen(r)
                    if (btnText == "수락" && (r.bottom < screenHeight * 0.35f || r.width() < 60 || r.height() < 30)) {
                        try { node.recycle() } catch (_: Throwable) {}
                        continue
                    }
                    val pick = pickAcceptNode(node)
                    if (pick != null) return pick
                }
            }
        }

        return null
    }

    private fun pickAcceptNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var curr: AccessibilityNodeInfo? = node
        while (curr != null) {
            if (curr.isClickable && curr.isEnabled) return curr
            curr = curr.parent
        }
        val r = Rect()
        node.getBoundsInScreen(r)
        return if (r.width() > 0 && r.height() > 0) node else null
    }

    private fun findDismissButton(root: AccessibilityNodeInfo, acceptRect: Rect): AccessibilityNodeInfo? {
        for (text in DISMISS_BUTTON_TEXTS) {
            val list = root.findAccessibilityNodeInfosByText(text)
            if (!list.isNullOrEmpty()) {
                for (node in list) {
                    val nr = Rect()
                    node.getBoundsInScreen(nr)
                    if (node.isClickable) {
                        LogBuffer.diag(this, "DISMISS-BUTTON", "source=ORIGINAL_FLOW_RESTORED, found=true, text='${node.text}', desc='${node.contentDescription}', cls='${node.className}', bounds=$nr, clickable=true")
                        return node
                    }
                    val parent = node.parent
                    if (parent != null && parent.isClickable) {
                        val pr = Rect()
                        parent.getBoundsInScreen(pr)
                        LogBuffer.diag(this, "DISMISS-BUTTON", "source=ORIGINAL_FLOW_RESTORED, found=true (parent), text='${node.text}', cls='${parent.className}', bounds=$pr, clickable=true")
                        try { node.recycle() } catch (_: Throwable) {}
                        return parent
                    }
                    try { node.recycle() } catch (_: Throwable) {}
                }
            }
        }
        val iconBtn = findIconCloseButton(root, acceptRect)
        LogBuffer.diag(this, "DISMISS-BUTTON", "source=ORIGINAL_FLOW_RESTORED, textSearchFound=false, iconSearchFound=${iconBtn != null}")
        return iconBtn
    }

    private fun findDismissViaParent(acceptBtn: AccessibilityNodeInfo, acceptRect: Rect): AccessibilityNodeInfo? {
        var cursor: AccessibilityNodeInfo? = try { acceptBtn.parent } catch (_: Throwable) { null }
        var depth = 0
        while (cursor != null && depth < 8) {
            val cursorRect = Rect()
            cursor.getBoundsInScreen(cursorRect)
            if (cursorRect.height() > acceptRect.height() * 1.5) {
                val candidate = findIconInSubtree(cursor, acceptRect)
                if (candidate != null) {
                    val cr = Rect()
                    candidate.getBoundsInScreen(cr)
                    LogBuffer.diag(this, "DISMISS-PARENT", "source=ORIGINAL_FLOW_RESTORED, found=true, depth=$depth, bounds=$cr, containerBounds=$cursorRect")
                    return candidate
                }
            }
            val parent = try { cursor.parent } catch (_: Throwable) { null }
            try { cursor.recycle() } catch (_: Throwable) {}
            cursor = parent
            depth++
        }
        if (cursor != null) {
            try { cursor.recycle() } catch (_: Throwable) {}
        }
        LogBuffer.diag(this, "DISMISS-PARENT", "source=ORIGINAL_FLOW_RESTORED, found=false, depth=$depth")
        return null
    }

    private fun findIconInSubtree(root: AccessibilityNodeInfo, acceptRect: Rect): AccessibilityNodeInfo? {
        val screenWidth = resources.displayMetrics.widthPixels
        val rightThreshold = 0.3f * screenWidth
        val yMin = acceptRect.top - 1500
        val yMax = acceptRect.top - 50
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var bestScore = -1
        var best: AccessibilityNodeInfo? = null

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            val it = Rect()
            node.getBoundsInScreen(it)
            val w = it.width()
            val h = it.height()
            var keepNode = false

            if (w in 1..400 && h in 1..400 && it.centerX() >= rightThreshold) {
                val centerY = it.centerY()
                if (centerY in yMin..yMax) {
                    val text = "${node.text} ${node.contentDescription}"
                    val isAccept = ACCEPT_BUTTON_TEXTS.any { text.contains(it, ignoreCase = true) }
                    if (!isAccept) {
                        val score = (acceptRect.top - it.centerY()) + (it.right * 10)
                        Log.d(TAG, "서브트리 후보: $it cls=${node.className} click=${node.isClickable} score=$score")
                        if (score > bestScore) {
                            if (best != root && best != null) {
                                try { best.recycle() } catch (_: Throwable) {}
                            }
                            keepNode = true
                            bestScore = score
                            best = node
                        }
                    }
                }
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                if (child != null) queue.add(child)
            }

            if (!keepNode && node != root && node != best) {
                try { node.recycle() } catch (_: Throwable) {}
            }
        }
        return best
    }

    private fun findIconCloseButton(root: AccessibilityNodeInfo, acceptRect: Rect): AccessibilityNodeInfo? {
        val screenWidth = resources.displayMetrics.widthPixels
        val yMin = Math.max(acceptRect.top - 1300, 100)
        val yMax = acceptRect.top - 400
        val xMin = screenWidth / 2
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var bestCandidate: AccessibilityNodeInfo? = null
        var totalNodes = 0
        var bestScore = -1

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            totalNodes++
            val rect = Rect()
            node.getBoundsInScreen(rect)
            val w = rect.width()
            val h = rect.height()
            var keepNode = false

            if (w in 1..200 && h in 1..200) {
                val centerY = rect.centerY()
                if (centerY in yMin..yMax && rect.centerX() >= xMin) {
                    val combined = "${node.text} ${node.contentDescription}"
                    val isAcceptBtn = ACCEPT_BUTTON_TEXTS.any { combined.contains(it, ignoreCase = true) }
                    if (!isAcceptBtn) {
                        val rightScore = screenWidth - rect.right
                        val score = (10000 - (rightScore * 10)) - (acceptRect.top - centerY)
                        Log.d(TAG, "X 후보: bounds=$rect cls=${node.className} click=${node.isClickable} score=$score")
                        if (score > bestScore) {
                            if (bestCandidate != root && bestCandidate != null) {
                                try { bestCandidate.recycle() } catch (_: Throwable) {}
                            }
                            keepNode = true
                            bestScore = score
                            bestCandidate = node
                        }
                    }
                }
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i)
                if (child != null) queue.add(child)
            }

            if (!keepNode && node != root && node != bestCandidate) {
                try { node.recycle() } catch (_: Throwable) {}
            }
        }

        Log.d(TAG, "X 버튼 탐색 완료 — 전체노드:$totalNodes, yRange:$yMin~$yMax, 결과: ${if (bestCandidate != null) "찾음 score=$bestScore" else "못 찾음"}")
        val br = Rect()
        bestCandidate?.getBoundsInScreen(br)
        LogBuffer.diag(this, "DISMISS-ICON", "source=ORIGINAL_FLOW_RESTORED, found=${bestCandidate != null}, bounds=${if (bestCandidate != null) br.toString() else "none"}, bestScore=$bestScore, totalNodes=$totalNodes")
        return bestCandidate
    }

    fun dumpCallTree(root: AccessibilityNodeInfo, acceptRect: Rect): String {
        val sb = StringBuilder()
        sb.append("▶ acceptRect: $acceptRect\n")
        sb.append("── 전체 노드 (Y 순서) ──\n")
        val collected = mutableListOf<AccessibilityNodeInfo>()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val n = queue.removeFirst()
            if (n != root) collected.add(n)
            for (i in 0 until n.childCount) {
                val child = n.getChild(i)
                if (child != null) queue.add(child)
            }
        }
        val sorted = collected.map { n ->
            val r = Rect()
            n.getBoundsInScreen(r)
            val cls = n.className?.toString()?.substringAfterLast('.') ?: "-"
            val txtList = listOfNotNull(n.text, n.contentDescription).filter { it.isNotEmpty() }
            val txt = txtList.joinToString("|").take(24).ifEmpty { "-" }
            val clk = if (n.isClickable) "Y" else "n"
            val act = n.actionList?.joinToString(",") { it.id.toString() } ?: "-"
            NodeSnap(r, cls, txt, clk, act)
        }.sortedWith(compareBy({ it.r.top }, { it.r.left }))

        for (snap in sorted) {
            sb.append("  [${snap.r.left},${snap.r.top},${snap.r.right},${snap.r.bottom}] ${snap.cls} clk=${snap.clk} act=${snap.act} txt=\"${snap.txt}\"\n")
        }
        return sb.toString()
    }

    data class NodeSnap(val r: Rect, val cls: String, val txt: String, val clk: String, val act: String)

    fun findXButtonByTemplate(bitmap: Bitmap, dismissCardRect: Rect, acceptRect: Rect, ocrText: String): Pair<Int, Int>? {
        if (xBtnTemplates.isEmpty()) {
            Log.w(TAG, "X버튼 템플릿 미로드 → 템플릿 매칭 건너뜀")
            return null
        }
        val searchL = (dismissCardRect.right - 180).coerceAtLeast(0)
        val searchR = (dismissCardRect.right + 20).coerceAtMost(bitmap.width - 1)
        val isFallbackCard = dismissCardRect.top == acceptRect.top - 800
        val searchT: Int
        val searchB: Int
        if (isFallbackCard) {
            val approxCenter = acceptRect.top - 690
            searchT = (approxCenter - 200).coerceAtLeast(0)
            searchB = (approxCenter + 150).coerceAtMost(bitmap.height - 1)
            Log.d(TAG, "폴백rect 탐색범위 보정: approxCenter=$approxCenter searchT=$searchT searchB=$searchB")
        } else {
            searchT = (dismissCardRect.top - 200).coerceAtLeast(0)
            searchB = (dismissCardRect.top + 100).coerceAtMost(bitmap.height - 1)
        }

        val searchW = (searchR - searchL + 1).coerceAtLeast(1)
        val searchH = (searchB - searchT + 1).coerceAtLeast(1)
        Log.d(TAG, "템플릿 매칭 탐색영역(카드기준): x=[$searchL,$searchR] y=[$searchT,$searchB]")
        val searchPixels = IntArray(searchW * searchH)
        bitmap.getPixels(searchPixels, 0, searchW, searchL, searchT, searchW, searchH)

        var bestSadPs = Double.MAX_VALUE
        var bestX = -1
        var bestY = -1
        var bestTw = 120
        var bestTh = 120

        for (tmpl in xBtnTemplates) {
            val tw = tmpl.width
            val th = tmpl.height
            val tmplSamples = ((tw + 2) / 3).coerceAtLeast(1).toDouble() *
                    ((th + 2) / 3).coerceAtLeast(1).toDouble() * 3.0
            for (ry in 0..(searchH - th) step 8) {
                for (rx in 0..(searchW - tw) step 8) {
                    val sad = computeSADArray(searchPixels, searchW, rx, ry, tmpl.pixels, tw, th)
                    val sadPs = sad.toDouble() / tmplSamples
                    if (sadPs < bestSadPs) {
                        bestSadPs = sadPs
                        bestX = searchL + rx + tw / 2
                        bestY = searchT + ry + th / 2
                        bestTw = tw
                        bestTh = th
                    }
                }
            }
        }

        if (bestX < 0) {
            LogBuffer.diag(this, "DISMISS-TEMPLATE", "source=ORIGINAL_FLOW_RESTORED, templates=${xBtnTemplates.size}, match=false, sad=none, coord=none")
            return null
        }
        val bestSadFormatted = String.format(Locale.US, "%.1f", bestSadPs)
        Log.d(TAG, "템플릿 매칭 최저SAD: ($bestX,$bestY) SAD/sample=$bestSadFormatted tmpl=${bestTw}x$bestTh")
        val matchSuccess = bestSadPs < 50.0
        LogBuffer.diag(this, "DISMISS-TEMPLATE", "source=ORIGINAL_FLOW_RESTORED, templates=${xBtnTemplates.size}, match=$matchSuccess, sad=$bestSadFormatted, coord=($bestX,$bestY)")
        if (bestSadPs < 50.0) {
            Log.d(TAG, "템플릿 매칭 성공!")
            LogBuffer.log(this, TAG, "✅ X템플릿 성공 SAD/sample=$bestSadFormatted 좌표=($bestX,$bestY) tmpl=${bestTw}x$bestTh")
            return Pair(bestX, bestY)
        }
        val fbX = dismissCardRect.right - 106
        val fbY = dismissCardRect.top + 78
        LogBuffer.log(this, TAG, "🔍 템플릿실패 SAD/sample=$bestSadFormatted 최저=($bestX,$bestY) 탐색=[$searchL,$searchT~$searchR,$searchB] 폴백=($fbX,$fbY) tmpl=${bestTw}x$bestTh")
        saveTemplateDebugBitmap(bitmap)
        return null
    }

    private var templateDebugSavedMs: Long = 0L

    private fun saveTemplateDebugBitmap(bitmap: Bitmap) {
        val now = System.currentTimeMillis()
        if (now - templateDebugSavedMs < 1800000L) return
        templateDebugSavedMs = now
        val copy = try {
            bitmap.copy(Bitmap.Config.ARGB_8888, false)
        } catch (_: Throwable) {
            null
        } ?: return

        Thread {
            try {
                val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
                val fileName = "template_debug_${sdf.format(Date())}.jpg"
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/스마트알림")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        copy.compress(Bitmap.CompressFormat.JPEG, 90, out)
                    }
                }
            } catch (_: Throwable) {
            } finally {
                copy.recycle()
            }
        }.start()
    }

    private fun findCardIndicator(root: AccessibilityNodeInfo): Boolean {
        val indicators = listOf(
            "분 거리", "분거리", "분 뒤", "분뒤", "km 남음", "km남음", "km",
            "★", "⭐", "콜 수락", "콜수락", "수락하기", "수락", "Accept",
            "새로운 요청", "새 요청", "요청", "픽업", "하차", "경유지",
            "가맹전용", "일반호출", "우버 택시", "우버택시", "UberX"
        )
        for (indicator in indicators) {
            val distNodes = root.findAccessibilityNodeInfosByText(indicator)
            if (!distNodes.isNullOrEmpty()) {
                for (it in distNodes) {
                    try { it.recycle() } catch (_: Throwable) {}
                }
                Log.d(TAG, "카드 지시자 발견 [$indicator 텍스트]")
                return true
            }
        }
        return false
    }

    private fun collectAllText(node: AccessibilityNodeInfo?): String {
        if (node == null) return ""
        val sb = StringBuilder()
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(node)
        while (queue.isNotEmpty()) {
            val curr = queue.removeFirst()
            val txt = curr.text
            if (!txt.isNullOrEmpty()) {
                sb.append(txt).append(" ")
            }
            val desc = curr.contentDescription
            if (!desc.isNullOrEmpty()) {
                sb.append(desc).append(" ")
            }
            for (i in 0 until curr.childCount) {
                val child = curr.getChild(i)
                if (child != null) {
                    queue.add(child)
                }
            }
        }
        return sb.toString()
    }

    private fun loadXBtnTemplates() {
        val ids = listOf(
            R.raw.xbtn_template1, R.raw.xbtn_template2, R.raw.xbtn_template3,
            R.raw.xbtn_template4, R.raw.xbtn_template5
        )
        for (id in ids) {
            try {
                val bmp = BitmapFactory.decodeResource(resources, id) ?: continue
                val w = bmp.width
                val h = bmp.height
                val pixels = IntArray(w * h)
                bmp.getPixels(pixels, 0, w, 0, 0, w, h)
                xBtnTemplates.add(TemplateData(pixels, w, h))
                bmp.recycle()
            } catch (_: Throwable) {
            }
        }
    }

    private fun loadAcceptBtnTemplates() {
        val ids = listOf(
            R.raw.accept_template_light, R.raw.accept_template_dark,
            R.raw.accept_template_dark1, R.raw.accept_template_dark2,
            R.raw.accept_template_fold5_dark
        )
        for (id in ids) {
            try {
                val bmp = BitmapFactory.decodeResource(resources, id) ?: continue
                val w = bmp.width
                val h = bmp.height
                val pixels = IntArray(w * h)
                bmp.getPixels(pixels, 0, w, 0, 0, w, h)
                acceptBtnTemplates.add(TemplateData(pixels, w, h))
                bmp.recycle()
            } catch (_: Throwable) {
            }
        }
    }

    private fun computeSADArray(
        src: IntArray, srcW: Int, startX: Int, startY: Int,
        tmpl: IntArray, tw: Int, th: Int
    ): Long {
        var sad = 0L
        for (row in 0 until th) {
            val srcRowOff = (startY + row) * srcW + startX
            val tmplRowOff = row * tw
            for (col in 0 until tw) {
                val c1 = src[srcRowOff + col]
                val c2 = tmpl[tmplRowOff + col]
                val r = abs(((c1 shr 16) and 0xFF) - ((c2 shr 16) and 0xFF))
                val g = abs(((c1 shr 8) and 0xFF) - ((c2 shr 8) and 0xFF))
                val b = abs((c1 and 0xFF) - (c2 and 0xFF))
                sad += (r + g + b)
            }
        }
        return sad
    }

    fun findAcceptButtonByTemplate(bitmap: Bitmap): Pair<Int, Int>? {
        if (acceptBtnTemplates.isEmpty()) return null
        val bw = bitmap.width
        val bh = bitmap.height
        val pixels = IntArray(bw * bh)
        bitmap.getPixels(pixels, 0, bw, 0, 0, bw, bh)

        var bestScore = Long.MAX_VALUE
        var bestX = -1
        var bestY = -1

        for (tmpl in acceptBtnTemplates) {
            val tw = tmpl.width
            val th = tmpl.height
            if (tw >= bw || th >= bh) continue

            val startSearchY = (bh * 0.40f).toInt()
            val endSearchY = bh - th

            for (y in startSearchY until endSearchY step 8) {
                for (x in 0 until (bw - tw) step 8) {
                    val sad = computeSADArray(pixels, bw, x, y, tmpl.pixels, tw, th)
                    if (sad < bestScore) {
                        bestScore = sad
                        bestX = x + tw / 2
                        bestY = y + th / 2
                    }
                }
            }
        }

        return if (bestX != -1 && bestY != -1) Pair(bestX, bestY) else null
    }

    private fun takeScreenshotAndSave() {
        takeScreenshot(0, ContextCompat.getMainExecutor(this), object : TakeScreenshotCallback {
            override fun onSuccess(screenshot: ScreenshotResult) {
                val hwBm = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace) ?: return
                val softBm = hwBm.copy(Bitmap.Config.ARGB_8888, false)
                hwBm.recycle()
                saveAcceptScreenshotToGallery(softBm)
            }
            override fun onFailure(errorCode: Int) {}
        })
    }

    fun saveAcceptScreenshotToGallery(bitmap: Bitmap) {
        val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
        val name = "UberAccept_${sdf.format(Date())}.png"
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_DCIM + "/스마트알림")
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                    }
                }
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "스마트알림")
                if (!dir.exists()) dir.mkdirs()
                val file = File(dir, name)
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "스크린샷 저장 실패: ${e.message}")
        } finally {
            bitmap.recycle()
        }
    }

    fun gaussianDelay(mean: Long, stdDev: Long, minVal: Long, maxVal: Long): Long {
        val u1 = Random.nextDouble().coerceAtLeast(1e-7)
        val u2 = Random.nextDouble()
        val z0 = sqrt(-2.0 * kotlin.math.ln(u1)) * kotlin.math.cos(2.0 * Math.PI * u2)
        val result = (mean + z0 * stdDev).toLong()
        return result.coerceIn(minVal, maxVal)
    }

    fun vibrate() {
        if (!PrefsManager.isVibration(this)) return
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(150)
            }
        } catch (_: Throwable) {
        }
    }

    fun triggerSleepAlarm() {
        if (!PrefsManager.isSleepAlarm(this)) return
        try {
            val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            val ringtone = RingtoneManager.getRingtone(this, alarmUri)
            ringtone?.play()
            sleepAlarmRingtone = ringtone
            handler.postDelayed({
                try {
                    ringtone?.stop()
                } catch (_: Throwable) {
                }
            }, 3000L)
        } catch (_: Throwable) {
        }
    }
}
