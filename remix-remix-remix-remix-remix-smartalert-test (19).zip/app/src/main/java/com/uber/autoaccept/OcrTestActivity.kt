package com.uber.autoaccept

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.io.InputStream

/**
 * 🧪 OCR 테스트 전용 Activity
 * 실제 Uber 콜을 기다리지 않고 UI에서 테스트 이미지를 직접 선택하여
 * 현재 프로젝트에서 사용하는 기존 OCR recognizer 및 process(image) 경로를 그대로 직접 실행하고
 * 성공/실패/상세 예외/처리 시간을 실시간으로 확인하는 화면
 */
class OcrTestActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "OCR-DIRECT-TEST"
    }

    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private lateinit var ivPreview: ImageView
    private lateinit var tvStatusBadge: TextView
    private lateinit var tvDurationBadge: TextView
    private lateinit var tvOcrResult: TextView
    private lateinit var tvLogDetails: TextView
    private lateinit var btnSelectImage: Button
    private lateinit var btnRunOcr: Button
    private lateinit var progressBar: ProgressBar

    private var selectedBitmap: Bitmap? = null

    private val imagePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri: Uri? = result.data?.data
            if (uri != null) {
                loadSelectedImage(uri)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUI()
    }

    override fun onDestroy() {
        super.onDestroy()
        selectedBitmap?.let {
            if (!it.isRecycled) {
                try { it.recycle() } catch (_: Throwable) {}
            }
        }
        selectedBitmap = null
    }

    private fun buildUI() {
        val BG = Color.parseColor("#141414")
        val CARD = Color.parseColor("#1E1E1E")
        val ACCENT = Color.parseColor("#06C167")
        val TEXT_SEC = Color.parseColor("#9A9A9A")
        val BORDER = Color.parseColor("#2E2E2E")

        val rootScroll = ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
            overScrollMode = View.OVER_SCROLL_NEVER
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(48), dp(16), dp(60))
        }

        // 1. Header (뒤로가기 + 타이틀)
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val btnBack = Button(this).apply {
            text = "← 뒤로"
            textSize = 13f
            setTextColor(Color.WHITE)
            background = roundRect(Color.parseColor("#333333"), dp(8))
            layoutParams = LinearLayout.LayoutParams(WRAP, dp(38)).apply {
                rightMargin = dp(12)
            }
            setOnClickListener { finish() }
        }
        headerRow.addView(btnBack)

        val tvTitle = TextView(this).apply {
            text = "🧪 OCR 직접 테스트"
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, WRAP).apply { weight = 1f }
        }
        headerRow.addView(tvTitle)
        root.addView(headerRow)
        root.addView(space(16))

        // 2. Info Card
        val infoCard = card(CARD, BORDER)
        val tvDesc = TextView(this).apply {
            text = "우버 콜을 기다리지 않고 갤러리의 스크린샷/이미지를 선택하여\n기존 앱과 동일한 ML Kit Korean OCR 파이프라인(process)을 직접 테스트합니다."
            textSize = 12.5f
            setTextColor(TEXT_SEC)
            setLineSpacing(dp(3).toFloat(), 1.0f)
        }
        infoCard.addView(tvDesc)
        root.addView(infoCard)
        root.addView(space(12))

        // 3. Image Selection & Preview Card
        val imageCard = card(CARD, BORDER)
        val tvImageTitle = TextView(this).apply {
            text = "1. 테스트 이미지 선택"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        imageCard.addView(tvImageTitle)
        imageCard.addView(space(10))

        btnSelectImage = Button(this).apply {
            text = "🖼️ 갤러리에서 이미지 선택"
            textSize = 14f
            setTextColor(Color.WHITE)
            background = roundRect(Color.parseColor("#276EF1"), dp(10))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(48))
            setOnClickListener { openImagePicker() }
        }
        imageCard.addView(btnSelectImage)
        imageCard.addView(space(12))

        // Preview Box
        val previewContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = roundRect(Color.parseColor("#0F0F0F"), dp(10))
            setPadding(dp(8), dp(8), dp(8), dp(8))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(220))
        }

        ivPreview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(MATCH, MATCH)
        }
        previewContainer.addView(ivPreview)
        imageCard.addView(previewContainer)
        root.addView(imageCard)
        root.addView(space(12))

        // 4. Action Card (실행 버튼 + 상태)
        val actionCard = card(CARD, BORDER)
        val tvActionTitle = TextView(this).apply {
            text = "2. OCR 엔진 실행"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        actionCard.addView(tvActionTitle)
        actionCard.addView(space(10))

        btnRunOcr = Button(this).apply {
            text = "⚡ 기존 OCR 실행 (recognizer.process)"
            textSize = 14f
            setTextColor(Color.WHITE)
            background = roundRect(ACCENT, dp(10))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(50))
            setOnClickListener { runOcrTest() }
        }
        actionCard.addView(btnRunOcr)
        actionCard.addView(space(12))

        progressBar = ProgressBar(this).apply {
            visibility = View.GONE
            indeterminateTintList = ColorStateList.valueOf(ACCENT)
            layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply {
                gravity = Gravity.CENTER_HORIZONTAL
            }
        }
        actionCard.addView(progressBar)

        // Status Row
        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        tvStatusBadge = TextView(this).apply {
            text = "대기 중"
            textSize = 12f
            setTextColor(TEXT_SEC)
            background = roundRect(Color.parseColor("#2A2A2A"), dp(6))
            setPadding(dp(10), dp(4), dp(10), dp(4))
            layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply {
                rightMargin = dp(8)
            }
        }
        statusRow.addView(tvStatusBadge)

        tvDurationBadge = TextView(this).apply {
            text = "소요 시간: -"
            textSize = 12f
            setTextColor(TEXT_SEC)
        }
        statusRow.addView(tvDurationBadge)
        actionCard.addView(statusRow)
        root.addView(actionCard)
        root.addView(space(12))

        // 5. OCR Result Card
        val resultCard = card(CARD, BORDER)
        val tvResultHeader = TextView(this).apply {
            text = "3. 인식된 텍스트 결과"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        resultCard.addView(tvResultHeader)
        resultCard.addView(space(8))

        val svResult = ScrollView(this).apply {
            background = roundRect(Color.parseColor("#0F0F0F"), dp(8))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(150))
            isScrollbarFadingEnabled = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        tvOcrResult = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.WHITE)
            typeface = Typeface.MONOSPACE
            text = "[인식된 텍스트가 여기에 표시됩니다]"
            setTextIsSelectable(true)
        }
        svResult.addView(tvOcrResult)
        resultCard.addView(svResult)
        root.addView(resultCard)
        root.addView(space(12))

        // 6. Detailed Log / Exception Card
        val logCard = card(CARD, BORDER)
        val tvLogHeader = TextView(this).apply {
            text = "4. 상세 진단 & Native / Exception 로그"
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        logCard.addView(tvLogHeader)
        logCard.addView(space(8))

        val svLog = ScrollView(this).apply {
            background = roundRect(Color.parseColor("#090909"), dp(8))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(180))
            isScrollbarFadingEnabled = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        tvLogDetails = TextView(this).apply {
            textSize = 11f
            setTextColor(Color.parseColor("#00E676"))
            typeface = Typeface.MONOSPACE
            text = "[상세 로그 대기 중...]"
            setTextIsSelectable(true)
        }
        svLog.addView(tvLogDetails)
        logCard.addView(svLog)
        root.addView(logCard)
        root.addView(space(24))

        rootScroll.addView(root)
        setContentView(rootScroll)
    }

    private fun openImagePicker() {
        try {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "image/*"
                addCategory(Intent.CATEGORY_OPENABLE)
            }
            imagePickerLauncher.launch(Intent.createChooser(intent, "테스트 이미지 선택"))
        } catch (e: Exception) {
            Toast.makeText(this, "이미지 선택기 실행 실패: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadSelectedImage(uri: Uri) {
        try {
            val inputStream: InputStream? = contentResolver.openInputStream(uri)
            val bmp = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            if (bmp == null) {
                Toast.makeText(this, "이미지 로드에 실패했습니다", Toast.LENGTH_SHORT).show()
                return
            }

            selectedBitmap?.let {
                if (!it.isRecycled) {
                    try { it.recycle() } catch (_: Throwable) {}
                }
            }
            selectedBitmap = bmp
            ivPreview.setImageBitmap(bmp)

            val logMsg = "IMAGE_SELECTED: width=${bmp.width}, height=${bmp.height}, config=${bmp.config}"
            Log.i(TAG, logMsg)
            LogBuffer.diag(this, TAG, logMsg)

            tvStatusBadge.text = "이미지 로드됨"
            tvStatusBadge.setTextColor(Color.parseColor("#00BFFF"))
            tvStatusBadge.background = roundRect(Color.parseColor("#0B2A3A"), dp(6))
            tvDurationBadge.text = "크기: ${bmp.width}x${bmp.height}"
            tvLogDetails.text = "[INFO] $logMsg\n준비 완료: '기존 OCR 실행' 버튼을 눌러주세요."

        } catch (e: Throwable) {
            Log.e(TAG, "이미지 열기 실패: ${e.message}", e)
            Toast.makeText(this, "이미지 불러오기 실패: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun runOcrTest() {
        val bmp = selectedBitmap
        if (bmp == null || bmp.isRecycled) {
            Toast.makeText(this, "먼저 테스트 이미지를 선택해주세요", Toast.LENGTH_SHORT).show()
            return
        }

        btnRunOcr.isEnabled = false
        progressBar.visibility = View.VISIBLE
        tvStatusBadge.text = "OCR 실행 중..."
        tvStatusBadge.setTextColor(Color.parseColor("#FFB800"))
        tvStatusBadge.background = roundRect(Color.parseColor("#332600"), dp(6))

        val startTime = SystemClock.elapsedRealtime()
        val startLog = "PROCESS_START: image=${bmp.width}x${bmp.height}, timeMs=$startTime"
        Log.i(TAG, startLog)
        LogBuffer.diag(this, TAG, startLog)

        tvLogDetails.text = "[PROCESS_START] $startLog\nML Kit Recognizer 생성 및 process(image) 호출 중...\n(Native C++ 파이프라인 진입)"

        try {
            // 기존 앱과 동일하게 Application Context 기반 MlKitContext 초기화
            val appContext = applicationContext ?: this
            try {
                com.google.mlkit.common.sdkinternal.MlKitContext.initializeIfNeeded(appContext)
            } catch (_: Throwable) {}

            // 기존 AutoAcceptService와 완전히 동일한 KoreanTextRecognizer 클라이언트 획득
            val recognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
            val inputImage = InputImage.fromBitmap(bmp, 0)

            recognizer.process(inputImage)
                .addOnSuccessListener { visionText ->
                    val elapsed = SystemClock.elapsedRealtime() - startTime
                    val resultText = visionText.text
                    val textBlocks = visionText.textBlocks.size
                    val lines = visionText.textBlocks.sumOf { it.lines.size }

                    val successLog = "SUCCESS: elapsed=${elapsed}ms, blocks=$textBlocks, lines=$lines, textLength=${resultText.length}"
                    Log.i(TAG, successLog)
                    LogBuffer.diag(this, TAG, successLog)

                    btnRunOcr.isEnabled = true
                    progressBar.visibility = View.GONE

                    tvStatusBadge.text = "✅ OCR 성공"
                    tvStatusBadge.setTextColor(Color.parseColor("#06C167"))
                    tvStatusBadge.background = roundRect(Color.parseColor("#0D2818"), dp(6))
                    tvDurationBadge.text = "소요 시간: ${elapsed} ms"

                    tvOcrResult.text = if (resultText.isBlank()) {
                        "(인식된 텍스트가 없습니다 — 빈 화면 또는 텍스트 없음)"
                    } else {
                        resultText
                    }

                    val logSummary = StringBuilder()
                        .append("[OCR-DIRECT-TEST] SUCCESS\n")
                        .append("처리 시간: ${elapsed} ms\n")
                        .append("블록 수: $textBlocks, 라인 수: $lines\n")
                        .append("텍스트 길이: ${resultText.length} 글자\n\n")
                        .append("=== 세부 라인별 텍스트 ===\n")

                    visionText.textBlocks.forEachIndexed { bIdx, block ->
                        logSummary.append("블록[$bIdx]: ${block.text}\n")
                    }

                    tvLogDetails.text = logSummary.toString()
                    Log.i(TAG, "PROCESS_END: SUCCESS")
                }
                .addOnFailureListener { e ->
                    val elapsed = SystemClock.elapsedRealtime() - startTime
                    val failLog = "FAILURE: elapsed=${elapsed}ms, exception=${e.javaClass.name}, msg=${e.message}"
                    Log.e(TAG, failLog, e)
                    LogBuffer.diag(this, TAG, failLog)

                    btnRunOcr.isEnabled = true
                    progressBar.visibility = View.GONE

                    tvStatusBadge.text = "❌ OCR 실패"
                    tvStatusBadge.setTextColor(Color.parseColor("#FF5555"))
                    tvStatusBadge.background = roundRect(Color.parseColor("#331414"), dp(6))
                    tvDurationBadge.text = "소요 시간: ${elapsed} ms"

                    tvOcrResult.text = "[실패] 텍스트를 인식하지 못했습니다."

                    val logSummary = StringBuilder()
                        .append("[OCR-DIRECT-TEST] FAILURE\n")
                        .append("처리 시간: ${elapsed} ms\n")
                        .append("Exception Class: ${e.javaClass.name}\n")
                        .append("Exception Message: ${e.message}\n\n")
                        .append("=== Cause Chain ===\n")

                    var currentCause: Throwable? = e
                    var depth = 0
                    while (currentCause != null && depth < 6) {
                        logSummary.append(" [Depth $depth] ${currentCause.javaClass.name}: ${currentCause.message}\n")
                        currentCause = currentCause.cause
                        depth++
                    }

                    logSummary.append("\n=== StackTrace (Top 8) ===\n")
                    e.stackTrace.take(8).forEach { st ->
                        logSummary.append("  at $st\n")
                    }

                    tvLogDetails.text = logSummary.toString()
                    Log.i(TAG, "PROCESS_END: FAILURE")
                }
        } catch (t: Throwable) {
            val elapsed = SystemClock.elapsedRealtime() - startTime
            val syncFailLog = "SYNC_EXCEPTION: elapsed=${elapsed}ms, exception=${t.javaClass.name}, msg=${t.message}"
            Log.e(TAG, syncFailLog, t)
            LogBuffer.diag(this, TAG, syncFailLog)

            btnRunOcr.isEnabled = true
            progressBar.visibility = View.GONE

            tvStatusBadge.text = "❌ 동기 예외 발생"
            tvStatusBadge.setTextColor(Color.parseColor("#FF5555"))
            tvStatusBadge.background = roundRect(Color.parseColor("#331414"), dp(6))
            tvDurationBadge.text = "소요 시간: ${elapsed} ms"

            tvLogDetails.text = "[OCR-DIRECT-TEST] SYNC_EXCEPTION\n${t.javaClass.name}: ${t.message}\n"
        }
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }

    private fun space(dp: Int): View {
        return View(this).apply {
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(dp))
        }
    }

    private fun card(bgColor: Int, borderColor: Int): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            val gd = GradientDrawable().apply {
                setColor(bgColor)
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), borderColor)
            }
            background = gd
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                bottomMargin = 0
            }
        }
    }

    private fun roundRect(color: Int, radius: Int): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }
    }
}
