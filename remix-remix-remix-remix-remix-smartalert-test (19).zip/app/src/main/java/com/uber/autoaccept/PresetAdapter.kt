package com.uber.autoaccept

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class PresetAdapter(
    private val items: MutableList<KeywordPreset>,
    private val onApply: (Int) -> Unit,
    private val onEdit: (Int) -> Unit,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<PresetAdapter.VH>() {

    class VH(val row: LinearLayout) : RecyclerView.ViewHolder(row) {
        val tvName: TextView = row.findViewWithTag("name")
        val tvKw: TextView = row.findViewWithTag("kw")
        val btnApply: Button = row.findViewWithTag("apply")
        val btnEdit: Button = row.findViewWithTag("edit")
        val btnDel: Button = row.findViewWithTag("del")
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val ctx = parent.context
        val density = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(14), dp(10), dp(10), dp(10))
            gravity = android.view.Gravity.CENTER_VERTICAL
            val bg = GradientDrawable().apply {
                setColor(Color.parseColor("#152238"))
                cornerRadius = dp(10).toFloat()
                setStroke(dp(1), Color.parseColor("#223554"))
            }
            background = bg
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            }
        }

        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val tvName = TextView(ctx).apply {
            textSize = 14.5f
            setTextColor(Color.parseColor("#F8FAFC"))
            typeface = Typeface.DEFAULT_BOLD
            tag = "name"
        }
        val tvKw = TextView(ctx).apply {
            textSize = 11.5f
            setTextColor(Color.parseColor("#00E5FF"))
            typeface = Typeface.MONOSPACE
            tag = "kw"
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                topMargin = dp(3)
            }
        }
        col.addView(tvName)
        col.addView(tvKw)
        row.addView(col)

        val btnApply = Button(ctx).apply {
            text = "적용"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#0F141F"))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#00FF9D"))
                cornerRadius = dp(6).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(34)).apply {
                marginStart = dp(6)
            }
            setPadding(0, 0, 0, 0)
            tag = "apply"
        }
        row.addView(btnApply)

        val btnEdit = Button(ctx).apply {
            text = "✏️"
            textSize = 13f
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#182740"))
                cornerRadius = dp(6).toFloat()
                setStroke(dp(1), Color.parseColor("#2B4168"))
            }
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(34)).apply {
                marginStart = dp(4)
            }
            setPadding(0, 0, 0, 0)
            tag = "edit"
        }
        row.addView(btnEdit)

        val btnDel = Button(ctx).apply {
            text = "🗑️"
            textSize = 13f
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2E141E"))
                cornerRadius = dp(6).toFloat()
                setStroke(dp(1), Color.parseColor("#5A1E2D"))
            }
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(34)).apply {
                marginStart = dp(4)
            }
            setPadding(0, 0, 0, 0)
            tag = "del"
        }
        row.addView(btnDel)

        return VH(row)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = items[position]
        holder.tvName.text = p.name
        holder.tvKw.text = p.keywords.joinToString(" · ")
        holder.btnApply.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                onApply(pos)
            }
        }
        holder.btnEdit.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                onEdit(pos)
            }
        }
        holder.btnDel.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                onDelete(pos)
            }
        }
    }

    override fun getItemCount(): Int = items.size
}

