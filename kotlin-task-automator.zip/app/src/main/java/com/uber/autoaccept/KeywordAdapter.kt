package com.uber.autoaccept

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class KeywordAdapter(
    private val items: List<String>,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<KeywordAdapter.VH>() {

    inner class VH(val row: LinearLayout) : RecyclerView.ViewHolder(row) {
        val tvText: TextView = row.findViewWithTag("text")
        val btnDel: Button = row.findViewWithTag("delete")
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val context = parent.context
        fun dp(v: Int): Int = (v * context.resources.displayMetrics.density).toInt()

        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(6)
            }
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E1E1E"))
                cornerRadius = dp(10).toFloat()
            }
            setPadding(dp(14), dp(10), dp(10), dp(10))
        }

        val tv = TextView(context).apply {
            tag = "text"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 15f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        row.addView(tv)

        val btn = Button(context).apply {
            tag = "delete"
            text = "✕"
            setTextColor(Color.parseColor("#FF5252"))
            textSize = 14f
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#2A1A1A"))
                cornerRadius = dp(8).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
            setPadding(0, 0, 0, 0)
        }
        row.addView(btn)

        return VH(row)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.tvText.text = items[position]
        holder.btnDel.setOnClickListener {
            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                onDelete(pos)
            }
        }
    }

    override fun getItemCount(): Int = items.size
}
