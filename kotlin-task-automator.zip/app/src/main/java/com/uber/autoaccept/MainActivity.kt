package com.uber.autoaccept

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import rikka.shizuku.Shizuku
import java.io.File

class MainActivity : AppCompatActivity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val handler = Handler(Looper.getMainLooper())
    private val keywords = mutableListOf<String>()
    private val presets = mutableListOf<KeywordPreset>()

    private val shizukuPermissionCode = 1001

    private lateinit var adapter: KeywordAdapter
    private lateinit var presetAdapter: PresetAdapter

    private lateinit var tvStatus: TextView
    private lateinit var switchActive: Switch

    private lateinit var tvCallCount: TextView
    private lateinit var tvAcceptScheduled: TextView
    private lateinit var tvDismissScheduled: TextView

    private lateinit var switchAcceptAll: Switch
    private lateinit var switchAutoDismiss: Switch
    private lateinit var switchOcrPoll: Switch
    private lateinit var switchSleepAlarm: Switch
    private lateinit var switchBlacklistMode: Switch
    private lateinit var switchAirportMode: Switch
    private lateinit var switchAcceptNoDelay: Switch
    private lateinit var switchFloatingBubble: Switch

    private lateinit var seekDismissCooldown: SeekBar
    private lateinit var tvDismissCooldown: TextView
    private lateinit var tvDismissDebug: TextView

    private lateinit var btnAccessibility: Button
    private lateinit var btnNotification: Button

    private lateinit var etKeyword: EditText
    private lateinit var btnAdd: Button
    private lateinit var rvKeywords: RecyclerView
    private lateinit var rvPresets: RecyclerView

    private lateinit var switchHumanMode: Switch
    private lateinit var seekMinDelay: SeekBar
    private lateinit var tvMinDelay: TextView
    private lateinit var seekMaxDelay: SeekBar
    private lateinit var tvMaxDelay: TextView
    private lateinit var switchVibration: Switch
    private lateinit var switchAcceptScreenshot: Switch

    private val statsRefresher = object : Runnable {
        override fun run() {
            updateStats()
            updateAccessibilityStatus()
            handler.postDelayed(this, 1000L)
        }
    }

    private val acceptReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            updateStats()
        }
    }

    private val shizukuPermissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == shizukuPermissionCode) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Shizuku 권한 승인됨", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Shizuku 권한 거부됨", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUI()
        loadSettings()
        setupListeners()
        requestShizukuPermission()
    }

    private fun requestShizukuPermission() {
        try {
            if (Shizuku.pingBinder()) {
                if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                    Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
                    Shizuku.requestPermission(shizukuPermissionCode)
                }
            }
        } catch (_: Throwable) {
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
        } catch (_: Throwable) {
        }
    }

    override fun onResume() {
        super.onResume()
        loadSettings()
        updateStats()
        updateAccessibilityStatus()
        handler.post(statsRefresher)
        val filter = IntentFilter("com.uber.autoaccept.ACCEPT_EVENT")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(acceptReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(acceptReceiver, filter)
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(statsRefresher)
        try {
            unregisterReceiver(acceptReceiver)
        } catch (_: Exception) {
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun space(h: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(h))
    }

    private fun dividerV(margin: Int = 12): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(MATCH, dp(1)).apply {
            topMargin = dp(margin)
            bottomMargin = dp(margin)
        }
        setBackgroundColor(Color.parseColor("#222222"))
    }

    private fun card(pad: Int = 16, margin: Int = 8): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
            topMargin = dp(margin)
            bottomMargin = dp(margin)
        }
        background = roundRect(dp(14), Color.parseColor("#1A1A1A"))
        setPadding(dp(pad), dp(pad), dp(pad), dp(pad))
    }

    private fun roundRect(radiusDp: Int, color: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusDp.toFloat()
    }

    private fun buildUI() {
        val rootScroll = ScrollView(this).apply {
            layoutParams = ViewGroup.LayoutParams(MATCH, MATCH)
            setBackgroundColor(Color.parseColor("#141414"))
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(MATCH, WRAP)
            setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        rootScroll.addView(root)

        // 1. Header Card
        val headerCard = card(pad = 16, margin = 4)
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        }
        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        val tvAppTitle = TextView(this).apply {
            text = "스마트 알림"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            try {
                typeface = Typeface.createFromAsset(assets, "fonts/Jua-Regular.ttf")
            } catch (_: Exception) {}
        }
        titleCol.addView(tvAppTitle)

        val tvSub = TextView(this).apply {
            text = "Uber Driver 자동 수락 보조"
            setTextColor(Color.parseColor("#888888"))
            textSize = 12f
        }
        titleCol.addView(tvSub)
        headerRow.addView(titleCol)

        tvStatus = TextView(this).apply {
            text = "⏹ 비활성"
            setTextColor(Color.parseColor("#888888"))
            textSize = 14f
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        headerRow.addView(tvStatus)

        switchActive = Switch(this).apply {
            layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply {
                leftMargin = dp(8)
            }
        }
        headerRow.addView(switchActive)
        headerCard.addView(headerRow)
        root.addView(headerCard)

        // 2. Statistics Card
        val statCard = card(pad = 12, margin = 4)
        val statRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        }

        fun statView(label: String, color: String): Pair<LinearLayout, TextView> {
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            }
            val tvVal = TextView(this).apply {
                text = "0"
                setTextColor(Color.parseColor(color))
                textSize = 20f
                setTypeface(typeface, Typeface.BOLD)
            }
            val tvLbl = TextView(this).apply {
                text = label
                setTextColor(Color.parseColor("#888888"))
                textSize = 11f
            }
            col.addView(tvVal)
            col.addView(tvLbl)
            return Pair(col, tvVal)
        }

        val (c1, v1) = statView("감지", "#FFFFFF")
        tvCallCount = v1
        statRow.addView(c1)

        val (c2, v2) = statView("수락 예정", "#06C167")
        tvAcceptScheduled = v2
        statRow.addView(c2)

        val (c3, v3) = statView("거절 예정", "#FF5252")
        tvDismissScheduled = v3
        statRow.addView(c3)

        val btnReset = Button(this).apply {
            text = "초기화"
            setTextColor(Color.parseColor("#888888"))
            textSize = 11f
            background = roundRect(dp(8), Color.parseColor("#222222"))
            layoutParams = LinearLayout.LayoutParams(dp(54), dp(32))
            setPadding(0, 0, 0, 0)
            setOnClickListener {
                PrefsManager.resetCounts(this@MainActivity)
                updateStats()
            }
        }
        statRow.addView(btnReset)
        statCard.addView(statRow)
        root.addView(statCard)

        // 3. Settings Card (Features & Switches)
        val featureCard = card(pad = 16, margin = 4)

        fun createSwitchRow(title: String, desc: String, tagColor: String = "#06C167"): Pair<LinearLayout, Switch> {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                    topMargin = dp(6)
                    bottomMargin = dp(6)
                }
            }
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            }
            val tvT = TextView(this).apply {
                text = title
                setTextColor(Color.parseColor("#FFFFFF"))
                textSize = 15f
            }
            val tvD = TextView(this).apply {
                text = desc
                setTextColor(Color.parseColor("#777777"))
                textSize = 12f
            }
            col.addView(tvT)
            col.addView(tvD)
            row.addView(col)

            val sw = Switch(this).apply {
                layoutParams = LinearLayout.LayoutParams(WRAP, WRAP)
            }
            row.addView(sw)
            return Pair(row, sw)
        }

        val (rAcceptAll, swAcceptAll) = createSwitchRow("모든 콜 수락", "키워드와 관계없이 모든 콜을 자동 수락")
        switchAcceptAll = swAcceptAll
        featureCard.addView(rAcceptAll)
        featureCard.addView(dividerV(8))

        val (rAutoDismiss, swAutoDismiss) = createSwitchRow("불일치 콜 자동 거절", "설정한 키워드가 없는 콜을 자동으로 닫기", "#FF5252")
        switchAutoDismiss = swAutoDismiss
        featureCard.addView(rAutoDismiss)

        // Dismiss cooldown seekbar
        val cooldownRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                topMargin = dp(4)
                bottomMargin = dp(4)
            }
        }
        val tvCooldownLabel = TextView(this).apply {
            text = "거절 대기 시간"
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 13f
        }
        cooldownRow.addView(tvCooldownLabel)
        tvDismissCooldown = TextView(this).apply {
            text = "1.5초"
            setTextColor(Color.parseColor("#FF5252"))
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(WRAP, WRAP).apply {
                leftMargin = dp(8)
            }
        }
        cooldownRow.addView(tvDismissCooldown)
        featureCard.addView(cooldownRow)

        seekDismissCooldown = SeekBar(this).apply {
            max = 50 // 0.5s to 5.5s (0..50 -> 500ms..5500ms)
            progress = 10
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        }
        featureCard.addView(seekDismissCooldown)

        tvDismissDebug = TextView(this).apply {
            text = "닫기 진단 결과 보기"
            setTextColor(Color.parseColor("#276EF1"))
            textSize = 12f
            setPadding(0, dp(4), 0, dp(4))
            setOnClickListener { showDiagDialog() }
        }
        featureCard.addView(tvDismissDebug)
        featureCard.addView(dividerV(8))

        val (rOcrPoll, swOcrPoll) = createSwitchRow("화면 캡처 기반 감지 (OCR)", "접근성 노드 미감지 시 화면 스크린샷으로 텍스트 분석", "#276EF1")
        switchOcrPoll = swOcrPoll
        featureCard.addView(rOcrPoll)
        featureCard.addView(dividerV(8))

        val (rSleepAlarm, swSleepAlarm) = createSwitchRow("수면 알람", "콜 수락/거절 시 알람 벨소리로 깨우기", "#F0A500")
        switchSleepAlarm = swSleepAlarm
        featureCard.addView(rSleepAlarm)
        featureCard.addView(dividerV(8))

        val (rBlacklist, swBlacklist) = createSwitchRow("블랙리스트 모드", "키워드가 포함된 콜을 거절", "#E53935")
        switchBlacklistMode = swBlacklist
        featureCard.addView(rBlacklist)
        featureCard.addView(dividerV(8))

        val (rAirport, swAirport) = createSwitchRow("공항 전용 모드", "공항 관련 키워드만 수락", "#F0A500")
        switchAirportMode = swAirport
        featureCard.addView(rAirport)
        featureCard.addView(dividerV(8))

        val (rNoDelay, swNoDelay) = createSwitchRow("수락 무딜레이", "수락만 0ms 즉시 탭 · 거절 딜레이는 그대로 유지", "#E53935")
        switchAcceptNoDelay = swNoDelay
        featureCard.addView(rNoDelay)
        featureCard.addView(dividerV(8))

        val (rBubble, swBubble) = createSwitchRow("위젯", "화면 위에 뜨는 콜대기중 버튼", "#06C167")
        switchFloatingBubble = swBubble
        featureCard.addView(rBubble)

        root.addView(featureCard)

        // 4. Permission / Service buttons
        val btnCard = card(pad = 12, margin = 4)
        btnAccessibility = Button(this).apply {
            text = "접근성 서비스 설정 열기"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 14f
            background = roundRect(dp(10), Color.parseColor("#276EF1"))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(48))
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        btnCard.addView(btnAccessibility)

        btnNotification = Button(this).apply {
            text = "알림 접근 권한 설정 열기"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 14f
            background = roundRect(dp(10), Color.parseColor("#E65C00"))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(48)).apply {
                topMargin = dp(8)
            }
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        }
        btnCard.addView(btnNotification)
        root.addView(btnCard)

        // 5. Destination Keywords Card
        val kwCard = card(pad = 16, margin = 4)
        val tvKwTitle = TextView(this).apply {
            text = "목적지 키워드"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
        }
        kwCard.addView(tvKwTitle)

        val kwInputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                topMargin = dp(10)
            }
        }
        etKeyword = EditText(this).apply {
            hint = "예: 인천공항, 강남"
            setHintTextColor(Color.parseColor("#555555"))
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 14f
            background = roundRect(dp(8), Color.parseColor("#272727"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            imeOptions = EditorInfo.IME_ACTION_DONE
            setSingleLine(true)
            layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply {
                rightMargin = dp(8)
            }
        }
        kwInputRow.addView(etKeyword)

        btnAdd = Button(this).apply {
            text = "추가"
            setTextColor(Color.parseColor("#06C167"))
            textSize = 13f
            background = roundRect(dp(8), Color.parseColor("#142E1F"))
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(44))
            setPadding(0, 0, 0, 0)
            setOnClickListener { addKeywordFromInput() }
        }
        kwInputRow.addView(btnAdd)
        kwCard.addView(kwInputRow)

        // Quick tags
        val tvQuickTitle = TextView(this).apply {
            text = "자주 쓰는 목적지"
            setTextColor(Color.parseColor("#777777"))
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                topMargin = dp(10)
                bottomMargin = dp(6)
            }
        }
        kwCard.addView(tvQuickTitle)

        val quickTagsLayout = FlexWrapLayout(this)
        val quickList = listOf("인천공항", "강남", "잠실", "홍대", "서울역", "여의도", "공항")
        for (kw in quickList) {
            val btnTag = Button(this).apply {
                text = "+ $kw"
                setTextColor(Color.parseColor("#06C167"))
                textSize = 12f
                background = roundRect(dp(6), Color.parseColor("#0D1F17"))
                setPadding(dp(10), dp(4), dp(10), dp(4))
                layoutParams = ViewGroup.LayoutParams(WRAP, dp(32))
                setOnClickListener { addKeyword(kw) }
            }
            quickTagsLayout.addView(btnTag)
        }
        kwCard.addView(quickTagsLayout)
        kwCard.addView(dividerV(10))

        // Keyword list header
        val kwListHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                bottomMargin = dp(8)
            }
        }
        val tvKwListLbl = TextView(this).apply {
            text = "키워드 목록"
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 13f
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        kwListHeader.addView(tvKwListLbl)

        val btnClearAll = Button(this).apply {
            text = "전체 삭제"
            setTextColor(Color.parseColor("#FF5555"))
            textSize = 12f
            background = roundRect(dp(6), Color.parseColor("#2A1515"))
            layoutParams = LinearLayout.LayoutParams(dp(74), dp(32))
            setPadding(0, 0, 0, 0)
            setOnClickListener {
                keywords.clear()
                adapter.notifyDataSetChanged()
                PrefsManager.saveKeywords(this@MainActivity, keywords)
            }
        }
        kwListHeader.addView(btnClearAll)
        kwCard.addView(kwListHeader)

        rvKeywords = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
            isNestedScrollingEnabled = false
        }
        adapter = KeywordAdapter(keywords) { pos ->
            keywords.removeAt(pos)
            adapter.notifyItemRemoved(pos)
            PrefsManager.saveKeywords(this, keywords)
        }
        rvKeywords.adapter = adapter
        kwCard.addView(rvKeywords)

        root.addView(kwCard)

        // 6. Presets Card
        val presetCard = card(pad = 16, margin = 4)
        val presetHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                bottomMargin = dp(8)
            }
        }
        val presetTitleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        val tvPrTitle = TextView(this).apply {
            text = "키워드 프리셋"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
        }
        val tvPrSub = TextView(this).apply {
            text = "탭하면 해당 키워드 목록으로 전환"
            setTextColor(Color.parseColor("#777777"))
            textSize = 12f
        }
        presetTitleCol.addView(tvPrTitle)
        presetTitleCol.addView(tvPrSub)
        presetHeader.addView(presetTitleCol)

        val btnSavePreset = Button(this).apply {
            text = "+ 현재 저장"
            setTextColor(Color.parseColor("#FFFFFF"))
            textSize = 12f
            background = roundRect(dp(8), Color.parseColor("#276EF1"))
            layoutParams = LinearLayout.LayoutParams(dp(80), dp(34))
            setPadding(0, 0, 0, 0)
            setOnClickListener { showSavePresetDialog() }
        }
        presetHeader.addView(btnSavePreset)
        presetCard.addView(presetHeader)

        rvPresets = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
            isNestedScrollingEnabled = false
        }
        presetAdapter = PresetAdapter(
            presets,
            onApply = { pos ->
                val p = presets[pos]
                keywords.clear()
                keywords.addAll(p.keywords)
                adapter.notifyDataSetChanged()
                PrefsManager.saveKeywords(this, keywords)
                Toast.makeText(this, "'${p.name}' 프리셋 적용됨", Toast.LENGTH_SHORT).show()
            },
            onEdit = { pos -> showEditPresetDialog(pos) },
            onDelete = { pos -> showDeletePresetDialog(pos) }
        )
        rvPresets.adapter = presetAdapter
        presetCard.addView(rvPresets)

        root.addView(presetCard)

        // 7. Human Mode & Timing Card
        val humanCard = card(pad = 16, margin = 4)
        val (rHuman, swHuman) = createSwitchRow("인간 반응 시뮬레이션", "랜덤 딜레이로 패턴 감지 방어", "#06C167")
        switchHumanMode = swHuman
        humanCard.addView(rHuman)

        // Min Delay
        val minDelayRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                topMargin = dp(8)
            }
        }
        val tvMinLbl = TextView(this).apply {
            text = "최소 딜레이"
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 13f
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        minDelayRow.addView(tvMinLbl)
        tvMinDelay = TextView(this).apply {
            text = "1.0초"
            setTextColor(Color.parseColor("#06C167"))
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
        }
        minDelayRow.addView(tvMinDelay)
        humanCard.addView(minDelayRow)

        seekMinDelay = SeekBar(this).apply {
            max = 50 // 0..50 -> 0.0s..5.0s
            progress = 10
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        }
        humanCard.addView(seekMinDelay)

        // Max Delay
        val maxDelayRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply {
                topMargin = dp(8)
            }
        }
        val tvMaxLbl = TextView(this).apply {
            text = "최대 딜레이"
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 13f
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        maxDelayRow.addView(tvMaxLbl)
        tvMaxDelay = TextView(this).apply {
            text = "3.0초"
            setTextColor(Color.parseColor("#06C167"))
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
        }
        maxDelayRow.addView(tvMaxDelay)
        humanCard.addView(maxDelayRow)

        seekMaxDelay = SeekBar(this).apply {
            max = 50
            progress = 30
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP)
        }
        humanCard.addView(seekMaxDelay)

        humanCard.addView(dividerV(8))

        val (rVib, swVib) = createSwitchRow("수락 시 진동", "콜 수락 시 진동 피드백", "#06C167")
        switchVibration = swVib
        humanCard.addView(rVib)
        humanCard.addView(dividerV(8))

        val (rScreen, swScreen) = createSwitchRow("수락 시 스크린샷", "콜 수락 시 화면을 DCIM/스마트알림/ 에 저장", "#06C167")
        switchAcceptScreenshot = swScreen
        humanCard.addView(rScreen)

        root.addView(humanCard)

        // 8. Export Log Button
        val btnExport = Button(this).apply {
            text = "로그 파일 내보내기"
            setTextColor(Color.parseColor("#AAAAAA"))
            textSize = 14f
            background = roundRect(dp(10), Color.parseColor("#222222"))
            layoutParams = LinearLayout.LayoutParams(MATCH, dp(48)).apply {
                topMargin = dp(8)
                bottomMargin = dp(16)
            }
            setOnClickListener { exportLog() }
        }
        root.addView(btnExport)

        setContentView(rootScroll)
    }

    private fun loadSettings() {
        val active = PrefsManager.isActive(this)
        switchActive.isChecked = active
        updateStatus(active)

        switchAcceptAll.isChecked = PrefsManager.isAcceptAll(this)
        switchAutoDismiss.isChecked = PrefsManager.isAutoDismiss(this)
        switchOcrPoll.isChecked = PrefsManager.isOcrPoll(this)
        switchSleepAlarm.isChecked = PrefsManager.isSleepAlarm(this)
        switchBlacklistMode.isChecked = PrefsManager.isBlacklistMode(this)
        switchAirportMode.isChecked = PrefsManager.isAirportMode(this)
        switchAcceptNoDelay.isChecked = PrefsManager.isAcceptNoDelay(this)
        switchFloatingBubble.isChecked = PrefsManager.isFloatingBubble(this)
        switchHumanMode.isChecked = PrefsManager.isHumanMode(this)
        switchVibration.isChecked = PrefsManager.isVibration(this)
        switchAcceptScreenshot.isChecked = PrefsManager.isAcceptScreenshot(this)

        val minDelay = PrefsManager.getMinDelayMs(this)
        val maxDelay = PrefsManager.getMaxDelayMs(this)
        seekMinDelay.progress = (minDelay / 100).toInt()
        seekMaxDelay.progress = (maxDelay / 100).toInt()
        tvMinDelay.text = String.format("%.1f초", minDelay / 1000f)
        tvMaxDelay.text = String.format("%.1f초", maxDelay / 1000f)

        val cooldown = PrefsManager.getDismissCooldownMs(this)
        seekDismissCooldown.progress = ((cooldown - 500) / 100).coerceAtLeast(0).toInt()
        tvDismissCooldown.text = String.format("%.1f초", cooldown / 1000f)

        keywords.clear()
        keywords.addAll(PrefsManager.getKeywords(this))
        adapter.notifyDataSetChanged()

        presets.clear()
        presets.addAll(PrefsManager.getPresets(this))
        presetAdapter.notifyDataSetChanged()
    }

    private fun setupListeners() {
        switchActive.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setActive(this, isChecked)
            updateStatus(isChecked)
        }

        switchAcceptAll.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setAcceptAll(this, isChecked)
        }

        switchAutoDismiss.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setAutoDismiss(this, isChecked)
        }

        switchOcrPoll.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.saveOcrPoll(this, isChecked)
        }

        switchSleepAlarm.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.saveSleepAlarm(this, isChecked)
        }

        switchBlacklistMode.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.saveBlacklistMode(this, isChecked)
        }

        switchAirportMode.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.saveAirportMode(this, isChecked)
        }

        switchAcceptNoDelay.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.saveAcceptNoDelay(this, isChecked)
        }

        switchFloatingBubble.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.saveFloatingBubble(this, isChecked)
            if (isChecked) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                } else {
                    startService(Intent(this, FloatingBubbleService::class.java))
                }
            } else {
                stopService(Intent(this, FloatingBubbleService::class.java))
            }
        }

        switchHumanMode.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setHumanMode(this, isChecked)
        }

        switchVibration.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.setVibration(this, isChecked)
        }

        switchAcceptScreenshot.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.saveAcceptScreenshot(this, isChecked)
        }

        etKeyword.setOnEditorActionListener { _, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_DONE ||
                (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN)
            ) {
                addKeywordFromInput()
                true
            } else false
        }

        seekMinDelay.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val minMs = progress * 100L
                val maxMs = seekMaxDelay.progress * 100L
                if (minMs > maxMs) {
                    seekMaxDelay.progress = progress
                }
                tvMinDelay.text = String.format("%.1f초", minMs / 1000f)
                PrefsManager.setDelays(this@MainActivity, minMs, seekMaxDelay.progress * 100L)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        seekMaxDelay.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val maxMs = progress * 100L
                val minMs = seekMinDelay.progress * 100L
                if (maxMs < minMs) {
                    seekMinDelay.progress = progress
                }
                tvMaxDelay.text = String.format("%.1f초", maxMs / 1000f)
                PrefsManager.setDelays(this@MainActivity, seekMinDelay.progress * 100L, maxMs)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        seekDismissCooldown.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val cooldownMs = 500L + progress * 100L
                tvDismissCooldown.text = String.format("%.1f초", cooldownMs / 1000f)
                PrefsManager.setDismissCooldownMs(this@MainActivity, cooldownMs)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
    }

    private fun addKeywordFromInput() {
        val text = etKeyword.text.toString().trim()
        if (text.isNotEmpty()) {
            addKeyword(text)
            etKeyword.setText("")
        }
    }

    private fun addKeyword(kw: String) {
        if (!keywords.contains(kw)) {
            keywords.add(kw)
            adapter.notifyItemInserted(keywords.size - 1)
            PrefsManager.saveKeywords(this, keywords)
            Toast.makeText(this, "'$kw' 추가됨", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateStats() {
        tvCallCount.text = "${PrefsManager.getCallCount(this)}"
        tvAcceptScheduled.text = "${PrefsManager.getAcceptScheduled(this)}"
        tvDismissScheduled.text = "${PrefsManager.getDismissScheduled(this)}"
    }

    private fun updateStatus(active: Boolean) {
        if (active) {
            tvStatus.text = "▶ 활성 중..."
            tvStatus.setTextColor(Color.parseColor("#06C167"))
        } else {
            tvStatus.text = "⏹ 비활성"
            tvStatus.setTextColor(Color.parseColor("#888888"))
        }
    }

    private fun updateAccessibilityStatus() {
        val serviceName = "$packageName/${AutoAcceptService::class.java.canonicalName}"
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: ""
        val isEnabled = enabledServices.split(":").any { it.equals(serviceName, ignoreCase = true) }
        if (isEnabled) {
            btnAccessibility.text = "접근성 서비스 활성화됨 ✓"
            btnAccessibility.setBackgroundColor(Color.parseColor("#142E1F"))
            btnAccessibility.setTextColor(Color.parseColor("#06C167"))
        } else {
            btnAccessibility.text = "접근성 서비스 설정 열기"
            btnAccessibility.background = roundRect(dp(10), Color.parseColor("#276EF1"))
            btnAccessibility.setTextColor(Color.parseColor("#FFFFFF"))
        }
    }

    private fun showDiagDialog() {
        val diag = PrefsManager.getDismissDiag(this)
        AlertDialog.Builder(this)
            .setTitle("닫기 진단 결과")
            .setMessage(diag)
            .setPositiveButton("확인", null)
            .show()
    }

    private fun showSavePresetDialog() {
        val input = EditText(this).apply {
            hint = "프리셋 이름 입력"
            setSingleLine(true)
        }
        AlertDialog.Builder(this)
            .setTitle("현재 키워드 프리셋 저장")
            .setView(input)
            .setPositiveButton("저장") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    val preset = KeywordPreset(name, keywords.toList())
                    presets.add(preset)
                    presetAdapter.notifyItemInserted(presets.size - 1)
                    PrefsManager.savePresets(this, presets)
                    Toast.makeText(this, "'$name' 저장됨", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun showEditPresetDialog(position: Int) {
        val preset = presets[position]
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val etName = EditText(this).apply {
            setText(preset.name)
            hint = "프리셋 이름"
        }
        val etKw = EditText(this).apply {
            setText(preset.keywords.joinToString(", "))
            hint = "키워드 (쉼표 구분)"
        }
        layout.addView(etName)
        layout.addView(etKw)

        AlertDialog.Builder(this)
            .setTitle("프리셋 수정")
            .setView(layout)
            .setPositiveButton("저장") { _, _ ->
                val newName = etName.text.toString().trim()
                val newKw = etKw.text.toString().split(",")
                    .map { it.trim() }
                    .filter { it.isNotEmpty() }
                if (newName.isNotEmpty()) {
                    presets[position] = KeywordPreset(newName, newKw)
                    presetAdapter.notifyItemChanged(position)
                    PrefsManager.savePresets(this, presets)
                }
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun showDeletePresetDialog(position: Int) {
        val preset = presets[position]
        AlertDialog.Builder(this)
            .setTitle("프리셋 삭제")
            .setMessage("'${preset.name}' 프리셋을 삭제하시겠습니까?")
            .setPositiveButton("삭제") { _, _ ->
                presets.removeAt(position)
                presetAdapter.notifyItemRemoved(position)
                PrefsManager.savePresets(this, presets)
            }
            .setNegativeButton("취소", null)
            .show()
    }

    private fun exportLog() {
        val logContent = LogBuffer.read(this)
        if (logContent.isEmpty()) {
            Toast.makeText(this, "저장된 로그가 없습니다", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val logDir = File(filesDir, "logs").apply { mkdirs() }
            val exportFile = File(logDir, "smart_notice_log.txt")
            exportFile.writeText(logContent)

            val uri = FileProvider.getUriForFile(
                this,
                "$packageName.fileprovider",
                exportFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(shareIntent, "로그 공유"))
        } catch (e: Exception) {
            Toast.makeText(this, "로그 내보내기 실패: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}
