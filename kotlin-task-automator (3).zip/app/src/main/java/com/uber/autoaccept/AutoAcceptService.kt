package com.uber.autoaccept

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.MediaStore
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import rikka.shizuku.Shizuku
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class AutoAcceptService : AccessibilityService() {

    companion object {
        private const val TAG = "AutoAcceptService"
        val ACCEPT_BUTTON_TEXTS = listOf("콜 수락", "수락", "Accept", "ACCEPT")
        val DISMISS_BUTTON_TEXTS = listOf("뒤로", "닫기", "Close", "close", "×", "✕", "X")
        val AIRPORT_KEYWORDS = listOf("공항", "인천공항", "김포공항", "Airport", "제1여객터미널", "제2여객터미널", "T1", "T2")

        var isRunning: Boolean = false
            private set
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val pollHandler = Handler(Looper.getMainLooper())
    private val screenshotHandler = Handler(Looper.getMainLooper())
    private val watchdogHandler = Handler(Looper.getMainLooper())

    private val random = Random()
    private val shizukuExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    private val ocrRecognizer: TextRecognizer by lazy {
        TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
    }

    private val acceptTemplates = mutableListOf<Bitmap>()
    private val xBtnTemplates = mutableListOf<Bitmap>()

    private var lastForegroundPackage: String = ""
    private var lastDismissTime: Long = 0L
    private var lastAcceptTime: Long = 0L
    private var isAcceptingInProgress: Boolean = false
    private var isDismissingInProgress: Boolean = false
    private var lastProcessedCardBounds: Rect? = null

    private val keepWarmRunnable = object : Runnable {
        override fun run() {
            try {
                if (PrefsManager.isActive(this@AutoAcceptService)) {
                    LogBuffer.log(this@AutoAcceptService, "KeepWarm", "Service heartbeat OK")
                }
            } catch (_: Exception) {}
            pollHandler.postDelayed(this, 15000L)
        }
    }

    private val screenshotPollRunnable = object : Runnable {
        override fun run() {
            if (PrefsManager.isActive(this@AutoAcceptService) && PrefsManager.isOcrPoll(this@AutoAcceptService)) {
                doScreenshotPoll()
            }
            screenshotHandler.postDelayed(this, 1200L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isRunning = true
        LogBuffer.log(this, "Service", "접근성 서비스 연결됨")
        loadAcceptBtnTemplates()
        loadXBtnTemplates()
        pollHandler.post(keepWarmRunnable)
        screenshotHandler.post(screenshotPollRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        LogBuffer.log(this, "Service", "접근성 서비스 종료됨")
        SleepAlarmManager.stopAlarm()
        pollHandler.removeCallbacksAndMessages(null)
        screenshotHandler.removeCallbacksAndMessages(null)
        mainHandler.removeCallbacksAndMessages(null)
        watchdogHandler.removeCallbacksAndMessages(null)
    }

    override fun onInterrupt() {
        LogBuffer.log(this, "Service", "접근성 서비스 중단됨")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (!PrefsManager.isActive(this)) return

        val pkgName = event.packageName?.toString() ?: ""
        if (pkgName.isNotEmpty()) {
            updateForegroundApp(pkgName)
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        ) {
            PrefsManager.incrementEventCount(this)
            val root = rootInActiveWindow ?: return
            val source = event.source ?: root
            processWindow(root, source)
        }
    }

    private fun updateForegroundApp(pkgName: String) {
        if (lastForegroundPackage != pkgName) {
            lastForegroundPackage = pkgName
        }
    }

    private fun isTargetPackage(pkgName: String): Boolean {
        return pkgName.contains("uber") ||
                pkgName.contains("ubercab") ||
                pkgName.contains("driver") ||
                pkgName.contains("launcher")
    }

    private fun loadAcceptBtnTemplates() {
        acceptTemplates.clear()
        val templateIds = listOf(
            R.raw.accept_template_dark,
            R.raw.accept_template_dark1,
            R.raw.accept_template_dark2,
            R.raw.accept_template_light,
            R.raw.accept_template_fold5_dark
        )
        for (id in templateIds) {
            try {
                val bmp = BitmapFactory.decodeResource(resources, id)
                if (bmp != null) acceptTemplates.add(bmp)
            } catch (_: Exception) {}
        }
    }

    private fun loadXBtnTemplates() {
        xBtnTemplates.clear()
        val templateIds = listOf(
            R.raw.xbtn_template1,
            R.raw.xbtn_template2,
            R.raw.xbtn_template3,
            R.raw.xbtn_template4,
            R.raw.xbtn_template5
        )
        for (id in templateIds) {
            try {
                val bmp = BitmapFactory.decodeResource(resources, id)
                if (bmp != null) xBtnTemplates.add(bmp)
            } catch (_: Exception) {}
        }
    }

    private fun processWindow(rootNode: AccessibilityNodeInfo, sourceNode: AccessibilityNodeInfo) {
        if (isAcceptingInProgress) return

        val acceptNode = pickAcceptNode(rootNode)
        if (acceptNode != null) {
            PrefsManager.incrementCallCount(this)
            val acceptRect = Rect()
            acceptNode.getBoundsInScreen(acceptRect)
            PrefsManager.saveLastAcceptRect(this, acceptRect.left, acceptRect.top, acceptRect.right, acceptRect.bottom)

            val textList = mutableListOf<String>()
            collectAllTexts(rootNode, textList)
            val combinedText = textList.joinToString(" ")

            LogBuffer.log(this, "CallDetect", "수락 노드 발견: bounds=$acceptRect, text=$combinedText")

            val shouldAccept = evaluateDecision(combinedText)
            if (shouldAccept) {
                performAcceptFresh(acceptNode, acceptRect)
            } else if (PrefsManager.isAutoDismiss(this)) {
                performDismissFresh(rootNode, acceptRect)
            }
        }
    }

    private fun evaluateDecision(text: String): Boolean {
        if (PrefsManager.isAcceptAll(this)) {
            return true
        }

        if (PrefsManager.isAirportMode(this)) {
            return AIRPORT_KEYWORDS.any { text.contains(it, ignoreCase = true) }
        }

        val keywords = PrefsManager.getKeywords(this)
        if (keywords.isEmpty()) {
            return false
        }

        val matched = keywords.any { text.contains(it, ignoreCase = true) }

        return if (PrefsManager.isBlacklistMode(this)) {
            !matched
        } else {
            matched
        }
    }

    private fun collectAllTexts(node: AccessibilityNodeInfo?, outList: MutableList<String>) {
        if (node == null) return
        val t = node.text?.toString()
        if (!t.isNullOrBlank()) outList.add(t)
        val cd = node.contentDescription?.toString()
        if (!cd.isNullOrBlank()) outList.add(cd)

        val count = node.childCount
        for (i in 0 until count) {
            collectAllTexts(node.getChild(i), outList)
        }
    }

    private fun pickAcceptNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (btnText in ACCEPT_BUTTON_TEXTS) {
            val list = root.findAccessibilityNodeInfosByText(btnText)
            if (!list.isNullOrEmpty()) {
                for (node in list) {
                    if (node.isVisibleToUser) {
                        return node
                    }
                }
            }
        }
        return findAcceptNodeRecursive(root)
    }

    private fun findAcceptNodeRecursive(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isVisibleToUser) {
            val text = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""
            if (ACCEPT_BUTTON_TEXTS.any { text.contains(it, ignoreCase = true) || desc.contains(it, ignoreCase = true) }) {
                return node
            }
        }
        val count = node.childCount
        for (i in 0 until count) {
            val child = node.getChild(i)
            val result = findAcceptNodeRecursive(child)
            if (result != null) return result
        }
        return null
    }

    private fun performAcceptFresh(node: AccessibilityNodeInfo, rect: Rect) {
        if (isAcceptingInProgress) return
        isAcceptingInProgress = true
        PrefsManager.incrementAcceptScheduled(this)

        val delay = if (PrefsManager.isAcceptNoDelay(this)) 0L else nextHumanDelay()
        LogBuffer.log(this, "Accept", "수락 실행 예약 (delay=${delay}ms)")

        mainHandler.postDelayed({
            try {
                var clicked = false
                if (node.isClickable) {
                    clicked = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                if (!clicked) {
                    var p = node.parent
                    while (p != null) {
                        if (p.isClickable) {
                            clicked = p.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                            if (clicked) break
                        }
                        p = p.parent
                    }
                }

                val centerX = rect.centerX()
                val centerY = rect.centerY()

                if (!clicked) {
                    dispatchTapGesture(centerX.toFloat(), centerY.toFloat())
                    clicked = true
                }

                shizukuTap(centerX, centerY)

                showTapIndicator(centerX, centerY, true)
                PrefsManager.incrementAcceptCount(this)
                LogBuffer.log(this, "Accept", "수락 완료: ($centerX, $centerY)")

                if (PrefsManager.isVibration(this)) vibrate()
                if (PrefsManager.isSleepAlarm(this)) triggerSleepAlarm()
                if (PrefsManager.isAcceptScreenshot(this)) takeScreenshotAndSave()

                val intent = Intent("com.uber.autoaccept.ACCEPT_EVENT")
                sendBroadcast(intent)
            } finally {
                mainHandler.postDelayed({ isAcceptingInProgress = false }, 1000L)
            }
        }, delay)
    }

    private fun performDismissFresh(root: AccessibilityNodeInfo, cardRect: Rect) {
        val now = System.currentTimeMillis()
        val cooldown = PrefsManager.getDismissCooldownMs(this)
        if (now - lastDismissTime < cooldown || isDismissingInProgress) {
            return
        }

        isDismissingInProgress = true
        PrefsManager.incrementDismissScheduled(this)
        LogBuffer.log(this, "Dismiss", "거절 대기 ($cooldown ms)")

        mainHandler.postDelayed({
            try {
                val closeNode = findCloseNode(root)
                var dismissed = false

                if (closeNode != null) {
                    val rect = Rect()
                    closeNode.getBoundsInScreen(rect)
                    if (closeNode.isClickable) {
                        dismissed = closeNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    }
                    if (!dismissed) {
                        dispatchTapGesture(rect.centerX().toFloat(), rect.centerY().toFloat())
                        shizukuTap(rect.centerX(), rect.centerY())
                        dismissed = true
                    }
                    showTapIndicator(rect.centerX(), rect.centerY(), false)
                    PrefsManager.saveDismissDiag(this, "노드 닫기 버튼 성공: $rect")
                } else {
                    // Tap top-right of the card as standard dismiss
                    val tapX = cardRect.right - dp(32)
                    val tapY = cardRect.top + dp(32)
                    dispatchTapGesture(tapX.toFloat(), tapY.toFloat())
                    shizukuTap(tapX, tapY)
                    showTapIndicator(tapX, tapY, false)
                    PrefsManager.saveDismissDiag(this, "상단 우측 좌표 탭 성공: ($tapX, $tapY)")
                    dismissed = true
                }

                if (dismissed) {
                    lastDismissTime = System.currentTimeMillis()
                    PrefsManager.incrementDismissExecuted(this)
                    PrefsManager.incrementDismissCount(this)
                    LogBuffer.log(this, "Dismiss", "거절 완료")
                }
            } finally {
                mainHandler.postDelayed({ isDismissingInProgress = false }, 500L)
            }
        }, cooldown)
    }

    private fun findCloseNode(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (txt in DISMISS_BUTTON_TEXTS) {
            val list = root.findAccessibilityNodeInfosByText(txt)
            if (!list.isNullOrEmpty()) {
                for (node in list) {
                    if (node.isVisibleToUser) return node
                }
            }
        }
        return findCloseNodeRecursive(root)
    }

    private fun findCloseNodeRecursive(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isVisibleToUser) {
            val desc = node.contentDescription?.toString() ?: ""
            val text = node.text?.toString() ?: ""
            if (DISMISS_BUTTON_TEXTS.any { desc.contains(it, ignoreCase = true) || text.contains(it, ignoreCase = true) }) {
                return node
            }
        }
        val count = node.childCount
        for (i in 0 until count) {
            val child = node.getChild(i)
            val result = findCloseNodeRecursive(child)
            if (result != null) return result
        }
        return null
    }

    private fun doScreenshotPoll() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        if (isAcceptingInProgress || isDismissingInProgress) return

        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            applicationContext.mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    val bitmap = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
                        ?.copy(Bitmap.Config.ARGB_8888, true)
                    screenshot.hardwareBuffer.close()
                    if (bitmap != null) {
                        processScreenshotOcr(bitmap)
                    }
                }

                override fun onFailure(errorCode: Int) {
                    Log.w(TAG, "스크린샷 캡처 실패: $errorCode")
                }
            }
        )
    }

    private fun processScreenshotOcr(bitmap: Bitmap) {
        val inputImage = InputImage.fromBitmap(bitmap, 0)
        ocrRecognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                val fullText = visionText.text
                if (fullText.isNotBlank()) {
                    val hasAccept = ACCEPT_BUTTON_TEXTS.any { fullText.contains(it, ignoreCase = true) }
                    if (hasAccept) {
                        LogBuffer.log(this, "OCR", "OCR로 콜 화면 감지됨: ${fullText.replace("\n", " ")}")
                        val shouldAccept = evaluateDecision(fullText)
                        if (shouldAccept) {
                            // Find accept text block for coordinates
                            var targetRect = Rect(bitmap.width / 4, bitmap.height * 3 / 4, bitmap.width * 3 / 4, bitmap.height * 9 / 10)
                            for (block in visionText.textBlocks) {
                                if (ACCEPT_BUTTON_TEXTS.any { block.text.contains(it, ignoreCase = true) }) {
                                    block.boundingBox?.let { targetRect = it }
                                    break
                                }
                            }
                            performAcceptFreshCoordinates(targetRect)
                        } else if (PrefsManager.isAutoDismiss(this)) {
                            performDismissFreshCoordinates(bitmap)
                        }
                    }
                }
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "OCR 분석 오류: ${e.message}")
            }
    }

    private fun performAcceptFreshCoordinates(rect: Rect) {
        if (isAcceptingInProgress) return
        isAcceptingInProgress = true
        PrefsManager.incrementAcceptScheduled(this)

        val delay = if (PrefsManager.isAcceptNoDelay(this)) 0L else nextHumanDelay()
        mainHandler.postDelayed({
            try {
                val cx = rect.centerX().toFloat()
                val cy = rect.centerY().toFloat()
                dispatchTapGesture(cx, cy)
                shizukuTap(rect.centerX(), rect.centerY())
                showTapIndicator(rect.centerX(), rect.centerY(), true)
                PrefsManager.incrementAcceptCount(this)
                if (PrefsManager.isVibration(this)) vibrate()
                if (PrefsManager.isSleepAlarm(this)) triggerSleepAlarm()

                val intent = Intent("com.uber.autoaccept.ACCEPT_EVENT")
                sendBroadcast(intent)
            } finally {
                mainHandler.postDelayed({ isAcceptingInProgress = false }, 1000L)
            }
        }, delay)
    }

    private fun performDismissFreshCoordinates(bitmap: Bitmap) {
        val now = System.currentTimeMillis()
        val cooldown = PrefsManager.getDismissCooldownMs(this)
        if (now - lastDismissTime < cooldown || isDismissingInProgress) return

        isDismissingInProgress = true
        PrefsManager.incrementDismissScheduled(this)

        mainHandler.postDelayed({
            try {
                val tapX = bitmap.width - dp(40)
                val tapY = dp(120)
                dispatchTapGesture(tapX.toFloat(), tapY.toFloat())
                shizukuTap(tapX, tapY)
                showTapIndicator(tapX, tapY, false)
                lastDismissTime = System.currentTimeMillis()
                PrefsManager.incrementDismissExecuted(this)
                PrefsManager.incrementDismissCount(this)
            } finally {
                mainHandler.postDelayed({ isDismissingInProgress = false }, 500L)
            }
        }, cooldown)
    }

    private fun dispatchTapGesture(x: Float, y: Float) {
        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }

    private fun shizukuTap(x: Int, y: Int): Boolean {
        return try {
            if (Shizuku.pingBinder()) {
                shizukuExecutor.execute {
                    try {
                        val method = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
                        method.isAccessible = true
                        val process = method.invoke(null, arrayOf("input", "tap", x.toString(), y.toString()), null, null) as? Process
                        process?.waitFor()
                    } catch (_: Exception) {}
                }
                true
            } else false
        } catch (_: Throwable) {
            false
        }
    }

    private fun showTapIndicator(x: Int, y: Int, isAccept: Boolean) {
        mainHandler.post {
            try {
                val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val size = dp(48)
                val view = View(this).apply {
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(if (isAccept) Color.parseColor("#4406C167") else Color.parseColor("#44FF5252"))
                        setStroke(dp(2), if (isAccept) Color.parseColor("#06C167") else Color.parseColor("#FF5252"))
                    }
                }

                val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    @Suppress("DEPRECATION")
                    WindowManager.LayoutParams.TYPE_PHONE
                }

                val params = WindowManager.LayoutParams(
                    size,
                    size,
                    layoutType,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.START
                    this.x = x - size / 2
                    this.y = y - size / 2
                }

                wm.addView(view, params)
                mainHandler.postDelayed({
                    try {
                        wm.removeView(view)
                    } catch (_: Exception) {}
                }, 400L)
            } catch (_: Exception) {}
        }
    }

    private fun nextHumanDelay(): Long {
        if (!PrefsManager.isHumanMode(this)) return 0L
        val min = PrefsManager.getMinDelayMs(this)
        val max = PrefsManager.getMaxDelayMs(this)
        return gaussianDelay(min, max, 100L, 5000L)
    }

    private fun gaussianDelay(minMs: Long, maxMs: Long, floorMs: Long, ceilMs: Long): Long {
        if (maxMs <= minMs) return minMs
        val mean = (minMs + maxMs) / 2.0
        val stdDev = (maxMs - minMs) / 4.0
        val sample = mean + random.nextGaussian() * stdDev
        return sample.toLong().coerceIn(floorMs, ceilMs)
    }

    private fun vibrate() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    v?.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    v?.vibrate(150)
                }
            }
        } catch (_: Exception) {}
    }

    private fun triggerSleepAlarm() {
        try {
            SleepAlarmManager.startAlarm(this)
        } catch (_: Exception) {}
    }

    private fun takeScreenshotAndSave() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        takeScreenshot(
            Display.DEFAULT_DISPLAY,
            applicationContext.mainExecutor,
            object : TakeScreenshotCallback {
                override fun onSuccess(screenshot: ScreenshotResult) {
                    val bitmap = Bitmap.wrapHardwareBuffer(screenshot.hardwareBuffer, screenshot.colorSpace)
                        ?.copy(Bitmap.Config.ARGB_8888, true)
                    screenshot.hardwareBuffer.close()
                    if (bitmap != null) {
                        saveAcceptScreenshotToGallery(bitmap)
                    }
                }
                override fun onFailure(errorCode: Int) {}
            }
        )
    }

    private fun saveAcceptScreenshotToGallery(bitmap: Bitmap) {
        try {
            val sdf = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.KOREA)
            val fileName = "ACCEPT_${sdf.format(Date())}.jpg"

            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_DCIM}/스마트알림")
                }
            }

            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
                }
                LogBuffer.log(this, "Screenshot", "스크린샷 저장됨: $fileName")
            }
        } catch (e: Exception) {
            Log.e(TAG, "스크린샷 저장 오류: ${e.message}")
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
