package com.uber.autoaccept

import android.graphics.Bitmap
import android.graphics.Rect
import android.os.SystemClock
import android.util.Log
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * 하이브리드 X 좌표 검증 모듈 (Diagnostic & Benchmark Validator)
 *
 * 1. Accessibility X Node 직접 검출 (1순위 reference)
 * 2. cardBounds 기반 상대좌표 계산 (relativeX=0.8934, relativeY=0.1186)
 * 3. Bitmap 우상단 ROI 기반 Grayscale + 정규화 + Sobel Edge + 대각선 교차 피크 검출
 * 4. 3가지 방식 간의 픽셀 오차 및 정밀 타이밍(Nanos/Us), 주간/야간 모드 비교 로그 출력
 */
object XCoordinateValidator {

    private const val TAG = "XCoordinateValidator"
    private val callCounter = AtomicInteger(0)

    enum class MapMode {
        DAY, NIGHT, UNKNOWN
    }

    data class ValidationResult(
        val callNumber: Int,
        val nodeCoord: Pair<Int, Int>?,
        val relativeCoord: Pair<Int, Int>?,
        val edgeCoord: Pair<Int, Int>?,
        val edgeScore: Double,
        val mapMode: MapMode,
        val cardBounds: Rect?,
        val nodeBounds: Rect?,
        val roiRect: Rect?,
        val diffNodeVsRelative: Double?,
        val diffNodeVsEdge: Double?,
        val diffRelativeVsEdge: Double?,
        val cardDetectedMs: Long,
        val cardBoundsMs: Long,
        val relativeCalcUs: Long,
        val bitmapRoiUs: Long,
        val edgeDetectUs: Long,
        val totalUs: Long,
        val blockedReason: String? = null
    )

    /**
     * 콜카드 발생 시 3가지 좌표를 측정 및 교차검증하고 정밀 로그를 기록합니다.
     */
    fun validateXCoordinates(
        service: AutoAcceptService,
        root: AccessibilityNodeInfo?,
        cardBounds: Rect?,
        acceptRect: Rect?,
        bitmap: Bitmap?,
        cardDetectedTimestampMs: Long = System.currentTimeMillis()
    ): ValidationResult {
        val totalStartNano = SystemClock.elapsedRealtimeNanos()
        val currentCallNum = callCounter.incrementAndGet()
        val displayMetrics = service.resources.displayMetrics
        val screenW = displayMetrics.widthPixels
        val screenH = displayMetrics.heightPixels

        var cardBoundsStartNano = 0L
        var cardBoundsEndNano = 0L
        var relativeStartNano = 0L
        var relativeEndNano = 0L
        var bitmapRoiStartNano = 0L
        var bitmapRoiEndNano = 0L
        var edgeDetectStartNano = 0L
        var edgeDetectEndNano = 0L

        // 1. [1순위] Accessibility X Node 검출
        var nodeCoord: Pair<Int, Int>? = null
        var nodeBounds: Rect? = null
        if (root != null) {
            val aRect = acceptRect ?: Rect(0, (screenH * 0.75f).toInt(), screenW, screenH)
            val xNode = findValidatedXNode(root, aRect, cardBounds)
            if (xNode != null) {
                val nr = Rect()
                xNode.getBoundsInScreen(nr)
                nodeBounds = Rect(nr)
                val cx = nr.centerX()
                val cy = nr.centerY()
                nodeCoord = Pair(cx, cy)
                try { xNode.recycle() } catch (_: Throwable) {}

                LogBuffer.diag(service, "X-NODE-FOUND", "viewId=${nr}\nclass=${nr}")
                LogBuffer.diag(service, "X-NODE-BOUNDS", "left=${nr.left}\ntop=${nr.top}\nright=${nr.right}\nbottom=${nr.bottom}\nwidth=${nr.width()}\nheight=${nr.height()}")
                LogBuffer.diag(service, "X-NODE-CENTER", "x=$cx\ny=$cy")
            }
        }

        // 2. [2순위] cardBounds 유효성 및 상대좌표 계산
        cardBoundsStartNano = SystemClock.elapsedRealtimeNanos()
        val validCardBounds = if (cardBounds != null && isValidBounds(cardBounds, screenW, screenH)) {
            cardBounds
        } else if (root != null) {
            val aRect = acceptRect ?: Rect(0, (screenH * 0.75f).toInt(), screenW, screenH)
            service.findOverlayCard(root, aRect)?.takeIf { isValidBounds(it, screenW, screenH) }
        } else {
            null
        }
        cardBoundsEndNano = SystemClock.elapsedRealtimeNanos()

        var relativeCoord: Pair<Int, Int>? = null
        var relCalcX = 0
        var relCalcY = 0
        if (validCardBounds != null) {
            relativeStartNano = SystemClock.elapsedRealtimeNanos()
            val relX = 0.8934f
            val relY = 0.1186f
            relCalcX = (validCardBounds.left + validCardBounds.width() * relX).roundToInt()
            relCalcY = (validCardBounds.top + validCardBounds.height() * relY).roundToInt()
            relativeCoord = Pair(relCalcX, relCalcY)
            relativeEndNano = SystemClock.elapsedRealtimeNanos()

            LogBuffer.diag(
                service,
                "X-CARD-BOUNDS",
                "left=${validCardBounds.left}\n" +
                "top=${validCardBounds.top}\n" +
                "right=${validCardBounds.right}\n" +
                "bottom=${validCardBounds.bottom}\n" +
                "width=${validCardBounds.width()}\n" +
                "height=${validCardBounds.height()}"
            )

            LogBuffer.diag(
                service,
                "X-RELATIVE-COORD",
                "relativeX=0.8934\n" +
                "relativeY=0.1186\n" +
                "x=$relCalcX\n" +
                "y=$relCalcY"
            )
        }

        // 3. [3순위] Bitmap ROI X 검출 (Grayscale + 정규화 + Sobel Edge + 대각선 교차 피크)
        var edgeCoord: Pair<Int, Int>? = null
        var edgeScore = 0.0
        var mapMode = MapMode.UNKNOWN
        var roiRect: Rect? = null
        var edgeFailReason: String? = null

        if (bitmap != null && !bitmap.isRecycled && validCardBounds != null) {
            bitmapRoiStartNano = SystemClock.elapsedRealtimeNanos()
            // ROI 영역: 카드 우상단 (가로 68%~100%, 세로 상단 -30px ~ +28%)
            val roiL = (validCardBounds.left + validCardBounds.width() * 0.68f).toInt().coerceIn(0, bitmap.width - 20)
            val roiR = (validCardBounds.right + 20).coerceIn(roiL + 20, bitmap.width)
            val roiT = (validCardBounds.top - 20).coerceIn(0, bitmap.height - 20)
            val roiB = (validCardBounds.top + validCardBounds.height() * 0.28f).toInt().coerceIn(roiT + 20, bitmap.height)
            val rRect = Rect(roiL, roiT, roiR, roiB)
            roiRect = rRect
            bitmapRoiEndNano = SystemClock.elapsedRealtimeNanos()

            edgeDetectStartNano = SystemClock.elapsedRealtimeNanos()
            val detectResult = detectXFromRoiBitmap(bitmap, rRect)
            edgeDetectEndNano = SystemClock.elapsedRealtimeNanos()

            if (detectResult != null) {
                edgeCoord = detectResult.coord
                edgeScore = detectResult.score
                mapMode = detectResult.mode

                LogBuffer.diag(service, "X-MODE", "mode=${mapMode.name}")
                LogBuffer.diag(service, "X-EDGE-SCORE", "score=${String.format(Locale.US, "%.2f", edgeScore)}")
                LogBuffer.diag(
                    service,
                    "X-EDGE-DETECTED",
                    "x=${edgeCoord.first}\n" +
                    "y=${edgeCoord.second}\n" +
                    "score=${String.format(Locale.US, "%.2f", edgeScore)}\n" +
                    "roiLeft=${rRect.left}\n" +
                    "roiTop=${rRect.top}\n" +
                    "roiWidth=${rRect.width()}\n" +
                    "roiHeight=${rRect.height()}"
                )
            } else {
                edgeFailReason = "EDGE_PATTERN_CONFIDENCE_LOW"
                LogBuffer.diag(service, "X-EDGE-FAILED", "reason=$edgeFailReason")
            }
        } else if (validCardBounds == null) {
            edgeFailReason = "NO_VALID_CARD_BOUNDS_FOR_ROI"
            LogBuffer.diag(service, "X-EDGE-FAILED", "reason=$edgeFailReason")
        } else {
            edgeFailReason = "BITMAP_NULL_OR_RECYCLED"
            LogBuffer.diag(service, "X-EDGE-FAILED", "reason=$edgeFailReason")
        }

        // 4. [4순위] 비교 로그 출력 및 오차 계산
        val nodeStr = if (nodeCoord != null) "(${nodeCoord.first},${nodeCoord.second})" else "null"
        val relStr = if (relativeCoord != null) "(${relativeCoord.first},${relativeCoord.second})" else "null"
        val edgeStr = if (edgeCoord != null) "(${edgeCoord.first},${edgeCoord.second})" else "null"

        LogBuffer.diag(
            service,
            "X-COORD-COMPARE",
            "node=$nodeStr\nrelative=$relStr\nedge=$edgeStr"
        )

        var diffNodeVsRelative: Double? = null
        var diffNodeVsEdge: Double? = null
        var diffRelativeVsEdge: Double? = null

        if (nodeCoord != null && relativeCoord != null) {
            diffNodeVsRelative = calculateDistance(nodeCoord, relativeCoord)
        }
        if (nodeCoord != null && edgeCoord != null) {
            diffNodeVsEdge = calculateDistance(nodeCoord, edgeCoord)
        }
        if (relativeCoord != null && edgeCoord != null) {
            diffRelativeVsEdge = calculateDistance(relativeCoord, edgeCoord)
        }

        LogBuffer.diag(
            service,
            "X-DIFF",
            "node_vs_relative=${diffNodeVsRelative?.let { String.format(Locale.US, "%.1f px", it) } ?: "null"}\n" +
            "node_vs_edge=${diffNodeVsEdge?.let { String.format(Locale.US, "%.1f px", it) } ?: "null"}\n" +
            "relative_vs_edge=${diffRelativeVsEdge?.let { String.format(Locale.US, "%.1f px", it) } ?: "null"}"
        )

        // 5. [5순위] 안전 진단 및 터치 차단 여부 판정
        var blockedReason: String? = null
        when {
            validCardBounds == null -> {
                blockedReason = "NO_VALID_CARD_BOUNDS"
            }
            !isValidBounds(validCardBounds, screenW, screenH) -> {
                blockedReason = "ABNORMAL_CARD_SIZE"
            }
            relativeCoord != null && (relativeCoord.first !in 0..screenW || relativeCoord.second !in 0..screenH) -> {
                blockedReason = "RELATIVE_COORD_OUT_OF_SCREEN"
            }
            edgeCoord != null && (edgeCoord.first !in 0..screenW || edgeCoord.second !in 0..screenH) -> {
                blockedReason = "EDGE_COORD_OUT_OF_SCREEN"
            }
            diffRelativeVsEdge != null && diffRelativeVsEdge > 120.0 -> {
                blockedReason = "LARGE_DIFF_BETWEEN_RELATIVE_AND_EDGE (${diffRelativeVsEdge.toInt()}px)"
            }
        }

        if (blockedReason != null) {
            LogBuffer.diag(service, "X-TOUCH-BLOCKED", "reason=$blockedReason")
        }

        // 7. [7순위] 성능 측정 타이밍
        val totalEndNano = SystemClock.elapsedRealtimeNanos()
        val totalUs = (totalEndNano - totalStartNano) / 1000L
        val cardDetectedMs = System.currentTimeMillis() - cardDetectedTimestampMs
        val cardBoundsMs = if (cardBoundsEndNano > cardBoundsStartNano) (cardBoundsEndNano - cardBoundsStartNano) / 1_000_000L else 0L
        val relativeCalcUs = if (relativeEndNano > relativeStartNano) (relativeEndNano - relativeStartNano) / 1000L else 0L
        val bitmapRoiUs = if (bitmapRoiEndNano > bitmapRoiStartNano) (bitmapRoiEndNano - bitmapRoiStartNano) / 1000L else 0L
        val edgeDetectUs = if (edgeDetectEndNano > edgeDetectStartNano) (edgeDetectEndNano - edgeDetectStartNano) / 1000L else 0L

        LogBuffer.diag(
            service,
            "X-TIMING",
            "cardDetectedMs=$cardDetectedMs\n" +
            "cardBoundsMs=$cardBoundsMs\n" +
            "relativeCalcUs=$relativeCalcUs\n" +
            "bitmapRoiUs=$bitmapRoiUs\n" +
            "edgeDetectUs=$edgeDetectUs\n" +
            "totalUs=$totalUs"
        )

        // 10. [10순위] 콜 요약 로그 포맷
        val totalElapsedMs = String.format(Locale.US, "%.2f", totalUs / 1000.0)
        val summaryLog = """
            |━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
            |CALL #$currentCallNum
            |Node X = $nodeStr
            |Relative X = $relStr
            |Edge X = $edgeStr
            |Node↔Relative diff = ${diffNodeVsRelative?.let { String.format(Locale.US, "%.1f px", it) } ?: "null"}
            |Node↔Edge diff = ${diffNodeVsEdge?.let { String.format(Locale.US, "%.1f px", it) } ?: "null"}
            |Relative↔Edge diff = ${diffRelativeVsEdge?.let { String.format(Locale.US, "%.1f px", it) } ?: "null"}
            |Edge score = ${String.format(Locale.US, "%.2f", edgeScore)} (Mode: ${mapMode.name})
            |Detection time = $totalElapsedMs ms
            |Blocked Reason = ${blockedReason ?: "NONE (READY)"}
            |━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        """.trimMargin()
        LogBuffer.log(service, TAG, summaryLog)
        Log.i(TAG, summaryLog)

        return ValidationResult(
            callNumber = currentCallNum,
            nodeCoord = nodeCoord,
            relativeCoord = relativeCoord,
            edgeCoord = edgeCoord,
            edgeScore = edgeScore,
            mapMode = mapMode,
            cardBounds = validCardBounds,
            nodeBounds = nodeBounds,
            roiRect = roiRect,
            diffNodeVsRelative = diffNodeVsRelative,
            diffNodeVsEdge = diffNodeVsEdge,
            diffRelativeVsEdge = diffRelativeVsEdge,
            cardDetectedMs = cardDetectedMs,
            cardBoundsMs = cardBoundsMs,
            relativeCalcUs = relativeCalcUs,
            bitmapRoiUs = bitmapRoiUs,
            edgeDetectUs = edgeDetectUs,
            totalUs = totalUs,
            blockedReason = blockedReason
        )
    }

    private fun calculateDistance(p1: Pair<Int, Int>, p2: Pair<Int, Int>): Double {
        val dx = (p1.first - p2.first).toDouble()
        val dy = (p1.second - p2.second).toDouble()
        return sqrt(dx * dx + dy * dy)
    }

    private fun isValidBounds(bounds: Rect, screenW: Int, screenH: Int): Boolean {
        if (bounds.isEmpty) return false
        val w = bounds.width()
        val h = bounds.height()
        if (w < 250 || h < 150) return false
        if (bounds.left <= 0 && bounds.right >= screenW) return false
        if (bounds.top <= 0 && bounds.bottom >= screenH) return false
        return true
    }

    private fun findValidatedXNode(root: AccessibilityNodeInfo, acceptRect: Rect, cardBounds: Rect?): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var bestNode: AccessibilityNodeInfo? = null
        var bestScore = -1

        while (queue.isNotEmpty()) {
            val node = queue.removeFirst()
            val nr = Rect()
            node.getBoundsInScreen(nr)
            val w = nr.width()
            val h = nr.height()
            val cls = node.className?.toString() ?: ""
            val vid = node.viewIdResourceName ?: ""
            val txt = "${node.text ?: ""} ${node.contentDescription ?: ""}".trim()

            val isAccept = txt.contains("수락") || txt.contains("콜")
            val isMapMarker = vid.contains("marker", ignoreCase = true) || cls.contains("Map", ignoreCase = true)

            if (!isAccept && !isMapMarker && w in 20..220 && h in 20..220) {
                var valid = true
                if (cardBounds != null) {
                    val isInside = nr.left >= cardBounds.left && nr.right <= cardBounds.right &&
                            nr.top >= cardBounds.top && nr.bottom <= cardBounds.bottom
                    val maxTop = cardBounds.top + (cardBounds.height() * 0.35f)
                    val minLeft = cardBounds.left + (cardBounds.width() * 0.60f)
                    if (!isInside || nr.top > maxTop || nr.left < minLeft) {
                        valid = false
                    }
                } else if (nr.top > acceptRect.top - 100) {
                    valid = false
                }

                if (valid) {
                    val score = (acceptRect.top - nr.centerY()) + (nr.right * 5)
                    if (score > bestScore) {
                        bestScore = score
                        if (bestNode != null && bestNode != root) {
                            try { bestNode.recycle() } catch (_: Throwable) {}
                        }
                        bestNode = node
                    }
                }
            }

            for (i in 0 until node.childCount) {
                node.getChild(i)?.let { queue.add(it) }
            }
            if (node != root && node != bestNode) {
                try { node.recycle() } catch (_: Throwable) {}
            }
        }
        return bestNode
    }

    private data class EdgeDetectionResult(
        val coord: Pair<Int, Int>,
        val score: Double,
        val mode: MapMode
    )

    /**
     * ROI Bitmap 내에서 Grayscale + 정규화 + Sobel 엣지 + 대각선 교차 피크 검출
     */
    private fun detectXFromRoiBitmap(bitmap: Bitmap, roi: Rect): EdgeDetectionResult? {
        val rw = roi.width()
        val rh = roi.height()
        if (rw < 30 || rh < 30) return null

        val pixels = IntArray(rw * rh)
        try {
            bitmap.getPixels(pixels, 0, rw, roi.left, roi.top, rw, rh)
        } catch (e: Throwable) {
            Log.w(TAG, "getPixels failed: ${e.message}")
            return null
        }

        // 1. Grayscale & 평균 밝기 측정 (주간/야간 모드 감지)
        val gray = IntArray(rw * rh)
        var sumLum = 0L
        var minLum = 255
        var maxLum = 0

        for (i in pixels.indices) {
            val p = pixels[i]
            val r = (p shr 16) and 0xFF
            val g = (p shr 8) and 0xFF
            val b = p and 0xFF
            val lum = (0.299 * r + 0.587 * g + 0.114 * b).toInt()
            gray[i] = lum
            sumLum += lum
            if (lum < minLum) minLum = lum
            if (lum > maxLum) maxLum = lum
        }

        val avgLum = sumLum / (rw * rh)
        val mapMode = when {
            avgLum >= 120 -> MapMode.DAY
            avgLum < 120 -> MapMode.NIGHT
            else -> MapMode.UNKNOWN
        }

        // 2. 밝기 정규화 (Min-Max contrast stretch)
        val range = (maxLum - minLum).coerceAtLeast(1)
        val norm = FloatArray(rw * rh)
        for (i in gray.indices) {
            norm[i] = ((gray[i] - minLum) * 255.0f / range)
        }

        // 3. Sobel Edge Detection (3x3 Kernel)
        val edge = FloatArray(rw * rh)
        for (y in 1 until rh - 1) {
            val yOffset = y * rw
            for (x in 1 until rw - 1) {
                val p00 = norm[(y - 1) * rw + (x - 1)]
                val p01 = norm[(y - 1) * rw + x]
                val p02 = norm[(y - 1) * rw + (x + 1)]
                val p10 = norm[yOffset + (x - 1)]
                val p12 = norm[yOffset + (x + 1)]
                val p20 = norm[(y + 1) * rw + (x - 1)]
                val p21 = norm[(y + 1) * rw + x]
                val p22 = norm[(y + 1) * rw + (x + 1)]

                val gx = (p02 + 2 * p12 + p22) - (p00 + 2 * p10 + p20)
                val gy = (p20 + 2 * p21 + p22) - (p00 + 2 * p01 + p02)
                edge[yOffset + x] = abs(gx) + abs(gy)
            }
        }

        // 4. X 대각선 교차 구조 검출 (+45° 및 -45° 대각선 correlation)
        // X 아이콘 크기: 약 12~24px 반경
        val rRadius = 9
        var maxPeakScore = 0.0
        var bestPx = -1
        var bestPy = -1

        for (y in rRadius until rh - rRadius step 2) {
            val yOffset = y * rw
            for (x in rRadius until rw - rRadius step 2) {
                var diag1Sum = 0.0 // \ 방향
                var diag2Sum = 0.0 // / 방향

                for (d in -rRadius..rRadius) {
                    diag1Sum += edge[(y + d) * rw + (x + d)]
                    diag2Sum += edge[(y + d) * rw + (x - d)]
                }

                // 두 대각선 모두 엣지가 뚜렷하고 교차할 때 높은 피크 형성
                val crossScore = sqrt(diag1Sum * diag2Sum)
                if (crossScore > maxPeakScore) {
                    maxPeakScore = crossScore
                    bestPx = x
                    bestPy = y
                }
            }
        }

        if (bestPx >= 0 && bestPy >= 0 && maxPeakScore >= 120.0) {
            val absX = roi.left + bestPx
            val absY = roi.top + bestPy
            return EdgeDetectionResult(
                coord = Pair(absX, absY),
                score = maxPeakScore,
                mode = mapMode
            )
        }

        return null
    }
}
